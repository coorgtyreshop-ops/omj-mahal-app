import os
import uuid
import bcrypt
import jwt
from datetime import datetime, timezone, timedelta
from fastapi import HTTPException, Request, Depends
from motor.motor_asyncio import AsyncIOMotorClient

client = AsyncIOMotorClient(os.environ["MONGO_URL"])
db = client[os.environ["DB_NAME"]]

JWT_ALGORITHM = "HS256"
NO_ID = {"_id": 0}


def new_id() -> str:
    return str(uuid.uuid4())


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def current_month() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m")


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


def create_access_token(user_id: str, role: str) -> str:
    payload = {
        "sub": user_id,
        "role": role,
        "type": "access",
        "exp": datetime.now(timezone.utc) + timedelta(days=7),
    }
    return jwt.encode(payload, os.environ["JWT_SECRET"], algorithm=JWT_ALGORITHM)


async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, os.environ["JWT_SECRET"], algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    if payload.get("type") != "access":
        raise HTTPException(status_code=401, detail="Invalid token type")
    user = await db.users.find_one({"id": payload["sub"]}, {"_id": 0, "password_hash": 0})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


async def require_admin(user: dict = Depends(get_current_user)) -> dict:
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


async def can_finance(user: dict) -> bool:
    if user.get("role") == "admin":
        return True
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "finance_manager_id": 1}) or {}
    manager = s.get("finance_manager_id")
    return bool(manager) and user["id"] == manager


async def ledger_scope(user: dict) -> str:
    """all = admin/treasurer; salath = appointed Salath committee member; none = read-only."""
    if await can_finance(user):
        return "all"
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "salath_manager_ids": 1}) or {}
    return "salath" if user["id"] in (s.get("salath_manager_ids") or []) else "none"


async def require_finance(user: dict = Depends(get_current_user)) -> dict:
    if not await can_finance(user):
        raise HTTPException(status_code=403, detail="Only the appointed treasurer can manage collections")
    return user


async def next_receipt_no(kind: str) -> str:
    settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    prefix = settings.get("receipt_prefix", "RCT")
    if kind == "donation":
        prefix = settings.get("donation_prefix", "DON")
    counter = await db.counters.find_one_and_update(
        {"key": kind}, {"$inc": {"seq": 1}}, upsert=True, return_document=True
    )
    return f"{prefix}-{counter['seq']:05d}"


def months_between(start: str, end: str) -> list:
    sy, sm = map(int, start.split("-"))
    ey, em = map(int, end.split("-"))
    out = []
    y, m = sy, sm
    while (y, m) <= (ey, em):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m > 12:
            m = 1
            y += 1
    return out


async def house_units(house: dict) -> dict:
    """Dues are charged per paying member: head + every second member (working man 18+). Students / women / children pay nothing."""
    from routes.houses import classify
    subs = 0
    async for m in db.members.find({"house_id": house["id"]}, {"_id": 0, "name": 1, "relation": 1, "dob": 1, "gender": 1, "status": 1}):
        if classify(m, house)["member_type"] == "sub":
            subs += 1
    return {"units": 1 + subs, "sub": subs}


def member_filter(member_id):
    """member_id=None → whole house; 'head' → payments not tagged to a sub-member; else that member's own payments."""
    if member_id is None:
        return {}
    if member_id == "head":
        return {"$and": [{"$or": [{"member_id": {"$exists": False}}, {"member_id": None}, {"member_id": ""}]}]}
    return {"member_id": member_id}


async def house_dues(house: dict, member_id=None) -> dict:
    """Amount-based monthly dues (× paying members): any partial amount reduces the balance; months are covered in order.
    With member_id the share of one paying member (1 unit, his own payments) is returned."""
    start = house.get("start_month") or current_month()
    all_months = months_between(start, current_month())
    units = 1 if member_id else (await house_units(house))["units"]
    rate = float(house.get("subscription_amount", 0) or 0) * units
    paid_amount = 0.0
    async for p in db.payments.find({"house_id": house["id"], "$or": [{"type": "varisankhya"}, {"type": {"$exists": False}}], **member_filter(member_id)}, {"_id": 0, "amount": 1}):
        paid_amount += float(p.get("amount", 0) or 0)
    covered = int(paid_amount // rate) if rate > 0 else len(all_months)
    paid_months = all_months[:covered]
    pending = all_months[covered:] if rate > 0 else []
    due = len(all_months) * rate
    return {
        "pending_months": pending,
        "pending_count": len(pending),
        "pending_amount": max(0.0, due - paid_amount),
        "paid_months": paid_months,
        "paid_amount": paid_amount,
        "due_amount": due,
        "advance": max(0.0, paid_amount - due),
    }
