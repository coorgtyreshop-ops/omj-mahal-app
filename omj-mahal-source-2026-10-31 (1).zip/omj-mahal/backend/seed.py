import os
import random
from datetime import datetime, timezone, timedelta
from core import db, new_id, now_iso, hash_password, months_between, current_month
from routes.content import DEFAULT_SETTINGS

HOUSES = [
    ("H-01", "Abdul Rahman K", "Kunnumpuram, Near Juma Masjid", "Ward 1", "9847000001", 150),
    ("H-02", "Muhammed Ashraf P", "Puthiyapurayil House", "Ward 1", "9847000002", 100),
    ("H-03", "Ibrahim Kutty", "Thottathil House, Bypass Road", "Ward 2", "9847000003", 100),
    ("H-04", "Hamza Musliyar", "Madrasa Road", "Ward 2", "9847000004", 200),
    ("H-05", "Salim Haji", "Palliyalil House", "Ward 3", "9847000005", 250),
    ("H-06", "Noushad M", "Chembankulam", "Ward 3", "9847000006", 100),
    ("H-07", "Yusuf Ali", "Kannanthodi House", "Ward 4", "9847000007", 100),
    ("H-08", "Shafeeq Rahman", "Mannil House, Market Road", "Ward 4", "9847000008", 150),
]

MEMBERS = {
    "H-01": [("Abdul Rahman K", "Self", "1965-03-12", "male", "Business", "married", "SSLC", "O+"),
             ("Khadeeja", "Wife", "1970-07-01", "female", "Homemaker", "married", "Plus Two", "A+"),
             ("Fathima Rahman", "Daughter", "1998-11-22", "female", "Teacher", "married", "B.Ed", "B+"),
             ("Muhammed Riyas", "Son", "2004-05-15", "male", "Student", "single", "B.Tech", "O+")],
    "H-02": [("Muhammed Ashraf P", "Self", "1978-01-20", "male", "Driver", "married", "SSLC", "A+"),
             ("Sainaba", "Wife", "1982-09-09", "female", "Tailor", "married", "SSLC", "AB+"),
             ("Ayisha", "Daughter", "2010-02-14", "female", "Student", "single", "Class 10", "")],
    "H-03": [("Ibrahim Kutty", "Self", "1958-06-30", "male", "Retired", "married", "Class 8", "B-"),
             ("Nafeesa", "Wife", "1962-12-05", "female", "Homemaker", "married", "Class 7", "O+"),
             ("Shameer", "Son", "1988-04-18", "male", "Gulf - Electrician", "married", "ITI", "O+"),
             ("Rasheeda", "Daughter-in-law", "1992-08-25", "female", "Homemaker", "married", "Degree", "A+")],
    "H-04": [("Hamza Musliyar", "Self", "1970-10-10", "male", "Madrasa Teacher", "married", "Faizy", "A+"),
             ("Ruqiya", "Wife", "1975-03-03", "female", "Homemaker", "married", "Plus Two", "B+"),
             ("Anas", "Son", "2001-01-01", "male", "Student", "single", "Hafiz", "A+")],
    "H-05": [("Salim Haji", "Self", "1955-02-02", "male", "Business", "married", "Degree", "O-"),
             ("Zainaba Haji", "Wife", "1960-05-20", "female", "Homemaker", "married", "SSLC", "B+"),
             ("Dr. Nazeer", "Son", "1985-07-07", "male", "Doctor", "married", "MBBS", "O+"),
             ("Dr. Shahina", "Daughter-in-law", "1988-09-19", "female", "Doctor", "married", "MBBS", "A+"),
             ("Aamina", "Granddaughter", "2016-06-06", "female", "Student", "single", "Class 4", "")],
    "H-06": [("Noushad M", "Self", "1983-08-08", "male", "Auto Driver", "married", "Plus Two", "B+"),
             ("Shahida", "Wife", "1987-11-11", "female", "Homemaker", "married", "Degree", "O+")],
    "H-07": [("Yusuf Ali", "Self", "1975-04-04", "male", "Mason", "married", "Class 9", "AB-"),
             ("Jameela", "Wife", "1979-01-17", "female", "Homemaker", "married", "SSLC", "A+"),
             ("Shabeer", "Son", "2002-12-12", "male", "Student", "single", "B.Com", "A+"),
             ("Shabna", "Daughter", "2006-03-30", "female", "Student", "single", "Plus Two", "B+")],
    "H-08": [("Shafeeq Rahman", "Self", "1990-09-09", "male", "IT Engineer", "married", "B.Tech", "O+"),
             ("Hafsa", "Wife", "1994-04-24", "female", "Bank Employee", "married", "MBA", "A-")],
}

COMMITTEE = [
    ("Salim Haji", "President", "9847000005"),
    ("Abdul Rahman K", "Secretary", "9847000001"),
    ("Shafeeq Rahman", "Treasurer", "9847000008"),
    ("Hamza Musliyar", "Vice President", "9847000004"),
    ("Ibrahim Kutty", "Joint Secretary", "9847000003"),
    ("Yusuf Ali", "Executive Member", "9847000007"),
]

EXPENSE_CATS = ["salary", "electricity", "maintenance", "madrasa", "water", "other"]


def shift_month(ym: str, delta: int) -> str:
    y, m = map(int, ym.split("-"))
    idx = y * 12 + (m - 1) + delta
    return f"{idx // 12:04d}-{idx % 12 + 1:02d}"


async def seed_admin():
    phone = os.environ["ADMIN_PHONE"]
    password = os.environ["ADMIN_PASSWORD"]
    existing = await db.users.find_one({"phone": phone})
    if existing is None:
        await db.users.insert_one({
            "id": new_id(), "phone": phone, "name": "Admin", "role": "admin", "login_id": "ADMIN-001",
            "house_id": None, "language": "en",
            "password_hash": hash_password(password), "created_at": now_iso(),
        })
        await db.counters.update_one({"key": "admin_login"}, {"$max": {"seq": 1}}, upsert=True)


async def ensure_login_ids():
    """Every admin/committee account gets an ADMIN-xxx login ID (members use their Member ID)."""
    async for u in db.users.find({"role": "admin", "$or": [{"login_id": {"$exists": False}}, {"login_id": ""}]}, {"_id": 0, "id": 1}):
        c = await db.counters.find_one_and_update({"key": "admin_login"}, {"$inc": {"seq": 1}}, upsert=True, return_document=True)
        await db.users.update_one({"id": u["id"]}, {"$set": {"login_id": f"ADMIN-{c['seq']:03d}"}})


STATUS_BY_OCC = {"Student": "student", "Homemaker": "homemaker", "Retired": "retired"}


async def ensure_member_numbers():
    """Backfill member_no / status / short_name for data created before membership cards existed."""
    s = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    fixes = {k: v for k, v in DEFAULT_SETTINGS.items() if k not in s and k != "key"}
    if not s.get("short_name"):
        fixes["short_name"] = "OMJ Mahal"
    if fixes:
        await db.settings.update_one({"key": "main"}, {"$set": fixes}, upsert=True)
    prefix = (s.get("member_prefix") or fixes.get("member_prefix") or "OMJ").strip()
    missing = await db.members.find({"$or": [{"member_no": {"$exists": False}}, {"member_no": ""}]}, {"_id": 0, "id": 1, "house_id": 1, "relation": 1, "occupation": 1}).to_list(50000)
    if not missing:
        return
    houses = {h["id"]: h.get("house_no", "") for h in await db.houses.find({}, {"_id": 0, "id": 1, "house_no": 1}).to_list(50000)}
    missing.sort(key=lambda m: (houses.get(m["house_id"], ""), 0 if m.get("relation") == "Self" else 1))
    for m in missing:
        counter = await db.counters.find_one_and_update({"key": "member"}, {"$inc": {"seq": 1}}, upsert=True, return_document=True)
        status = STATUS_BY_OCC.get(m.get("occupation", ""), "working" if m.get("occupation") else "")
        await db.members.update_one({"id": m["id"]}, {"$set": {"member_no": f"{prefix}-{counter['seq']:04d}", "status": status, "photo_url": ""}})


async def seed_demo():
    if await db.houses.count_documents({}) > 0:
        return
    random.seed(7)
    cm = current_month()
    start = shift_month(cm, -5)
    if not await db.settings.find_one({"key": "main"}):
        await db.settings.insert_one({**DEFAULT_SETTINGS, "mahal_name": "Ontiyangadi Muslim Jamaath",
                                      "mahal_name_ml": "ഒന്റിയങ്ങാടി മുസ്ലിം ജമാഅത്ത്", "mahal_name_kn": "ಒಂಟಿಯಂಗಾಡಿ ಮುಸ್ಲಿಂ ಜಮಾಅತ್",
                                      "address": "Ontiyangadi", "phone": "04832 000000", "short_name": "OMJ Mahal", "member_prefix": "OMJ",
                                      "registration_no": "",
                                      "president_name": "Salim Haji", "secretary_name": "Abdul Rahman K"})
    house_ids = {}
    for hn, head, addr, ward, phone, amt in HOUSES:
        hid = new_id()
        house_ids[hn] = hid
        await db.houses.insert_one({
            "id": hid, "house_no": hn, "head_name": head, "address": addr, "ward": ward, "phone": phone,
            "whatsapp": phone, "subscription_amount": amt, "start_month": start, "created_at": now_iso(),
        })
        for name, rel, dob, gender, occ, ms, edu, bg in MEMBERS[hn]:
            await db.members.insert_one({
                "id": new_id(), "house_id": hid, "name": name, "relation": rel, "dob": dob, "gender": gender,
                "occupation": occ, "marital_status": ms, "education": edu, "blood_group": bg, "phone": "",
                "status": STATUS_BY_OCC.get(occ, "working"), "photo_url": "", "created_at": now_iso(),
            })
    seq = 0
    all_months = months_between(start, cm)
    for hn, head, addr, ward, phone, amt in HOUSES:
        paid_upto = len(all_months) - random.choice([0, 0, 1, 2, 3])
        i = 0
        while i < paid_upto:
            n = min(random.choice([1, 1, 2, 3]), paid_upto - i)
            months = all_months[i:i + n]
            seq += 1
            await db.payments.insert_one({
                "id": new_id(), "receipt_no": f"RCT-{seq:05d}", "house_id": house_ids[hn], "months": months,
                "amount": amt * n, "mode": random.choice(["cash", "upi", "cash", "bank"]),
                "date": f"{months[-1]}-{random.randint(1, 25):02d}", "note": "", "created_by": "Admin", "created_at": now_iso(),
            })
            i += n
    await db.counters.update_one({"key": "subscription"}, {"$set": {"seq": seq}}, upsert=True)
    funds = [
        ("Masjid Renovation Fund", "Renovation of the main prayer hall and roof repair", 1500000),
        ("Ramadan Relief Fund", "Food kits for needy families during Ramadan", 200000),
        ("Madrasa Building Fund", "New classrooms for the madrasa", 800000),
    ]
    fund_ids = []
    for name, desc, target in funds:
        fid = new_id()
        fund_ids.append(fid)
        await db.funds.insert_one({"id": fid, "name": name, "description": desc, "target": target, "active": True, "created_at": now_iso()})
    dseq = 0
    for _ in range(14):
        hn = random.choice(HOUSES)
        dseq += 1
        await db.donations.insert_one({
            "id": new_id(), "receipt_no": f"DON-{dseq:05d}", "fund_id": random.choice(fund_ids), "donor_name": hn[1],
            "house_id": house_ids[hn[0]], "amount": random.choice([500, 1000, 2500, 5000, 10000, 25000]),
            "mode": random.choice(["cash", "upi", "bank"]), "date": f"{random.choice(all_months)}-{random.randint(1, 28):02d}",
            "note": "", "created_by": "Admin", "created_at": now_iso(),
        })
    await db.counters.update_one({"key": "donation"}, {"$set": {"seq": dseq}}, upsert=True)
    for m in all_months:
        await db.expenses.insert_one({"id": new_id(), "category": "salary", "amount": 12000, "date": f"{m}-05", "description": "Imam & Muadhin salary", "mode": "bank", "paid_to": "Staff", "created_by": "Admin", "created_at": now_iso()})
        await db.expenses.insert_one({"id": new_id(), "category": "electricity", "amount": random.randint(1800, 3200), "date": f"{m}-12", "description": "KSEB bill", "mode": "upi", "paid_to": "KSEB", "created_by": "Admin", "created_at": now_iso()})
        if random.random() > 0.5:
            await db.expenses.insert_one({"id": new_id(), "category": random.choice(["maintenance", "madrasa", "water", "other"]), "amount": random.randint(500, 6000), "date": f"{m}-{random.randint(15, 27):02d}", "description": "Misc", "mode": "cash", "paid_to": "", "created_by": "Admin", "created_at": now_iso()})
    today = datetime.now(timezone.utc)
    anns = [
        ("Monthly General Body Meeting", "All members are requested to attend the general body meeting after Isha prayer on Friday at the Masjid hall. Agenda: renovation fund progress and annual accounts.", "meeting", 1),
        ("Janazah - Late Kunhi Moideen Haji", "Inna lillahi wa inna ilaihi raji'un. Kunhi Moideen Haji (Ward 2) passed away this morning. Janazah prayer after Dhuhr at Juma Masjid. Please make dua.", "janazah", 2),
        ("Ramadan Relief Kit Distribution", "Relief kits will be distributed to registered families on Sunday 10 AM at the Madrasa. Bring your Mahal ID.", "event", 5),
        ("Varisankhya Reminder", "Members with pending monthly subscription are requested to clear dues before the end of this month. Contact the treasurer for details.", "general", 9),
    ]
    for title, content, cat, days_ago in anns:
        await db.announcements.insert_one({
            "id": new_id(), "title": title, "content": content, "category": cat,
            "date": (today - timedelta(days=days_ago)).strftime("%Y-%m-%d"), "image_url": "",
            "created_by": "Admin", "created_at": now_iso(),
        })
    for i, (name, desig, phone) in enumerate(COMMITTEE):
        await db.committee.insert_one({"id": new_id(), "name": name, "designation": desig, "phone": phone,
                                       "term_start": "2024-04-01", "term_end": "2027-03-31", "order": i, "created_at": now_iso()})
    if not await db.users.find_one({"phone": "8888888888"}):
        await db.users.insert_one({
            "id": new_id(), "phone": "8888888888", "name": "Abdul Rahman K", "role": "member",
            "house_id": house_ids["H-01"], "language": "ml",
            "password_hash": hash_password("member123"), "created_at": now_iso(),
        })
