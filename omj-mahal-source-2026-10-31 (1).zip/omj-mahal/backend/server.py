from pathlib import Path
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

import os
import asyncio
import logging
from datetime import datetime, timezone
from fastapi import FastAPI, APIRouter
from starlette.middleware.cors import CORSMiddleware
from core import client, db
from routes.auth_routes import router as auth_router, users_router
from routes.houses import router as houses_router
from routes.finance import router as finance_router
from routes.content import router as content_router
from routes.notifications import router as notifications_router, auto_reminder_loop
from routes.files import router as files_router
from routes.public import router as public_router
from routes.collections import router as collections_router
from routes.events import router as events_router, event_notify_loop
from routes.ledger import router as ledger_router
from routes.chat import router as chat_router
from routes.suggestions import router as suggestions_router
from routes.backup import router as backup_router, backup_loop
from routes.assistant import router as assistant_router
from storage import init_storage
from seed import seed_admin, ensure_member_numbers, ensure_login_ids

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(title="Mahal App API")
api_router = APIRouter(prefix="/api")


@api_router.get("/")
async def root():
    return {"message": "Mahal App API"}


BUILD_ID = os.environ.get("BUILD_ID") or datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")


@api_router.get("/version")
async def version():
    """Changes on every backend start/deploy — the app uses it to drop stale caches on old phones."""
    return {"build": BUILD_ID}


api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(houses_router)
api_router.include_router(finance_router)
api_router.include_router(content_router)
api_router.include_router(notifications_router)
api_router.include_router(files_router)
api_router.include_router(public_router)
api_router.include_router(collections_router)
api_router.include_router(events_router)
api_router.include_router(ledger_router)
api_router.include_router(chat_router)
api_router.include_router(suggestions_router)
api_router.include_router(backup_router)
api_router.include_router(assistant_router)
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    await db.users.create_index("phone", unique=True)
    await db.houses.create_index("house_no", unique=True)
    await db.members.create_index("house_id")
    await db.payments.create_index("house_id")
    await db.payments.create_index("months")
    await db.donations.create_index("fund_id")
    await db.members.create_index("member_no")
    await db.otps.create_index("phone")
    await db.users.create_index("login_id", sparse=True)
    await db.login_attempts.create_index("key")
    await db.book_entries.create_index("book_id")
    await db.chat_messages.create_index("created_at")
    await seed_admin()
    await ensure_member_numbers()
    await ensure_login_ids()
    asyncio.create_task(auto_reminder_loop())
    asyncio.create_task(event_notify_loop())
    asyncio.create_task(backup_loop())
    try:
        init_storage()
        logger.info("Storage initialized")
    except Exception as exc:
        logger.error("Storage init failed: %s", exc)
    logger.info("Startup complete")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
