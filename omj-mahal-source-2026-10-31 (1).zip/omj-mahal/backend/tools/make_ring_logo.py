import math
import numpy as np
from PIL import Image, ImageDraw, ImageFont

SRC = "/app/frontend/public/logos/logo1.png"
FONTS = "/app/frontend/public/logos/fonts"
DARK = (9, 70, 44)
GOLD = (212, 175, 55)
SIZE = 1024


def text_strip(text, font, fill):
    bbox = font.getbbox(text)
    w, h = bbox[2] - bbox[0] + 8, bbox[3] - bbox[1] + 8
    strip = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(strip).text((4 - bbox[0], 4 - bbox[1]), text, font=font, fill=fill)
    return strip


def arc_text(img, text, font, center, r_mid, center_deg, fill=GOLD, flip=False):
    """Warp a rendered text strip along a circular arc (keeps complex-script shaping intact)."""
    strip = text_strip(text, font, fill)
    W, H = strip.size
    src = np.array(strip)
    span = W / r_mid
    r_outer, r_inner = r_mid + H / 2, r_mid - H / 2
    N = img.size[0]
    ys, xs = np.mgrid[0:N, 0:N]
    dx, dy = xs - center[0], ys - center[1]
    rr = np.hypot(dx, dy)
    theta = np.arctan2(dx, -dy)  # 0 at top, clockwise positive
    if flip:
        theta = np.arctan2(dx, dy)  # 0 at bottom, positive to the right → reads left→right
    start = math.radians(center_deg) - span / 2
    rel = (theta - start) % (2 * math.pi)
    inside = (rr >= r_inner) & (rr <= r_outer) & (rel <= span)
    sx = np.clip((rel / span * W).astype(int), 0, W - 1)
    if flip:
        sy = np.clip(((rr - r_inner) / (r_outer - r_inner) * H).astype(int), 0, H - 1)
    else:
        sy = np.clip(((r_outer - rr) / (r_outer - r_inner) * H).astype(int), 0, H - 1)
    dst = np.array(img)
    sampled = src[sy, sx]
    alpha = (sampled[..., 3:4] / 255.0) * inside[..., None]
    dst[..., :3] = (dst[..., :3] * (1 - alpha) + sampled[..., :3] * alpha).astype(np.uint8)
    dst[..., 3] = np.maximum(dst[..., 3], (alpha[..., 0] * 255).astype(np.uint8))
    return Image.fromarray(dst)


def star(draw, x, y, size=20):
    pts = []
    for i in range(10):
        rr = size if i % 2 == 0 else size * 0.42
        aa = math.radians(i * 36 - 90)
        pts.append((x + rr * math.cos(aa), y + rr * math.sin(aa)))
    draw.polygon(pts, fill=GOLD)


def build(text_top, text_bottom, font_path, out, top_size, bottom_size, star_deg=132):
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = (SIZE / 2, SIZE / 2)
    d.ellipse([6, 6, SIZE - 6, SIZE - 6], fill=GOLD)
    d.ellipse([22, 22, SIZE - 22, SIZE - 22], fill=DARK)
    inner_r = 335
    d.ellipse([c[0] - inner_r - 10, c[1] - inner_r - 10, c[0] + inner_r + 10, c[1] + inner_r + 10], fill=GOLD)
    logo = Image.open(SRC).convert("RGBA").resize((inner_r * 2, inner_r * 2), Image.LANCZOS)
    mask = Image.new("L", logo.size, 0)
    ImageDraw.Draw(mask).ellipse([0, 0, logo.size[0] - 1, logo.size[1] - 1], fill=255)
    img.paste(logo, (int(c[0] - inner_r), int(c[1] - inner_r)), mask)
    ft, fb = ImageFont.truetype(font_path, top_size), ImageFont.truetype(font_path, bottom_size)
    for f in (ft, fb):
        try:
            f.set_variation_by_name("Bold")
        except Exception:
            pass
    r = 430
    img = arc_text(img, text_top, ft, c, r, 0)
    img = arc_text(img, text_bottom, fb, c, r, 0, flip=True)
    d = ImageDraw.Draw(img)
    for ang in (-star_deg, star_deg):
        a = math.radians(ang)
        star(d, c[0] + r * math.sin(a), c[1] - r * math.cos(a))
    img.convert("RGB").resize((512, 512), Image.LANCZOS).save(out)
    print("saved", out)


build("ONTIYANGADI MUSLIM JAMAATH", "COMMITTEE", f"{FONTS}/Cinzel-Bold.ttf", "/app/frontend/public/logos/logo4.png", 72, 66)
