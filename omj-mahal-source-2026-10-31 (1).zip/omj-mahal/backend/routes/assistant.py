import os
import logging
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from core import db, new_id, now_iso, get_current_user

router = APIRouter(prefix="/assistant", tags=["assistant"])
logger = logging.getLogger("assistant")

LANG_NAMES = {"ml": "Malayalam", "kn": "Kannada", "en": "English"}
ACTIONS = ("polish", "translate", "draft")


class ComposeIn(BaseModel):
    text: str
    language: str = "ml"
    action: str = "polish"
    purpose: str = "message"


def _key() -> str:
    key = os.environ.get("EMERGENT_LLM_KEY", "").strip()
    if not key:
        raise HTTPException(status_code=503, detail="AI key not configured")
    return key


@router.post("/transcribe")
async def transcribe(file: UploadFile = File(...), language: str = Form(""), user: dict = Depends(get_current_user)):
    """Voice → text (OpenAI whisper-1). Malayalam / Kannada / English speech."""
    from emergentintegrations.llm.openai import OpenAISpeechToText
    raw = await file.read()
    if not raw or len(raw) > 25 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Audio missing or too large (25 MB max)")
    ext = (file.filename or "voice.webm").rsplit(".", 1)[-1].lower()
    ext = ext if ext in ("webm", "mp3", "mp4", "m4a", "wav", "mpeg", "mpga", "ogg") else "webm"
    path = f"/tmp/{new_id()}.{ext}"
    with open(path, "wb") as fh:
        fh.write(raw)
    try:
        stt = OpenAISpeechToText(api_key=_key())
        with open(path, "rb") as fh:
            hint = f"Speech in {LANG_NAMES.get(language, 'Malayalam or Kannada')} about a mosque Mahal committee, dues, receipts and programmes."
            res = await stt.transcribe(file=fh, model="whisper-1", response_format="json", prompt=hint)
        return {"text": (getattr(res, "text", None) or "").strip()}
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Transcription failed: %s", exc)
        raise HTTPException(status_code=400, detail=f"Transcription failed: {str(exc)[:200]}")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


@router.post("/compose")
async def compose(body: ComposeIn, user: dict = Depends(get_current_user)):
    """AI helper: fix spelling/grammar, translate (ML ⇄ KN ⇄ EN) or draft a respectful committee message."""
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    text = body.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Text is required")
    if body.action not in ACTIONS:
        raise HTTPException(status_code=400, detail="Invalid action")
    lang = LANG_NAMES.get(body.language, "Malayalam")
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "mahal_name": 1, "short_name": 1}) or {}
    mahal = s.get("short_name") or s.get("mahal_name") or "Mahal"
    system = (f"You are the writing assistant of {mahal}, a mosque (Mahal) committee in Kerala/Karnataka, India. "
              f"You help the committee write short, respectful {body.purpose}s to Muslim community members. "
              f"Always write in {lang} script. Keep amounts (₹), dates, names, phone numbers and IDs exactly as given. "
              "Do not add explanations, options or quotes — return ONLY the final text.")
    task = {
        "polish": f"Correct the spelling, grammar and wording of this {lang} text written by a committee member (it may contain transliteration or speech-to-text mistakes). Keep the meaning and length; make it polite and clear. Output in {lang}:\n\n{text}",
        "translate": f"Translate this text into {lang}, respectfully and naturally (as a mosque committee would write to members). Output only the {lang} translation:\n\n{text}",
        "draft": f"Write a short, polite {lang} {body.purpose} to Mahal members based on these notes. Start with 'Assalamu Alaikum' in {lang} script. Notes:\n\n{text}",
    }[body.action]
    try:
        chat = LlmChat(api_key=_key(), session_id=f"assist-{user['id']}-{new_id()[:8]}", system_message=system).with_model("openai", "gpt-5.4-mini")
        out = await chat.send_message(UserMessage(text=task))
    except Exception as exc:
        logger.warning("AI compose failed: %s", exc)
        raise HTTPException(status_code=400, detail=f"AI failed: {str(exc)[:200]}")
    result = (out or "").strip().strip('"')
    await db.ai_log.insert_one({"id": new_id(), "user_id": user["id"], "action": body.action, "language": body.language, "input": text[:2000], "output": result[:4000], "created_at": now_iso()})
    return {"text": result, "language": body.language, "action": body.action}
