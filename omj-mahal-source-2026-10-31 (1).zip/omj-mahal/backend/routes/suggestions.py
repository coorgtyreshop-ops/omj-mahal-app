from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel
from core import db, new_id, now_iso, get_current_user, require_admin

router = APIRouter(prefix="/suggestions", tags=["suggestions"])
KINDS = ("feature", "issue", "other")
STATUSES = ("new", "planned", "done", "declined")


class SuggestionIn(BaseModel):
    title: str
    details: str = ""
    kind: str = "feature"


class StatusIn(BaseModel):
    status: str
    reply: str = ""


@router.get("")
async def list_suggestions(user: dict = Depends(get_current_user)):
    query = {} if user.get("role") == "admin" else {"user_id": user["id"]}
    return await db.suggestions.find(query, {"_id": 0}).sort("created_at", -1).to_list(500)


@router.post("", status_code=201)
async def add_suggestion(body: SuggestionIn, background: BackgroundTasks, user: dict = Depends(get_current_user)):
    title = body.title.strip()
    if not title:
        raise HTTPException(status_code=400, detail="Title is required")
    if body.kind not in KINDS:
        raise HTTPException(status_code=400, detail="Invalid kind")
    house = await db.houses.find_one({"id": user["house_id"]}, {"_id": 0, "house_no": 1}) if user.get("house_id") else None
    doc = {"id": new_id(), "title": title[:200], "details": body.details.strip()[:3000], "kind": body.kind, "status": "new", "reply": "",
           "user_id": user["id"], "name": user.get("name", ""), "house_no": (house or {}).get("house_no", ""), "created_at": now_iso()}
    await db.suggestions.insert_one(doc)
    doc.pop("_id", None)
    if user.get("role") != "admin":
        background.add_task(alert_admins, doc)
    return doc


async def alert_admins(doc: dict):
    """Queue a WhatsApp note to every admin so member messages are never missed."""
    from messaging import send_message, with_salaam
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "notify_language": 1}) or {}
    who = doc.get("name", "") + (f" (വീട് {doc['house_no']})" if doc.get("house_no") else "")
    text = f"അംഗം {who} കമ്മിറ്റിക്ക് ഒരു സന്ദേശം അയച്ചു:\n\"{doc['title']}\"" + (f"\n{doc['details']}" if doc.get("details") else "") + "\nApp → ഡാഷ്‌ബോർഡ് / നിർദ്ദേശങ്ങൾ പേജിൽ കാണാം."
    async for admin in db.users.find({"role": "admin", "phone": {"$nin": [None, ""]}}, {"_id": 0, "name": 1, "phone": 1}):
        try:
            await send_message(admin["phone"], with_salaam(admin.get("name", ""), text, respectful=False, settings=s), "whatsapp", "suggestion", doc["id"], admin.get("name", ""))
        except Exception:
            pass


@router.put("/{sid}/status")
async def set_status(sid: str, body: StatusIn, _: dict = Depends(require_admin)):
    if body.status not in STATUSES:
        raise HTTPException(status_code=400, detail="Invalid status")
    res = await db.suggestions.update_one({"id": sid}, {"$set": {"status": body.status, "reply": body.reply.strip(), "updated_at": now_iso()}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Not found")
    return await db.suggestions.find_one({"id": sid}, {"_id": 0})


@router.delete("/{sid}")
async def delete_suggestion(sid: str, user: dict = Depends(get_current_user)):
    row = await db.suggestions.find_one({"id": sid}, {"_id": 0})
    if not row:
        raise HTTPException(status_code=404, detail="Not found")
    if row["user_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Not allowed")
    await db.suggestions.delete_one({"id": sid})
    return {"ok": True}
