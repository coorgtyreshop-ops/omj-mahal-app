from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from core import db, new_id, now_iso, get_current_user, require_admin, ledger_scope

router = APIRouter(prefix="/ledger", tags=["ledger"])

COMMITTEES = ("main", "salath", "rent")
INCOME_CATS = ("donation", "kind", "tin", "auction", "rent", "other")
EXPENSE_CATS = ("food", "guest", "sound", "decoration", "printing", "transport", "rent", "maintenance", "electricity", "other")


class BookIn(BaseModel):
    name: str
    name_ml: str = ""
    committee: str = "main"
    date: str = ""
    month: str = ""
    event_id: Optional[str] = None
    note: str = ""


class EntryIn(BaseModel):
    kind: str
    category: str
    party: str = ""
    house_id: Optional[str] = None
    amount: float = 0
    qty: float = 0
    unit: str = ""
    date: str = ""
    note: str = ""


class ManagerIn(BaseModel):
    user_id: str
    on: bool = True


async def require_write(user: dict, committee: str):
    scope = await ledger_scope(user)
    if scope == "all" or (scope == "salath" and committee == "salath"):
        return
    raise HTTPException(status_code=403, detail="You are not allowed to edit these accounts")


def validate_entry(body: EntryIn):
    if body.kind not in ("income", "expense"):
        raise HTTPException(status_code=400, detail="Invalid entry kind")
    cats = INCOME_CATS if body.kind == "income" else EXPENSE_CATS
    if body.category not in cats:
        raise HTTPException(status_code=400, detail="Invalid category")
    if body.amount < 0 or body.qty < 0:
        raise HTTPException(status_code=400, detail="Amount cannot be negative")
    if body.amount == 0 and body.qty == 0:
        raise HTTPException(status_code=400, detail="Enter an amount or a quantity")


def summarize(entries: list) -> dict:
    income_by = {c: 0.0 for c in INCOME_CATS}
    expense_by = {c: 0.0 for c in EXPENSE_CATS}
    kind_items = []
    for e in entries:
        if e["kind"] == "income":
            income_by[e["category"]] = income_by.get(e["category"], 0) + e["amount"]
            if e["category"] == "kind" and e.get("qty"):
                kind_items.append({"party": e.get("party", ""), "qty": e["qty"], "unit": e.get("unit", ""), "amount": e["amount"]})
        else:
            expense_by[e["category"]] = expense_by.get(e["category"], 0) + e["amount"]
    income = sum(income_by.values())
    expense = sum(expense_by.values())
    donors = sorted({e["party"] for e in entries if e["kind"] == "income" and e.get("party")})
    return {"income": income, "expense": expense, "balance": income - expense, "income_by": income_by, "expense_by": expense_by,
            "kind_items": kind_items, "donors": len(donors), "entries": len(entries)}


async def get_book(book_id: str) -> dict:
    book = await db.books.find_one({"id": book_id}, {"_id": 0})
    if not book:
        raise HTTPException(status_code=404, detail="Account book not found")
    return book


@router.get("/meta")
async def meta(user: dict = Depends(get_current_user)):
    return {"income_categories": list(INCOME_CATS), "expense_categories": list(EXPENSE_CATS), "scope": await ledger_scope(user)}


async def readable(user: dict) -> list:
    scope = await ledger_scope(user)
    if scope == "all":
        return list(COMMITTEES)  # main, salath and room-rent books
    if scope == "salath":
        return ["salath"]
    raise HTTPException(status_code=403, detail="Accounts are visible only to the committee (President, Secretary, Treasurer)")


@router.get("/books")
async def list_books(committee: Optional[str] = None, year: Optional[int] = None, user: dict = Depends(get_current_user)):
    allowed = await readable(user)
    query = {"committee": {"$in": allowed}}
    if committee in COMMITTEES:
        if committee not in allowed:
            raise HTTPException(status_code=403, detail="Not allowed to view these accounts")
        query["committee"] = committee
    if year:
        query["$or"] = [{"date": {"$regex": f"^{year}-"}}, {"month": {"$regex": f"^{year}-"}}]
    books = await db.books.find(query, {"_id": 0}).sort([("date", -1), ("month", -1), ("created_at", -1)]).to_list(1000)
    totals = {}
    async for row in db.book_entries.aggregate([{"$group": {"_id": {"book": "$book_id", "kind": "$kind"}, "sum": {"$sum": "$amount"}, "n": {"$sum": 1}}}]):
        t = totals.setdefault(row["_id"]["book"], {"income": 0.0, "expense": 0.0, "entries": 0})
        t[row["_id"]["kind"]] = row["sum"]
        t["entries"] += row["n"]
    for b in books:
        t = totals.get(b["id"], {"income": 0.0, "expense": 0.0, "entries": 0})
        b.update({"income": t["income"], "expense": t["expense"], "balance": t["income"] - t["expense"], "entries": t["entries"]})
    return books


@router.post("/books", status_code=201)
async def create_book(body: BookIn, user: dict = Depends(get_current_user)):
    if body.committee not in COMMITTEES:
        raise HTTPException(status_code=400, detail="Invalid committee")
    if not body.name.strip():
        raise HTTPException(status_code=400, detail="Name is required")
    await require_write(user, body.committee)
    doc = body.model_dump()
    doc["name"] = doc["name"].strip()
    if doc["month"] and not doc["date"]:
        doc["date"] = f"{doc['month']}-01"
    doc.update({"id": new_id(), "created_by": user.get("name", ""), "created_at": now_iso()})
    await db.books.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.get("/books/{book_id}")
async def book_detail(book_id: str, user: dict = Depends(get_current_user)):
    book = await get_book(book_id)
    if book["committee"] not in await readable(user):
        raise HTTPException(status_code=403, detail="Not allowed to view these accounts")
    entries = await db.book_entries.find({"book_id": book_id}, {"_id": 0}).sort([("date", 1), ("created_at", 1)]).to_list(5000)
    scope = await ledger_scope(user)
    book["entries"] = entries
    book["summary"] = summarize(entries)
    book["can_edit"] = scope == "all" or (scope == "salath" and book["committee"] == "salath")
    return book


@router.put("/books/{book_id}")
async def update_book(book_id: str, body: BookIn, user: dict = Depends(get_current_user)):
    book = await get_book(book_id)
    await require_write(user, book["committee"])
    if body.committee not in COMMITTEES:
        raise HTTPException(status_code=400, detail="Invalid committee")
    update = body.model_dump()
    update["name"] = update["name"].strip()
    await db.books.update_one({"id": book_id}, {"$set": update})
    return await get_book(book_id)


@router.delete("/books/{book_id}")
async def delete_book(book_id: str, user: dict = Depends(get_current_user)):
    book = await get_book(book_id)
    await require_write(user, book["committee"])
    await db.book_entries.delete_many({"book_id": book_id})
    await db.books.delete_one({"id": book_id})
    return {"ok": True}


@router.post("/books/{book_id}/entries", status_code=201)
async def add_entry(book_id: str, body: EntryIn, user: dict = Depends(get_current_user)):
    book = await get_book(book_id)
    await require_write(user, book["committee"])
    validate_entry(body)
    doc = body.model_dump()
    doc["party"] = doc["party"].strip()
    doc["date"] = doc["date"] or book.get("date") or now_iso()[:10]
    doc.update({"id": new_id(), "book_id": book_id, "created_by": user.get("name", ""), "created_at": now_iso()})
    await db.book_entries.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.put("/entries/{entry_id}")
async def update_entry(entry_id: str, body: EntryIn, user: dict = Depends(get_current_user)):
    entry = await db.book_entries.find_one({"id": entry_id}, {"_id": 0})
    if not entry:
        raise HTTPException(status_code=404, detail="Entry not found")
    book = await get_book(entry["book_id"])
    await require_write(user, book["committee"])
    validate_entry(body)
    update = body.model_dump()
    update["party"] = update["party"].strip()
    update["date"] = update["date"] or entry["date"]
    await db.book_entries.update_one({"id": entry_id}, {"$set": update})
    return await db.book_entries.find_one({"id": entry_id}, {"_id": 0})


@router.delete("/entries/{entry_id}")
async def delete_entry(entry_id: str, user: dict = Depends(get_current_user)):
    entry = await db.book_entries.find_one({"id": entry_id}, {"_id": 0})
    if not entry:
        raise HTTPException(status_code=404, detail="Entry not found")
    book = await get_book(entry["book_id"])
    await require_write(user, book["committee"])
    await db.book_entries.delete_one({"id": entry_id})
    return {"ok": True}


@router.put("/salath-managers")
async def set_salath_manager(body: ManagerIn, _: dict = Depends(require_admin)):
    if not await db.users.find_one({"id": body.user_id}):
        raise HTTPException(status_code=404, detail="User not found")
    op = {"$addToSet" if body.on else "$pull": {"salath_manager_ids": body.user_id}}
    await db.settings.update_one({"key": "main"}, op, upsert=True)
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "salath_manager_ids": 1}) or {}
    return {"ok": True, "salath_manager_ids": s.get("salath_manager_ids", [])}
