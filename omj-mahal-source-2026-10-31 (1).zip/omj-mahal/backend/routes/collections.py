from datetime import date, datetime, timedelta, timezone
from urllib.parse import quote
import re
import unicodedata
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List
from core import db, new_id, now_iso, today, get_current_user, require_admin, require_finance, can_finance, house_dues, house_units, next_receipt_no, member_filter
from messaging import notify_house, receipt_text, send_message, with_salaam, sign, LABELS_ML, tx, label_for

router = APIRouter(prefix="/finance", tags=["finance"])

# type -> (kind, settings fee key)
COLLECTIONS = {
    "varisankhya": ("monthly", None),
    "eid_fitr": ("yearly", "fee_eid_fitr"),
    "eid_adha": ("yearly", "fee_eid_adha"),
    "nabidinam": ("yearly", "fee_nabidinam"),
    "building": ("one_time", "fee_building"),
    "special": ("one_time", "fee_special"),
    "auction": ("house", None),
    "pledge": ("house", None),
    "old_balance": ("house", None),
    "donation": ("free", None),
}
def custom_heads(settings: dict) -> list:
    """Committee-defined heads (e.g. Maidan fund, Nikah fee): [{id, name, kind: yearly|one_time, amount}]."""
    return [h for h in (settings or {}).get("custom_heads") or [] if isinstance(h, dict) and h.get("id") and h.get("name") and float(h.get("amount") or 0) > 0]


def heads(settings: dict) -> dict:
    """All collection heads in display order: fixed ones, committee-defined ones, donation last."""
    out = {k: v for k, v in COLLECTIONS.items() if k != "donation"}
    for h in custom_heads(settings):
        out[h["id"]] = ("one_time" if h.get("kind") == "one_time" else "yearly", None)
    out["donation"] = COLLECTIONS["donation"]
    return out


def head_rate(settings: dict, typ: str, key) -> float:
    if key:
        return float(settings.get(key, 0) or 0)
    return next((float(h["amount"]) for h in custom_heads(settings) if h["id"] == typ), 0.0)


FEE_KEYS = ("fee_eid_fitr", "fee_eid_adha", "fee_nabidinam", "fee_building", "fee_special", "special_name", "default_subscription", "upi_id", "upi_name", "upi_phone", "upi_app", "upi_qr_url", "bank_name", "bank_account_name", "bank_account_no", "bank_ifsc")


class FeesIn(BaseModel):
    fee_eid_fitr: float = 0
    fee_eid_adha: float = 0
    fee_nabidinam: float = 0
    fee_building: float = 0
    fee_special: float = 0
    special_name: str = ""
    default_subscription: Optional[float] = None
    upi_id: str = ""
    upi_name: str = ""
    upi_phone: str = ""
    upi_app: str = ""
    upi_qr_url: str = ""
    bank_name: str = ""
    bank_account_name: str = ""
    bank_account_no: str = ""
    bank_ifsc: str = ""
    custom_heads: List[dict] = []


class ManagerIn(BaseModel):
    user_id: Optional[str] = None


class PayRequestIn(BaseModel):
    type: str
    amount: float
    upi_ref: str = ""
    note: str = ""
    fund_id: Optional[str] = None
    months: List[str] = []
    stage: str = "submitted"  # "started" = QR shown / UPI app opened (auto), "submitted" = member confirmed payment
    years: List[str] = []


class DecisionIn(BaseModel):
    reason: str = ""


class OldBalanceIn(BaseModel):
    amount: float
    note: str = ""
    date: str = ""
    type: str = "other"


OLD_BALANCE_TYPES = ("varisankhya", "eid_fitr", "eid_adha", "nabidinam", "building", "special", "donation", "other")


def old_balance_items(house: dict) -> list:
    """Old balances per head (category). Legacy single old_balance is shown as one 'other' item."""
    items = house.get("old_balance_items")
    if items is None:
        legacy = float(house.get("old_balance", 0) or 0)
        items = [{"id": "legacy", "type": "other", "amount": legacy, "note": house.get("old_balance_note", ""), "date": house.get("old_balance_date", "")}] if legacy > 0 else []
    return items


def house_items(house: dict, typ: str) -> list:
    """Per-house dues entered by the treasurer: old_balance items, auction (lelam) items or pledges/other promised amounts."""
    if typ == "old_balance":
        return old_balance_items(house)
    return list(house.get(f"{typ}_items") or [])


async def main_settings() -> dict:
    return await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}


def years_between(start_year: int, end_year: int) -> list:
    return [str(y) for y in range(start_year, end_year + 1)]


async def house_collections(house: dict, settings: dict, member_id=None) -> dict:
    """Per-collection summary for one house: rate, due, paid, pending. member_id → one paying member's own share (1 unit, own payments)."""
    out = {}
    u = await house_units(house)
    units = 1 if member_id else u["units"]
    d = await house_dues(house, member_id)
    out["varisankhya"] = {"kind": "monthly", "rate": house.get("subscription_amount", 0) * units, "due": d["due_amount"], "paid": d["paid_amount"], "pending": d["pending_amount"],
                          "pending_periods": d["pending_months"], "paid_periods": d["paid_months"], "advance": d["advance"], "yearly_total": house.get("subscription_amount", 0) * 12 * units}
    start_year = int((house.get("start_month") or today())[:4])
    all_years = years_between(start_year, date.today().year)
    all_heads = heads(settings)
    names = {h["id"]: h["name"] for h in custom_heads(settings)}
    payments = await db.payments.find({"house_id": house["id"], "type": {"$in": [k for k in all_heads if k not in ("varisankhya", "donation")]}, **member_filter(member_id)}, {"_id": 0, "type": 1, "years": 1, "amount": 1}).to_list(5000)
    for typ, (kind, key) in all_heads.items():
        if kind == "yearly":
            rate = head_rate(settings, typ, key) * units
            paid_amt = sum(float(p.get("amount", 0) or 0) for p in payments if p["type"] == typ)
            covered = int(paid_amt // rate) if rate > 0 else len(all_years)
            paid_years, pending_years = all_years[:covered], (all_years[covered:] if rate > 0 else [])
            due = rate * len(all_years)
            out[typ] = {"kind": kind, "rate": rate, "due": due, "paid": paid_amt, "pending": max(0.0, due - paid_amt), "pending_periods": pending_years, "paid_periods": paid_years, "advance": max(0.0, paid_amt - due)}
        elif kind == "one_time":
            target = head_rate(settings, typ, key) * units
            paid = sum(p["amount"] for p in payments if p["type"] == typ)
            out[typ] = {"kind": kind, "rate": target, "due": target, "paid": paid, "pending": max(0.0, target - paid), "pending_periods": []}
            if typ == "special":
                out[typ]["name"] = settings.get("special_name") or ""
        elif kind == "house":
            items = house_items(house, typ) if member_id in (None, "head") else []
            target = sum(i["amount"] for i in items)
            paid = sum(p["amount"] for p in payments if p["type"] == typ)
            out[typ] = {"kind": "one_time", "rate": target, "due": target, "paid": paid, "pending": max(0.0, target - paid), "pending_periods": [], "items": items,
                        "note": "; ".join(f"{i['note']}" for i in items if i.get("note")), "date": house.get("old_balance_date", "") if typ == "old_balance" else max((i.get("date") or "" for i in items), default="")}
    paid_don = 0.0
    async for r in db.donations.find({"house_id": house["id"]}, {"_id": 0, "amount": 1}):
        paid_don += r["amount"]
    out["donation"] = {"kind": "free", "rate": 0, "due": 0, "paid": paid_don, "pending": 0, "pending_periods": []}
    for typ, name in names.items():
        if typ in out:
            out[typ]["label"] = name
    out["total_pending"] = sum(v.get("pending", 0) for k, v in out.items() if isinstance(v, dict))
    out["members"] = {"units": 1, "sub": 0} if member_id else u
    out["heads"] = [k for k in all_heads]
    return out


def upi_ascii(text: str, limit: int) -> str:
    """UPI apps reject payee names / notes with non-ASCII or special characters ('technical issue'). Keep A-Z, 0-9, space, dot, dash."""
    plain = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9 .\-]", "", plain).strip()[:limit]


def upi_link(settings: dict, amount: float, note: str) -> str:
    pa = (settings.get("upi_id") or "").strip()
    if not pa:
        return ""
    pn = upi_ascii(settings.get("upi_name") or settings.get("short_name") or settings.get("mahal_name") or "", 40) or "Mahal"
    tn = upi_ascii(note, 40) or "Mahal payment"
    return f"upi://pay?pa={quote(pa)}&pn={quote(pn)}&am={amount:.2f}&cu=INR&tn={quote(tn)}"


@router.get("/fees")
async def get_fees(user: dict = Depends(get_current_user)):
    s = await main_settings()
    return {**{k: s.get(k, 0 if k.startswith("fee_") or k == "default_subscription" else "") for k in FEE_KEYS}, "finance_manager_id": s.get("finance_manager_id"), "can_finance": await can_finance(user), "types": list(heads(s).keys()), "custom_heads": custom_heads(s)}


@router.put("/fees")
async def set_fees(body: FeesIn, _: dict = Depends(require_finance)):
    """Only fields actually sent are changed — a partial save never wipes bank / UPI details."""
    data = body.model_dump(exclude_unset=True)
    if "default_subscription" in data and data.get("default_subscription") is None:
        data.pop("default_subscription")
    for k in ("upi_id", "upi_phone", "bank_account_no", "bank_ifsc"):
        if isinstance(data.get(k), str):
            data[k] = data[k].strip().replace(" ", "")
    if data.get("bank_ifsc"):
        data["bank_ifsc"] = data["bank_ifsc"].upper()
    if data.get("upi_id") and ("@" not in data["upi_id"] or len(data["upi_id"].split("@")[0]) < 2):
        raise HTTPException(status_code=400, detail="UPI ID must look like name@bank (e.g. mahal@okicici)")
    clean = []
    if "custom_heads" not in data:
        clean = None
    for h in data.get("custom_heads") or []:
        name = str(h.get("name", "")).strip()
        amount = float(h.get("amount") or 0)
        if name and amount > 0:
            clean.append({"id": h.get("id") or f"c_{new_id()[:8]}", "name": name[:60], "kind": "one_time" if h.get("kind") == "one_time" else "yearly", "amount": amount})
    if clean is not None:
        data["custom_heads"] = clean
    await db.settings.update_one({"key": "main"}, {"$set": data}, upsert=True)
    return await main_settings()


@router.put("/manager")
async def set_manager(body: ManagerIn, _: dict = Depends(require_admin)):
    if body.user_id and not await db.users.find_one({"id": body.user_id}):
        raise HTTPException(status_code=404, detail="User not found")
    await db.settings.update_one({"key": "main"}, {"$set": {"finance_manager_id": body.user_id}}, upsert=True)
    return {"ok": True, "finance_manager_id": body.user_id}


@router.get("/house/{house_id}/summary")
async def house_summary(house_id: str, user: dict = Depends(get_current_user)):
    if user["role"] != "admin" and not await can_finance(user) and user.get("house_id") != house_id:
        raise HTTPException(status_code=403, detail="Not your house")
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    s = await main_settings()
    if user["role"] != "admin" and not await can_finance(user) and not house.get("statement_released"):
        return {"house": {k: house.get(k, "") for k in ("id", "house_no", "head_name")}, "released": False, "collections": None}
    mid = user.get("member_id") if user["role"] != "admin" else None
    member = await db.members.find_one({"id": mid}, {"_id": 0, "id": 1, "name": 1, "member_no": 1}) if mid else None
    return {"house": {k: house.get(k, "") for k in ("id", "house_no", "head_name", "subscription_amount", "start_month")}, "member": member, "released": bool(house.get("statement_released")), "released_at": house.get("statement_released_at", ""), "collections": await house_collections(house, s, mid), "upi_configured": bool(s.get("upi_id")), "upi_id": s.get("upi_id", ""), "upi_phone": s.get("upi_phone", ""),
            "upi_name": s.get("upi_name") or s.get("short_name") or s.get("mahal_name") or "", "upi_qr_url": s.get("upi_qr_url", ""),
            "bank": {k: s.get(k, "") for k in ("bank_name", "bank_account_name", "bank_account_no", "bank_ifsc")} if s.get("bank_account_no") else None}


@router.get("/scan/{member_no}")
async def scan_member(member_no: str, scope: str = "auto", user: dict = Depends(get_current_user)):
    """Membership-card QR scan: who this is + what he owes / paid per head, live. Committee sees every card; a member only his own house (after release)."""
    from routes.auth_routes import id_variants
    from routes.houses import classify, HEAD_LOGIN
    ident = member_no.strip().upper()
    variants = list(dict.fromkeys(id_variants(ident) + [member_no.strip()]))
    m = await db.members.find_one({"member_no": {"$in": variants}}, {"_id": 0})
    if m:
        house = await db.houses.find_one({"id": m["house_id"]}, {"_id": 0})
    else:
        house = await db.houses.find_one({"house_no": {"$in": variants}}, {"_id": 0})
        m = await db.members.find_one({"house_id": house["id"], "relation": "Self"}, {"_id": 0}) if house else None
    if not m or not house:
        raise HTTPException(status_code=404, detail="Member not found")
    privileged = await can_finance(user)
    if not privileged:
        if user.get("house_id") != house["id"]:
            raise HTTPException(status_code=403, detail="committee_only")
        if not house.get("statement_released"):
            raise HTTPException(status_code=403, detail="not_released")
    s = await main_settings()
    classify(m, house)
    mid = m["id"] if (m["member_type"] == "sub" and scope != "house") else None
    pays = await db.payments.find({"house_id": house["id"], **member_filter(mid)}, {"_id": 0, "id": 1, "date": 1, "amount": 1, "type": 1, "receipt_no": 1, "mode": 1, "member_name": 1, "months": 1, "years": 1, "note": 1}).sort([("date", -1), ("created_at", -1)]).to_list(30)
    for p in pays:
        p["type"] = p.get("type") or "varisankhya"
    login = await db.users.find_one({"member_id": m["id"]} if mid else {"house_id": house["id"], **HEAD_LOGIN}, {"_id": 0, "login_id": 1, "phone": 1})
    return {
        "member": m,
        "house": {k: house.get(k, "") for k in ("id", "house_no", "head_name", "ward", "phone", "start_month", "subscription_amount")},
        "scope": "member" if mid else "house",
        "member_since": (house.get("start_month") or house.get("created_at") or "")[:4],
        "released": bool(house.get("statement_released")),
        "has_login": bool(login),
        "collections": await house_collections(house, s, mid),
        "payments": pays,
        "last_paid": pays[0] if pays else None,
        "can_record": privileged,
        "scanned_at": now_iso(),
    }


@router.get("/overview")
async def overview(_: dict = Depends(require_finance)):
    s = await main_settings()
    rows, totals = [], {}
    for h in await db.houses.find({}, {"_id": 0}).sort("house_no", 1).to_list(5000):
        c = await house_collections(h, s)
        rows.append({"id": h["id"], "house_no": h["house_no"], "head_name": h["head_name"], "phone": h.get("phone", ""), **{k: c[k]["pending"] for k in heads(s)}, "total_pending": c["total_pending"], "old_balance_due": c["old_balance"]["due"]})
        for k in heads(s):
            totals.setdefault(k, {"pending": 0.0, "paid": 0.0})
            totals[k]["pending"] += c[k]["pending"]
            totals[k]["paid"] += c[k]["paid"]
    return {"rows": rows, "totals": totals, "pending_requests": await db.pay_requests.count_documents({"status": "pending"})}


async def save_old_balance_items(house_id: str, items: list, user: dict) -> dict:
    total = sum(i["amount"] for i in items)
    await db.houses.update_one({"id": house_id}, {"$set": {"old_balance_items": items, "old_balance": total, "old_balance_note": "; ".join(i["note"] for i in items if i.get("note")),
                                                          "old_balance_date": max((i.get("date") or "" for i in items), default=today()), "old_balance_by": user["name"]}})
    return {"ok": True, "items": items, "total": total}


@router.post("/house/{house_id}/old-balance", status_code=201)
async def add_old_balance(house_id: str, body: OldBalanceIn, user: dict = Depends(require_finance)):
    """Add a previous outstanding (arrears) item for a house — with the head/category and reason."""
    if body.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    if body.type not in OLD_BALANCE_TYPES:
        raise HTTPException(status_code=400, detail="Invalid category")
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    items = old_balance_items(house) + [{"id": new_id(), "type": body.type, "amount": body.amount, "note": body.note.strip(), "date": body.date or today(), "by": user["name"]}]
    return await save_old_balance_items(house_id, items, user)


class BulkOldBalanceRow(BaseModel):
    house_id: str
    amount: float
    type: str = "other"
    note: str = ""
    date: str = ""


class BulkOldBalanceIn(BaseModel):
    rows: List[BulkOldBalanceRow]


@router.post("/old-balance/bulk")
async def bulk_old_balance(body: BulkOldBalanceIn, user: dict = Depends(require_finance)):
    """Opening balances for many houses at once — one item per house (rows with amount 0 are skipped)."""
    added, skipped = 0, []
    for r in body.rows:
        if r.amount <= 0:
            continue
        if r.type not in OLD_BALANCE_TYPES:
            skipped.append({"house_id": r.house_id, "reason": "invalid type"})
            continue
        house = await db.houses.find_one({"id": r.house_id}, {"_id": 0})
        if not house:
            skipped.append({"house_id": r.house_id, "reason": "house not found"})
            continue
        items = old_balance_items(house) + [{"id": new_id(), "type": r.type, "amount": r.amount, "note": r.note.strip(), "date": r.date or today(), "by": user["name"]}]
        await save_old_balance_items(r.house_id, items, user)
        added += 1
    return {"ok": True, "added": added, "skipped": skipped}


@router.delete("/house/{house_id}/old-balance/{item_id}")
async def delete_old_balance(house_id: str, item_id: str, user: dict = Depends(require_finance)):
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    items = [i for i in old_balance_items(house) if i["id"] != item_id]
    return await save_old_balance_items(house_id, items, user)


@router.put("/house/{house_id}/old-balance")
async def set_old_balance(house_id: str, body: OldBalanceIn, user: dict = Depends(require_finance)):
    """Legacy: replace all old-balance items with a single one."""
    if body.amount < 0:
        raise HTTPException(status_code=400, detail="Amount must be >= 0")
    if not await db.houses.find_one({"id": house_id}):
        raise HTTPException(status_code=404, detail="House not found")
    items = [{"id": new_id(), "type": body.type if body.type in OLD_BALANCE_TYPES else "other", "amount": body.amount, "note": body.note.strip(), "date": body.date or today(), "by": user["name"]}] if body.amount > 0 else []
    return await save_old_balance_items(house_id, items, user)


# ---------- Auction (lelam) dues per house ----------
HOUSE_ITEM_HEADS = ("auction", "pledge")


@router.post("/house/{house_id}/{head}", status_code=201)
async def add_house_item(house_id: str, head: str, body: OldBalanceIn, user: dict = Depends(require_finance)):
    """Per-house promised/owed amounts: auction (lelam) wins or pledges / other gifts promised to the Mahal. Cleared via payments of that type."""
    if head not in HOUSE_ITEM_HEADS:
        raise HTTPException(status_code=404, detail="Unknown head")
    if body.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    items = house_items(house, head) + [{"id": new_id(), "type": head, "amount": body.amount, "note": body.note.strip(), "date": body.date or today(), "by": user["name"]}]
    await db.houses.update_one({"id": house_id}, {"$set": {f"{head}_items": items}})
    return {"ok": True, "items": items, "total": sum(i["amount"] for i in items)}


@router.delete("/house/{house_id}/{head}/{item_id}")
async def delete_house_item(house_id: str, head: str, item_id: str, _: dict = Depends(require_finance)):
    if head not in HOUSE_ITEM_HEADS:
        raise HTTPException(status_code=404, detail="Unknown head")
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    items = [i for i in house_items(house, head) if i["id"] != item_id]
    await db.houses.update_one({"id": house_id}, {"$set": {f"{head}_items": items}})
    return {"ok": True, "items": items, "total": sum(i["amount"] for i in items)}


@router.get("/statement")
async def yearly_statement(year: int, _: dict = Depends(require_finance)):
    """Year-end statement: per house, paid per collection in the year + pending now."""
    s = await main_settings()
    y = str(year)
    types = [k for k in heads(s) if k != "donation"]
    rows, totals = [], {k: {"paid": 0.0, "pending": 0.0} for k in types + ["donation"]}
    for h in await db.houses.find({}, {"_id": 0}).sort("house_no", 1).to_list(5000):
        c = await house_collections(h, s)
        paid = {k: 0.0 for k in types + ["donation"]}
        async for p in db.payments.find({"house_id": h["id"], "date": {"$gte": f"{y}-01-01", "$lte": f"{y}-12-31"}}, {"_id": 0, "type": 1, "amount": 1}):
            paid[p.get("type") or "varisankhya"] = paid.get(p.get("type") or "varisankhya", 0) + p["amount"]
        async for r in db.donations.find({"house_id": h["id"], "date": {"$gte": f"{y}-01-01", "$lte": f"{y}-12-31"}}, {"_id": 0, "amount": 1}):
            paid["donation"] += r["amount"]
        row = {"id": h["id"], "house_no": h["house_no"], "head_name": h["head_name"], "paid": paid, "pending": {k: c[k]["pending"] for k in types}, "total_paid": sum(paid.values()), "total_pending": c["total_pending"]}
        rows.append(row)
        for k in paid:
            totals[k]["paid"] += paid[k]
        for k in types:
            totals[k]["pending"] += c[k]["pending"]
    return {"year": year, "rows": rows, "totals": totals, "types": types}


@router.get("/report")
async def collection_report(_: dict = Depends(require_finance)):
    """Per collection head: who paid fully, who paid partly (and what is left), who paid nothing — with totals."""
    s = await main_settings()
    hd = heads(s)
    types = [k for k in hd if k != "donation"]
    rep = {k: {"kind": hd[k][0], "rate": 0, "full": [], "partial": [], "none": [], "totals": {"due": 0.0, "paid": 0.0, "pending": 0.0, "houses": 0}} for k in types}
    donors = []
    for h in await db.houses.find({}, {"_id": 0}).sort("house_no", 1).to_list(5000):
        c = await house_collections(h, s)
        base = {"id": h["id"], "house_no": h["house_no"], "head_name": h["head_name"], "phone": h.get("phone", "")}
        for k in types:
            v = c[k]
            if v["due"] <= 0 and v["paid"] <= 0:
                continue
            group = "full" if v["pending"] <= 0 else ("partial" if v["paid"] > 0 else "none")
            rep[k][group].append({**base, "due": v["due"], "paid": v["paid"], "pending": v["pending"], "periods": v.get("pending_periods", [])})
            tot = rep[k]["totals"]
            tot["due"] += v["due"]; tot["paid"] += v["paid"]; tot["pending"] += v["pending"]; tot["houses"] += 1
            rep[k]["rate"] = v.get("rate", 0)
        if c["donation"]["paid"] > 0:
            donors.append({**base, "due": 0, "paid": c["donation"]["paid"], "pending": 0, "periods": []})
    rep["donation"] = {"kind": "free", "rate": 0, "full": donors, "partial": [], "none": [], "totals": {"due": 0.0, "paid": sum(d["paid"] for d in donors), "pending": 0.0, "houses": len(donors)}}
    grand = {key: sum(rep[k]["totals"][key] for k in types) for key in ("due", "paid", "pending")}
    grand["donation"] = rep["donation"]["totals"]["paid"]
    return {"types": types + ["donation"], "report": rep, "grand": grand, "special_name": s.get("special_name") or "", "date": today()}


@router.get("/report/houses")
async def house_report(year: Optional[int] = None, _: dict = Depends(require_finance)):
    """Year-end, house-wise: every house in one of three lists (fully paid / partly paid / nothing paid) with what was received and when."""
    s = await main_settings()
    yr = year or date.today().year
    hd = heads(s)
    types = [k for k in hd if k != "donation"]
    names = {h["id"]: h["name"] for h in custom_heads(s)}
    groups = {"full": [], "partial": [], "none": []}
    totals = {"due": 0.0, "paid": 0.0, "pending": 0.0, "houses": 0, "year_received": 0.0}
    for h in await db.houses.find({}, {"_id": 0}).sort("house_no", 1).to_list(5000):
        c = await house_collections(h, s)
        due = sum(c[k]["due"] for k in types)
        paid = sum(c[k]["paid"] for k in types)
        if due <= 0 and paid <= 0:
            continue
        pending = c["total_pending"]
        pays = await db.payments.find({"house_id": h["id"], "date": {"$gte": f"{yr}-01-01", "$lte": f"{yr}-12-31"}}, {"_id": 0, "date": 1, "amount": 1, "type": 1, "receipt_no": 1}).sort("date", 1).to_list(2000)
        for p in pays:
            p["type"] = p.get("type") or "varisankhya"
        row = {"id": h["id"], "house_no": h["house_no"], "head_name": h["head_name"], "phone": h.get("phone", ""), "ward": h.get("ward", ""), "due": due, "paid": paid, "pending": pending,
               "heads": [{"type": k, "label": names.get(k, ""), "due": c[k]["due"], "paid": c[k]["paid"], "pending": c[k]["pending"]} for k in types if c[k]["due"] > 0 or c[k]["paid"] > 0],
               "payments": pays, "year_received": sum(float(p.get("amount", 0) or 0) for p in pays), "last_paid": pays[-1]["date"] if pays else ""}
        groups["full" if pending <= 0 else ("partial" if paid > 0 else "none")].append(row)
        totals["due"] += due; totals["paid"] += paid; totals["pending"] += pending; totals["houses"] += 1; totals["year_received"] += row["year_received"]
    return {"year": yr, "groups": groups, "counts": {k: len(v) for k, v in groups.items()}, "totals": totals, "date": today()}


@router.get("/notices")
async def notices(house_id: Optional[str] = None, include_all: bool = False, _: dict = Depends(require_finance)):
    """Balance notice data (per collection, with pending periods) for printing — all houses with balance, or one house.
    include_all=true also includes houses with nothing pending (year-end notice for everyone) and lists this year's payments."""
    s = await main_settings()
    q = {"id": house_id} if house_id else {}
    yr = date.today().year
    out = []
    for h in await db.houses.find(q, {"_id": 0}).sort("house_no", 1).to_list(5000):
        c = await house_collections(h, s)
        if house_id or include_all or c["total_pending"] > 0:
            pays = await db.payments.find({"house_id": h["id"], "date": {"$gte": f"{yr}-01-01", "$lte": f"{yr}-12-31"}}, {"_id": 0, "date": 1, "amount": 1, "type": 1, "receipt_no": 1}).sort("date", 1).to_list(2000)
            for p in pays:
                p["type"] = p.get("type") or "varisankhya"
            out.append({"house": {k: h.get(k, "") for k in ("id", "house_no", "head_name", "phone", "ward", "subscription_amount")}, "collections": c, "year": yr, "year_payments": pays,
                        "upi_link": upi_link(s, c["total_pending"], f"Balance {h['house_no']}") if c["total_pending"] > 0 else ""})
    return out


# ---------- Member UPI pay requests ----------
@router.post("/pay-requests", status_code=201)
async def create_pay_request(body: PayRequestIn, background: BackgroundTasks, user: dict = Depends(get_current_user)):
    if body.type not in heads(await main_settings()):
        raise HTTPException(status_code=400, detail="Invalid collection type")
    if body.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    house_id = user.get("house_id")
    if not house_id:
        raise HTTPException(status_code=403, detail="No house linked to your account")
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    s = await main_settings()
    stage = "started" if body.stage == "started" else "submitted"
    if stage == "started":
        # Auto-recorded the moment the member shows the QR / opens the UPI app — reuse a recent attempt for the same head.
        since = (datetime.now(timezone.utc) - timedelta(hours=3)).isoformat()
        prev = await db.pay_requests.find_one({"house_id": house_id, "type": body.type, "status": "pending", "stage": "started", "created_at": {"$gte": since}}, {"_id": 0})
        if prev:
            await db.pay_requests.update_one({"id": prev["id"]}, {"$set": {"amount": body.amount, "created_at": now_iso()}})
            return {**prev, "amount": body.amount}
    payer = await db.members.find_one({"id": user.get("member_id")}, {"_id": 0, "name": 1}) if user.get("member_id") else None
    doc = {**body.model_dump(), "stage": stage, "id": new_id(), "house_id": house_id, "house_no": house["house_no"], "head_name": house["head_name"], "user_id": user["id"], "member_id": user.get("member_id") or None, "member_name": (payer or {}).get("name", ""),
           "status": "pending", "upi_link": upi_link(s, body.amount, f"{body.type} {house['house_no']}"), "created_at": now_iso(), "decided_at": None, "receipt_no": "", "reason": ""}
    await db.pay_requests.insert_one(doc)
    if stage == "submitted":
        background.add_task(ack_pay_request, house, doc, s)
    else:
        background.add_task(alert_committee, house, doc, s)
    doc.pop("_id", None)
    return doc


@router.put("/pay-requests/{req_id}")
async def update_pay_request(req_id: str, body: PayRequestIn, background: BackgroundTasks, user: dict = Depends(get_current_user)):
    """Member confirms an auto-recorded attempt: adds UPI reference / note, marks it submitted."""
    req = await db.pay_requests.find_one({"id": req_id, "status": "pending"}, {"_id": 0})
    if not req or req.get("house_id") != user.get("house_id"):
        raise HTTPException(status_code=404, detail="Pending request not found")
    if body.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    upd = {"amount": body.amount, "upi_ref": body.upi_ref, "note": body.note, "months": body.months, "fund_id": body.fund_id, "stage": "submitted", "submitted_at": now_iso()}
    await db.pay_requests.update_one({"id": req_id}, {"$set": upd})
    doc = {**req, **upd}
    house = await db.houses.find_one({"id": req["house_id"]}, {"_id": 0})
    background.add_task(ack_pay_request, house, doc, await main_settings())
    return doc


@router.get("/pay-requests/feed")
async def pay_request_feed(_: dict = Depends(require_finance)):
    """Live 'money arriving' feed for the treasurer dashboard: pending member UPI requests + recently decided ones."""
    pending = await db.pay_requests.find({"status": "pending"}, {"_id": 0}).sort("created_at", -1).to_list(500)
    since = (datetime.now(timezone.utc) - timedelta(days=3)).isoformat()
    recent = await db.pay_requests.find({"status": {"$in": ["approved", "rejected"]}, "decided_at": {"$gte": since}}, {"_id": 0}).sort("decided_at", -1).to_list(10)
    return {"pending": pending, "recent": recent, "pending_total": sum(float(r.get("amount", 0) or 0) for r in pending)}


@router.get("/pay-requests")
async def list_pay_requests(status: Optional[str] = None, user: dict = Depends(get_current_user)):
    q = {}
    if status:
        q["status"] = status
    if not await can_finance(user) and user["role"] != "admin":
        q["house_id"] = user.get("house_id") or "__none__"
    return await db.pay_requests.find(q, {"_id": 0}).sort("created_at", -1).to_list(2000)


@router.get("/upi-link")
async def get_upi_link(amount: float, note: str = "", user: dict = Depends(get_current_user)):
    s = await main_settings()
    house = await db.houses.find_one({"id": user.get("house_id") or "__none__"}, {"_id": 0, "house_no": 1})
    link = upi_link(s, amount, f"{note} {house['house_no']}" if house else note)
    if not link:
        raise HTTPException(status_code=400, detail="UPI ID not configured by the committee")
    return {"link": link, "upi_id": s.get("upi_id"), "upi_name": s.get("upi_name") or s.get("short_name")}


async def record_from_request(req: dict, approver: dict, background: BackgroundTasks) -> str:
    house = await db.houses.find_one({"id": req["house_id"]}, {"_id": 0})
    s = await main_settings()
    note = f"UPI {req.get('upi_ref', '')}".strip()
    if req["type"] == "donation":
        fund = await db.funds.find_one({"id": req.get("fund_id") or "__none__"}, {"_id": 0})
        if not fund:
            fund = await db.funds.find_one({"active": True}, {"_id": 0})
        if not fund:
            raise HTTPException(status_code=400, detail="No active fund to receive donation")
        doc = {"id": new_id(), "receipt_no": await next_receipt_no("donation"), "fund_id": fund["id"], "donor_name": house["head_name"], "house_id": house["id"],
               "amount": req["amount"], "mode": "upi", "date": today(), "note": note, "created_by": approver["name"], "created_at": now_iso()}
        await db.donations.insert_one(doc)
        return doc["receipt_no"]
    kind = heads(s)[req["type"]][0]
    doc = {"id": new_id(), "type": req["type"], "house_id": house["id"], "member_id": req.get("member_id") or None, "member_name": req.get("member_name", ""), "amount": req["amount"], "mode": "upi", "date": today(), "note": note,
           "created_by": approver["name"], "created_at": now_iso(), "receipt_no": await next_receipt_no("subscription")}
    if kind == "monthly":
        months = req.get("months") or []
        if not months:
            d = await house_dues(house)
            n = int(req["amount"] // max(house.get("subscription_amount", 1), 1))
            months = d["pending_months"][:n]
        doc["months"] = months
    elif kind == "yearly":
        years = req.get("years") or []
        if not years:
            c = await house_collections(house, s)
            rate = c[req["type"]]["rate"] or req["amount"]
            years = c[req["type"]]["pending_periods"][: max(1, int(req["amount"] // rate))]
        doc["years"] = years
    await db.payments.insert_one(doc)
    from routes.finance import balance_snapshot
    doc["balance_after"] = await balance_snapshot(house, req["type"], s)
    await db.payments.update_one({"id": doc["id"]}, {"$set": {"balance_after": doc["balance_after"]}})
    if s.get("notify_on_payment", True):
        background.add_task(receipt_text, house, doc, s)
    return doc["receipt_no"]


async def alert_committee(house: dict, req: dict, s: dict, submitted: bool = False):
    """In-app bell entry for every admin + the finance manager: who is paying what, when (no WhatsApp spam for mere QR opens)."""
    label = label_for(s, req["type"])
    ref = f" · UPI Ref: {req['upi_ref']}" if req.get("upi_ref") else ""
    state = "അടച്ചു എന്ന് അറിയിച്ചു" if submitted else "QR scan ചെയ്തു (reference ഇല്ല) — Google Pay/bank-ൽ പണം വന്നോ നോക്കുക"
    body = f"വീട് {house['house_no']} · {house['head_name']} — {label} ₹{req['amount']:.0f}. {state}{ref}. ഡാഷ്ബോർഡിലെ 'പണം വരവ്'-ൽ confirm ചെയ്യുക."
    ids = {u["id"] async for u in db.users.find({"role": "admin"}, {"_id": 0, "id": 1})}
    if s.get("finance_manager_id"):
        ids.add(s["finance_manager_id"])
    for uid in ids:
        await db.messages.insert_one({"id": new_id(), "to": "", "recipient_name": "", "channel": "app", "kind": "pay_alert", "body": body, "ref": req["id"], "house_id": f"user:{uid}", "status": "sent", "error": "", "provider_sid": "", "created_at": now_iso()})


async def ack_pay_request(house: dict, req: dict, s: dict):
    """Instant WhatsApp/in-app acknowledgement to the payer + alert to the treasurer."""
    await alert_committee(house, req, s, submitted=True)
    label = label_for(s, req["type"])
    ref = f" (UPI Ref: {req['upi_ref']})" if req.get("upi_ref") else ""
    await notify_house(house, tx(s, "ack", amount=f"{req['amount']:.0f}", label=label, ref=ref) + sign(s), "pay_request", req["id"], s.get("notify_channel", "whatsapp"))
    manager = await db.users.find_one({"id": s.get("finance_manager_id")}, {"_id": 0}) if s.get("finance_manager_id") else None
    if manager and manager.get("phone"):
        text = with_salaam(manager.get("name", ""), settings=s, body=f"പുതിയ UPI payment: വീട് {house['house_no']} ({house['head_name']}) — ₹{req['amount']:.0f} {label}{ref}. App-ൽ 'പിരിവുകൾ' page-ൽ confirm ചെയ്യുക." + sign(s))
        await send_message(manager["phone"], text, "whatsapp", "pay_alert", req["id"], manager.get("name", ""))


@router.post("/pay-requests/{req_id}/approve")
async def approve_pay_request(req_id: str, background: BackgroundTasks, user: dict = Depends(require_finance)):
    req = await db.pay_requests.find_one({"id": req_id}, {"_id": 0})
    if not req or req["status"] != "pending":
        raise HTTPException(status_code=404, detail="Pending request not found")
    receipt = await record_from_request(req, user, background)
    await db.pay_requests.update_one({"id": req_id}, {"$set": {"status": "approved", "decided_at": now_iso(), "decided_by": user["name"], "receipt_no": receipt}})
    return {"ok": True, "receipt_no": receipt}


@router.post("/pay-requests/{req_id}/reject")
async def reject_pay_request(req_id: str, body: DecisionIn, background: BackgroundTasks, user: dict = Depends(require_finance)):
    res = await db.pay_requests.update_one({"id": req_id, "status": "pending"}, {"$set": {"status": "rejected", "decided_at": now_iso(), "decided_by": user["name"], "reason": body.reason}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Pending request not found")
    req = await db.pay_requests.find_one({"id": req_id}, {"_id": 0})
    house = await db.houses.find_one({"id": req["house_id"]}, {"_id": 0})
    s = await main_settings()
    if house:
        reason = tx(s, "reason", reason=body.reason) if body.reason else ""
        background.add_task(notify_house, house, tx(s, "reject", amount=f"{req['amount']:.0f}", label=label_for(s, req["type"]), reason=reason) + sign(s), "pay_rejected", req_id, s.get("notify_channel", "whatsapp"))
    return {"ok": True}
