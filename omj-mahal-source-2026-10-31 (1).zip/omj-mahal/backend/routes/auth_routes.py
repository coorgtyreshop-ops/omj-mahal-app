import os
import re
import hashlib
import hmac
import secrets
import jwt
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel
from typing import Optional
from core import (
    db, new_id, now_iso, hash_password, verify_password,
    create_access_token, get_current_user, require_admin, JWT_ALGORITHM, ledger_scope,
)
from messaging import send_message, provider_status, e164, with_salaam, sign
import random

router = APIRouter(prefix="/auth", tags=["auth"])
users_router = APIRouter(prefix="/users", tags=["users"])

OTP_TTL_MIN = 5
OTP_MAX_ATTEMPTS = 5
OTP_MAX_REQUESTS = 5
OTP_WINDOW_MIN = 15
LOCK_MAX_FAILS = 5
LOCK_MINUTES = 15
INVALID_LOGIN = "Invalid Member ID or password"
ID_HINT = "Members must sign in with their Member ID (e.g. OMJ-0001), not a phone number"
ID_NOT_FOUND = "This Member ID is not registered. Contact your Mahal committee."


class LoginIn(BaseModel):
    login_id: str = ""
    phone: str = ""
    password: str


class OtpRequestIn(BaseModel):
    login_id: str = ""
    phone: str = ""
    channel: str = "whatsapp"
    purpose: str = "login"


class OtpVerifyIn(BaseModel):
    login_id: str = ""
    phone: str = ""
    code: str
    purpose: str = "login"


class OtpResetIn(BaseModel):
    reset_token: str
    new_password: str


def norm_id(s: str) -> str:
    return (s or "").strip().upper().replace(" ", "")


def looks_like_phone(s: str) -> bool:
    n = norm_id(s).lstrip("+")
    return n.isdigit() and len(n) >= 10


def mask_phone(p: str) -> str:
    return p[:-7] + "XXXX" + p[-3:] if len(p) > 8 else p


async def head_member_no(house_id: str) -> str:
    m = await db.members.find_one({"house_id": house_id, "relation": "Self"}, {"_id": 0, "member_no": 1})
    if not m:
        m = await db.members.find_one({"house_id": house_id}, {"_id": 0, "member_no": 1}, sort=[("created_at", 1)])
    return (m or {}).get("member_no", "")


async def login_id_for(user: dict) -> str:
    if user.get("login_id"):
        return user["login_id"]
    if user.get("house_id"):
        return await head_member_no(user["house_id"])
    return ""


async def next_staff_id() -> str:
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "member_prefix": 1}) or {}
    c = await db.counters.find_one_and_update({"key": "staff_login"}, {"$inc": {"seq": 1}}, upsert=True, return_document=True)
    return f"{s.get('member_prefix') or 'OMJ'}-S{c['seq']:03d}"


async def next_admin_id() -> str:
    c = await db.counters.find_one_and_update({"key": "admin_login"}, {"$inc": {"seq": 1}}, upsert=True, return_document=True)
    return f"ADMIN-{c['seq']:03d}"


def id_variants(ident: str) -> list:
    """Forgiving Member-ID matching: 0↔O in the prefix, missing dash, short numbers (OMJ-98 → OMJ-0098)."""
    m = re.match(r"^([A-Z0-9]*?)-?(\d+)$", ident)
    if not m:
        return [ident]
    prefix, num = m.group(1), m.group(2)
    prefixes = {prefix, prefix.replace("0", "O")} if prefix else {""}
    out = [ident]
    for p in prefixes:
        for n in {num, num.zfill(4), num.zfill(3), num.lstrip("0") or "0"}:
            out += [f"{p}-{n}" if p else n, f"{p}{n}"]
    return list(dict.fromkeys(out))


HEAD_LOGIN = {"$or": [{"member_id": {"$exists": False}}, {"member_id": None}, {"member_id": ""}]}


async def resolve_login_user(identifier: str) -> Optional[dict]:
    """Member ID (any member of the house) or house number -> house login; ADMIN-xxx -> admin; phone -> admins only."""
    ident = norm_id(identifier)
    if not ident:
        return None
    variants = id_variants(ident)
    user = await db.users.find_one({"login_id": {"$in": variants}})
    if user:
        return user
    m = await db.members.find_one({"member_no": {"$in": variants}}, {"_id": 0, "house_id": 1})
    if m:
        return await db.users.find_one({"house_id": m["house_id"], **HEAD_LOGIN})
    if ident.lstrip("+").isdigit():
        admin = await db.users.find_one({"phone": ident, "role": "admin"})
        if admin:
            return admin
    mnum = re.match(r"^[A-Z0-9]*?-?(\d+)$", ident)
    num = mnum.group(1) if mnum else ""
    nums = [ident] + ([num, num.zfill(3), num.zfill(4), num.lstrip("0") or "0"] if num else [])
    house = await db.houses.find_one({"house_no": {"$in": list(dict.fromkeys(nums))}}, {"_id": 0, "id": 1})
    if house:
        return await db.users.find_one({"house_id": house["id"], **HEAD_LOGIN})
    return None


async def check_lock(key: str):
    row = await db.login_attempts.find_one({"key": key})
    if row and row.get("count", 0) >= LOCK_MAX_FAILS:
        if row.get("locked_until", "") > now_iso():
            raise HTTPException(status_code=429, detail="Too many failed attempts. Please try again after 15 minutes.")
        await db.login_attempts.delete_one({"key": key})


async def record_fail(key: str):
    now = datetime.now(timezone.utc)
    await db.login_attempts.update_one({"key": key}, {"$inc": {"count": 1}, "$set": {"locked_until": (now + timedelta(minutes=LOCK_MINUTES)).isoformat(), "updated_at": now.isoformat()}}, upsert=True)


async def enrich(user: dict) -> dict:
    u = public_user(user)
    u["login_id"] = await login_id_for(user)
    u["ledger_scope"] = await ledger_scope(user)
    return u


def otp_hash(phone: str, code: str) -> str:
    return hmac.new(os.environ["JWT_SECRET"].encode(), f"{phone}:{code}".encode(), hashlib.sha256).hexdigest()


def otp_target(user: dict, house: Optional[dict], channel: str) -> str:
    if channel == "whatsapp" and house and house.get("whatsapp"):
        return house["whatsapp"]
    return user["phone"]


@router.post("/otp/request")
async def otp_request(body: OtpRequestIn):
    if body.channel not in ("sms", "whatsapp"):
        raise HTTPException(status_code=400, detail="Invalid channel")
    if body.purpose not in ("login", "reset"):
        raise HTTPException(status_code=400, detail="Invalid purpose")
    ident = body.login_id or body.phone
    user = await resolve_login_user(ident)
    if not user:
        raise HTTPException(status_code=404, detail=ID_HINT if looks_like_phone(ident) else ID_NOT_FOUND)
    phone = user["phone"]
    now = datetime.now(timezone.utc)
    window_start = (now - timedelta(minutes=OTP_WINDOW_MIN)).isoformat()
    recent = await db.otps.count_documents({"phone": phone, "created_at": {"$gte": window_start}})
    if recent >= OTP_MAX_REQUESTS:
        raise HTTPException(status_code=429, detail="Too many OTP requests. Please try again after some time.")
    house = await db.houses.find_one({"id": user["house_id"]}, {"_id": 0}) if user.get("house_id") else None
    code = f"{secrets.randbelow(10**6):06d}"
    await db.otps.delete_many({"phone": phone, "purpose": body.purpose})
    await db.otps.insert_one({
        "id": new_id(), "phone": phone, "purpose": body.purpose, "code_hash": otp_hash(phone, code), "attempts": 0,
        "expires_at": (now + timedelta(minutes=OTP_TTL_MIN)).isoformat(), "created_at": now.isoformat(),
    })
    settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    name = settings.get("short_name") or settings.get("mahal_name") or "Mahal"
    what = "login" if body.purpose == "login" else "password reset"
    text = f"{name}: Your {what} OTP is {code}. Valid for {OTP_TTL_MIN} minutes. Do not share this code."
    to = otp_target(user, house, body.channel)
    log = await send_message(to, text, body.channel, f"otp_{body.purpose}", user["id"], user.get("name", ""))
    out = {"ok": True, "sent_to": mask_phone(e164(to)), "channel": body.channel, "expires_in": OTP_TTL_MIN * 60, "mode": provider_status()["mode"]}
    if log["status"] != "sent":
        out["demo_code"] = code
    return out


async def consume_otp(phone: str, code: str, purpose: str) -> dict:
    row = await db.otps.find_one({"phone": phone, "purpose": purpose})
    if not row:
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")
    if row["expires_at"] < datetime.now(timezone.utc).isoformat():
        await db.otps.delete_one({"id": row["id"]})
        raise HTTPException(status_code=401, detail="OTP expired. Please request a new one.")
    if row["attempts"] >= OTP_MAX_ATTEMPTS:
        await db.otps.delete_one({"id": row["id"]})
        raise HTTPException(status_code=429, detail="Too many wrong attempts. Please request a new OTP.")
    if not hmac.compare_digest(row["code_hash"], otp_hash(phone, code.strip())):
        await db.otps.update_one({"id": row["id"]}, {"$inc": {"attempts": 1}})
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")
    await db.otps.delete_one({"id": row["id"]})
    user = await db.users.find_one({"phone": phone})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.post("/otp/verify")
async def otp_verify(body: OtpVerifyIn, response: Response):
    if body.purpose not in ("login", "reset"):
        raise HTTPException(status_code=400, detail="Invalid purpose")
    target = await resolve_login_user(body.login_id or body.phone)
    if not target:
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")
    user = await consume_otp(target["phone"], body.code, body.purpose)
    if body.purpose == "reset":
        token = jwt.encode({"sub": user["id"], "type": "reset", "exp": datetime.now(timezone.utc) + timedelta(minutes=10)}, os.environ["JWT_SECRET"], algorithm=JWT_ALGORITHM)
        return {"ok": True, "reset_token": token}
    token = create_access_token(user["id"], user["role"])
    response.set_cookie("access_token", token, httponly=True, secure=True, samesite="none", max_age=7 * 86400, path="/")
    return {"token": token, "user": await enrich(user)}


@router.post("/otp/reset-password")
async def otp_reset_password(body: OtpResetIn):
    try:
        payload = jwt.decode(body.reset_token, os.environ["JWT_SECRET"], algorithms=[JWT_ALGORITHM])
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Reset link expired. Please request a new OTP.")
    if payload.get("type") != "reset":
        raise HTTPException(status_code=401, detail="Invalid reset token")
    if len(body.new_password) < 4:
        raise HTTPException(status_code=400, detail="Password too short")
    res = await db.users.update_one({"id": payload["sub"]}, {"$set": {"password_hash": hash_password(body.new_password), "must_change_password": False}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"ok": True}


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str


class LanguageIn(BaseModel):
    language: str


class UserCreate(BaseModel):
    name: str
    phone: str
    password: str
    role: str = "member"
    house_id: Optional[str] = None
    language: str = "en"


class BulkLoginIn(BaseModel):
    mode: str = "house_no"
    fixed_password: str = ""
    suffix: str = "1234"
    send_whatsapp: bool = False


class SendIdsIn(BaseModel):
    app_url: str = ""


def gen_password() -> str:
    return f"{random.randint(0, 999999):06d}"


async def create_house_login(house: dict, password: str, phone: Optional[str] = None) -> dict:
    phone = (phone or house.get("phone") or "").strip()
    if not phone:
        raise HTTPException(status_code=400, detail="House has no phone number")
    if await db.users.find_one({"phone": phone}):
        raise HTTPException(status_code=400, detail="Phone number already registered")
    doc = {
        "id": new_id(), "name": house["head_name"], "phone": phone, "role": "member", "house_id": house["id"],
        "language": "ml", "password_hash": hash_password(password), "must_change_password": True, "created_at": now_iso(),
    }
    await db.users.insert_one(doc)
    out = public_user(doc)
    out["login_id"] = await head_member_no(house["id"])
    return out


async def send_credentials(house: dict, phone: str, password: str, app_url: str = "") -> dict:
    settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    name = settings.get("short_name") or settings.get("mahal_name", "Mahal")
    mid = await head_member_no(house["id"])
    url = app_url or settings.get("app_url", "")
    link = f"\nApp link: {url}" if url else ""
    text = with_salaam(house["head_name"], f"നിങ്ങളുടെ {name} App login:\nMember ID: {mid}\nപാസ്‌വേഡ്: {password}{link}\nഈ Member ID ഉപയോഗിച്ച് മാത്രമേ ആപ്പ് തുറക്കാൻ കഴിയൂ. ആദ്യ login-ന് ശേഷം പാസ്‌വേഡ് മാറ്റുക." + sign(settings), house.get("father_name", ""))
    to = house.get("whatsapp") or phone
    return await send_message(to, text, "whatsapp", "credentials", house["id"], house["head_name"], house["id"])


async def send_member_id(house: dict, app_url: str = "") -> dict:
    settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    name = settings.get("short_name") or settings.get("mahal_name", "Mahal")
    mid = await head_member_no(house["id"])
    if not mid:
        raise HTTPException(status_code=400, detail="House has no member number yet")
    url = app_url or settings.get("app_url", "")
    link = f"\nApp link: {url}" if url else ""
    text = with_salaam(house["head_name"], f"നിങ്ങളുടെ {name} App Member ID: {mid}\nഈ Member ID ഉപയോഗിച്ചാണ് ആപ്പ് തുറക്കേണ്ടത്. ഈ ID ഇല്ലാതെ ആപ്പ് തുറക്കാൻ കഴിയില്ല.\nപാസ്‌വേഡ് മറന്നാൽ 'പാസ്‌വേഡ് മറന്നോ?' വഴി OTP ഉപയോഗിച്ച് പുതിയത് സെറ്റ് ചെയ്യാം.{link}" + sign(settings), house.get("father_name", ""))
    to = house.get("whatsapp") or house.get("phone") or ""
    if not to:
        raise HTTPException(status_code=400, detail="House has no phone number")
    return await send_message(to, text, "whatsapp", "member_id", house["id"], house["head_name"], house["id"])


class UserUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    role: Optional[str] = None
    house_id: Optional[str] = None
    password: Optional[str] = None


def public_user(u: dict) -> dict:
    u = dict(u)
    u.pop("password_hash", None)
    u.pop("_id", None)
    return u


@router.post("/login")
async def login(body: LoginIn, response: Response):
    ident = body.login_id or body.phone
    key = norm_id(ident)
    if not key:
        raise HTTPException(status_code=401, detail=INVALID_LOGIN)
    await check_lock(key)
    user = await resolve_login_user(ident)
    if not user or not verify_password(body.password, user["password_hash"]):
        await record_fail(key)
        if not user and looks_like_phone(ident):
            raise HTTPException(status_code=401, detail=ID_HINT)
        raise HTTPException(status_code=401, detail=INVALID_LOGIN)
    await db.login_attempts.delete_one({"key": key})
    token = create_access_token(user["id"], user["role"])
    response.set_cookie("access_token", token, httponly=True, secure=True, samesite="none", max_age=7 * 86400, path="/")
    return {"token": token, "user": await enrich(user)}


@router.post("/logout")
async def logout(response: Response):
    response.delete_cookie("access_token", path="/")
    return {"ok": True}


@router.get("/me")
async def me(user: dict = Depends(get_current_user)):
    return await enrich(user)


@router.post("/change-password")
async def change_password(body: ChangePasswordIn, user: dict = Depends(get_current_user)):
    full = await db.users.find_one({"id": user["id"]})
    if not verify_password(body.current_password, full["password_hash"]):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    if len(body.new_password) < 4:
        raise HTTPException(status_code=400, detail="Password too short")
    await db.users.update_one({"id": user["id"]}, {"$set": {"password_hash": hash_password(body.new_password), "must_change_password": False}})
    return {"ok": True}


@router.patch("/language")
async def set_language(body: LanguageIn, user: dict = Depends(get_current_user)):
    if body.language not in ("en", "ml", "kn"):
        raise HTTPException(status_code=400, detail="Unsupported language")
    await db.users.update_one({"id": user["id"]}, {"$set": {"language": body.language}})
    return {"ok": True, "language": body.language}


@users_router.get("")
async def list_users(_: dict = Depends(require_admin)):
    users = await db.users.find({}, {"_id": 0, "password_hash": 0}).sort("created_at", -1).to_list(2000)
    heads = {m["house_id"]: m.get("member_no", "") async for m in db.members.find({"relation": "Self"}, {"_id": 0, "house_id": 1, "member_no": 1})}
    for u in users:
        u["login_id"] = u.get("login_id") or heads.get(u.get("house_id") or "", "")
    return users


@users_router.post("", status_code=201)
async def create_user(body: UserCreate, _: dict = Depends(require_admin)):
    phone = body.phone.strip()
    if await db.users.find_one({"phone": phone}):
        raise HTTPException(status_code=400, detail="Phone number already registered")
    if body.role not in ("admin", "member"):
        raise HTTPException(status_code=400, detail="Invalid role")
    doc = {
        "id": new_id(), "name": body.name.strip(), "phone": phone, "role": body.role,
        "house_id": body.house_id, "language": body.language,
        "password_hash": hash_password(body.password), "created_at": now_iso(),
    }
    if body.role == "admin":
        doc["login_id"] = await next_admin_id()
    elif not body.house_id:
        doc["login_id"] = await next_staff_id()
    await db.users.insert_one(doc)
    return await enrich(doc)


@users_router.post("/bulk-logins")
async def bulk_logins(body: BulkLoginIn, _: dict = Depends(require_admin)):
    if body.mode == "fixed" and len(body.fixed_password) < 4:
        raise HTTPException(status_code=400, detail="Password too short")
    linked = {u["house_id"] async for u in db.users.find({"house_id": {"$ne": None}, **HEAD_LOGIN}, {"_id": 0, "house_id": 1})}
    created, skipped = [], []
    for h in await db.houses.find({}, {"_id": 0}).sort("house_no", 1).to_list(5000):
        if h["id"] in linked:
            continue
        pwd = body.fixed_password if body.mode == "fixed" else f"{h['house_no'].replace('-', '').replace(' ', '')}{body.suffix}"
        try:
            user = await create_house_login(h, pwd)
        except HTTPException as exc:
            skipped.append({"house_no": h["house_no"], "head_name": h["head_name"], "reason": exc.detail})
            continue
        created.append({"house_no": h["house_no"], "head_name": h["head_name"], "phone": h.get("phone", ""), "login_id": user["login_id"], "password": pwd})
        if body.send_whatsapp:
            await send_credentials(h, h.get("phone", ""), pwd)
    return {"created": created, "skipped": skipped}


@users_router.post("/send-ids")
async def send_all_ids(body: SendIdsIn, _: dict = Depends(require_admin)):
    """Queue a 'your Member ID' WhatsApp message for every house that has a login."""
    results, skipped = [], []
    async for u in db.users.find({"house_id": {"$ne": None}}, {"_id": 0, "house_id": 1}):
        house = await db.houses.find_one({"id": u["house_id"]}, {"_id": 0})
        if not house:
            continue
        try:
            results.append(await send_member_id(house, body.app_url))
        except HTTPException as exc:
            skipped.append({"house_no": house["house_no"], "reason": exc.detail})
    return {"sent": len(results), "results": results, "skipped": skipped}


@users_router.put("/{user_id}")
async def update_user(user_id: str, body: UserUpdate, admin: dict = Depends(require_admin)):
    existing = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="User not found")
    update = {k: v for k, v in body.model_dump(exclude_none=True).items() if k != "password"}
    if "phone" in update:
        update["phone"] = update["phone"].strip()
        dup = await db.users.find_one({"phone": update["phone"], "id": {"$ne": user_id}})
        if dup:
            raise HTTPException(status_code=400, detail="Phone number already registered")
    if body.password:
        update["password_hash"] = hash_password(body.password)
        update["must_change_password"] = True
    if update.get("role") == "admin" and not existing.get("login_id"):
        update["login_id"] = await next_admin_id()
    if update:
        await db.users.update_one({"id": user_id}, {"$set": update})
    return await enrich(await db.users.find_one({"id": user_id}))


@users_router.delete("/{user_id}")
async def delete_user(user_id: str, admin: dict = Depends(require_admin)):
    if user_id == admin["id"]:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    res = await db.users.delete_one({"id": user_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"ok": True}
