from datetime import date
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel
from typing import Optional, List
from core import db, new_id, now_iso, current_month, get_current_user, require_admin, house_dues, can_finance, hash_password
from routes.auth_routes import create_house_login, send_credentials, gen_password, public_user, head_member_no, send_member_id
from routes.files import store_image
from messaging import notify_house, statement_text, send_message, with_salaam, sign

router = APIRouter(tags=["houses"])
STATUSES = ("", "student", "working", "homemaker", "retired", "none")


HEAD_LOGIN = {"$or": [{"member_id": {"$exists": False}}, {"member_id": None}, {"member_id": ""}]}


class HouseIn(BaseModel):
    house_no: str
    head_name: str
    father_name: str = ""
    address: str = ""
    ward: str = ""
    phone: str = ""
    whatsapp: str = ""
    subscription_amount: Optional[float] = None
    start_month: Optional[str] = None
    head_dob: str = ""
    head_blood_group: str = ""
    head_occupation: str = ""
    head_occupation_detail: str = ""
    head_education: str = ""


class LoginIn(BaseModel):
    phone: Optional[str] = None
    password: Optional[str] = None
    send_whatsapp: bool = False
    app_url: str = ""


class MemberIn(BaseModel):
    house_id: str
    name: str
    relation: str = ""
    dob: str = ""
    gender: str = ""
    occupation: str = ""
    marital_status: str = ""
    education: str = ""
    blood_group: str = ""
    phone: str = ""
    status: str = ""
    occupation_detail: str = ""


class MemberRow(BaseModel):
    name: str
    relation: str = ""
    dob: str = ""
    gender: str = ""
    status: str = ""
    occupation: str = ""


class BulkMembersIn(BaseModel):
    house_id: str
    members: List[MemberRow]


async def default_subscription() -> float:
    s = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    return float(s.get("default_subscription", 100))


async def next_member_no() -> str:
    s = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    prefix = (s.get("member_prefix") or "OMJ").strip()
    counter = await db.counters.find_one_and_update({"key": "member"}, {"$inc": {"seq": 1}}, upsert=True, return_document=True)
    return f"{prefix}-{counter['seq']:04d}"


def age_from(dob: str) -> Optional[int]:
    try:
        y, m, d = map(int, dob[:10].split("-"))
    except Exception:
        return None
    t = date.today()
    return t.year - y - ((t.month, t.day) < (m, d))


def classify(member: dict, house: dict) -> dict:
    age = age_from(member.get("dob", ""))
    # A son carrying his father's name (common) must NOT become the head: name-match only when no relation is recorded.
    is_head = member.get("relation") == "Self" or (not member.get("relation") and house and member.get("name", "").strip().lower() == (house.get("head_name") or "").strip().lower())
    if is_head:
        kind = "head"
    elif member.get("gender") == "male" and age is not None and age >= 18 and member.get("status") == "working":
        kind = "sub"  # second member: working adult male
    else:
        kind = "family"
    member["age"] = age
    member["member_type"] = kind
    return member


def type_counts(members: list) -> dict:
    out = {"head": 0, "sub": 0, "family": 0}
    for m in members:
        out[m.get("member_type", "family")] = out.get(m.get("member_type", "family"), 0) + 1
    return out


def sort_members(members: list) -> list:
    order = {"head": 0, "sub": 1, "family": 2}
    return sorted(members, key=lambda m: (order.get(m.get("member_type"), 9), -(m.get("age") or 0)))


async def is_privileged(user: dict) -> bool:
    return user["role"] == "admin" or await can_finance(user)


def member_scope(user: dict, house_id: Optional[str]) -> Optional[str]:
    if user["role"] == "admin":
        return house_id
    if not user.get("house_id"):
        raise HTTPException(status_code=403, detail="No house linked to your account")
    return user["house_id"]


async def new_member_doc(house_id: str, data: dict) -> dict:
    doc = {"house_id": house_id, "name": "", "relation": "", "dob": "", "gender": "", "occupation": "", "marital_status": "",
           "education": "", "blood_group": "", "phone": "", "status": "", "occupation_detail": "", "photo_url": ""}
    doc.update({k: v for k, v in data.items() if k in doc})
    doc["name"] = doc["name"].strip()
    if doc["status"] not in STATUSES:
        raise HTTPException(status_code=400, detail="Invalid status")
    doc.update({"id": new_id(), "member_no": await next_member_no(), "created_at": now_iso()})
    await db.members.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.get("/houses")
async def list_houses(q: Optional[str] = None, ward: Optional[str] = None, with_dues: bool = False, user: dict = Depends(get_current_user)):
    query = {}
    if not await is_privileged(user):
        query["id"] = user.get("house_id") or "__none__"
    if q:
        query["$or"] = [
            {"house_no": {"$regex": q, "$options": "i"}},
            {"head_name": {"$regex": q, "$options": "i"}},
            {"phone": {"$regex": q, "$options": "i"}},
            {"whatsapp": {"$regex": q, "$options": "i"}},
        ]
    if ward:
        query["ward"] = ward
    houses = await db.houses.find(query, {"_id": 0}).sort("house_no", 1).to_list(5000)
    linked = {u["house_id"] async for u in db.users.find({"house_id": {"$ne": None}, **HEAD_LOGIN}, {"_id": 0, "house_id": 1})}
    counts = {}
    async for row in db.members.aggregate([{"$group": {"_id": "$house_id", "n": {"$sum": 1}}}]):
        counts[row["_id"]] = row["n"]
    for h in houses:
        h["member_count"] = counts.get(h["id"], 0)
        h["has_login"] = h["id"] in linked
        if with_dues:
            h["dues"] = await house_dues(h)
    return houses


@router.get("/houses/wards")
async def list_wards(_: dict = Depends(get_current_user)):
    wards = await db.houses.distinct("ward")
    return sorted([w for w in wards if w])


@router.post("/houses/release-all")
async def release_all(user: dict = Depends(get_current_user)):
    """Committee releases every house's verified statement at once (members see balances + get the update)."""
    if not await is_privileged(user):
        raise HTTPException(status_code=403, detail="Not allowed")
    n = 0
    for h in await db.houses.find({}, {"_id": 0}).to_list(5000):
        await release_house(h)
        n += 1
    return {"released": n}


@router.post("/houses/{house_id}/release")
async def release_one(house_id: str, user: dict = Depends(get_current_user)):
    """Committee has checked this house (Jan → today) — release the statement: member's dashboard opens up and an update is sent."""
    if not await is_privileged(user):
        raise HTTPException(status_code=403, detail="Not allowed")
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    return await release_house(house)


async def release_house(house: dict) -> dict:
    s = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    ts = now_iso()
    await db.houses.update_one({"id": house["id"]}, {"$set": {"statement_released": True, "statement_released_at": ts}})
    body = await statement_text(house, s)
    await notify_house(house, body, "statement", f"{house['id']}:{ts}", s.get("notify_channel", "whatsapp"))
    return {"id": house["id"], "statement_released": True, "statement_released_at": ts, "message": body}


@router.get("/houses/{house_id}")
async def get_house(house_id: str, user: dict = Depends(get_current_user)):
    privileged = await is_privileged(user)
    if not privileged:
        house_id = member_scope(user, house_id)
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    members = [classify(m, house) for m in await db.members.find({"house_id": house_id}, {"_id": 0}).to_list(500)]
    logins = {u["member_id"]: u.get("login_id", "") async for u in db.users.find({"house_id": house_id, "member_id": {"$nin": [None, ""]}}, {"_id": 0, "member_id": 1, "login_id": 1})}
    for m in members:
        m["login_id"] = logins.get(m["id"], "")
    house["members"] = sort_members(members)
    house["type_counts"] = type_counts(members)
    released = bool(house.get("statement_released"))
    house["dues"] = await house_dues(house) if (privileged or released) else None
    house["payments"] = await db.payments.find({"house_id": house_id}, {"_id": 0}).sort("date", -1).to_list(500) if (privileged or released) else []
    login = await db.users.find_one({"house_id": house_id, **HEAD_LOGIN}, {"_id": 0, "password_hash": 0})
    if login:
        login["login_id"] = await head_member_no(house_id)
    house["login"] = login if user["role"] == "admin" else None
    return house


@router.post("/houses/{house_id}/login", status_code=201)
async def create_login(house_id: str, body: LoginIn, _: dict = Depends(require_admin)):
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    if await db.users.find_one({"house_id": house_id, **HEAD_LOGIN}):
        raise HTTPException(status_code=400, detail="Login already exists for this house")
    password = (body.password or "").strip() or gen_password()
    if len(password) < 4:
        raise HTTPException(status_code=400, detail="Password too short")
    user = await create_house_login(house, password, body.phone)
    result = {"user": user, "phone": user["phone"], "login_id": user["login_id"], "password": password, "sent": None}
    if body.send_whatsapp:
        result["sent"] = await send_credentials(house, user["phone"], password, body.app_url)
    return result


@router.post("/houses/{house_id}/login/reset")
async def reset_login(house_id: str, body: LoginIn, _: dict = Depends(require_admin)):
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    login = await db.users.find_one({"house_id": house_id, **HEAD_LOGIN})
    if not login:
        raise HTTPException(status_code=404, detail="No login for this house")
    password = (body.password or "").strip() or gen_password()
    if len(password) < 4:
        raise HTTPException(status_code=400, detail="Password too short")
    await db.users.update_one({"id": login["id"]}, {"$set": {"password_hash": hash_password(password), "must_change_password": True}})
    result = {"user": public_user(login), "phone": login["phone"], "login_id": await head_member_no(house_id), "password": password, "sent": None}
    if body.send_whatsapp:
        result["sent"] = await send_credentials(house, login["phone"], password, body.app_url)
    return result


@router.post("/houses/{house_id}/login/send")
async def send_login(house_id: str, body: LoginIn, _: dict = Depends(require_admin)):
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    login = await db.users.find_one({"house_id": house_id, **HEAD_LOGIN}, {"_id": 0, "password_hash": 0})
    if not house or not login:
        raise HTTPException(status_code=404, detail="No login for this house")
    if not body.password:
        raise HTTPException(status_code=400, detail="Password required to send")
    return await send_credentials(house, login["phone"], body.password, body.app_url)


@router.post("/houses/{house_id}/login/send-id")
async def send_house_id(house_id: str, body: LoginIn, _: dict = Depends(require_admin)):
    house = await db.houses.find_one({"id": house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    return await send_member_id(house, body.app_url)


@router.post("/houses", status_code=201)
async def create_house(body: HouseIn, _: dict = Depends(require_admin)):
    if await db.houses.find_one({"house_no": body.house_no.strip()}):
        raise HTTPException(status_code=400, detail="House number already exists")
    doc = body.model_dump()
    doc["house_no"] = doc["house_no"].strip()
    doc["head_name"] = doc["head_name"].strip()
    doc["subscription_amount"] = doc["subscription_amount"] if doc["subscription_amount"] is not None else await default_subscription()
    doc["start_month"] = doc["start_month"] or current_month()
    doc.update({"id": new_id(), "created_at": now_iso()})
    await db.houses.insert_one(doc)
    doc.pop("_id", None)
    head = await new_member_doc(doc["id"], {"name": doc["head_name"], "relation": "Self", "dob": doc.get("head_dob", ""), "gender": "male", "phone": doc.get("phone", ""),
                                            "blood_group": doc.get("head_blood_group", ""), "occupation": doc.get("head_occupation", ""), "occupation_detail": doc.get("head_occupation_detail", ""), "education": doc.get("head_education", "")})
    doc["head_member"] = classify(head, doc)
    return doc


@router.put("/houses/{house_id}")
async def update_house(house_id: str, body: HouseIn, _: dict = Depends(require_admin)):
    dup = await db.houses.find_one({"house_no": body.house_no.strip(), "id": {"$ne": house_id}})
    if dup:
        raise HTTPException(status_code=400, detail="House number already exists")
    update = body.model_dump(exclude_none=True)
    update["house_no"] = update["house_no"].strip()
    update["head_name"] = update["head_name"].strip()
    res = await db.houses.update_one({"id": house_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="House not found")
    head_set = {"name": update["head_name"], "blood_group": update.get("head_blood_group", ""), "occupation": update.get("head_occupation", ""), "occupation_detail": update.get("head_occupation_detail", ""), "education": update.get("head_education", "")}
    if update.get("head_dob"):
        head_set["dob"] = update["head_dob"]
    if update.get("phone"):
        head_set["phone"] = update["phone"]
    await db.members.update_one({"house_id": house_id, "relation": "Self"}, {"$set": head_set})
    return await db.houses.find_one({"id": house_id}, {"_id": 0})


@router.delete("/houses/{house_id}")
async def delete_house(house_id: str, _: dict = Depends(require_admin)):
    """Removing a house removes everything that belonged to it — its money must not linger in the dashboard totals."""
    res = await db.houses.delete_one({"id": house_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="House not found")
    await db.members.delete_many({"house_id": house_id})
    await db.users.delete_many({"house_id": house_id, "role": "member"})
    await db.users.update_many({"house_id": house_id}, {"$set": {"house_id": None}})
    for col in ("payments", "pay_requests", "messages", "otps"):
        await db[col].delete_many({"house_id": house_id})
    return {"ok": True}


@router.get("/members")
async def list_members(q: Optional[str] = None, house_id: Optional[str] = None, user: dict = Depends(get_current_user)):
    query = {}
    scoped = member_scope(user, house_id)
    if scoped:
        query["house_id"] = scoped
    if q:
        query["$or"] = [{"name": {"$regex": q, "$options": "i"}}, {"member_no": {"$regex": q, "$options": "i"}}]
    members = await db.members.find(query, {"_id": 0}).sort("name", 1).to_list(10000)
    houses = {h["id"]: h for h in await db.houses.find({}, {"_id": 0, "id": 1, "house_no": 1, "head_name": 1, "ward": 1}).to_list(5000)}
    for m in members:
        h = houses.get(m["house_id"], {})
        m["house_no"] = h.get("house_no", "")
        m["head_name"] = h.get("head_name", "")
        m["ward"] = h.get("ward", "")
        classify(m, h)
    return members


@router.get("/members/stats")
async def member_stats(_: dict = Depends(get_current_user)):
    houses = {h["id"]: h for h in await db.houses.find({}, {"_id": 0, "id": 1, "head_name": 1}).to_list(5000)}
    members = [classify(m, houses.get(m["house_id"], {})) for m in await db.members.find({}, {"_id": 0, "name": 1, "relation": 1, "dob": 1, "gender": 1, "status": 1, "house_id": 1, "marital_status": 1}).to_list(20000)]
    widows = sum(1 for m in members if m.get("marital_status") == "widowed" and m.get("gender") != "male")
    return {"total": len(members), **type_counts(members), "widows": widows}


@router.post("/members", status_code=201)
async def create_member(body: MemberIn, _: dict = Depends(require_admin)):
    house = await db.houses.find_one({"id": body.house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    doc = await new_member_doc(body.house_id, body.model_dump())
    return classify(doc, house)


@router.post("/members/bulk", status_code=201)
async def create_members_bulk(body: BulkMembersIn, _: dict = Depends(require_admin)):
    house = await db.houses.find_one({"id": body.house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    created = []
    for row in body.members:
        if not row.name.strip():
            continue
        created.append(classify(await new_member_doc(body.house_id, row.model_dump()), house))
    return {"created": created, "count": len(created)}


@router.put("/members/{member_id}")
async def update_member(member_id: str, body: MemberIn, _: dict = Depends(require_admin)):
    if body.status not in STATUSES:
        raise HTTPException(status_code=400, detail="Invalid status")
    res = await db.members.update_one({"id": member_id}, {"$set": body.model_dump()})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Member not found")
    m = await db.members.find_one({"id": member_id}, {"_id": 0})
    if not m.get("member_no"):
        m["member_no"] = await next_member_no()
        await db.members.update_one({"id": member_id}, {"$set": {"member_no": m["member_no"]}})
    house = await db.houses.find_one({"id": m["house_id"]}, {"_id": 0}) or {}
    return classify(m, house)


@router.delete("/members/{member_id}")
async def delete_member(member_id: str, _: dict = Depends(require_admin)):
    res = await db.members.delete_one({"id": member_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Member not found")
    return {"ok": True}


async def scoped_member(member_id: str, user: dict) -> tuple:
    m = await db.members.find_one({"id": member_id}, {"_id": 0})
    if not m:
        raise HTTPException(status_code=404, detail="Member not found")
    if user["role"] != "admin" and user.get("house_id") != m["house_id"]:
        raise HTTPException(status_code=403, detail="Not your family member")
    house = await db.houses.find_one({"id": m["house_id"]}, {"_id": 0}) or {}
    return m, house


class MemberLoginIn(BaseModel):
    password: Optional[str] = None
    phone: Optional[str] = None
    send_whatsapp: bool = False
    app_url: str = ""


@router.post("/members/{member_id}/login", status_code=201)
async def member_login(member_id: str, body: MemberLoginIn, _: dict = Depends(require_admin)):
    """Own login for a secondary member (working son): Member ID = his member_no, own phone, own password. Same house view/pay."""
    m = await db.members.find_one({"id": member_id}, {"_id": 0})
    if not m:
        raise HTTPException(status_code=404, detail="Member not found")
    house = await db.houses.find_one({"id": m["house_id"]}, {"_id": 0})
    m = classify(m, house)
    if m["member_type"] == "head":
        raise HTTPException(status_code=400, detail="Use the house login for the head of family")
    phone = (body.phone or m.get("phone") or "").strip()
    if not phone:
        raise HTTPException(status_code=400, detail="Member has no phone number")
    password = (body.password or "").strip() or gen_password()
    if len(password) < 4:
        raise HTTPException(status_code=400, detail="Password too short")
    existing = await db.users.find_one({"member_id": member_id})
    if existing:
        await db.users.update_one({"id": existing["id"]}, {"$set": {"password_hash": hash_password(password), "phone": phone, "name": m["name"], "must_change_password": True}})
    else:
        if await db.users.find_one({"phone": phone}):
            raise HTTPException(status_code=400, detail="Phone number already registered")
        await db.users.insert_one({"id": new_id(), "name": m["name"], "phone": phone, "role": "member", "house_id": m["house_id"], "member_id": member_id, "login_id": m["member_no"],
                                   "language": "ml", "password_hash": hash_password(password), "must_change_password": True, "created_at": now_iso()})
    if phone != (m.get("phone") or ""):
        await db.members.update_one({"id": member_id}, {"$set": {"phone": phone}})
    result = {"login_id": m["member_no"], "phone": phone, "password": password, "sent": None}
    if body.send_whatsapp:
        settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
        name = settings.get("short_name") or settings.get("mahal_name", "Mahal")
        url = body.app_url or settings.get("app_url", "")
        text = with_salaam(m["name"], f"നിങ്ങളുടെ {name} App login:\nMember ID: {m['member_no']}\nപാസ്‌വേഡ്: {password}" + (f"\nApp link: {url}" if url else "") + "\nആദ്യ login-ന് ശേഷം പാസ്‌വേഡ് മാറ്റുക." + sign(settings))
        result["sent"] = await send_message(phone, text, "whatsapp", "credentials", member_id, m["name"], m["house_id"])
    return result


@router.delete("/members/{member_id}/login")
async def delete_member_login(member_id: str, _: dict = Depends(require_admin)):
    res = await db.users.delete_one({"member_id": member_id})
    return {"deleted": res.deleted_count}


@router.get("/members/{member_id}/card")
async def member_card(member_id: str, user: dict = Depends(get_current_user)):
    m, house = await scoped_member(member_id, user)
    s = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    since = (house.get("start_month") or house.get("created_at") or "")[:4]
    return {
        "member": classify(m, house),
        "house": {k: house.get(k, "") for k in ("id", "house_no", "head_name", "ward", "address", "phone")},
        "member_since": since,
        "settings": {k: s.get(k, "") for k in ("mahal_name", "mahal_name_ml", "mahal_name_kn", "short_name", "logo_url", "logo_preset", "address", "phone", "app_url", "registration_no", "president_name", "secretary_name")},
    }


@router.post("/members/{member_id}/photo")
async def upload_member_photo(member_id: str, file: UploadFile = File(...), user: dict = Depends(get_current_user)):
    m, house = await scoped_member(member_id, user)
    stored = await store_image(file, "members")
    await db.members.update_one({"id": member_id}, {"$set": {"photo_url": stored["url"]}})
    m["photo_url"] = stored["url"]
    return classify(m, house)


@router.delete("/members/{member_id}/photo")
async def remove_member_photo(member_id: str, user: dict = Depends(get_current_user)):
    m, house = await scoped_member(member_id, user)
    await db.members.update_one({"id": member_id}, {"$set": {"photo_url": ""}})
    m["photo_url"] = ""
    return classify(m, house)
