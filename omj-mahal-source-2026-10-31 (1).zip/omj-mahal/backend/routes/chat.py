import asyncio
import uuid
from typing import Optional
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from core import db, new_id, now_iso, get_current_user, require_admin
from storage import put_object

router = APIRouter(prefix="/chat", tags=["chat"])

AUDIO_MIME = {"webm": "audio/webm", "ogg": "audio/ogg", "mp4": "audio/mp4", "m4a": "audio/mp4", "mp3": "audio/mpeg", "aac": "audio/aac", "wav": "audio/wav"}
MAX_AUDIO = 5 * 1024 * 1024
MAX_TEXT = 2000
PROJ = {"_id": 0}


class TextIn(BaseModel):
    text: str


class LockIn(BaseModel):
    locked: bool


class KhatheebIn(BaseModel):
    user_id: Optional[str] = None


ROOMS = ("all", "committee", "khatheeb")


async def khatheeb_id() -> Optional[str]:
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "khatheeb_user_id": 1}) or {}
    return s.get("khatheeb_user_id")


async def rooms_for(user: dict) -> list:
    rooms = ["all"]
    kid = await khatheeb_id()
    if user.get("role") == "admin":
        rooms.append("committee")
        if kid:
            rooms.append("khatheeb")
    elif kid and user["id"] == kid:
        rooms.append("khatheeb")
    return rooms


async def require_room(user: dict, room: str) -> str:
    if room not in ROOMS:
        raise HTTPException(status_code=400, detail="Invalid room")
    if room not in await rooms_for(user):
        raise HTTPException(status_code=403, detail="You are not a member of this room")
    return room


async def chat_locked() -> bool:
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "chat_locked": 1}) or {}
    return bool(s.get("chat_locked"))


async def author(user: dict) -> dict:
    house = await db.houses.find_one({"id": user["house_id"]}, {"_id": 0, "house_no": 1}) if user.get("house_id") else None
    return {"user_id": user["id"], "name": user.get("name", ""), "role": user.get("role", "member"), "house_no": (house or {}).get("house_no", "")}


async def ensure_open(user: dict, room: str = "all"):
    if room == "all" and user.get("role") != "admin" and await chat_locked():
        raise HTTPException(status_code=403, detail="Group is locked by the committee — only announcements for now")


@router.get("/messages")
async def list_messages(room: str = "all", after: Optional[str] = None, before: Optional[str] = None, limit: int = 50, user: dict = Depends(get_current_user)):
    await require_room(user, room)
    query = {"room": room}
    if after:
        query["created_at"] = {"$gt": after}
    elif before:
        query["created_at"] = {"$lt": before}
    limit = max(1, min(limit, 200))
    if after:
        rows = await db.chat_messages.find(query, PROJ).sort("created_at", 1).to_list(limit)
    else:
        rows = await db.chat_messages.find(query, PROJ).sort("created_at", -1).to_list(limit)
        rows.reverse()
    total = await db.chat_messages.count_documents({"room": room, "deleted": {"$ne": True}})
    return {"messages": rows, "locked": await chat_locked(), "total": total, "rooms": await rooms_for(user), "room": room}


@router.post("/messages", status_code=201)
async def post_text(body: TextIn, room: str = "all", user: dict = Depends(get_current_user)):
    await require_room(user, room)
    text = body.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Message is empty")
    if len(text) > MAX_TEXT:
        raise HTTPException(status_code=400, detail="Message too long")
    await ensure_open(user, room)
    doc = {"id": new_id(), "room": room, **(await author(user)), "text": text, "audio_url": None, "duration": 0, "deleted": False, "created_at": now_iso()}
    await db.chat_messages.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.post("/voice", status_code=201)
async def post_voice(file: UploadFile = File(...), duration: float = Form(0), room: str = "all", user: dict = Depends(get_current_user)):
    await require_room(user, room)
    await ensure_open(user, room)
    ext = (file.filename or "").rsplit(".", 1)[-1].lower() if "." in (file.filename or "") else ""
    ctype = (file.content_type or "").split(";")[0].strip()
    if ext not in AUDIO_MIME:
        ext = next((k for k, v in AUDIO_MIME.items() if v == ctype), "")
    if ext not in AUDIO_MIME:
        raise HTTPException(status_code=400, detail="Only audio recordings are allowed")
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Empty recording")
    if len(data) > MAX_AUDIO:
        raise HTTPException(status_code=400, detail="Recording too large (max 5 MB)")
    path = f"mahal-app/voice/{uuid.uuid4()}.{ext}"
    try:
        result = await asyncio.to_thread(put_object, path, data, AUDIO_MIME[ext])
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Upload failed: {exc}")
    file_id = new_id()
    await db.files.insert_one({"id": file_id, "storage_path": result["path"], "original_filename": file.filename, "folder": "voice",
                               "content_type": AUDIO_MIME[ext], "size": len(data), "is_deleted": False, "created_at": now_iso()})
    doc = {"id": new_id(), "room": room, **(await author(user)), "text": "", "audio_url": f"/api/files/{file_id}", "duration": round(max(duration, 0), 1), "deleted": False, "created_at": now_iso()}
    await db.chat_messages.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.delete("/messages/{message_id}")
async def delete_message(message_id: str, user: dict = Depends(get_current_user)):
    msg = await db.chat_messages.find_one({"id": message_id}, PROJ)
    if not msg:
        raise HTTPException(status_code=404, detail="Message not found")
    if msg["user_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="You can delete only your own messages")
    if msg.get("audio_url"):
        await db.files.update_one({"id": msg["audio_url"].rsplit("/", 1)[-1]}, {"$set": {"is_deleted": True}})
    await db.chat_messages.update_one({"id": message_id}, {"$set": {"deleted": True, "text": "", "audio_url": None, "deleted_by": user.get("name", "")}})
    return {"ok": True}


@router.put("/khatheeb")
async def set_khatheeb(body: KhatheebIn, _: dict = Depends(require_admin)):
    """Appoint the Mahal Khatheeb/Usthad — he gets a private room with the committee and programme alerts."""
    if body.user_id and not await db.users.find_one({"id": body.user_id}):
        raise HTTPException(status_code=404, detail="User not found")
    await db.settings.update_one({"key": "main"}, {"$set": {"khatheeb_user_id": body.user_id or None}}, upsert=True)
    return {"ok": True, "khatheeb_user_id": body.user_id or None}


@router.put("/lock")
async def set_lock(body: LockIn, _: dict = Depends(require_admin)):
    await db.settings.update_one({"key": "main"}, {"$set": {"chat_locked": body.locked}}, upsert=True)
    return {"ok": True, "locked": body.locked}
