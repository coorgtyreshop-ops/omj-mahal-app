from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, Dict, Any
from core import db, new_id, now_iso, today, get_current_user, require_admin
from messaging import notify_house, sign

router = APIRouter(tags=["content"])


class AnnouncementIn(BaseModel):
    title: str
    content: str
    category: str = "general"
    date: Optional[str] = None
    image_url: str = ""


class CommitteeIn(BaseModel):
    name: str
    designation: str
    phone: str = ""
    term_start: str = ""
    term_end: str = ""
    order: int = 0
    create_login: bool = False


async def committee_login(doc: dict, settings: dict) -> dict:
    """Create (or reset) an admin login for a committee member and WhatsApp the password."""
    from routes.auth_routes import gen_password, public_user, next_admin_id
    from core import hash_password
    from messaging import send_message, with_salaam, sign
    phone = (doc.get("phone") or "").strip()
    if not phone:
        raise HTTPException(status_code=400, detail="Phone number required to create a login")
    password = gen_password()
    user = await db.users.find_one({"phone": phone}, {"_id": 0})
    if user:
        upd = {"password_hash": hash_password(password), "must_change_password": True}
        if not user.get("login_id") and user.get("role") == "admin":
            upd["login_id"] = user["login_id"] = await next_admin_id()
        await db.users.update_one({"id": user["id"]}, {"$set": upd})
    else:
        user = {"id": new_id(), "name": doc["name"], "phone": phone, "role": "admin", "house_id": None, "language": settings.get("default_language", "ml"),
                "login_id": await next_admin_id(), "password_hash": hash_password(password), "must_change_password": True, "created_at": now_iso()}
        await db.users.insert_one(user)
        user.pop("_id", None)
    await db.committee.update_one({"id": doc["id"]}, {"$set": {"user_id": user["id"]}})
    name = settings.get("short_name") or settings.get("mahal_name", "Mahal")
    link = f"\nApp link: {settings['app_url']}" if settings.get("app_url") else ""
    ident = f"Login ID: {user['login_id']} (അല്ലെങ്കിൽ ഫോൺ: {phone})" if user.get("login_id") else f"ഫോൺ: {phone}"
    text = with_salaam(doc["name"], f"{name} കമ്മിറ്റി ({doc.get('designation', '')}) — നിങ്ങളുടെ App login:\n{ident}\nപാസ്‌വേഡ്: {password}{link}\nആദ്യ login-ന് ശേഷം പാസ്‌വേഡ് മാറ്റുക." + sign(settings))
    result = await send_message(phone, text, "whatsapp", "credentials", doc["id"], doc["name"])
    return {"user": public_user(user), "password": password, "sent": result}


class SettingsIn(BaseModel):
    mahal_name: str
    mahal_name_ml: str = ""
    mahal_name_kn: str = ""
    address: str = ""
    phone: str = ""
    committee_whatsapp: str = ""
    email: str = ""
    registration_no: str = ""
    logo_url: str = ""
    default_subscription: float = 100
    receipt_prefix: str = "RCT"
    donation_prefix: str = "DON"
    default_language: str = "en"
    president_name: str = ""
    secretary_name: str = ""
    notify_channel: str = "whatsapp"
    notify_on_announcement: bool = True
    notify_on_payment: bool = True
    logo_preset: str = "logo5"
    short_name: str = ""
    app_url: str = ""
    member_prefix: str = "OMJ"
    auto_reminder_enabled: bool = True
    auto_reminder_threshold: float = 1000
    auto_reminder_days: int = 7
    auto_reminder_channel: str = "both"
    guest_mode_enabled: bool = True
    fee_eid_fitr: float = 0
    fee_eid_adha: float = 0
    fee_nabidinam: float = 0
    fee_building: float = 0
    upi_id: str = ""
    upi_name: str = ""
    finance_manager_id: Optional[str] = None
    hijri_adjustment: int = 0
    notify_provider: str = "phone"
    twilio_sid: str = ""
    twilio_token: str = ""
    twilio_sms_from: str = ""
    twilio_whatsapp_from: str = ""
    upi_phone: str = ""
    upi_app: str = ""
    fee_special: float = 0
    special_name: str = ""
    bank_name: str = ""
    bank_account_name: str = ""
    bank_account_no: str = ""
    bank_ifsc: str = ""
    notify_language: str = "ml"


class CertificateIn(BaseModel):
    type: str
    data: Dict[str, Any]


DEFAULT_SETTINGS = {
    "notify_language": "ml",
    "key": "main", "mahal_name": "Masjid Mahal Committee", "mahal_name_ml": "മസ്ജിദ് മഹൽ കമ്മിറ്റി",
    "mahal_name_kn": "ಮಸ್ಜಿದ್ ಮಹಲ್ ಸಮಿತಿ", "address": "", "phone": "", "email": "", "registration_no": "",
    "logo_url": "", "default_subscription": 100, "receipt_prefix": "RCT", "donation_prefix": "DON",
    "default_language": "en", "president_name": "", "secretary_name": "",
    "notify_channel": "whatsapp", "notify_on_announcement": True, "notify_on_payment": True,
    "logo_preset": "logo5", "short_name": "OMJ Mahal", "app_url": "", "member_prefix": "OMJ",
    "auto_reminder_enabled": True, "auto_reminder_threshold": 1000, "auto_reminder_days": 7, "auto_reminder_channel": "both", "guest_mode_enabled": True,
    "fee_eid_fitr": 0, "fee_eid_adha": 0, "fee_nabidinam": 0, "fee_building": 0, "upi_id": "", "upi_name": "", "finance_manager_id": None, "hijri_adjustment": 0,
    "salath_manager_ids": [], "chat_locked": False, "khatheeb_user_id": None,
}


@router.get("/announcements")
async def list_announcements(category: Optional[str] = None, _: dict = Depends(get_current_user)):
    query = {"category": category} if category else {}
    return await db.announcements.find(query, {"_id": 0}).sort("date", -1).to_list(1000)


@router.post("/announcements", status_code=201)
async def create_announcement(body: AnnouncementIn, background: BackgroundTasks, admin: dict = Depends(require_admin)):
    doc = body.model_dump()
    doc.update({"id": new_id(), "date": body.date or today(), "created_by": admin["name"], "created_at": now_iso()})
    await db.announcements.insert_one(doc)
    doc.pop("_id", None)
    settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    if settings.get("notify_on_announcement", True):
        label = {"janazah": "Janazah", "meeting": "Meeting", "event": "Event"}.get(doc["category"], "Announcement")
        text = f"{label}: {doc['title']}\n{doc['content']}" + sign(settings)
        background.add_task(broadcast_announcement, text, doc["id"], settings.get("notify_channel", "whatsapp"))
    return doc


async def broadcast_announcement(text: str, ref: str, channel: str):
    for h in await db.houses.find({}, {"_id": 0}).to_list(5000):
        await notify_house(h, text, "announcement", ref, channel)


@router.put("/announcements/{ann_id}")
async def update_announcement(ann_id: str, body: AnnouncementIn, _: dict = Depends(require_admin)):
    update = body.model_dump()
    update["date"] = body.date or today()
    res = await db.announcements.update_one({"id": ann_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Announcement not found")
    return await db.announcements.find_one({"id": ann_id}, {"_id": 0})


@router.delete("/announcements/{ann_id}")
async def delete_announcement(ann_id: str, _: dict = Depends(require_admin)):
    res = await db.announcements.delete_one({"id": ann_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Announcement not found")
    return {"ok": True}


@router.get("/committee")
async def list_committee(_: dict = Depends(get_current_user)):
    return await db.committee.find({}, {"_id": 0}).sort("order", 1).to_list(200)


@router.post("/committee", status_code=201)
async def create_committee(body: CommitteeIn, _: dict = Depends(require_admin)):
    doc = body.model_dump(exclude={"create_login"})
    doc.update({"id": new_id(), "created_at": now_iso()})
    await db.committee.insert_one(doc)
    doc.pop("_id", None)
    if body.create_login and doc.get("phone"):
        settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
        doc["login"] = await committee_login(doc, settings)
        doc["user_id"] = doc["login"]["user"]["id"]
    return doc


@router.post("/committee/{cid}/login")
async def committee_send_login(cid: str, _: dict = Depends(require_admin)):
    doc = await db.committee.find_one({"id": cid}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Committee member not found")
    settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    return await committee_login(doc, settings)


@router.put("/committee/{cid}")
async def update_committee(cid: str, body: CommitteeIn, _: dict = Depends(require_admin)):
    res = await db.committee.update_one({"id": cid}, {"$set": body.model_dump(exclude={"create_login"})})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Committee member not found")
    return await db.committee.find_one({"id": cid}, {"_id": 0})


@router.delete("/committee/{cid}")
async def delete_committee(cid: str, _: dict = Depends(require_admin)):
    res = await db.committee.delete_one({"id": cid})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Committee member not found")
    return {"ok": True}


@router.get("/settings")
async def get_settings():
    s = await db.settings.find_one({"key": "main"}, {"_id": 0})
    if not s:
        await db.settings.insert_one(dict(DEFAULT_SETTINGS))
        s = dict(DEFAULT_SETTINGS)
    return s


@router.put("/settings")
async def update_settings(body: SettingsIn, _: dict = Depends(require_admin)):
    update = body.model_dump(exclude_unset=True)
    await db.settings.update_one({"key": "main"}, {"$set": update}, upsert=True)
    return await db.settings.find_one({"key": "main"}, {"_id": 0})


@router.get("/certificates")
async def list_certificates(_: dict = Depends(require_admin)):
    return await db.certificates.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)


@router.get("/certificates/{cert_id}")
async def get_certificate(cert_id: str, _: dict = Depends(require_admin)):
    c = await db.certificates.find_one({"id": cert_id}, {"_id": 0})
    if not c:
        raise HTTPException(status_code=404, detail="Certificate not found")
    c["settings"] = await get_settings()
    return c


@router.post("/certificates", status_code=201)
async def create_certificate(body: CertificateIn, admin: dict = Depends(require_admin)):
    if body.type not in ("membership", "nikah", "death", "birth"):
        raise HTTPException(status_code=400, detail="Invalid certificate type")
    counter = await db.counters.find_one_and_update({"key": "certificate"}, {"$inc": {"seq": 1}}, upsert=True, return_document=True)
    doc = {
        "id": new_id(), "type": body.type, "data": body.data,
        "cert_no": f"CERT-{counter['seq']:05d}", "issued_on": today(),
        "issued_by": admin["name"], "created_at": now_iso(),
    }
    await db.certificates.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.delete("/certificates/{cert_id}")
async def delete_certificate(cert_id: str, _: dict = Depends(require_admin)):
    res = await db.certificates.delete_one({"id": cert_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Certificate not found")
    return {"ok": True}
