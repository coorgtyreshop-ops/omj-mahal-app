import asyncio
import logging
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List
from core import now_iso, db, get_current_user, require_admin, house_dues
from messaging import notify_house, LABELS_ML, sign, with_links, provider_status_async, tx, label_for

LABELS = {"varisankhya": "Varisankhya", "eid_fitr": "Cheriya Perunnal", "eid_adha": "Valiya Perunnal", "nabidinam": "Nabidinam", "building": "Building Fund"}

router = APIRouter(prefix="/notifications", tags=["notifications"])


class CustomMessageIn(BaseModel):
    body: str
    house_ids: Optional[List[str]] = None
    channel: str = ""


async def main_settings() -> dict:
    return await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}


def month_names(months: list) -> str:
    return ", ".join(months)


async def send_dues_reminders(house_ids: Optional[List[str]], channel: str):
    settings = await main_settings()
    channel = channel or settings.get("notify_channel", "whatsapp")
    query = {"id": {"$in": house_ids}} if house_ids else {}
    sent = 0
    for h in await db.houses.find(query, {"_id": 0}).to_list(5000):
        d = await house_dues(h)
        if not d["pending_count"]:
            continue
        body = tx(settings, "dues", no=h["house_no"], n=d["pending_count"], months=month_names(d["pending_months"]), amount=f"{d['pending_amount']:.0f}") + sign(settings)
        await notify_house(h, body, "dues_reminder", h["id"], channel)
        sent += 1
    return sent


async def broadcast(body: str, house_ids: Optional[List[str]], channel: str, kind: str, ref: str = ""):
    settings = await main_settings()
    channel = channel or settings.get("notify_channel", "whatsapp")
    query = {"id": {"$in": house_ids}} if house_ids else {}
    for h in await db.houses.find(query, {"_id": 0}).to_list(5000):
        await notify_house(h, body, kind, ref, channel)


@router.get("/outbox")
async def outbox(kind: Optional[str] = None, limit: int = 300, _: dict = Depends(require_admin)):
    """Messages waiting to be sent from the admin's own phone (WhatsApp / SMS links)."""
    q = {"status": "queued"}
    if kind:
        q["kind"] = kind
    rows = await db.messages.find(q, {"_id": 0}).sort("created_at", -1).to_list(limit)
    seen, out = set(), []
    for r in rows:
        key = (r["to"], r["body"])
        if key in seen:
            continue
        seen.add(key)
        out.append(with_links(r))
    return out


@router.post("/outbox/{msg_id}/sent")
async def outbox_mark_sent(msg_id: str, _: dict = Depends(require_admin)):
    m = await db.messages.find_one({"id": msg_id}, {"_id": 0})
    if not m:
        raise HTTPException(status_code=404, detail="Message not found")
    await db.messages.update_many({"to": m["to"], "body": m["body"], "status": "queued"}, {"$set": {"status": "sent_manual", "sent_at": now_iso()}})
    return {"ok": True}


@router.post("/outbox/clear")
async def outbox_clear(_: dict = Depends(require_admin)):
    res = await db.messages.update_many({"status": "queued"}, {"$set": {"status": "dismissed"}})
    return {"ok": True, "count": res.modified_count}


@router.get("/status")
async def status(_: dict = Depends(get_current_user)):
    s = await main_settings()
    st, _s = await provider_status_async()
    return {**st, "queued": await db.messages.count_documents({"status": "queued"}), "notify_channel": s.get("notify_channel", "whatsapp"),
            "notify_on_announcement": s.get("notify_on_announcement", True), "notify_on_payment": s.get("notify_on_payment", True)}


@router.get("")
async def list_messages(kind: Optional[str] = None, channel: Optional[str] = None, limit: int = 200, _: dict = Depends(require_admin)):
    q = {"channel": {"$ne": "app"}}
    if kind:
        q["kind"] = kind
    if channel:
        q["channel"] = channel
    return await db.messages.find(q, {"_id": 0}).sort("created_at", -1).to_list(min(limit, 1000))


@router.get("/mine")
async def my_notifications(user: dict = Depends(get_current_user)):
    """In-app notification feed: messages sent to this user's house (one entry per message, not per channel)."""
    targets = [f"user:{user['id']}"] + ([user["house_id"]] if user.get("house_id") else [])
    rows = await db.messages.find({"house_id": {"$in": targets}}, {"_id": 0, "id": 1, "kind": 1, "body": 1, "ref": 1, "created_at": 1, "channel": 1}).sort("created_at", -1).to_list(200)
    seen, out = set(), []
    for r in rows:
        key = (r["kind"], r.get("ref"), r["body"])
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
        if len(out) >= 40:
            break
    return out


@router.get("/summary")
async def summary(_: dict = Depends(require_admin)):
    out = {"total": await db.messages.count_documents({}), "by_status": {}, "by_kind": {}}
    async for r in db.messages.aggregate([{"$group": {"_id": "$status", "n": {"$sum": 1}}}]):
        out["by_status"][r["_id"]] = r["n"]
    async for r in db.messages.aggregate([{"$group": {"_id": "$kind", "n": {"$sum": 1}}}]):
        out["by_kind"][r["_id"]] = r["n"]
    return out


class ReminderIn(BaseModel):
    house_ids: Optional[List[str]] = None
    channel: str = ""


@router.post("/dues-reminder")
async def dues_reminder(body: Optional[ReminderIn] = None, _: dict = Depends(require_admin)):
    sent = await send_dues_reminders(body.house_ids if body else None, body.channel if body else "")
    return {"ok": True, "houses_notified": sent}


@router.post("/custom")
async def custom_message(body: CustomMessageIn, background: BackgroundTasks, _: dict = Depends(require_admin)):
    settings = await main_settings()
    text = body.body.strip() + sign(settings)
    background.add_task(broadcast, text, body.house_ids, body.channel, "custom")
    count = await db.houses.count_documents({"id": {"$in": body.house_ids}} if body.house_ids else {})
    return {"ok": True, "houses": count}


@router.delete("/clear")
async def clear_log(_: dict = Depends(require_admin)):
    res = await db.messages.delete_many({})
    return {"ok": True, "deleted": res.deleted_count}


# ---- Automatic dues reminders (SMS + WhatsApp until balance is cleared) ----

async def eligible_houses(settings: dict) -> list:
    from routes.collections import house_collections
    threshold = float(settings.get("auto_reminder_threshold", 1000) or 0)
    out = []
    for h in await db.houses.find({}, {"_id": 0}).to_list(5000):
        c = await house_collections(h, settings)
        d = {"pending_amount": c["total_pending"], "pending_count": c["varisankhya"]["pending_count"] if "pending_count" in c["varisankhya"] else len(c["varisankhya"]["pending_periods"]),
             "pending_months": c["varisankhya"]["pending_periods"], "breakdown": {k: v["pending"] for k, v in c.items() if isinstance(v, dict) and v.get("pending", 0) > 0}}
        if d["pending_amount"] >= threshold and d["pending_amount"] > 0:
            out.append({**h, "dues": d})
    return out


def balance_body(h: dict, d: dict, settings: dict) -> str:
    parts = ", ".join(f"{label_for(settings, k)} ₹{v:.0f}" for k, v in d["breakdown"].items())
    return tx(settings, "balance", no=h["house_no"], amount=f"{d['pending_amount']:.0f}", parts=parts) + sign(settings)


class BalanceReminderIn(BaseModel):
    house_ids: List[str]
    channel: Optional[str] = None


@router.post("/balance-reminder")
async def balance_reminder(body: BalanceReminderIn, _: dict = Depends(require_admin)):
    """Balance message (all collections) for chosen houses — returns WhatsApp/SMS links for phone-mode sending."""
    from routes.collections import house_collections
    settings = await main_settings()
    results = []
    for h in await db.houses.find({"id": {"$in": body.house_ids}}, {"_id": 0}).to_list(500):
        c = await house_collections(h, settings)
        if c["total_pending"] <= 0:
            continue
        d = {"pending_amount": c["total_pending"], "breakdown": {k: v["pending"] for k, v in c.items() if isinstance(v, dict) and v.get("pending", 0) > 0}}
        results.extend(await notify_house(h, balance_body(h, d, settings), "auto_reminder", h["id"], body.channel or settings.get("auto_reminder_channel", "whatsapp")))
    return {"sent": len(results), "results": results}


async def run_auto_reminders(force: bool = False) -> dict:
    settings = await main_settings()
    if not settings.get("auto_reminder_enabled", True) and not force:
        return {"ran": False, "reason": "disabled", "sent": 0}
    channel = settings.get("auto_reminder_channel", "both")
    interval = timedelta(days=int(settings.get("auto_reminder_days", 7) or 7))
    now = datetime.now(timezone.utc)
    sent, skipped = 0, 0
    for h in await eligible_houses(settings):
        last = h.get("last_auto_reminder")
        if last and not force and datetime.fromisoformat(last) + interval > now:
            skipped += 1
            continue
        await notify_house(h, balance_body(h, h["dues"], settings), "auto_reminder", h["id"], channel)
        await db.houses.update_one({"id": h["id"]}, {"$set": {"last_auto_reminder": now.isoformat()}})
        sent += 1
    await db.settings.update_one({"key": "auto_reminder_state"}, {"$set": {"last_run": now.isoformat(), "last_sent": sent}}, upsert=True)
    return {"ran": True, "sent": sent, "skipped": skipped}


async def auto_reminder_loop():
    await asyncio.sleep(20)
    while True:
        try:
            await run_auto_reminders()
        except Exception as exc:
            logging.getLogger("auto_reminder").warning("auto reminder failed: %s", exc)
        await asyncio.sleep(3600)


@router.get("/auto-reminder/status")
async def auto_reminder_status(_: dict = Depends(require_admin)):
    settings = await main_settings()
    state = await db.settings.find_one({"key": "auto_reminder_state"}, {"_id": 0}) or {}
    houses = await eligible_houses(settings)
    return {
        "enabled": settings.get("auto_reminder_enabled", True), "threshold": settings.get("auto_reminder_threshold", 1000),
        "days": settings.get("auto_reminder_days", 7), "channel": settings.get("auto_reminder_channel", "both"),
        "last_run": state.get("last_run"), "last_sent": state.get("last_sent", 0),
        "eligible": [{"id": h["id"], "house_no": h["house_no"], "head_name": h["head_name"], "phone": h.get("phone", ""),
                      "pending_amount": h["dues"]["pending_amount"], "pending_count": h["dues"]["pending_count"],
                      "last_auto_reminder": h.get("last_auto_reminder")} for h in houses],
    }


@router.post("/auto-reminder/run")
async def auto_reminder_run(_: dict = Depends(require_admin)):
    return await run_auto_reminders(force=True)
