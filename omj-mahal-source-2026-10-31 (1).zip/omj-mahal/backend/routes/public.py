from fastapi import APIRouter, HTTPException
from typing import Optional
from core import db
from routes.content import list_announcements, list_committee, get_settings
from routes.finance import list_funds
from routes.houses import classify

router = APIRouter(prefix="/public", tags=["public"])


async def require_guest_mode():
    s = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    if not s.get("guest_mode_enabled", True):
        raise HTTPException(status_code=403, detail="Guest access is disabled by the committee")


@router.get("/announcements")
async def public_announcements(category: Optional[str] = None):
    await require_guest_mode()
    return await list_announcements(category, None)


@router.get("/committee")
async def public_committee():
    await require_guest_mode()
    return await list_committee(None)


@router.get("/funds")
async def public_funds():
    await require_guest_mode()
    return [f for f in await list_funds(None) if f.get("active", True)]


@router.get("/ticker")
async def ticker(days: int = 7):
    from datetime import date, timedelta
    start = date.today()
    end = start + timedelta(days=days)
    rows = await db.announcements.find({"date": {"$gte": start.isoformat(), "$lte": end.isoformat()}}, {"_id": 0, "id": 1, "title": 1, "category": 1, "date": 1}).sort("date", 1).to_list(50)
    events = await db.events.find({"date": {"$gte": start.isoformat(), "$lte": end.isoformat()}}, {"_id": 0, "id": 1, "title": 1, "title_ml": 1, "date": 1, "time": 1}).sort("date", 1).to_list(50)
    for e in events:
        e["category"] = "event"
        e["kind"] = "event"
    rows = sorted(rows + events, key=lambda r: (r["date"], r.get("time", "")))
    for r in rows:
        r["when"] = "today" if r["date"] == start.isoformat() else "upcoming"
    return rows


@router.get("/display")
async def public_display(days: int = 45):
    """Poster showcase for login/guest/dashboard: upcoming programmes (until the event day passes)."""
    from datetime import date, timedelta
    from routes.events import with_hijri
    s = await get_settings()
    end = (date.today() + timedelta(days=days)).isoformat()
    fields = {"_id": 0, "id": 1, "title": 1, "title_ml": 1, "title_kn": 1, "date": 1, "time": 1, "venue": 1, "category": 1, "poster_url": 1, "guest_photos": 1, "guests": 1, "chair": 1, "organizer": 1, "leader": 1, "women_facility": 1, "women_note": 1, "description": 1}
    rows = await db.events.find({"date": {"$gte": date.today().isoformat(), "$lte": end}}, fields).sort([("date", 1), ("time", 1)]).to_list(30)
    return [with_hijri(r, s.get("hijri_adjustment", 0)) for r in rows]


@router.get("/events")
async def public_events(days: int = 60):
    await require_guest_mode()
    from datetime import date, timedelta
    from routes.events import with_hijri
    s = await get_settings()
    end = (date.today() + timedelta(days=days)).isoformat()
    rows = await db.events.find({"date": {"$gte": date.today().isoformat(), "$lte": end}}, {"_id": 0, "created_by": 0, "notified_at": 0, "poster_error": 0}).sort([("date", 1), ("time", 1)]).to_list(200)
    return [with_hijri(r, s.get("hijri_adjustment", 0)) for r in rows]


@router.get("/verify/{member_no}")
async def verify_member(member_no: str):
    m = await db.members.find_one({"member_no": member_no.strip().upper()}, {"_id": 0})
    if not m:
        raise HTTPException(status_code=404, detail="Member not found")
    house = await db.houses.find_one({"id": m["house_id"]}, {"_id": 0}) or {}
    s = await get_settings()
    classify(m, house)
    return {
        "valid": True,
        "member": {k: m.get(k, "") for k in ("name", "member_no", "relation", "gender", "member_type", "photo_url")},
        "house_no": house.get("house_no", ""), "head_name": house.get("head_name", ""), "ward": house.get("ward", ""),
        "member_since": (house.get("start_month") or house.get("created_at") or "")[:4],
        "settings": {k: s.get(k, "") for k in ("mahal_name", "mahal_name_ml", "mahal_name_kn", "short_name", "logo_url", "logo_preset", "address", "phone")},
    }
