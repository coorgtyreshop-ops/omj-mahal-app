import json
import io
import os
import jwt
import zipfile
import asyncio
import logging
from pathlib import Path
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Request
from fastapi.responses import Response
from core import db, new_id, now_iso, today, require_admin, get_current_user
from storage import put_object

router = APIRouter(prefix="/backup", tags=["backup"])
logger = logging.getLogger("backup")

APP = "OMJ Mahal"
SKIP = {"otps", "login_attempts", "backups", "ai_log"}
KEEP = 30
META = {"_id": 0, "data": 0}

ROOT = Path(__file__).resolve().parents[2]
SRC_INCLUDE = ["frontend", "backend", "memory/PRD.md", "README.md"]
SRC_SKIP_DIRS = {"node_modules", ".git", "build", "dist", "__pycache__", ".pytest_cache", ".ruff_cache", "coverage", ".emergent"}
SRC_SKIP_FILES = {".env", ".env.local", ".env.production", "yarn-error.log", "yarn.lock"}


def build_source_zip() -> bytes:
    """Whole app source (frontend + backend), secrets replaced by .env.example key lists."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for top in SRC_INCLUDE:
            p = ROOT / top
            if p.is_file():
                z.write(p, f"omj-mahal/{top}")
                continue
            for f in sorted(p.rglob("*")) if p.is_dir() else []:
                rel = f.relative_to(ROOT)
                if f.is_dir() or any(part in SRC_SKIP_DIRS for part in rel.parts) or f.name in SRC_SKIP_FILES or f.suffix in (".log", ".pyc"):
                    continue
                z.write(f, f"omj-mahal/{rel}")
        for env in ("frontend/.env", "backend/.env"):
            ep = ROOT / env
            if ep.exists():
                keys = [line.split("=", 1)[0] for line in ep.read_text().splitlines() if "=" in line and not line.startswith("#")]
                z.writestr(f"omj-mahal/{env}.example", "".join(f"{k}=\n" for k in keys))
    return buf.getvalue()


@router.get("/source-code")
async def source_code(request: Request, t: str = ""):
    """Admin download; or a time-limited share link made with POST /backup/source-link (?t=token)."""
    allowed = False
    if t:
        try:
            allowed = jwt.decode(t, os.environ["JWT_SECRET"], algorithms=["HS256"]).get("type") == "source_zip"
        except jwt.InvalidTokenError:
            allowed = False
    if not allowed:
        await require_admin(await get_current_user(request))
    data = await asyncio.to_thread(build_source_zip)
    return Response(content=data, media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="omj-mahal-source-{today()}.zip"'})


@router.post("/source-link")
async def source_link(_: dict = Depends(require_admin)):
    """Direct download link for the source ZIP, valid 24 h (code only — no passwords or data)."""
    token = jwt.encode({"type": "source_zip", "exp": datetime.now(timezone.utc) + timedelta(hours=24)}, os.environ["JWT_SECRET"], algorithm="HS256")
    return {"token": token, "expires_hours": 24}


async def dump() -> dict:
    data = {}
    for name in sorted(await db.list_collection_names()):
        if name in SKIP or name.startswith("system."):
            continue
        data[name] = await db[name].find({}, {"_id": 0}).to_list(200000)
    return {"app": APP, "format": 1, "created_at": now_iso(), "collections": data}


def serialize(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False, default=str)


def counts(payload: dict) -> dict:
    return {k: len(v) for k, v in payload["collections"].items() if v}


async def snapshot(kind: str = "auto", by: str = "system") -> dict:
    payload = await dump()
    raw = serialize(payload)
    doc = {"id": new_id(), "created_at": payload["created_at"], "kind": kind, "by": by, "size": len(raw.encode("utf-8")), "counts": counts(payload), "cloud": False, "data": raw}
    try:
        await asyncio.to_thread(put_object, f"mahal-app/backups/{doc['created_at'][:10]}-{doc['id'][:8]}.json", raw.encode("utf-8"), "application/json")
        doc["cloud"] = True
    except Exception as exc:
        logger.warning("Cloud copy of backup failed: %s", exc)
    await db.backups.insert_one(doc)
    old = await db.backups.find({}, {"_id": 0, "id": 1}).sort("created_at", -1).skip(KEEP).to_list(1000)
    if old:
        await db.backups.delete_many({"id": {"$in": [o["id"] for o in old]}})
    doc.pop("data"), doc.pop("_id", None)
    return doc


def validate(payload) -> dict:
    cols = payload.get("collections") if isinstance(payload, dict) else None
    if payload.get("app") != APP or not isinstance(cols, dict) or not any(k in cols for k in ("houses", "settings", "users")):
        raise HTTPException(status_code=400, detail="Not a valid OMJ Mahal backup file")
    return cols


async def apply(payload: dict, admin: dict) -> dict:
    cols = validate(payload)
    me = await db.users.find_one({"id": admin["id"]}, {"_id": 0})
    await snapshot("pre_restore", admin.get("name", ""))
    restored = 0
    for name, docs in cols.items():
        if name in SKIP or name.startswith("system.") or not isinstance(docs, list):
            continue
        await db[name].delete_many({})
        clean = [{k: v for k, v in d.items() if k != "_id"} for d in docs if isinstance(d, dict)]
        if clean:
            await db[name].insert_many(clean)
            restored += len(clean)
    if me and not await db.users.find_one({"id": me["id"]}):
        await db.users.delete_many({"phone": me.get("phone")})
        await db.users.insert_one(me)
    return {"ok": True, "restored": restored, "counts": {k: len(v) for k, v in cols.items() if isinstance(v, list) and v}}


@router.get("/export")
async def export_backup(user: dict = Depends(require_admin)):
    raw = serialize(await dump())
    await db.settings.update_one({"key": "main"}, {"$set": {"last_backup_download": now_iso(), "last_backup_by": user.get("name", "")}}, upsert=True)
    name = f"omj-mahal-backup-{today()}.json"
    return Response(content=raw, media_type="application/json", headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.post("/restore")
async def restore_from_file(file: UploadFile = File(...), user: dict = Depends(require_admin)):
    raw = await file.read()
    if len(raw) > 50 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Backup file too large")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Not a valid OMJ Mahal backup file")
    return await apply(payload, user)


@router.get("/snapshots")
async def list_snapshots(_: dict = Depends(require_admin)):
    rows = await db.backups.find({}, META).sort("created_at", -1).to_list(KEEP)
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "last_backup_download": 1}) or {}
    last_auto = next((r["created_at"] for r in rows if r["kind"] == "auto"), None)
    return {"snapshots": rows, "last_auto": last_auto, "last_download": s.get("last_backup_download"), "keep": KEEP}


@router.post("/snapshots", status_code=201)
async def create_snapshot(user: dict = Depends(require_admin)):
    return await snapshot("manual", user.get("name", ""))


@router.post("/snapshots/{sid}/restore")
async def restore_snapshot(sid: str, user: dict = Depends(require_admin)):
    doc = await db.backups.find_one({"id": sid}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Backup not found")
    return await apply(json.loads(doc["data"]), user)


@router.get("/snapshots/{sid}/download")
async def download_snapshot(sid: str, _: dict = Depends(require_admin)):
    doc = await db.backups.find_one({"id": sid}, {"_id": 0, "data": 1, "created_at": 1})
    if not doc:
        raise HTTPException(status_code=404, detail="Backup not found")
    return Response(content=doc["data"], media_type="application/json", headers={"Content-Disposition": f'attachment; filename="omj-mahal-backup-{doc["created_at"][:10]}.json"'})


@router.delete("/snapshots/{sid}")
async def delete_snapshot(sid: str, _: dict = Depends(require_admin)):
    res = await db.backups.delete_one({"id": sid})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Backup not found")
    return {"ok": True}


async def backup_loop():
    """Daily automatic snapshot (checked hourly); keeps the last KEEP copies."""
    await asyncio.sleep(90)
    while True:
        try:
            last = await db.backups.find_one({"kind": "auto"}, {"_id": 0, "created_at": 1}, sort=[("created_at", -1)])
            due = not last or datetime.now(timezone.utc) - datetime.fromisoformat(last["created_at"]) > timedelta(hours=24)
            if due:
                await snapshot("auto", "system")
                logger.info("Automatic backup created")
        except Exception as exc:
            logger.warning("Automatic backup failed: %s", exc)
        await asyncio.sleep(3600)
