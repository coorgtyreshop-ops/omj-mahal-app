import asyncio
import uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Response
from fastapi.responses import JSONResponse
from core import db, new_id, now_iso, require_admin, require_finance
from storage import put_object, get_object

router = APIRouter(tags=["files"])

MIME = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp", "gif": "image/gif", "svg": "image/svg+xml"}
MAX_BYTES = 3 * 1024 * 1024

PRESET_LOGOS = [
    {"id": "logo1", "url": "/logos/logo1.png", "icon192": "/icons/icon1-192.png", "icon512": "/icons/icon1-512.png", "favicon": "/icons/favicon1.png"},
    {"id": "logo2", "url": "/logos/logo2.png", "icon192": "/icons/icon2-192.png", "icon512": "/icons/icon2-512.png", "favicon": "/icons/favicon2.png"},
    {"id": "logo3", "url": "/logos/logo3.png", "icon192": "/icons/icon3-192.png", "icon512": "/icons/icon3-512.png", "favicon": "/icons/favicon3.png"},
    {"id": "logo4", "url": "/logos/logo4.png", "icon192": "/icons/icon4-192.png", "icon512": "/icons/icon4-512.png", "favicon": "/icons/favicon4.png"},
    {"id": "logo5", "url": "/logos/logo5.png", "icon192": "/icons/icon5-192.png", "icon512": "/icons/icon5-512.png", "favicon": "/icons/favicon5.png"},
    {"id": "logo6", "url": "/logos/logo6.png", "icon192": "/icons/icon6-192.png", "icon512": "/icons/icon6-512.png", "favicon": "/icons/favicon6.png"},
]


async def store_image(file: UploadFile, folder: str) -> dict:
    ext = (file.filename or "").rsplit(".", 1)[-1].lower() if "." in (file.filename or "") else ""
    if ext not in MIME:
        raise HTTPException(status_code=400, detail="Only PNG, JPG, WEBP, GIF or SVG images are allowed")
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=400, detail="Image too large (max 3 MB)")
    path = f"mahal-app/{folder}/{uuid.uuid4()}.{ext}"
    try:
        result = await asyncio.to_thread(put_object, path, data, MIME[ext])
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Upload failed: {exc}")
    file_id = new_id()
    await db.files.insert_one({
        "id": file_id, "storage_path": result["path"], "original_filename": file.filename, "folder": folder,
        "content_type": MIME[ext], "size": result.get("size", len(data)), "is_deleted": False, "created_at": now_iso(),
    })
    return {"id": file_id, "url": f"/api/files/{file_id}"}


@router.post("/upload/upi-qr")
async def upload_upi_qr(file: UploadFile = File(...), _: dict = Depends(require_finance)):
    """Committee's own Google Pay / bank QR picture (fallback when the UPI ID could not be read from it)."""
    return await store_image(file, "upi")


@router.get("/logos/presets")
async def logo_presets():
    return PRESET_LOGOS


@router.post("/upload/logo")
async def upload_logo(file: UploadFile = File(...), _: dict = Depends(require_admin)):
    stored = await store_image(file, "logos")
    await db.settings.update_one({"key": "main"}, {"$set": {"logo_url": stored["url"], "logo_preset": ""}}, upsert=True)
    return stored


@router.get("/files/{file_id}")
async def serve_file(file_id: str):
    rec = await db.files.find_one({"id": file_id, "is_deleted": False}, {"_id": 0})
    if not rec:
        raise HTTPException(status_code=404, detail="File not found")
    try:
        data, ctype = await asyncio.to_thread(get_object, rec["storage_path"])
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Download failed: {exc}")
    return Response(content=data, media_type=rec.get("content_type") or ctype, headers={"Cache-Control": "public, max-age=86400"})


@router.get("/manifest.json")
async def manifest():
    s = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    preset = next((p for p in PRESET_LOGOS if p["id"] == s.get("logo_preset")), PRESET_LOGOS[4])
    full = s.get("mahal_name") or "Mahal App"
    short = s.get("short_name") or (full if len(full) <= 12 else "Mahal App")
    icons = [
        {"src": preset["icon192"], "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
        {"src": preset["icon512"], "sizes": "512x512", "type": "image/png", "purpose": "any maskable"},
    ]
    body = {
        "name": short, "short_name": short, "description": f"{full} - Mahal management app",
        "start_url": "/", "scope": "/", "display": "standalone", "orientation": "portrait",
        "background_color": "#0D5C3A", "theme_color": "#0D5C3A", "lang": s.get("default_language", "en"), "icons": icons,
    }
    return JSONResponse(body, media_type="application/manifest+json", headers={"Cache-Control": "no-cache"})
