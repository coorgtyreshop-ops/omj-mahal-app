import asyncio
import base64
import logging
import os
import uuid
from datetime import date, timedelta
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, UploadFile, File, Form, Query
from pydantic import BaseModel
from hijridate import Gregorian
from core import db, new_id, now_iso, today, get_current_user, require_admin
from messaging import notify_house, send_message, with_salaam
from storage import put_object

router = APIRouter(prefix="/events", tags=["events"])
log = logging.getLogger("events")

CATEGORIES = ("programme", "class", "meeting", "eid", "nabidinam", "ramadan", "other")
HIJRI_KN = ["ಮುಹರ್ರಂ", "ಸಫರ್", "ರಬೀಉಲ್ ಅವ್ವಲ್", "ರಬೀಉಲ್ ಆಖಿರ್", "ಜಮಾದುಲ್ ಅವ್ವಲ್", "ಜಮಾದುಲ್ ಆಖಿರ್", "ರಜಬ್", "ಶಅಬಾನ್", "ರಮದಾನ್", "ಶವ್ವಾಲ್", "ದುಲ್ ಖಅದ್", "ದುಲ್ ಹಿಜ್ಜ"]
HIJRI_ML = ["മുഹറം", "സഫർ", "റബീഉൽ അവ്വൽ", "റബീഉൽ ആഖിർ", "ജമാദുൽ അവ്വൽ", "ജമാദുൽ ആഖിർ", "റജബ്", "ശഅ്ബാൻ", "റമദാൻ", "ശവ്വാൽ", "ദുൽഖഅദ്", "ദുൽഹിജ്ജ"]


class EventIn(BaseModel):
    title: str
    title_ml: str = ""
    title_kn: str = ""
    guests: str = ""
    chair: str = ""
    organizer: str = ""
    leader: str = ""
    women_facility: bool = False
    women_note: str = ""
    date: str
    time: str = ""
    venue: str = ""
    description: str = ""
    category: str = "programme"
    notify_members: bool = True


class PosterEditIn(BaseModel):
    instruction: str
    poster_id: Optional[str] = None


async def main_settings() -> dict:
    return await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}


def hijri_for(d: str, adjustment: int = 0) -> dict:
    try:
        g = date.fromisoformat(d) + timedelta(days=int(adjustment or 0))
        h = Gregorian(g.year, g.month, g.day).to_hijri()
        return {"day": h.day, "month": h.month, "year": h.year, "month_name": h.month_name(), "month_name_ml": HIJRI_ML[h.month - 1],
                "label": f"{h.day} {h.month_name()} {h.year}", "label_ml": f"{HIJRI_ML[h.month - 1]} {h.day}, {h.year}", "label_kn": f"{HIJRI_KN[h.month - 1]} {h.day}, {h.year}"}
    except Exception:
        return {}


def with_hijri(ev: dict, adj: int) -> dict:
    ev["hijri"] = hijri_for(ev.get("date", ""), adj)
    return ev


@router.get("/hijri")
async def hijri_today(d: Optional[str] = None):
    s = await main_settings()
    return {"date": d or today(), "adjustment": s.get("hijri_adjustment", 0), **hijri_for(d or today(), s.get("hijri_adjustment", 0))}


@router.get("")
async def list_events(from_: Optional[str] = Query(None, alias="from"), to: Optional[str] = None, _: dict = Depends(get_current_user)):
    q = {}
    if from_ or to:
        q["date"] = {k: v for k, v in (("$gte", from_), ("$lte", to)) if v}
    s = await main_settings()
    rows = await db.events.find(q, {"_id": 0}).sort([("date", 1), ("time", 1)]).to_list(2000)
    return [with_hijri(r, s.get("hijri_adjustment", 0)) for r in rows]


@router.get("/today")
async def today_events(_: dict = Depends(get_current_user)):
    s = await main_settings()
    end = (date.today() + timedelta(days=7)).isoformat()
    rows = await db.events.find({"date": {"$gte": today(), "$lte": end}}, {"_id": 0}).sort([("date", 1), ("time", 1)]).to_list(50)
    return {"hijri": hijri_for(today(), s.get("hijri_adjustment", 0)), "today": [with_hijri(r, s.get("hijri_adjustment", 0)) for r in rows if r["date"] == today()],
            "upcoming": [with_hijri(r, s.get("hijri_adjustment", 0)) for r in rows if r["date"] != today()]}


@router.get("/{event_id}")
async def get_event(event_id: str, _: dict = Depends(get_current_user)):
    ev = await db.events.find_one({"id": event_id}, {"_id": 0})
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    s = await main_settings()
    return with_hijri(ev, s.get("hijri_adjustment", 0))


@router.post("", status_code=201)
async def create_event(body: EventIn, admin: dict = Depends(require_admin)):
    if body.category not in CATEGORIES:
        raise HTTPException(status_code=400, detail="Invalid category")
    date.fromisoformat(body.date)
    doc = {**body.model_dump(), "id": new_id(), "posters": [], "guest_photos": [], "poster_url": "", "poster_status": "", "poster_error": "", "notified_at": None,
           "created_by": admin["name"], "created_at": now_iso()}
    await db.events.insert_one(doc)
    doc.pop("_id", None)
    s = await main_settings()
    await notify_khatheeb(doc, s)
    return with_hijri(doc, s.get("hijri_adjustment", 0))


@router.put("/{event_id}")
async def update_event(event_id: str, body: EventIn, _: dict = Depends(require_admin)):
    if body.category not in CATEGORIES:
        raise HTTPException(status_code=400, detail="Invalid category")
    date.fromisoformat(body.date)
    before = await db.events.find_one({"id": event_id}, {"_id": 0})
    if not before:
        raise HTTPException(status_code=404, detail="Event not found")
    await db.events.update_one({"id": event_id}, {"$set": body.model_dump()})
    if any(before.get(k) != getattr(body, k, None) for k in ("date", "time", "venue", "title", "status")):
        await notify_khatheeb({**before, **body.model_dump()}, await main_settings(), changed=True)
    return await get_event(event_id, _)


@router.delete("/{event_id}")
async def delete_event(event_id: str, _: dict = Depends(require_admin)):
    res = await db.events.delete_one({"id": event_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Event not found")
    return {"ok": True}


# ---------- Notifications ----------
def event_text(ev: dict, s: dict) -> str:
    name = s.get("short_name") or s.get("mahal_name", "Mahal")
    h = hijri_for(ev["date"], s.get("hijri_adjustment", 0))
    parts = [(f"{ev['title_ml']} / " if ev.get("title_ml") else "") + ev["title"]]
    parts.append(f"Date: {ev['date']}" + (f" ({h.get('label', '')})" if h else "") + (f", {ev['time']}" if ev.get("time") else ""))
    if ev.get("venue"):
        parts.append(f"Venue: {ev['venue']}")
    if ev.get("guests"):
        parts.append(f"അതിഥികൾ: {ev['guests'][:200]}")
    if ev.get("description"):
        parts.append(ev["description"][:200])
    parts.append(f"എല്ലാവരും പങ്കെടുക്കണമെന്ന് അഭ്യർത്ഥിക്കുന്നു. — {name}")
    return "\n".join(parts)


async def notify_khatheeb(ev: dict, s: dict, changed: bool = False):
    """Tell the Mahal Khatheeb/Usthad about a programme (WhatsApp in phone mode + in-app feed)."""
    kid = s.get("khatheeb_user_id")
    if not kid:
        return None
    u = await db.users.find_one({"id": kid}, {"_id": 0})
    if not u or not u.get("phone"):
        return None
    head = "പരിപാടിയിൽ മാറ്റം (ഖത്തീബിന് അറിയിപ്പ്)" if changed else "പുതിയ പരിപാടി (ഖത്തീബിന് അറിയിപ്പ്)"
    text = with_salaam(u.get("name", ""), f"{head}\n" + event_text(ev, s))
    return await send_message(u["phone"], text, "whatsapp", "event_khatheeb", ev["id"], u.get("name", ""), f"user:{kid}")


async def broadcast_event(ev: dict, s: dict):
    text = event_text(ev, s)
    for h in await db.houses.find({}, {"_id": 0}).to_list(5000):
        await notify_house(h, text, "event", ev["id"], s.get("notify_channel", "whatsapp"))
    await db.events.update_one({"id": ev["id"]}, {"$set": {"notified_at": now_iso()}})


@router.post("/{event_id}/notify")
async def notify_event(event_id: str, background: BackgroundTasks, _: dict = Depends(require_admin)):
    ev = await db.events.find_one({"id": event_id}, {"_id": 0})
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    s = await main_settings()
    background.add_task(broadcast_event, ev, s)
    houses = await db.houses.count_documents({})
    return {"ok": True, "houses": houses}


async def event_notify_loop():
    await asyncio.sleep(40)
    while True:
        try:
            s = await main_settings()
            async for ev in db.events.find({"date": today(), "notify_members": True, "notified_at": None}, {"_id": 0}):
                await broadcast_event(ev, s)
        except Exception as exc:
            log.warning("event notify failed: %s", exc)
        await asyncio.sleep(1800)


# ---------- AI posters (Gemini Nano Banana) ----------
SIZES = {
    "story": "vertical portrait 9:16 (1080x1920, WhatsApp status / Instagram story)",
    "square": "square 1:1 (1080x1080, WhatsApp / Instagram post)",
    "a4": "A4 portrait 210x297 mm proportions (print flyer, 2480x3508)",
    "landscape": "landscape 16:9 (1920x1080, TV / projector / Facebook cover)",
    "banner": "wide horizontal banner 3:1 (flex banner)",
}
COLOURS = {
    "green_gold": "deep emerald green with gold accents and cream text",
    "blue_gold": "royal navy blue with gold accents and white text",
    "maroon_gold": "rich maroon / burgundy with gold accents and cream text",
    "black_gold": "black and charcoal with luxurious gold accents",
    "white_green": "clean white / ivory background with emerald green and gold details, dark text",
    "teal_orange": "teal and warm orange, modern and energetic",
    "purple_gold": "deep purple with gold, elegant",
}
STYLES = {
    "classic": "elegant Islamic geometric patterns, deep emerald green and gold, arabesque border, mosque dome and minaret silhouette, soft light rays",
    "modern": "clean modern flat design, bold typography, emerald, gold and cream colour blocks, minimal Islamic motif",
    "festive": "festive celebration mood, crescent moon, lanterns, golden bokeh, warm night sky, rich colours",
    "ramadan": "Ramadan night atmosphere, crescent moon and stars, hanging lanterns, deep blue and gold",
    "minimal": "minimalist white-space design, one accent colour, thin lines, elegant typography, very little decoration",
    "photo": "photo-centred poster: the supplied photo fills most of the poster with a soft gradient overlay and text on top",
    "calligraphy": "Arabic calligraphy art background, ink brush textures, gold leaf, classic mosque architecture",
    "kids": "bright playful design for madrasa / children's programme, cheerful shapes, balloons, colourful",
}


LANG_SETS = {"ml": {"ml"}, "en": {"en"}, "kn": {"kn"}, "both": {"ml", "en"}, "kn_en": {"kn", "en"}, "all": {"ml", "kn", "en"}}


def poster_prompt(ev: dict, s: dict, language: str, style: str, extra: str, has_photo: bool, has_logo: bool, size: str = "story", colour: str = "") -> str:
    langs = LANG_SETS.get(language, {"ml", "en"})
    h = hijri_for(ev["date"], s.get("hijri_adjustment", 0))
    names = {"en": s.get("mahal_name", ""), "ml": s.get("mahal_name_ml", ""), "kn": s.get("mahal_name_kn", "")}
    titles = {"en": ev.get("title", ""), "ml": ev.get("title_ml", ""), "kn": ev.get("title_kn", "")}
    lang_names = {"en": "English", "ml": "Malayalam", "kn": "Kannada"}
    lines = [
        f"Design a premium, vivid event poster in {SIZES.get(size, SIZES['story'])} — the output image MUST have exactly this aspect ratio — for a Kerala/Karnataka Muslim mahal (mosque committee). Rich colours, glowing accents, festive but elegant.",
        f"Visual style: {STYLES.get(style, STYLES['classic'])}.",
        f"Colour theme: {COLOURS.get(colour, COLOURS['green_gold'])}." if colour else "",
        "Layout: mahal name at the top, large event title in the centre, date/time/venue block below, guests/speakers block, committee name at the bottom.",
        f"Poster text languages: {', '.join(lang_names[k] for k in ('ml', 'kn', 'en') if k in langs)}.",
    ]
    if has_logo:
        lines.append("The first reference image is the mahal's round logo — place it at the top centre exactly as it is (do not redraw or alter it).")
    if has_photo:
        lines.append(f"The {'second' if has_logo else 'first'} reference image is a photo supplied by the committee (guest / speaker / venue) — feature it prominently and blend it into the design.")
    lines.append("Render ALL text exactly as written below, spelled correctly in the given script, clearly legible, no extra words:")
    for k in ("ml", "kn", "en"):
        if k in langs and names.get(k):
            lines.append(f'- Mahal name ({lang_names[k]}): "{names[k]}"')
    for k in ("ml", "kn", "en"):
        if k in langs and titles.get(k):
            lines.append(f'- Title ({lang_names[k]}): "{titles[k]}"')
    if "en" not in langs and not any(titles.get(k) for k in langs):
        lines.append(f'- Title: "{ev["title"]}"')
    date_line = f"{ev['date']}" + (f" | {h.get('label', '')}" if h else "") + (f" | {ev['time']}" if ev.get("time") else "")
    lines.append(f'- Date line: "{date_line}"')
    if "ml" in langs and h:
        lines.append(f'- Hijri date (Malayalam): "{h.get("label_ml", "")}"')
    if "kn" in langs and h:
        lines.append(f'- Hijri date (Kannada): "{h.get("label_kn", "")}"')
    if ev.get("venue"):
        lines.append(f'- Venue: "{ev["venue"]}"')
    if ev.get("guests"):
        lines.append(f'- Guests / speakers (render exactly, one per line): "{ev["guests"][:300]}"')
    roles = [(lbl, ev.get(k)) for k, lbl in (("chair", "President / Chair (അധ്യക്ഷൻ)"), ("organizer", "Organised by (നടത്തുന്നത്)"), ("leader", "Led by (നേതൃത്വം)")) if ev.get(k)]
    for lbl, val in roles:
        lines.append(f'- {lbl}: "{val}"')
    if ev.get("women_facility"):
        lines.append(f'- Footer note (render exactly): "{ev.get("women_note") or "സ്ത്രീകൾക്ക് പ്രത്യേക സൗകര്യം ഉണ്ട്"}"')
    photos = ev.get("guest_photos") or []
    if photos:
        names = ", ".join(p.get("name", "") for p in photos if p.get("name"))
        lines.append(f"The guest portrait photos supplied (after logo/photo) belong to: {names}. Place each guest's photo in a neat circular frame with their name under it, in the guests block. Do not alter their faces.")
    if ev.get("description"):
        lines.append(f'- Short note: "{ev["description"][:160]}"')
    if extra:
        lines.append(f"Additional instructions from the committee: {extra}")
    lines.append("No watermarks, no gibberish text, no people’s faces unless in the supplied photo.")
    return "\n".join(l for l in lines if l)


def load_logo_bytes(s: dict) -> Optional[bytes]:
    preset = s.get("logo_preset") or "logo5"
    for p in (f"/app/frontend/public/logos/{preset}.png", f"/app/frontend/build/logos/{preset}.png"):
        if os.path.exists(p):
            with open(p, "rb") as f:
                return f.read()
    return None


async def gemini_image(prompt: str, images_b64: List[str]) -> bytes:
    from emergentintegrations.llm.chat import LlmChat, UserMessage, ImageContent
    api_key = os.environ.get("EMERGENT_LLM_KEY")
    if not api_key:
        raise RuntimeError("EMERGENT_LLM_KEY missing")
    chat = LlmChat(api_key=api_key, session_id=f"poster-{uuid.uuid4()}", system_message="You are a professional graphic designer creating event posters.")
    chat.with_model("gemini", "gemini-3.1-flash-image-preview").with_params(modalities=["image", "text"])
    msg = UserMessage(text=prompt, file_contents=[ImageContent(b) for b in images_b64] or None)
    text, images = await chat.send_message_multimodal_response(msg)
    if not images:
        raise RuntimeError(f"No image returned: {(text or '')[:200]}")
    return base64.b64decode(images[0]["data"])


async def save_poster(ev_id: str, data: bytes, language: str, note: str) -> dict:
    path = f"mahal-app/posters/{uuid.uuid4()}.png"
    result = await asyncio.to_thread(put_object, path, data, "image/png")
    file_id = new_id()
    await db.files.insert_one({"id": file_id, "storage_path": result["path"], "original_filename": f"poster-{ev_id}.png", "folder": "posters",
                               "content_type": "image/png", "size": result.get("size", len(data)), "is_deleted": False, "created_at": now_iso()})
    poster = {"id": new_id(), "url": f"/api/files/{file_id}", "language": language, "note": note[:200], "created_at": now_iso()}
    await db.events.update_one({"id": ev_id}, {"$push": {"posters": poster}, "$set": {"poster_url": poster["url"], "poster_status": "ready", "poster_error": ""}})
    return poster


async def run_generation(ev_id: str, prompt: str, images_b64: List[str], language: str, note: str):
    try:
        data = await gemini_image(prompt, images_b64)
        await save_poster(ev_id, data, language, note)
    except Exception as exc:
        log.warning("poster generation failed: %s", exc)
        await db.events.update_one({"id": ev_id}, {"$set": {"poster_status": "failed", "poster_error": str(exc)[:300]}})


async def start_job(ev: dict):
    if ev.get("poster_status") == "generating":
        raise HTTPException(status_code=409, detail="A poster is already being generated for this event")
    await db.events.update_one({"id": ev["id"]}, {"$set": {"poster_status": "generating", "poster_error": ""}})


@router.post("/{event_id}/poster")
async def generate_poster(event_id: str, background: BackgroundTasks, language: str = Form("both"), style: str = Form("classic"), instruction: str = Form(""),
                          size: str = Form("story"), colour: str = Form(""), photo: Optional[UploadFile] = File(None), _: dict = Depends(require_admin)):
    ev = await db.events.find_one({"id": event_id}, {"_id": 0})
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    await start_job(ev)
    s = await main_settings()
    images = []
    logo = await asyncio.to_thread(load_logo_bytes, s)
    if logo:
        images.append(base64.b64encode(logo).decode())
    has_photo = False
    if photo and photo.filename:
        data = await photo.read()
        if len(data) > 5 * 1024 * 1024:
            await db.events.update_one({"id": event_id}, {"$set": {"poster_status": ""}})
            raise HTTPException(status_code=400, detail="Photo too large (max 5 MB)")
        images.append(base64.b64encode(data).decode())
        has_photo = True
    for gp in (ev.get("guest_photos") or [])[:4]:
        f = await db.files.find_one({"id": gp["url"].rsplit("/", 1)[-1]}, {"_id": 0})
        if f:
            from storage import get_object
            try:
                data, _ct = await asyncio.to_thread(get_object, f["storage_path"])
                images.append(base64.b64encode(data).decode())
            except Exception as exc:
                log.warning("guest photo load failed: %s", exc)
    prompt = poster_prompt(ev, s, language, style, instruction, has_photo, bool(logo), size, colour)
    background.add_task(run_generation, event_id, prompt, images, language, instruction or style)
    return {"ok": True, "status": "generating"}


@router.post("/{event_id}/poster/edit")
async def edit_poster(event_id: str, body: PosterEditIn, background: BackgroundTasks, _: dict = Depends(require_admin)):
    ev = await db.events.find_one({"id": event_id}, {"_id": 0})
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    posters = ev.get("posters") or []
    poster = next((p for p in posters if p["id"] == body.poster_id), posters[-1] if posters else None)
    if not poster:
        raise HTTPException(status_code=400, detail="Generate a poster first")
    f = await db.files.find_one({"id": poster["url"].rsplit("/", 1)[-1]}, {"_id": 0})
    if not f:
        raise HTTPException(status_code=404, detail="Poster file not found")
    from storage import get_object
    data, _ct = await asyncio.to_thread(get_object, f["storage_path"])
    await start_job(ev)
    prompt = ("Edit the attached event poster. Keep the overall design, layout and all existing text exactly the same unless the instruction says otherwise. "
              f"Instruction: {body.instruction}. Keep all text legible and correctly spelled. Output the full edited poster.")
    background.add_task(run_generation, event_id, prompt, [base64.b64encode(data).decode()], poster.get("language", "both"), body.instruction)
    return {"ok": True, "status": "generating"}


# ---------- Guest photos ----------
@router.post("/{event_id}/guests", status_code=201)
async def add_guest_photo(event_id: str, name: str = Form(""), role: str = Form(""), photo: UploadFile = File(...), _: dict = Depends(require_admin)):
    ev = await db.events.find_one({"id": event_id}, {"_id": 0, "id": 1})
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    from routes.files import store_image
    stored = await store_image(photo, "guests")
    guest = {"id": new_id(), "name": name.strip(), "role": role.strip(), "url": stored["url"], "created_at": now_iso()}
    await db.events.update_one({"id": event_id}, {"$push": {"guest_photos": guest}})
    return guest


@router.delete("/{event_id}/guests/{guest_id}")
async def delete_guest_photo(event_id: str, guest_id: str, _: dict = Depends(require_admin)):
    res = await db.events.update_one({"id": event_id}, {"$pull": {"guest_photos": {"id": guest_id}}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Event not found")
    return {"ok": True}


@router.put("/{event_id}/poster/{poster_id}/cover")
async def set_cover(event_id: str, poster_id: str, _: dict = Depends(require_admin)):
    ev = await db.events.find_one({"id": event_id}, {"_id": 0})
    poster = next((p for p in (ev or {}).get("posters", []) if p["id"] == poster_id), None)
    if not poster:
        raise HTTPException(status_code=404, detail="Poster not found")
    await db.events.update_one({"id": event_id}, {"$set": {"poster_url": poster["url"]}})
    return {"ok": True}


@router.delete("/{event_id}/poster/{poster_id}")
async def delete_poster(event_id: str, poster_id: str, _: dict = Depends(require_admin)):
    ev = await db.events.find_one({"id": event_id}, {"_id": 0})
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    posters = [p for p in ev.get("posters", []) if p["id"] != poster_id]
    cover = ev.get("poster_url")
    if not any(p["url"] == cover for p in posters):
        cover = posters[-1]["url"] if posters else ""
    await db.events.update_one({"id": event_id}, {"$set": {"posters": posters, "poster_url": cover}})
    return {"ok": True}
