from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List
from core import (
    can_finance, db, new_id, now_iso, today, current_month, get_current_user, require_admin, require_finance,
    next_receipt_no, house_dues,
)
from messaging import receipt_text
from routes.houses import member_stats

router = APIRouter(tags=["finance"])


class PaymentIn(BaseModel):
    house_id: str
    months: List[str] = []
    years: List[str] = []
    type: str = "varisankhya"
    amount: float
    mode: str = "cash"
    date: Optional[str] = None
    note: str = ""
    member_id: Optional[str] = None  # secondary member who paid (None = head / whole house)


class FundIn(BaseModel):
    name: str
    description: str = ""
    target: float = 0
    active: bool = True


class DonationIn(BaseModel):
    fund_id: str
    donor_name: str
    house_id: Optional[str] = None
    amount: float
    mode: str = "cash"
    date: Optional[str] = None
    note: str = ""


class ExpenseIn(BaseModel):
    category: str
    amount: float
    date: Optional[str] = None
    description: str = ""
    mode: str = "cash"
    paid_to: str = ""


def scope_house(user: dict, house_id: Optional[str]) -> dict:
    if user["role"] == "admin":
        return {"house_id": house_id} if house_id else {}
    return {"house_id": user.get("house_id") or "__none__"}


async def attach_house(rows: list):
    houses = {h["id"]: h for h in await db.houses.find({}, {"_id": 0, "id": 1, "house_no": 1, "head_name": 1}).to_list(5000)}
    for r in rows:
        h = houses.get(r.get("house_id"), {})
        r["house_no"] = h.get("house_no", "")
        r["head_name"] = h.get("head_name", "")
    return rows


# ---------- Subscription payments ----------
@router.get("/payments")
async def list_payments(house_id: Optional[str] = None, month: Optional[str] = None, year: Optional[str] = None, type: Optional[str] = None, user: dict = Depends(get_current_user)):
    query = scope_house(user, house_id)
    if type == "varisankhya":
        query["type"] = {"$in": [None, "varisankhya"]}
    elif type:
        query["type"] = type
    if month:
        query["months"] = month
    if year:
        query["date"] = {"$regex": f"^{year}"}
    rows = await db.payments.find(query, {"_id": 0}).sort("date", -1).to_list(5000)
    return await attach_house(rows)


@router.get("/payments/dues")
async def dues(user: dict = Depends(get_current_user)):
    query = {} if user["role"] == "admin" else {"id": user.get("house_id") or "__none__"}
    out = []
    for h in await db.houses.find(query, {"_id": 0}).sort("house_no", 1).to_list(5000):
        d = await house_dues(h)
        if d["pending_count"] > 0:
            out.append({**{k: h.get(k) for k in ("id", "house_no", "head_name", "phone", "ward", "subscription_amount")}, **d})
    return out


@router.get("/payments/{payment_id}")
async def get_payment(payment_id: str, user: dict = Depends(get_current_user)):
    row = await db.payments.find_one({"id": payment_id, **scope_house(user, None)}, {"_id": 0})
    if not row:
        raise HTTPException(status_code=404, detail="Payment not found")
    settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    (await attach_house([row]))
    row["settings"] = settings
    return row


YEARLY_TYPES = ("eid_fitr", "eid_adha", "nabidinam")
LABELS = {"varisankhya": "Varisankhya", "eid_fitr": "Cheriya Perunnal", "eid_adha": "Valiya Perunnal", "nabidinam": "Nabidinam", "building": "Building Fund", "special": "Special Collection", "auction": "Auction", "pledge": "Pledge / Other", "old_balance": "Old Balance"}


@router.post("/payments", status_code=201)
async def create_payment(body: PaymentIn, background: BackgroundTasks, admin: dict = Depends(require_finance)):
    house = await db.houses.find_one({"id": body.house_id}, {"_id": 0})
    if not house:
        raise HTTPException(status_code=404, detail="House not found")
    from routes.collections import heads
    settings0 = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    if body.type not in heads(settings0):
        raise HTTPException(status_code=400, detail="Invalid collection type")
    if body.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    # Partial payments allowed: any amount reduces the balance of that head; months/years are informational.
    doc = body.model_dump()
    if doc.get("member_id"):
        payer = await db.members.find_one({"id": doc["member_id"], "house_id": body.house_id}, {"_id": 0, "name": 1})
        if not payer:
            raise HTTPException(status_code=400, detail="Member not in this house")
        doc["member_name"] = payer["name"]
    if body.type == "varisankhya" and not body.months:
        d = await house_dues(house)
        doc["months"] = d["pending_months"][: int(body.amount // max(house.get("subscription_amount", 1) or 1, 1))]
    doc["partial"] = bool(body.type == "varisankhya" and house.get("subscription_amount") and body.amount % house["subscription_amount"])
    doc.update({
        "id": new_id(), "receipt_no": await next_receipt_no("subscription"),
        "date": body.date or today(), "created_by": admin["name"], "created_at": now_iso(),
    })
    await db.payments.insert_one(doc)
    doc.pop("_id", None)
    settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    doc["balance_after"] = await balance_snapshot(house, body.type, settings)
    await db.payments.update_one({"id": doc["id"]}, {"$set": {"balance_after": doc["balance_after"]}})
    if settings.get("notify_on_payment", True):
        background.add_task(receipt_text, house, doc, settings)
    return doc


async def balance_snapshot(house: dict, typ: str, settings: dict) -> dict:
    """Balance of this head + overall, right after a payment — stored on the receipt."""
    from routes.collections import house_collections
    c = await house_collections(house, settings)
    head = c.get(typ) or {}
    return {"head_due": head.get("due", 0), "head_paid": head.get("paid", 0), "head_pending": head.get("pending", 0), "head_advance": head.get("advance", 0), "total_pending": c["total_pending"],
            "breakdown": {k: v["pending"] for k, v in c.items() if isinstance(v, dict) and v.get("pending", 0) > 0}}


class PaymentUpdate(BaseModel):
    amount: Optional[float] = None
    date: Optional[str] = None
    mode: Optional[str] = None
    note: Optional[str] = None
    type: Optional[str] = None


@router.put("/payments/{payment_id}")
async def update_payment(payment_id: str, body: PaymentUpdate, admin: dict = Depends(require_finance)):
    """Treasurer corrects a recorded payment (amount / date / mode / head / note); balances recompute automatically."""
    row = await db.payments.find_one({"id": payment_id}, {"_id": 0})
    if not row:
        raise HTTPException(status_code=404, detail="Payment not found")
    changes = {k: v for k, v in body.model_dump().items() if v is not None}
    if "amount" in changes and changes["amount"] <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    from routes.collections import heads
    if "type" in changes and changes["type"] not in heads(await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}):
        raise HTTPException(status_code=400, detail="Invalid collection type")
    if not changes:
        return row
    changes.update({"edited_by": admin["name"], "edited_at": now_iso()})
    await db.payments.update_one({"id": payment_id}, {"$set": changes})
    house = await db.houses.find_one({"id": row["house_id"]}, {"_id": 0})
    if house:
        settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
        changes["balance_after"] = await balance_snapshot(house, changes.get("type", row["type"]), settings)
        await db.payments.update_one({"id": payment_id}, {"$set": {"balance_after": changes["balance_after"]}})
    return {**row, **changes}


@router.delete("/payments/{payment_id}")
async def delete_payment(payment_id: str, _: dict = Depends(require_finance)):
    res = await db.payments.delete_one({"id": payment_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Payment not found")
    return {"ok": True}


# ---------- Funds & donations ----------
@router.get("/funds")
async def list_funds(user: dict = Depends(get_current_user)):
    """Fund totals (raised/target/donors) are visible only to admin/treasurer; members & guests see names only."""
    funds = await db.funds.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)
    if not user or not await can_finance(user):
        for f in funds:
            for k in ("target", "raised", "donor_count"):
                f.pop(k, None)
        return funds
    totals = {}
    async for row in db.donations.aggregate([{"$group": {"_id": "$fund_id", "total": {"$sum": "$amount"}, "count": {"$sum": 1}}}]):
        totals[row["_id"]] = row
    for f in funds:
        t = totals.get(f["id"], {})
        f["raised"] = t.get("total", 0)
        f["donor_count"] = t.get("count", 0)
    return funds


@router.post("/funds", status_code=201)
async def create_fund(body: FundIn, _: dict = Depends(require_admin)):
    doc = body.model_dump()
    doc.update({"id": new_id(), "created_at": now_iso()})
    await db.funds.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.put("/funds/{fund_id}")
async def update_fund(fund_id: str, body: FundIn, _: dict = Depends(require_admin)):
    res = await db.funds.update_one({"id": fund_id}, {"$set": body.model_dump()})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Fund not found")
    return await db.funds.find_one({"id": fund_id}, {"_id": 0})


@router.delete("/funds/{fund_id}")
async def delete_fund(fund_id: str, _: dict = Depends(require_admin)):
    res = await db.funds.delete_one({"id": fund_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Fund not found")
    await db.donations.delete_many({"fund_id": fund_id})
    return {"ok": True}


@router.get("/donations")
async def list_donations(fund_id: Optional[str] = None, user: dict = Depends(get_current_user)):
    query = {}
    if fund_id:
        query["fund_id"] = fund_id
    if user["role"] != "admin":
        query["house_id"] = user.get("house_id") or "__none__"
    rows = await db.donations.find(query, {"_id": 0}).sort("date", -1).to_list(5000)
    funds = {f["id"]: f["name"] for f in await db.funds.find({}, {"_id": 0, "id": 1, "name": 1}).to_list(500)}
    for r in rows:
        r["fund_name"] = funds.get(r["fund_id"], "")
    return rows


@router.get("/donations/{donation_id}")
async def get_donation(donation_id: str, user: dict = Depends(get_current_user)):
    query = {"id": donation_id}
    if user["role"] != "admin":
        query["house_id"] = user.get("house_id") or "__none__"
    row = await db.donations.find_one(query, {"_id": 0})
    if not row:
        raise HTTPException(status_code=404, detail="Donation not found")
    fund = await db.funds.find_one({"id": row["fund_id"]}, {"_id": 0}) or {}
    row["fund_name"] = fund.get("name", "")
    row["settings"] = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    return row


@router.post("/donations", status_code=201)
async def create_donation(body: DonationIn, admin: dict = Depends(require_finance)):
    if not await db.funds.find_one({"id": body.fund_id}):
        raise HTTPException(status_code=404, detail="Fund not found")
    doc = body.model_dump()
    doc.update({
        "id": new_id(), "receipt_no": await next_receipt_no("donation"),
        "date": body.date or today(), "created_by": admin["name"], "created_at": now_iso(),
    })
    await db.donations.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.delete("/donations/{donation_id}")
async def delete_donation(donation_id: str, _: dict = Depends(require_finance)):
    res = await db.donations.delete_one({"id": donation_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Donation not found")
    return {"ok": True}


# ---------- Expenses ----------
@router.get("/expenses")
async def list_expenses(year: Optional[str] = None, month: Optional[str] = None, category: Optional[str] = None, _: dict = Depends(require_admin)):
    query = {}
    if month:
        query["date"] = {"$regex": f"^{month}"}
    elif year:
        query["date"] = {"$regex": f"^{year}"}
    if category:
        query["category"] = category
    return await db.expenses.find(query, {"_id": 0}).sort("date", -1).to_list(5000)


@router.post("/expenses", status_code=201)
async def create_expense(body: ExpenseIn, admin: dict = Depends(require_admin)):
    doc = body.model_dump()
    doc.update({"id": new_id(), "date": body.date or today(), "created_by": admin["name"], "created_at": now_iso()})
    await db.expenses.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.put("/expenses/{expense_id}")
async def update_expense(expense_id: str, body: ExpenseIn, _: dict = Depends(require_admin)):
    update = body.model_dump()
    update["date"] = body.date or today()
    res = await db.expenses.update_one({"id": expense_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Expense not found")
    return await db.expenses.find_one({"id": expense_id}, {"_id": 0})


@router.delete("/expenses/{expense_id}")
async def delete_expense(expense_id: str, _: dict = Depends(require_admin)):
    res = await db.expenses.delete_one({"id": expense_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Expense not found")
    return {"ok": True}


# ---------- Reports & dashboard ----------
async def sum_where(coll, query: dict) -> float:
    """Sum of amounts. Payments are only counted for houses that still exist — money of a deleted house never lingers in totals."""
    if coll == "payments":
        live = [h["id"] async for h in db.houses.find({}, {"_id": 0, "id": 1})]
        query = {**query, "house_id": {"$in": live}}
    total = 0.0
    async for row in db[coll].aggregate([{"$match": query}, {"$group": {"_id": None, "t": {"$sum": "$amount"}}}]):
        total = row["t"]
    return total


@router.get("/reports/summary")
async def report_summary(year: Optional[str] = None, month: Optional[str] = None, _: dict = Depends(require_admin)):
    prefix = month or year or ""
    q = {"date": {"$regex": f"^{prefix}"}} if prefix else {}
    subs = await sum_where("payments", q)
    dons = await sum_where("donations", q)
    exps = await sum_where("expenses", q)
    by_cat = []
    async for row in db.expenses.aggregate([{"$match": q}, {"$group": {"_id": "$category", "total": {"$sum": "$amount"}}}, {"$sort": {"total": -1}}]):
        by_cat.append({"category": row["_id"], "total": row["total"]})
    by_fund = []
    async for row in db.donations.aggregate([{"$match": q}, {"$group": {"_id": "$fund_id", "total": {"$sum": "$amount"}}}]):
        f = await db.funds.find_one({"id": row["_id"]}, {"_id": 0, "name": 1}) or {}
        by_fund.append({"fund": f.get("name", ""), "total": row["total"]})
    monthly = []
    if year and not month:
        for m in range(1, 13):
            mp = f"{year}-{m:02d}"
            mq = {"date": {"$regex": f"^{mp}"}}
            monthly.append({
                "month": mp,
                "subscriptions": await sum_where("payments", mq),
                "donations": await sum_where("donations", mq),
                "expenses": await sum_where("expenses", mq),
            })
    return {
        "period": prefix or "all",
        "income": {"subscriptions": subs, "donations": dons, "total": subs + dons},
        "expenses": {"total": exps, "by_category": by_cat},
        "balance": subs + dons - exps,
        "donations_by_fund": by_fund,
        "monthly": monthly,
    }


async def collection_totals(settings: dict) -> list:
    """Per collection head across all houses: what is due this year, what came in, what is still pending."""
    from routes.collections import house_collections, heads, custom_heads
    hd = heads(settings)
    names = {h["id"]: h["name"] for h in custom_heads(settings)}
    tot = {k: {"type": k, "label": names.get(k), "due": 0.0, "paid": 0.0, "pending": 0.0, "houses": 0} for k in hd}
    async for h in db.houses.find({}, {"_id": 0}):
        c = await house_collections(h, settings)
        for k in hd:
            v = c.get(k) or {}
            if not v or (v.get("due", 0) <= 0 and v.get("paid", 0) <= 0):
                continue
            t = tot[k]
            t["due"] += v.get("due", 0); t["paid"] += v.get("paid", 0); t["pending"] += v.get("pending", 0); t["houses"] += 1
    return [t for t in tot.values() if t["houses"] > 0 or t["type"] in ("varisankhya", "eid_fitr", "eid_adha", "nabidinam", "building")]


async def member_inbox() -> dict:
    """What members wrote to the committee: new suggestions/messages + latest group-chat posts."""
    sugg = await db.suggestions.find({}, {"_id": 0, "id": 1, "title": 1, "details": 1, "name": 1, "house_no": 1, "created_at": 1, "status": 1}).sort("created_at", -1).to_list(5)
    chat = await db.chat_messages.find({"room": "all", "deleted": {"$ne": True}, "role": {"$ne": "admin"}}, {"_id": 0, "id": 1, "text": 1, "name": 1, "house_no": 1, "created_at": 1, "audio_url": 1}).sort("created_at", -1).to_list(5)
    items = [{"kind": "suggestion", "id": x["id"], "text": x["title"] + (f" — {x['details']}" if x.get("details") else ""), "name": x.get("name", ""), "house_no": x.get("house_no", ""), "created_at": x["created_at"], "status": x.get("status", "new")} for x in sugg]
    items += [{"kind": "chat", "id": x["id"], "text": x.get("text") or "🎤", "name": x.get("name", ""), "house_no": x.get("house_no", ""), "created_at": x["created_at"], "status": ""} for x in chat]
    items.sort(key=lambda x: x["created_at"], reverse=True)
    return {"new_suggestions": await db.suggestions.count_documents({"status": "new"}), "items": items[:6]}


@router.get("/dashboard")
async def dashboard(user: dict = Depends(get_current_user)):
    cm = current_month()
    announcements = await db.announcements.find({}, {"_id": 0}).sort("date", -1).to_list(5)
    if user["role"] == "admin":
        total_pending = 0.0
        pending_houses = 0
        for h in await db.houses.find({}, {"_id": 0}).to_list(5000):
            d = await house_dues(h)
            if d["pending_count"]:
                pending_houses += 1
                total_pending += d["pending_amount"]
        year = cm[:4]
        yq = {"date": {"$regex": f"^{year}"}}
        income = await sum_where("payments", yq) + await sum_where("donations", yq)
        birthdays = []
        async for m in db.members.find({"dob": {"$regex": f"^\\d{{4}}-{cm[5:]}-"}}, {"_id": 0, "id": 1, "name": 1, "dob": 1, "house_id": 1}):
            h = await db.houses.find_one({"id": m["house_id"]}, {"_id": 0, "house_no": 1}) or {}
            birthdays.append({**m, "house_no": h.get("house_no", ""), "day": int(m["dob"][8:10]), "age": int(cm[:4]) - int(m["dob"][:4])})
        birthdays.sort(key=lambda x: x["day"])
        settings = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
        setup = {
            "settings": bool(settings.get("address")) and settings.get("mahal_name") not in ("", "Masjid Mahal Committee"),
            "houses": await db.houses.count_documents({}) > 0,
            "members": await db.members.count_documents({}) > 0,
            "payments": await db.payments.count_documents({}) > 0,
            "announcements": await db.announcements.count_documents({}) > 0,
            "committee": await db.committee.count_documents({}) > 0,
            "logins": await db.users.count_documents({"role": "member"}) > 0,
        }
        return {
            "role": "admin",
            "birthdays": birthdays,
            "setup": setup,
            "houses": await db.houses.count_documents({}),
            "members": await db.members.count_documents({}),
            "member_types": await member_stats(user),
            "this_month_collection": await sum_where("payments", {"date": {"$regex": f"^{cm}"}}),
            "this_month_donations": await sum_where("donations", {"date": {"$regex": f"^{cm}"}}),
            "this_month_expenses": await sum_where("expenses", {"date": {"$regex": f"^{cm}"}}),
            "pending_amount": total_pending,
            "pending_houses": pending_houses,
            "year_balance": income - await sum_where("expenses", yq),
            "announcements": announcements,
            "funds": await list_funds(user),
            "inbox": await member_inbox(),
            "collections": await collection_totals(settings),
        }
    house = await db.houses.find_one({"id": user.get("house_id") or "__none__"}, {"_id": 0})
    released = bool(house and house.get("statement_released"))
    mid = user.get("member_id") or None
    d = await house_dues(house, mid) if (house and released) else None
    member = await db.members.find_one({"id": mid}, {"_id": 0, "id": 1, "name": 1, "member_no": 1}) if mid else None
    return {
        "role": "member",
        "house": house,
        "member": member,
        "released": released,
        "released_at": (house or {}).get("statement_released_at", ""),
        "dues": d,
        "member_count": await db.members.count_documents({"house_id": house["id"]}) if house else 0,
        "announcements": announcements,
        "funds": await list_funds(user),
    }
