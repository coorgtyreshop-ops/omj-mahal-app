import os
import asyncio
import logging
from typing import Optional
from urllib.parse import quote
from core import db, new_id, now_iso

logger = logging.getLogger("messaging")


_provider_cache = {"at": 0.0, "value": None}


def _creds(settings: dict) -> dict:
    """Twilio credentials: Settings (entered by admin in the app) override .env."""
    return {
        "sid": (settings.get("twilio_sid") or os.environ.get("TWILIO_ACCOUNT_SID", "")).strip(),
        "token": (settings.get("twilio_token") or os.environ.get("TWILIO_AUTH_TOKEN", "")).strip(),
        "sms_from": (settings.get("twilio_sms_from") or os.environ.get("TWILIO_SMS_FROM", "")).strip(),
        "whatsapp_from": (settings.get("twilio_whatsapp_from") or os.environ.get("TWILIO_WHATSAPP_FROM", "")).strip(),
        "provider": settings.get("notify_provider") or "phone",
    }


def provider_status(settings: Optional[dict] = None) -> dict:
    c = _creds(settings or {})
    live = c["provider"] == "twilio" and bool(c["sid"] and c["token"])
    return {
        "mode": "live" if live else "phone",
        "provider": c["provider"],
        "sms_enabled": live and bool(c["sms_from"]),
        "whatsapp_enabled": live and bool(c["whatsapp_from"]),
        "configured": bool(c["sid"] and c["token"]),
    }


async def provider_status_async() -> dict:
    import time
    if time.time() - _provider_cache["at"] > 5 or _provider_cache["value"] is None:
        s = await db.settings.find_one({"key": "main"}, {"_id": 0, "twilio_sid": 1, "twilio_token": 1, "twilio_sms_from": 1, "twilio_whatsapp_from": 1, "notify_provider": 1}) or {}
        _provider_cache.update({"at": time.time(), "value": (provider_status(s), s)})
    return _provider_cache["value"]


def wa_link(to_e164: str, body: str) -> str:
    return f"https://wa.me/{to_e164.lstrip('+')}?text={quote(body)}"


def sms_link(to_e164: str, body: str) -> str:
    return f"sms:{to_e164}?body={quote(body)}"


def with_links(log: dict) -> dict:
    if log.get("to", "").startswith("+"):
        log["wa_link"] = wa_link(log["to"], log["body"])
        log["sms_link"] = sms_link(log["to"], log["body"])
    return log


def e164(phone: str) -> str:
    digits = "".join(ch for ch in (phone or "") if ch.isdigit())
    if not digits:
        return ""
    if len(digits) == 10:
        return f"+91{digits}"
    return f"+{digits}"


def _twilio_send(to: str, body: str, channel: str, c: dict) -> str:
    from twilio.rest import Client
    client = Client(c["sid"], c["token"])
    if channel == "whatsapp":
        frm = c["whatsapp_from"] if c["whatsapp_from"].startswith("whatsapp:") else f"whatsapp:{c['whatsapp_from']}"
        msg = client.messages.create(from_=frm, to=f"whatsapp:{to}", body=body)
    else:
        msg = client.messages.create(from_=c["sms_from"], to=to, body=body)
    return msg.sid


async def send_message(to: str, body: str, channel: str, kind: str, ref: str = "", recipient_name: str = "", house_id: str = "") -> dict:
    to_e164 = e164(to)
    status, s = await provider_status_async()
    log = {
        "id": new_id(), "to": to_e164 or (to or ""), "recipient_name": recipient_name, "channel": channel,
        "kind": kind, "body": body, "ref": ref, "house_id": house_id, "status": "queued", "error": "", "provider_sid": "", "created_at": now_iso(),
    }
    if not to_e164:
        log.update({"status": "failed", "error": "No phone number"})
    elif status["mode"] == "live" and status.get(f"{channel}_enabled"):
        try:
            log["provider_sid"] = await asyncio.to_thread(_twilio_send, to_e164, body, channel, _creds(s))
            log["status"] = "sent"
        except Exception as exc:
            log.update({"status": "failed", "error": str(exc)[:300]})
            logger.warning("Twilio send failed: %s", exc)
    else:
        logger.info("[QUEUED %s] to %s: %s", channel.upper(), to_e164, body[:80])
    await db.messages.insert_one(log)
    log.pop("_id", None)
    return with_links(log)


SALAAM = "അസ്സലാമു അലൈക്കും"
SALAAM_KN = "ಅಸ್ಸಲಾಮು ಅಲೈಕುಂ"
LABELS_ML = {"varisankhya": "വരിസംഖ്യ", "eid_fitr": "ചെറിയ പെരുന്നാൾ", "eid_adha": "വലിയ പെരുന്നാൾ", "nabidinam": "നബിദിനം", "building": "Building Fund", "special": "പ്രത്യേക പിരിവ്", "auction": "ലേലം", "pledge": "വാഗ്ദാനം / മറ്റ്", "old_balance": "പഴയ ബാക്കി", "donation": "സംഭാവന"}
LABELS_KN = {"varisankhya": "ವರಿಸಂಖ್ಯೆ", "eid_fitr": "ಚಿಕ್ಕ ಪೆರುನ್ನಾಳ್", "eid_adha": "ದೊಡ್ಡ ಪೆರುನ್ನಾಳ್", "nabidinam": "ನಬಿದಿನ", "building": "Building Fund", "special": "ವಿಶೇಷ ಸಂಗ್ರಹ", "auction": "ಹರಾಜು", "pledge": "ವಾಗ್ದಾನ / ಇತರ", "old_balance": "ಹಳೆಯ ಬಾಕಿ", "donation": "ದೇಣಿಗೆ"}

# Message templates per notification language (settings.notify_language: ml | kn)
TXT = {
    "ml": {
        "address": "ബഹുമാനപ്പെട്ട മഹല്ല് അംഗം {who},", "son_of": " ({father}-ന്റെ മകൻ)", "sign": "ജസാക്കല്ലാഹ് ഖൈർ — {name}",
        "receipt": "{label}-ലേക്ക് ₹{amount}{period} {date}-ന് സ്വീകരിച്ചു. രസീത് നമ്പർ: {no}.", "head": "\n{label}: ആകെ ₹{due} · ഇതുവരെ അടച്ചത് ₹{paid} · ", "head_pending": "ബാക്കി ₹{pending}", "head_clear": "ഈ വക പൂർണ്ണമായി അടച്ചു ✔",
        "breakdown": "\nഇനി ബാക്കിയുള്ളത്:", "line": "\n• {label}: ₹{amount}", "all_clear": "\nനിങ്ങളുടെ കുടിശ്ശിക മുഴുവൻ അടച്ചു തീർത്തിരിക്കുന്നു. വളരെ നന്ദി! അല്ലാഹു അനുഗ്രഹിക്കട്ടെ.", "total_pending": "\nഎല്ലാ വകകളിലും കൂടി ഇനി ബാക്കി: ₹{total}",
        "balance": "വീട് {no} — നിങ്ങളുടെ ആകെ ബാക്കി ₹{amount} ({parts}). എത്രയും വേഗം അടച്ചു തീർക്കാൻ അഭ്യർത്ഥിക്കുന്നു.",
        "statement": "കമ്മിറ്റി പരിശോധിച്ച നിങ്ങളുടെ വീട് {no}-ന്റെ {year} വർഷത്തെ കണക്ക് ({date}):", "st_line": "\n• {label}: ആകെ ₹{due} · അടച്ചത് ₹{paid} · ബാക്കി ₹{pending}", "st_total": "\nആകെ അടച്ചത്: ₹{paid} · ആകെ ബാക്കി: ₹{pending}", "st_app": "\nApp-ൽ 'എന്റെ ബാക്കി' തുറന്ന് വിശദമായി കാണാം; QR scan ചെയ്ത് അടയ്ക്കാം.",
        "dues": "വീട് {no} — {n} മാസത്തെ വരിസംഖ്യ ({months}) ₹{amount} അടയ്ക്കാൻ ബാക്കിയുണ്ട്. എത്രയും വേഗം അടച്ചു തീർക്കാൻ അഭ്യർത്ഥിക്കുന്നു.",
        "ack": "₹{amount} ({label}) UPI payment വിവരം ലഭിച്ചു{ref}. ട്രഷറർ പരിശോധിച്ച് confirm ചെയ്ത ശേഷം രസീത് WhatsApp-ൽ ലഭിക്കും.",
        "reject": "₹{amount} ({label}) UPI payment വിവരം സ്ഥിരീകരിക്കാനായില്ല.{reason} ദയവായി ട്രഷററെ ബന്ധപ്പെടുക.", "reason": " കാരണം: {reason}",
    },
    "kn": {
        "address": "ಗೌರವಾನ್ವಿತ ಮಹಲ್ ಸದಸ್ಯ {who},", "son_of": " ({father} ಅವರ ಮಗ)", "sign": "ಜಝಾಕಲ್ಲಾಹು ಖೈರ್ — {name}",
        "receipt": "{label} ಗೆ ₹{amount}{period} {date} ರಂದು ಸ್ವೀಕರಿಸಲಾಗಿದೆ. ರಸೀದಿ ಸಂಖ್ಯೆ: {no}.", "head": "\n{label}: ಒಟ್ಟು ₹{due} · ಇದುವರೆಗೆ ಪಾವತಿ ₹{paid} · ", "head_pending": "ಬಾಕಿ ₹{pending}", "head_clear": "ಈ ಬಾಬ್ತು ಪೂರ್ಣ ಪಾವತಿಯಾಗಿದೆ ✔",
        "breakdown": "\nಇನ್ನೂ ಬಾಕಿ ಇರುವುದು:", "line": "\n• {label}: ₹{amount}", "all_clear": "\nನಿಮ್ಮ ಎಲ್ಲಾ ಬಾಕಿ ಪಾವತಿಯಾಗಿದೆ. ತುಂಬಾ ಧನ್ಯವಾದಗಳು! ಅಲ್ಲಾಹ್ ಆಶೀರ್ವದಿಸಲಿ.", "total_pending": "\nಎಲ್ಲಾ ಬಾಬ್ತುಗಳಲ್ಲಿ ಇನ್ನೂ ಬಾಕಿ: ₹{total}",
        "balance": "ಮನೆ {no} — ನಿಮ್ಮ ಒಟ್ಟು ಬಾಕಿ ₹{amount} ({parts}). ಆದಷ್ಟು ಬೇಗ ಪಾವತಿಸಿ ತೀರಿಸಲು ವಿನಂತಿ.",
        "statement": "ಸಮಿತಿ ಪರಿಶೀಲಿಸಿದ ನಿಮ್ಮ ಮನೆ {no} ರ {year} ವರ್ಷದ ಲೆಕ್ಕ ({date}):", "st_line": "\n• {label}: ಒಟ್ಟು ₹{due} · ಪಾವತಿ ₹{paid} · ಬಾಕಿ ₹{pending}", "st_total": "\nಒಟ್ಟು ಪಾವತಿ: ₹{paid} · ಒಟ್ಟು ಬಾಕಿ: ₹{pending}", "st_app": "\nಆಪ್‌ನಲ್ಲಿ 'ನನ್ನ ಬಾಕಿ' ತೆರೆದು ವಿವರ ನೋಡಿ; QR scan ಮಾಡಿ ಪಾವತಿಸಬಹುದು.",
        "dues": "ಮನೆ {no} — {n} ತಿಂಗಳ ವರಿಸಂಖ್ಯೆ ({months}) ₹{amount} ಪಾವತಿಸಲು ಬಾಕಿ ಇದೆ. ಆದಷ್ಟು ಬೇಗ ಪಾವತಿಸಿ ತೀರಿಸಲು ವಿನಂತಿ.",
        "ack": "₹{amount} ({label}) UPI ಪಾವತಿ ಮಾಹಿತಿ ಬಂದಿದೆ{ref}. ಖಜಾಂಚಿ ಪರಿಶೀಲಿಸಿ confirm ಮಾಡಿದ ನಂತರ ರಸೀದಿ WhatsApp-ನಲ್ಲಿ ಬರುತ್ತದೆ.",
        "reject": "₹{amount} ({label}) UPI ಪಾವತಿ ಮಾಹಿತಿ ದೃಢೀಕರಿಸಲಾಗಲಿಲ್ಲ.{reason} ದಯವಿಟ್ಟು ಖಜಾಂಚಿಯನ್ನು ಸಂಪರ್ಕಿಸಿ.", "reason": " ಕಾರಣ: {reason}",
    },
}


def msg_lang(settings: dict) -> str:
    return "kn" if (settings or {}).get("notify_language") == "kn" else "ml"


def tx(settings: dict, key: str, **kw) -> str:
    return TXT[msg_lang(settings)][key].format(**kw)


def label_for(settings: dict, typ: str) -> str:
    custom = next((h.get("name") for h in (settings or {}).get("custom_heads") or [] if isinstance(h, dict) and h.get("id") == typ), None)
    return custom or (LABELS_KN if msg_lang(settings) == "kn" else LABELS_ML).get(typ, typ)


def with_salaam(name: str, body: str, father: str = "", respectful: bool = True, settings: dict = None) -> str:
    """Every message starts with Salaam, then a respectful address ('ബഹുമാനപ്പെട്ട മഹല്ല് അംഗം <name> (<father>-ന്റെ മകൻ)' / Kannada), then the content."""
    head = body.lstrip()
    if head.startswith(SALAAM) or head.startswith(SALAAM_KN) or head.lower().startswith("assalamu"):
        return body
    salaam = SALAAM_KN if msg_lang(settings) == "kn" else SALAAM
    if not (name and name.strip()):
        return f"{salaam},\n{body}"
    who = name.strip() + (tx(settings, "son_of", father=father.strip()) if father and father.strip() else "")
    return f"{salaam},\n{tx(settings, 'address', who=who)}\n{body}" if respectful else f"{salaam} {who},\n{body}"


def sign(settings: dict) -> str:
    return "\n" + tx(settings, "sign", name=settings.get("short_name") or settings.get("mahal_name", "Mahal"))


def channels_for(setting: str) -> list:
    if setting == "both":
        return ["sms", "whatsapp"]
    return [setting or "whatsapp"]


async def sub_members_with_phone(house: dict) -> list:
    """Working adult sons (member_type 'sub') who have their own mobile — they get every house notification too."""
    from routes.houses import classify
    out = []
    async for m in db.members.find({"house_id": house.get("id", "")}, {"_id": 0}):
        m = classify(m, house)
        if m.get("member_type") == "sub" and (m.get("phone") or "").strip():
            out.append(m)
    return out


async def notify_house(house: dict, body: str, kind: str, ref: str = "", channel_setting: str = "whatsapp"):
    results = []
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "notify_language": 1}) or {}
    head_body = with_salaam(house.get("head_name", ""), body, house.get("father_name", ""), settings=s)
    subs = await sub_members_with_phone(house)
    for ch in channels_for(channel_setting):
        to = house.get("whatsapp") or house.get("phone") if ch == "whatsapp" else house.get("phone")
        sent_to = set()
        if to:
            sent_to.add(e164(to))
            results.append(await send_message(to, head_body, ch, kind, ref, house.get("head_name", ""), house.get("id", "")))
        for m in subs:
            if e164(m["phone"]) in sent_to:
                continue
            sent_to.add(e164(m["phone"]))
            results.append(await send_message(m["phone"], with_salaam(m.get("name", ""), body, settings=s), ch, kind, f"{ref}:{m['id']}" if ref else "", m.get("name", ""), house.get("id", "")))
    return results


async def statement_text(house: dict, settings: dict) -> str:
    """Committee-verified year statement sent when a house's account is released to the member."""
    from routes.collections import house_collections
    from datetime import date
    c = await house_collections(house, settings)
    heads = [(k, v) for k, v in c.items() if isinstance(v, dict) and v.get("kind") != "free" and (v.get("due", 0) > 0 or v.get("paid", 0) > 0)]
    text = tx(settings, "statement", no=house.get("house_no", ""), year=date.today().year, date=date.today().strftime("%d-%m-%Y"))
    text += "".join(tx(settings, "st_line", label=label_for(settings, k), due=f"{v['due']:.0f}", paid=f"{v['paid']:.0f}", pending=f"{v['pending']:.0f}") for k, v in heads)
    text += tx(settings, "st_total", paid=f"{sum(v['paid'] for _, v in heads):.0f}", pending=f"{c['total_pending']:.0f}")
    text += tx(settings, "all_clear") if c["total_pending"] <= 0 else ""
    return text + tx(settings, "st_app") + sign(settings)


async def receipt_text(house: dict, doc: dict, settings: dict):
    """Receipt notification; thanks the house when the whole balance is cleared."""
    from routes.collections import house_collections
    period = ", ".join(doc.get("months") or doc.get("years") or [])
    label = label_for(settings, doc.get("type", "varisankhya"))
    c = await house_collections(house, settings)
    head = c.get(doc.get("type", "varisankhya")) or {}
    period = f" {period}" if period else ""
    text = tx(settings, "receipt", label=label, amount=f"{doc['amount']:.0f}", period=period, date=doc["date"], no=doc["receipt_no"])
    if not house.get("statement_released"):
        # Committee has not released this house's statement yet — acknowledge the payment only, no balance figures.
        return await notify_house(house, text + sign(settings), "receipt", doc["id"], settings.get("notify_channel", "whatsapp"))
    if head.get("kind") != "free":
        text += tx(settings, "head", label=label, due=f"{head.get('due', 0):.0f}", paid=f"{head.get('paid', 0):.0f}")
        text += tx(settings, "head_pending", pending=f"{head['pending']:.0f}") if head.get("pending", 0) > 0 else tx(settings, "head_clear")
    if c["total_pending"] <= 0:
        text += tx(settings, "all_clear")
    else:
        text += tx(settings, "breakdown") + "".join(tx(settings, "line", label=label_for(settings, k), amount=f"{v['pending']:.0f}") for k, v in c.items() if isinstance(v, dict) and v.get("pending", 0) > 0)
        text += tx(settings, "total_pending", total=f"{c['total_pending']:.0f}")
    await notify_house(house, text + sign(settings), "receipt", doc["id"], settings.get("notify_channel", "whatsapp"))
