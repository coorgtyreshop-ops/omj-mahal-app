"""Iteration 16: sub-member own login, per-member share, blood/occ/edu fields, committee_whatsapp."""
import os
import pytest
import requests

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://anoo-platform.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"

ADMIN = {"login_id": "ADMIN-TMP", "password": "tmp12345"}


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_h(admin_token):
    return {"Authorization": f"Bearer {admin_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def state():
    return {}


# ---------- House creation with head fields ----------
def test_create_house_with_head_fields(admin_h, state):
    body = {
        "house_no": "TMP-QA3", "head_name": "Shahajahan QA", "phone": "9888800021",
        "start_month": "2026-01", "head_dob": "1970-05-10",
        "head_blood_group": "B+", "head_occupation": "tyre", "head_occupation_detail": "Coorg Tyre Shop",
    }
    r = requests.post(f"{API}/houses", json=body, headers=admin_h, timeout=15)
    assert r.status_code == 201, r.text
    d = r.json()
    state["house_id"] = d["id"]
    assert d["head_member"]["blood_group"] == "B+"
    assert d["head_member"]["occupation"] == "tyre"
    assert d["head_member"]["occupation_detail"] == "Coorg Tyre Shop"


def test_update_house_head_education_persists(admin_h, state):
    hid = state["house_id"]
    body = {
        "house_no": "TMP-QA3", "head_name": "Shahajahan QA", "phone": "9888800021",
        "start_month": "2026-01", "head_dob": "1970-05-10",
        "head_blood_group": "B+", "head_occupation": "tyre",
        "head_occupation_detail": "Coorg Tyre Shop", "head_education": "degree",
    }
    r = requests.put(f"{API}/houses/{hid}", json=body, headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    g = requests.get(f"{API}/houses/{hid}", headers=admin_h, timeout=15).json()
    self_m = next(m for m in g["members"] if m.get("relation") == "Self")
    assert self_m["blood_group"] == "B+"
    assert self_m["occupation"] == "tyre"
    assert self_m["occupation_detail"] == "Coorg Tyre Shop"
    assert self_m["education"] == "degree"


# ---------- Classification: same-name son must be sub, not head ----------
def test_create_same_name_son_is_sub(admin_h, state):
    hid = state["house_id"]
    body = {
        "house_id": hid, "name": "Shahajahan QA", "relation": "Son",
        "dob": "2000-03-15", "gender": "male", "status": "working",
        "phone": "9888800022", "occupation": "engineer", "blood_group": "O+",
    }
    r = requests.post(f"{API}/members", json=body, headers=admin_h, timeout=15)
    assert r.status_code == 201, r.text
    d = r.json()
    state["son_id"] = d["id"]
    state["son_member_no"] = d["member_no"]
    assert d["member_type"] == "sub", f"Expected sub, got {d['member_type']}"
    g = requests.get(f"{API}/houses/{hid}", headers=admin_h, timeout=15).json()
    tc = g["type_counts"]
    assert tc["head"] == 1
    assert tc["sub"] == 1
    state["head_member_id"] = next(m["id"] for m in g["members"] if m["member_type"] == "head")


# ---------- Sub login (admin issues; head login still works) ----------
def test_head_login_create(admin_h, state):
    hid = state["house_id"]
    r = requests.post(f"{API}/houses/{hid}/login", json={"password": "head1234"}, headers=admin_h, timeout=15)
    assert r.status_code == 201, r.text
    state["head_login_id"] = r.json()["login_id"]


def test_sub_login_create(admin_h, state):
    r = requests.post(f"{API}/members/{state['son_id']}/login", json={"password": "son12345"}, headers=admin_h, timeout=15)
    assert r.status_code == 201, r.text
    d = r.json()
    assert d["login_id"] == state["son_member_no"]
    assert d["phone"] == "9888800022"


def test_sub_login_auth_me(state):
    r = requests.post(f"{API}/auth/login", json={"login_id": state["son_member_no"], "password": "son12345"}, timeout=15)
    assert r.status_code == 200, r.text
    tok = r.json()["token"]
    state["son_token"] = tok
    me = requests.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {tok}"}, timeout=15).json()
    assert me.get("house_id") == state["house_id"]
    assert me.get("member_id") == state["son_id"]


def test_head_login_still_works(state):
    r = requests.post(f"{API}/auth/login", json={"login_id": state["head_login_id"], "password": "head1234"}, timeout=15)
    assert r.status_code == 200, r.text
    state["head_token"] = r.json()["token"]


def test_cannot_create_login_for_head_member(admin_h, state):
    r = requests.post(f"{API}/members/{state['head_member_id']}/login", json={"password": "x1234"}, headers=admin_h, timeout=15)
    assert r.status_code == 400, r.text


def test_login_by_phone_rejected_for_member(state):
    r = requests.post(f"{API}/auth/login", json={"login_id": "9888800022", "password": "son12345"}, timeout=15)
    assert r.status_code == 401
    assert "Member ID" in r.json().get("detail", "")


def test_no_register_endpoint():
    r = requests.post(f"{API}/auth/register", json={"phone": "x", "password": "y"}, timeout=15)
    assert r.status_code == 404


def test_sub_login_requires_admin(state):
    r = requests.post(f"{API}/members/{state['son_id']}/login", json={"password": "x1234"}, timeout=15)
    assert r.status_code in (401, 403)


# ---------- Per-member share ----------
def test_payments_head_and_son(admin_h, state):
    hid = state["house_id"]
    r1 = requests.post(f"{API}/payments", json={"house_id": hid, "amount": 500, "type": "varisankhya", "mode": "cash", "date": "2026-09-25"}, headers=admin_h, timeout=15)
    assert r1.status_code == 201, r1.text
    r2 = requests.post(f"{API}/payments", json={"house_id": hid, "amount": 250, "type": "varisankhya", "mode": "cash", "date": "2026-09-25", "member_id": state["son_id"]}, headers=admin_h, timeout=15)
    assert r2.status_code == 201, r2.text
    assert r2.json().get("member_name") == "Shahajahan QA"


def test_payment_member_from_other_house_rejected(admin_h, state):
    # Create a second temp house + member
    h = requests.post(f"{API}/houses", json={"house_no": "TMP-QA3B", "head_name": "Other H", "phone": "9888800099", "start_month": "2026-01"}, headers=admin_h, timeout=15).json()
    state["other_house_id"] = h["id"]
    m = requests.post(f"{API}/members", json={"house_id": h["id"], "name": "Other Son", "relation": "Son", "dob": "1999-01-01", "gender": "male", "status": "working", "phone": "9888800098"}, headers=admin_h, timeout=15).json()
    r = requests.post(f"{API}/payments", json={"house_id": state["house_id"], "amount": 100, "type": "varisankhya", "mode": "cash", "member_id": m["id"]}, headers=admin_h, timeout=15)
    assert r.status_code == 400


def test_release_and_summary_views(admin_h, state):
    hid = state["house_id"]
    requests.post(f"{API}/houses/{hid}/release", headers=admin_h, timeout=15)
    # Son view
    sh = {"Authorization": f"Bearer {state['son_token']}"}
    r = requests.get(f"{API}/finance/house/{hid}/summary", headers=sh, timeout=15)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d.get("member", {}).get("member_no") == state["son_member_no"]
    vari = d["collections"]["varisankhya"]
    assert vari["rate"] == 250, f"son rate expected 250, got {vari['rate']}"
    assert vari["paid"] == 250, f"son paid expected 250, got {vari['paid']}"
    assert d["collections"].get("members", {}).get("units") == 1
    # Admin view
    ah = {"Authorization": f"Bearer {admin_h['Authorization'].split()[1]}"}
    r2 = requests.get(f"{API}/finance/house/{hid}/summary", headers={"Authorization": admin_h["Authorization"]}, timeout=15).json()
    v2 = r2["collections"]["varisankhya"]
    assert v2["rate"] == 500, f"admin rate expected 500 (2 units), got {v2['rate']}"
    assert v2["paid"] == 750, f"admin paid expected 750, got {v2['paid']}"


def test_dashboard_son(state):
    sh = {"Authorization": f"Bearer {state['son_token']}"}
    r = requests.get(f"{API}/dashboard", headers=sh, timeout=15)
    assert r.status_code == 200
    d = r.json()
    assert d.get("member", {}).get("name") == "Shahajahan QA"
    # dues.pending_amount reflects son share (not full house)
    assert "dues" in d


def test_son_pay_request_and_approve(admin_h, state):
    sh = {"Authorization": f"Bearer {state['son_token']}", "Content-Type": "application/json"}
    r = requests.post(f"{API}/finance/pay-requests", json={"type": "varisankhya", "amount": 250}, headers=sh, timeout=15)
    assert r.status_code in (200, 201), r.text
    d = r.json()
    assert d.get("member_id") == state["son_id"]
    assert d.get("member_name")
    req_id = d["id"]
    ap = requests.post(f"{API}/finance/pay-requests/{req_id}/approve", headers=admin_h, timeout=15)
    assert ap.status_code == 200, ap.text
    # Find the created payment with member_id
    pays = requests.get(f"{API}/payments?house_id={state['house_id']}", headers=admin_h, timeout=15).json()
    assert any(p.get("member_id") == state["son_id"] and p.get("amount") == 250 for p in pays), pays


# ---------- Settings ----------
def test_settings_committee_whatsapp(admin_h):
    r = requests.get(f"{API}/settings", headers=admin_h, timeout=15)
    assert r.status_code == 200
    d = r.json()
    assert "committee_whatsapp" in d, list(d.keys())


# ---------- Cleanup ----------
def test_cleanup(admin_h, state):
    for k in ("house_id", "other_house_id"):
        hid = state.get(k)
        if hid:
            requests.delete(f"{API}/houses/{hid}", headers=admin_h, timeout=15)
