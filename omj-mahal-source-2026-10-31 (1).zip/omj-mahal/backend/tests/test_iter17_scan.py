"""Iteration 17 backend tests: GET /api/finance/scan/{member_no} and iter16 leftover."""
import os
import time
import pytest
import requests

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://anoo-platform.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"

ADMIN = {"login_id": "ADMIN-TMP", "password": "tmp12345"}
TMP_HOUSE_ID = "58f5faff-722f-4822-9d36-cdebef760175"
HEAD_MNO = "OMJ-0255"
SUB_MNO = "OMJ-0256"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_h(admin_token):
    return {"Authorization": f"Bearer {admin_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def st():
    return {"created_houses": []}


# ---------- Scan: auth required ----------
def test_scan_requires_auth():
    r = requests.get(f"{API}/finance/scan/{HEAD_MNO}", timeout=15)
    assert r.status_code in (401, 403)


# ---------- Scan HEAD as admin ----------
def test_scan_head_as_admin(admin_h):
    r = requests.get(f"{API}/finance/scan/{HEAD_MNO}", headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["scope"] == "house"
    assert d["member"]["member_type"] == "head"
    assert d["member"]["member_no"] == HEAD_MNO
    assert d["house"]["id"] == TMP_HOUSE_ID
    assert d["house"]["house_no"] == "TMP-SCAN"
    assert d["can_record"] is True
    assert d["released"] is False
    assert "scanned_at" in d
    c = d["collections"]
    v = c["varisankhya"]
    for key in ("due", "paid", "pending", "pending_periods", "paid_periods"):
        assert key in v, key
    assert "total_pending" in c
    assert c.get("members", {}).get("units") in (1, 2)
    # Payments latest first, contain expected fields
    pays = d["payments"]
    assert len(pays) >= 2
    p0 = pays[0]
    for k in ("type", "date", "amount", "receipt_no", "mode"):
        assert k in p0, k
    # Sorted descending by date+created_at
    dates = [p["date"] for p in pays]
    assert dates == sorted(dates, reverse=True)


# ---------- Scan SUB member as admin ----------
def test_scan_sub_as_admin_member_scope(admin_h):
    r = requests.get(f"{API}/finance/scan/{SUB_MNO}", headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["scope"] == "member"
    assert d["member"]["member_no"] == SUB_MNO
    assert d["collections"]["members"]["units"] == 1
    # Only son-tagged payments
    pays = d["payments"]
    for p in pays:
        # member_name may be blank OR "Scan Son"
        pass
    # Son payment RCT-00038 should be present, RCT-00037 (house) shouldn't
    receipts = {p.get("receipt_no") for p in pays}
    assert "RCT-00038" in receipts
    assert "RCT-00037" not in receipts
    # varisankhya rate = 250 * 1 unit
    v = d["collections"]["varisankhya"]
    assert v["rate"] == 250.0
    assert v["paid"] == 500.0  # son's tagged payment


def test_scan_sub_house_scope_override(admin_h):
    r = requests.get(f"{API}/finance/scan/{SUB_MNO}?scope=house", headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["scope"] == "house"
    # Whole house payments visible
    receipts = {p.get("receipt_no") for p in d["payments"]}
    assert "RCT-00037" in receipts
    assert "RCT-00038" in receipts


# ---------- Forgiving identifiers ----------
def test_scan_by_house_no(admin_h):
    r = requests.get(f"{API}/finance/scan/TMP-SCAN", headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    assert r.json()["member"]["member_type"] == "head"


def test_scan_lowercase(admin_h):
    r = requests.get(f"{API}/finance/scan/omj-0255", headers=admin_h, timeout=15)
    assert r.status_code == 200
    assert r.json()["member"]["member_no"] == HEAD_MNO


def test_scan_zero_vs_o(admin_h):
    # '0MJ-0255' style (zero instead of O)
    r = requests.get(f"{API}/finance/scan/0MJ-0255", headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    assert r.json()["member"]["member_no"] == HEAD_MNO


def test_scan_unknown_404(admin_h):
    r = requests.get(f"{API}/finance/scan/OMJ-9999999", headers=admin_h, timeout=15)
    assert r.status_code == 404


# ---------- Access control: member logins ----------
@pytest.fixture(scope="module")
def other_house(admin_h, st):
    # Create a second temp house for cross-house access test
    body = {"house_no": f"TMP-SCANX-{int(time.time())}", "head_name": "Other Head", "phone": "9000004411", "start_month": "2026-01"}
    r = requests.post(f"{API}/houses", json=body, headers=admin_h, timeout=15)
    assert r.status_code == 201, r.text
    d = r.json()
    st["created_houses"].append(d["id"])
    # Create head login
    lr = requests.post(f"{API}/houses/{d['id']}/login", json={"password": "other1234"}, headers=admin_h, timeout=15)
    assert lr.status_code == 201, lr.text
    login_id = lr.json()["login_id"]
    tok = requests.post(f"{API}/auth/login", json={"login_id": login_id, "password": "other1234"}, timeout=15).json()["token"]
    return {"id": d["id"], "token": tok, "login_id": login_id}


def test_member_scanning_other_house_403(other_house):
    h = {"Authorization": f"Bearer {other_house['token']}"}
    r = requests.get(f"{API}/finance/scan/{HEAD_MNO}", headers=h, timeout=15)
    assert r.status_code == 403
    assert r.json().get("detail") == "committee_only"


# ---------- Own-house before release: 403 not_released ----------
@pytest.fixture(scope="module")
def scan_head_login(admin_h, st):
    """Create a head login for TMP-SCAN house."""
    r = requests.post(f"{API}/houses/{TMP_HOUSE_ID}/login", json={"password": "scan1234"}, headers=admin_h, timeout=15)
    # If already exists we still want token; try login regardless
    login_id = HEAD_MNO
    if r.status_code == 201:
        login_id = r.json()["login_id"]
    lr = requests.post(f"{API}/auth/login", json={"login_id": login_id, "password": "scan1234"}, timeout=15)
    if lr.status_code != 200:
        pytest.skip(f"Cannot login as head: {lr.status_code} {lr.text}")
    return lr.json()["token"]


def test_own_house_not_released_403(scan_head_login):
    h = {"Authorization": f"Bearer {scan_head_login}"}
    r = requests.get(f"{API}/finance/scan/{HEAD_MNO}", headers=h, timeout=15)
    assert r.status_code == 403
    assert r.json().get("detail") == "not_released"


# ---------- Public verify unchanged ----------
def test_public_verify_identity_only():
    r = requests.get(f"{API}/public/verify/{HEAD_MNO}", timeout=15)
    assert r.status_code == 200
    d = r.json()
    assert "collections" not in d
    assert "payments" not in d
    # Should contain identity fields
    assert d.get("valid") is True or "name" in d or "member" in d


# ---------- Live update after payment ----------
def test_live_update_after_payment(admin_h):
    # Baseline
    r0 = requests.get(f"{API}/finance/scan/{HEAD_MNO}", headers=admin_h, timeout=15).json()
    tp0 = r0["collections"]["total_pending"]
    paid0 = r0["collections"]["varisankhya"]["paid"]
    n0 = len(r0["payments"])
    # Record a payment
    body = {"house_id": TMP_HOUSE_ID, "type": "varisankhya", "amount": 500, "mode": "cash", "date": "2026-09-27"}
    p = requests.post(f"{API}/payments", json=body, headers=admin_h, timeout=15)
    assert p.status_code == 201, p.text
    rec = p.json().get("receipt_no")
    # Refetch
    r1 = requests.get(f"{API}/finance/scan/{HEAD_MNO}", headers=admin_h, timeout=15).json()
    tp1 = r1["collections"]["total_pending"]
    paid1 = r1["collections"]["varisankhya"]["paid"]
    assert paid1 == paid0 + 500
    assert tp1 <= tp0  # pending should not increase
    assert len(r1["payments"]) == n0 + 1
    assert r1["payments"][0]["receipt_no"] == rec


# ---------- After release, member sees own-house scan (no can_record) ----------
def test_after_release_member_view(admin_h, scan_head_login):
    rel = requests.post(f"{API}/houses/{TMP_HOUSE_ID}/release", headers=admin_h, timeout=15)
    assert rel.status_code == 200, rel.text
    h = {"Authorization": f"Bearer {scan_head_login}"}
    r = requests.get(f"{API}/finance/scan/{HEAD_MNO}", headers=h, timeout=15)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["can_record"] is False
    assert d["released"] is True
    assert d["collections"] is not None


# ---------- Iteration-16 leftover: head_occupation_detail persistence ----------
def test_iter16_head_occupation_detail(admin_h, st):
    body = {"house_no": f"TMP-OCC-{int(time.time())}", "head_name": "Occ Head", "phone": "9000005511", "start_month": "2026-01",
            "head_occupation": "driver", "head_occupation_detail": "Timber lorry"}
    r = requests.post(f"{API}/houses", json=body, headers=admin_h, timeout=15)
    assert r.status_code == 201, r.text
    hid = r.json()["id"]
    st["created_houses"].append(hid)
    g = requests.get(f"{API}/houses/{hid}", headers=admin_h, timeout=15).json()
    self_m = next(m for m in g["members"] if m.get("relation") == "Self")
    assert self_m.get("occupation_detail") == "Timber lorry", self_m


# ---------- Cleanup ----------
def test_cleanup(admin_h, st):
    for hid in st.get("created_houses", []):
        requests.delete(f"{API}/houses/{hid}", headers=admin_h, timeout=15)
