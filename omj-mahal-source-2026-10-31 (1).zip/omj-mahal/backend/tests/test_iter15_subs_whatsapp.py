"""Iteration 15: Secondary member (sub) classification, dues x units, notifications to sub-member phones, member card."""
import os
import time
import pytest
import requests
from dotenv import load_dotenv
load_dotenv("/app/frontend/.env")

BASE = os.environ["REACT_APP_BACKEND_URL"].rstrip("/") + "/api"
ADMIN_ID = "ADMIN-TMP"
ADMIN_PW = "tmp12345"


@pytest.fixture(scope="session")
def token():
    r = requests.post(f"{BASE}/auth/login", json={"login_id": ADMIN_ID, "password": ADMIN_PW})
    assert r.status_code in (200,201), r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def H(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="session")
def house(H):
    r = requests.post(f"{BASE}/houses", headers=H, json={
        "house_no": "TMP-QA2", "head_name": "QA Head", "phone": "9888800011",
        "start_month": "2026-01", "head_dob": "1970-05-10", "subscription_amount": 250,
    })
    assert r.status_code in (200, 201), r.text
    hid = r.json()["id"]
    yield r.json()
    requests.delete(f"{BASE}/houses/{hid}", headers=H)


@pytest.fixture(scope="session")
def members(H, house):
    hid = house["id"]
    created = {}
    # QA Son: male working 26yr → sub
    r = requests.post(f"{BASE}/members", headers=H, json={
        "house_id": hid, "name": "QA Son", "relation": "Son", "dob": "2000-03-15",
        "gender": "male", "status": "working", "phone": "9888800012",
    })
    assert r.status_code in (200,201), r.text
    created["son"] = r.json()

    r = requests.post(f"{BASE}/members", headers=H, json={
        "house_id": hid, "name": "QA Student", "relation": "Son", "dob": "2005-01-01",
        "gender": "male", "status": "student",
    })
    assert r.status_code in (200,201), r.text
    created["student"] = r.json()

    r = requests.post(f"{BASE}/members", headers=H, json={
        "house_id": hid, "name": "QA Female", "relation": "Daughter", "dob": "1996-01-01",
        "gender": "female", "status": "working",
    })
    assert r.status_code in (200,201)
    created["female"] = r.json()

    r = requests.post(f"{BASE}/members", headers=H, json={
        "house_id": hid, "name": "QA Minor", "relation": "Son", "dob": "2009-06-01",
        "gender": "male", "status": "working",
    })
    assert r.status_code in (200,201)
    created["minor"] = r.json()
    return created


class TestClassify:
    def test_son_is_sub_age26(self, members):
        m = members["son"]
        assert m["member_type"] == "sub", m
        # Age at Jan 2026: still 25 until Mar 15. Test expects 26 "as of Sept 2026" — accept either.
        assert m["age"] in (25, 26)
        assert m["phone"] == "9888800012"

    def test_student_is_family(self, members):
        assert members["student"]["member_type"] == "family"

    def test_female_working_is_family(self, members):
        assert members["female"]["member_type"] == "family"

    def test_male_minor_is_family(self, members):
        assert members["minor"]["member_type"] == "family"


class TestHouseDues:
    def test_type_counts_sub_one(self, H, house, members):
        r = requests.get(f"{BASE}/houses/{house['id']}", headers=H)
        assert r.status_code in (200,201)
        j = r.json()
        assert j.get("type_counts", {}).get("sub") == 1, j.get("type_counts")

    def test_finance_summary_units_two(self, H, house, members):
        r = requests.get(f"{BASE}/finance/house/{house['id']}/summary", headers=H)
        assert r.status_code in (200,201), r.text
        j = r.json()
        # Check for units==2 or varisankhya rate==500
        found = False
        for key in ("collections", "heads"):
            c = j.get(key) or {}
            v = c.get("varisankhya") if isinstance(c, dict) else None
            if v and (v.get("rate") == 500 or v.get("units") == 2):
                found = True
        if not found:
            # Check members list
            members_list = j.get("members") or []
            units = [m.get("units") for m in members_list]
            assert 2 in units or j.get("varisankhya", {}).get("rate") == 500, f"units={units}, json keys={list(j.keys())}"


class TestSubNotifications:
    def test_receipt_goes_to_both_numbers(self, H, house, members):
        r = requests.post(f"{BASE}/payments", headers=H, json={
            "house_id": house["id"], "amount": 500, "mode": "cash",
            "type": "varisankhya", "date": "2026-09-25",
        })
        assert r.status_code in (200,201), r.text
        time.sleep(3)
        r = requests.get(f"{BASE}/notifications/outbox?limit=200", headers=H)
        assert r.status_code in (200,201)
        msgs = r.json() if isinstance(r.json(), list) else r.json().get("messages", [])
        receipt_msgs = [m for m in msgs if m.get("kind") == "receipt" and m.get("house_id") == house["id"]]
        tos = {m["to"] for m in receipt_msgs}
        assert "+919888800011" in tos, tos
        assert "+919888800012" in tos, tos
        # wa_link and sms_link present
        for m in receipt_msgs:
            if m["to"] in ("+919888800011", "+919888800012"):
                assert m.get("wa_link", "").startswith("https://wa.me/91988880001"), m.get("wa_link")
                assert m.get("sms_link", "").startswith("sms:+91"), m.get("sms_link")

    def test_balance_reminder_both(self, H, house, members):
        r = requests.post(f"{BASE}/notifications/balance-reminder", headers=H,
                          json={"house_ids": [house["id"]], "channel": "whatsapp"})
        assert r.status_code in (200,201), r.text
        time.sleep(2)
        r = requests.get(f"{BASE}/notifications/outbox?limit=200", headers=H)
        msgs = r.json() if isinstance(r.json(), list) else r.json().get("messages", [])
        bal = [m for m in msgs if m.get("kind") in ("balance", "auto_reminder") and m.get("house_id") == house["id"]]
        tos = {m["to"] for m in bal}
        assert "+919888800011" in tos and "+919888800012" in tos, tos

    def test_release_statement_both(self, H, house, members):
        r = requests.post(f"{BASE}/houses/{house['id']}/release", headers=H)
        assert r.status_code in (200,201), r.text
        time.sleep(3)
        r = requests.get(f"{BASE}/notifications/outbox?limit=200", headers=H)
        msgs = r.json() if isinstance(r.json(), list) else r.json().get("messages", [])
        stmt = [m for m in msgs if m.get("kind") == "statement" and m.get("house_id") == house["id"]]
        tos = {m["to"] for m in stmt}
        assert "+919888800011" in tos and "+919888800012" in tos, tos


class TestMemberCard:
    def test_card_has_dob_age_phone_signatures(self, H, members):
        sid = members["son"]["id"]
        r = requests.get(f"{BASE}/members/{sid}/card", headers=H)
        assert r.status_code in (200,201), r.text
        j = r.json()
        assert j["member"]["dob"] == "2000-03-15"
        assert j["member"]["age"] in (25, 26)
        assert j["member"].get("phone") == "9888800012"
        s = j.get("settings", {})
        assert "president_name" in s and "secretary_name" in s
