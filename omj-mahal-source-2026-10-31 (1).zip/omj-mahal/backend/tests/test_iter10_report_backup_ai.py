"""Iteration 10 backend tests.

Covers:
  - /finance/report (collection report with types incl. auction; RBAC)
  - /finance/house/{id}/auction (add/delete auction dues; validations)
  - /finance/notices (per-head due/paid/pending incl. auction)
  - /backup (export/restore/snapshots)
  - notify_language ml|kn (balance-reminder + receipt outbox)
  - /members/stats.widows
  - /assistant/compose + /assistant/transcribe
"""
import io
import json
import os
import time
import wave
import struct

import pytest
import requests

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://anoo-platform.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"

ADMIN = {"login_id": "ADMIN-099", "password": "test1234"}


# ---------- fixtures ----------
@pytest.fixture(scope="session")
def admin_token():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def admin_h(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def temp_house(admin_h):
    """Create a temp TST- house with fee_building 5000 subscription tests."""
    hno = f"TST-{int(time.time()) % 100000}"
    payload = {"house_no": hno, "head_name": "TST Head", "phone": "9000000010",
               "address": "test", "ward": "TSTW", "subscription_amount": 100,
               "start_month": "2026-01"}
    r = requests.post(f"{API}/houses", headers=admin_h, json=payload, timeout=15)
    assert r.status_code in (200, 201), r.text
    hid = r.json()["id"]
    yield {"id": hid, "house_no": hno}
    # cleanup
    requests.delete(f"{API}/houses/{hid}", headers=admin_h, timeout=15)


@pytest.fixture(scope="module")
def member_h(admin_h, temp_house):
    """Create a member login for the temp house and return its auth headers."""
    r = requests.post(f"{API}/houses/{temp_house['id']}/login",
                      headers=admin_h, json={"password": "member123"}, timeout=15)
    assert r.status_code in (200, 201), r.text
    lid = r.json().get("login_id") or r.json().get("member_no")
    lg = requests.post(f"{API}/auth/login",
                       json={"login_id": lid, "password": "member123"}, timeout=15)
    assert lg.status_code == 200, lg.text
    tok = lg.json()["token"]
    uid = lg.json()["user"]["id"]
    yield {"Authorization": f"Bearer {tok}"}
    requests.delete(f"{API}/users/{uid}", headers=admin_h, timeout=15)


# ---------- /finance/report ----------
class TestCollectionReport:
    def test_member_forbidden(self, member_h):
        r = requests.get(f"{API}/finance/report", headers=member_h, timeout=15)
        assert r.status_code == 403

    def test_report_shape_and_types(self, admin_h, temp_house):
        # Pay 5000 building for temp house -> full
        r = requests.post(f"{API}/payments", headers=admin_h,
                          json={"house_id": temp_house["id"], "type": "building",
                                "amount": 5000, "mode": "cash"}, timeout=15)
        assert r.status_code in (200, 201), r.text
        pid_full = r.json().get("id")

        rep = requests.get(f"{API}/finance/report", headers=admin_h, timeout=20).json()
        assert "auction" in rep["types"], rep["types"]
        assert "building" in rep["report"]
        full_ids = [x["id"] for x in rep["report"]["building"]["full"]]
        assert temp_house["id"] in full_ids

        # Totals consistency for building
        b = rep["report"]["building"]["totals"]
        assert b["due"] >= b["paid"] - 0.01
        assert abs(b["pending"] - max(0.0, b["due"] - b["paid"])) < 0.01

        # cleanup payment so subsequent tests are clean
        if pid_full:
            requests.delete(f"{API}/payments/{pid_full}", headers=admin_h, timeout=15)

    def test_partial_and_none_groups(self, admin_h, temp_house):
        # partial: pay 1500 on building (target 5000)
        r = requests.post(f"{API}/payments", headers=admin_h,
                          json={"house_id": temp_house["id"], "type": "building",
                                "amount": 1500, "mode": "cash"}, timeout=15)
        assert r.status_code in (200, 201), r.text
        pid = r.json().get("id")

        rep = requests.get(f"{API}/finance/report", headers=admin_h, timeout=20).json()
        partial = [x for x in rep["report"]["building"]["partial"]
                   if x["id"] == temp_house["id"]]
        assert partial, "temp house should be partial"
        assert abs(partial[0]["pending"] - 3500) < 0.01
        assert abs(partial[0]["paid"] - 1500) < 0.01

        if pid:
            requests.delete(f"{API}/payments/{pid}", headers=admin_h, timeout=15)


# ---------- Auction ----------
class TestAuction:
    def test_auction_flow(self, admin_h, temp_house):
        hid = temp_house["id"]
        # Add auction 1200
        r = requests.post(f"{API}/finance/house/{hid}/auction", headers=admin_h,
                          json={"amount": 1200, "note": "TST auction"}, timeout=15)
        assert r.status_code in (200, 201), r.text
        items = r.json()["items"]
        assert len(items) >= 1
        item_id = items[-1]["id"]

        s = requests.get(f"{API}/finance/house/{hid}/summary",
                         headers=admin_h, timeout=15).json()
        auc = s["collections"]["auction"]
        assert abs(auc["due"] - 1200) < 0.01
        assert abs(auc["pending"] - 1200) < 0.01

        # Pay 500 of auction
        p = requests.post(f"{API}/payments", headers=admin_h,
                         json={"house_id": hid, "type": "auction",
                               "amount": 500, "mode": "cash"}, timeout=15)
        assert p.status_code in (200, 201), p.text
        pid = p.json().get("id")

        s2 = requests.get(f"{API}/finance/house/{hid}/summary",
                          headers=admin_h, timeout=15).json()
        assert abs(s2["collections"]["auction"]["pending"] - 700) < 0.01

        # Delete auction item
        d = requests.delete(f"{API}/finance/house/{hid}/auction/{item_id}",
                            headers=admin_h, timeout=15)
        assert d.status_code == 200

        if pid:
            requests.delete(f"{API}/payments/{pid}", headers=admin_h, timeout=15)

    def test_auction_amount_invalid(self, admin_h, temp_house):
        r = requests.post(f"{API}/finance/house/{temp_house['id']}/auction",
                          headers=admin_h, json={"amount": 0}, timeout=15)
        assert r.status_code == 400


# ---------- Notices ----------
class TestNotices:
    def test_notices_contains_auction(self, admin_h, temp_house):
        hid = temp_house["id"]
        # Ensure there is an auction due
        requests.post(f"{API}/finance/house/{hid}/auction", headers=admin_h,
                      json={"amount": 500, "note": "N"}, timeout=15)
        r = requests.get(f"{API}/finance/notices?house_id={hid}",
                         headers=admin_h, timeout=15)
        assert r.status_code == 200
        rows = r.json()
        assert rows and rows[0]["collections"].get("auction"), rows
        a = rows[0]["collections"]["auction"]
        for k in ("due", "paid", "pending"):
            assert k in a
        # cleanup auction items
        s = requests.get(f"{API}/finance/house/{hid}/summary",
                        headers=admin_h, timeout=15).json()
        for it in s["collections"]["auction"].get("items", []):
            requests.delete(f"{API}/finance/house/{hid}/auction/{it['id']}",
                            headers=admin_h, timeout=15)


# ---------- Backup ----------
class TestBackup:
    def test_export_json(self, admin_h):
        r = requests.get(f"{API}/backup/export", headers=admin_h, timeout=30)
        assert r.status_code == 200
        assert "attachment" in r.headers.get("content-disposition", "").lower()
        j = r.json()
        assert j.get("app") == "OMJ Mahal"
        assert "collections" in j and "houses" in j["collections"]

    def test_member_forbidden(self, member_h):
        r = requests.get(f"{API}/backup/export", headers=member_h, timeout=15)
        assert r.status_code == 403

    def test_snapshot_list_create_delete(self, admin_h):
        c = requests.post(f"{API}/backup/snapshots", headers=admin_h, timeout=30)
        assert c.status_code in (200, 201), c.text
        sid = c.json()["id"]
        assert c.json()["kind"] == "manual"

        lst = requests.get(f"{API}/backup/snapshots",
                           headers=admin_h, timeout=15).json()
        assert any(x["id"] == sid for x in lst["snapshots"])

        d = requests.delete(f"{API}/backup/snapshots/{sid}",
                            headers=admin_h, timeout=15)
        assert d.status_code == 200

    def test_invalid_restore_file(self, admin_h):
        files = {"file": ("bad.json", b"{}", "application/json")}
        r = requests.post(f"{API}/backup/restore", headers=admin_h,
                         files=files, timeout=15)
        assert r.status_code == 400
        assert "OMJ Mahal" in r.text

    def test_restore_roundtrip(self, admin_h):
        # 1. Create a marker temp house
        hno = f"TST-RST-{int(time.time()) % 100000}"
        cr = requests.post(f"{API}/houses", headers=admin_h,
                          json={"house_no": hno, "head_name": "TST RST",
                                "phone": "9000000099", "address": "x",
                                "ward": "W", "subscription_amount": 100,
                                "start_month": "2026-01"}, timeout=15)
        assert cr.status_code in (200, 201), cr.text
        hid = cr.json()["id"]

        try:
            # 2. Export
            exp = requests.get(f"{API}/backup/export",
                               headers=admin_h, timeout=30)
            assert exp.status_code == 200
            backup_bytes = exp.content

            # 3. Delete the marker house
            del_r = requests.delete(f"{API}/houses/{hid}",
                                    headers=admin_h, timeout=15)
            assert del_r.status_code == 200

            # 4. Confirm gone
            gone = requests.get(f"{API}/houses/{hid}",
                                headers=admin_h, timeout=15)
            assert gone.status_code == 404

            # 5. Restore
            files = {"file": ("bk.json", backup_bytes, "application/json")}
            rs = requests.post(f"{API}/backup/restore", headers=admin_h,
                              files=files, timeout=60)
            assert rs.status_code == 200, rs.text
            body = rs.json()
            assert body.get("ok") is True
            assert body.get("restored", 0) > 0

            # 6. House should be back
            back = requests.get(f"{API}/houses/{hid}",
                                headers=admin_h, timeout=15)
            assert back.status_code == 200
        finally:
            # Final cleanup: ensure the TST-RST marker house is gone from DB.
            requests.delete(f"{API}/houses/{hid}",
                           headers=admin_h, timeout=15)


# ---------- notify_language ----------
class TestNotifyLanguage:
    def _set_lang(self, admin_h, lang):
        # Read current settings and update notify_language only
        cur = requests.get(f"{API}/settings", timeout=15).json()
        cur["notify_language"] = lang
        r = requests.put(f"{API}/settings", headers=admin_h,
                        json=cur, timeout=15)
        assert r.status_code == 200, r.text

    def test_kn_and_ml_balance_reminder(self, admin_h, temp_house):
        hid = temp_house["id"]
        # Ensure a pending due (auction 300)
        requests.post(f"{API}/finance/house/{hid}/auction", headers=admin_h,
                     json={"amount": 300, "note": "L"}, timeout=15)
        try:
            self._set_lang(admin_h, "kn")
            r = requests.post(f"{API}/notifications/balance-reminder",
                             headers=admin_h,
                             json={"house_ids": [hid], "channel": "whatsapp"},
                             timeout=20)
            assert r.status_code == 200, r.text
            results = r.json().get("results", [])
            assert results, r.json()
            body = results[0].get("body", "")
            assert body.startswith("ಅಸ್ಸಲಾಮು ಅಲೈಕುಂ"), body[:80]
            assert "ಗೌರವಾನ್ವಿತ ಮಹಲ್ ಸದಸ್ಯ" in body

            self._set_lang(admin_h, "ml")
            r2 = requests.post(f"{API}/notifications/balance-reminder",
                              headers=admin_h,
                              json={"house_ids": [hid], "channel": "whatsapp"},
                              timeout=20)
            assert r2.status_code == 200
            results2 = r2.json().get("results", [])
            assert results2
            body2 = results2[0]["body"]
            assert body2.startswith("അസ്സലാമു അലൈക്കും"), body2[:80]
            assert "ബഹുമാനപ്പെട്ട മഹല്ല് അംഗം" in body2
        finally:
            # Ensure language reset to ml
            self._set_lang(admin_h, "ml")
            # Cleanup auction items and messages
            s = requests.get(f"{API}/finance/house/{hid}/summary",
                            headers=admin_h, timeout=15).json()
            for it in s["collections"]["auction"].get("items", []):
                requests.delete(f"{API}/finance/house/{hid}/auction/{it['id']}",
                               headers=admin_h, timeout=15)
            # clear outbox to avoid clutter
            requests.post(f"{API}/notifications/outbox/clear",
                         headers=admin_h, timeout=15)


# ---------- widows ----------
class TestWidows:
    def test_widows_increment(self, admin_h, temp_house):
        stats0 = requests.get(f"{API}/members/stats",
                              headers=admin_h, timeout=15).json()
        w0 = stats0.get("widows", 0)
        m = requests.post(f"{API}/members", headers=admin_h,
                        json={"house_id": temp_house["id"],
                              "name": "TST Widow", "relation": "mother",
                              "gender": "female",
                              "marital_status": "widowed"}, timeout=15)
        assert m.status_code in (200, 201), m.text
        mid = m.json()["id"]
        try:
            stats1 = requests.get(f"{API}/members/stats",
                                 headers=admin_h, timeout=15).json()
            assert stats1.get("widows", 0) >= w0 + 1
        finally:
            requests.delete(f"{API}/members/{mid}",
                           headers=admin_h, timeout=15)


# ---------- AI assistant ----------
class TestAssistant:
    def test_compose_empty_400(self, admin_h):
        r = requests.post(f"{API}/assistant/compose", headers=admin_h,
                         json={"text": "  ", "language": "ml",
                               "action": "polish"}, timeout=20)
        assert r.status_code == 400

    def test_compose_invalid_action_400(self, admin_h):
        r = requests.post(f"{API}/assistant/compose", headers=admin_h,
                         json={"text": "hello", "language": "ml",
                               "action": "bogus"}, timeout=20)
        assert r.status_code == 400

    def test_compose_polish_ml(self, admin_h):
        r = requests.post(f"{API}/assistant/compose", headers=admin_h,
                         json={"text": "nale meeting undu ellavarum varanam",
                               "language": "ml", "action": "polish"},
                         timeout=60)
        # Real LLM; allow 503 if key missing
        if r.status_code == 503:
            pytest.skip("AI key not configured")
        assert r.status_code == 200, r.text
        out = r.json().get("text", "")
        assert out, r.text
        # Should contain Malayalam script
        assert any("\u0d00" <= ch <= "\u0d7f" for ch in out), out[:120]

    def test_transcribe_wav(self, admin_h):
        # generate a small silent wav
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(16000)
            w.writeframes(struct.pack("<" + "h" * 1600, *([0] * 1600)))
        buf.seek(0)
        files = {"file": ("silence.wav", buf.read(), "audio/wav")}
        r = requests.post(f"{API}/assistant/transcribe", headers=admin_h,
                         files=files, data={"language": "ml"}, timeout=60)
        if r.status_code == 503:
            pytest.skip("AI key not configured")
        # whisper may return 200 with empty or 400 w/ "audio too short"
        assert r.status_code in (200, 400), r.text
        if r.status_code == 200:
            assert "text" in r.json()
