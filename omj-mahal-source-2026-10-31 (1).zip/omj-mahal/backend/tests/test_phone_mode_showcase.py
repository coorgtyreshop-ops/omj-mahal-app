"""Iteration 5 backend tests:
- Phone-mode messaging (outbox, wa/sms links, balance-reminder)
- Provider settings (phone <-> twilio switch)
- Event fields chair/organizer/leader/women_facility/women_note + guest photos
- Public display endpoint
"""
import io
import os
import struct
import zlib
from datetime import date, timedelta

import pytest
import requests

def _read_env(path, key):
    try:
        for line in open(path):
            if line.startswith(key + "="):
                return line.split("=", 1)[1].strip()
    except Exception:
        return None
    return None


BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or _read_env("/app/frontend/.env", "REACT_APP_BACKEND_URL")).rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_PHONE = "9999999999"
ADMIN_PASS = "admin123"
MEMBER_PHONE = "8888888888"
MEMBER_PASS = "member123"


def _login(phone, password):
    r = requests.post(f"{API}/auth/login", json={"phone": phone, "password": password}, timeout=15)
    if r.status_code != 200:
        return None
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_hdr():
    tok = _login(ADMIN_PHONE, ADMIN_PASS)
    assert tok, "admin login failed"
    return {"Authorization": f"Bearer {tok}"}


@pytest.fixture(scope="module")
def member_hdr():
    tok = _login(MEMBER_PHONE, MEMBER_PASS)
    if not tok:
        pytest.skip("Member 8888888888/member123 not seeded")
    return {"Authorization": f"Bearer {tok}"}


@pytest.fixture(scope="module")
def temp_house(admin_hdr):
    # Create a temp house TEST_99 with balance (default_subscription accrues pending)
    payload = {
        "house_no": "TEST99",
        "head_name": "TEST_TempHead",
        "phone": "9900000099",
        "whatsapp": "9900000099",
        "ward": "TEST",
        "address": "Test Address",
        "start_month": "2024-01",
    }
    r = requests.post(f"{API}/houses", json=payload, headers=admin_hdr, timeout=15)
    assert r.status_code in (200, 201), f"create house: {r.status_code} {r.text}"
    h = r.json()
    yield h
    requests.delete(f"{API}/houses/{h['id']}", headers=admin_hdr, timeout=15)


def _tiny_png_bytes():
    # 1x1 transparent PNG
    sig = b"\x89PNG\r\n\x1a\n"
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0))
    idat = chunk(b"IDAT", zlib.compress(b"\x00\x00\x00\x00\x00"))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


# ---------------- Phone-mode status & outbox ----------------
class TestPhoneModeMessaging:
    def test_status_phone_mode(self, admin_hdr):
        r = requests.get(f"{API}/notifications/status", headers=admin_hdr, timeout=10)
        assert r.status_code == 200
        s = r.json()
        assert s["mode"] == "phone"
        assert s["provider"] == "phone"
        assert s["configured"] is False
        assert "queued" in s

    def test_balance_reminder_queues(self, admin_hdr, temp_house):
        r = requests.post(
            f"{API}/notifications/balance-reminder",
            json={"house_ids": [temp_house["id"]], "channel": "whatsapp"},
            headers=admin_hdr, timeout=20,
        )
        assert r.status_code == 200, r.text
        j = r.json()
        assert "sent" in j and "results" in j
        # Some houses may have zero pending -> results empty. Ensure the temp house had pending.
        if j["sent"] == 0:
            pytest.skip("Temp house had no pending balance (defaults set fee_varisankhya=0)")
        res = j["results"][0]
        assert res["status"] == "queued"
        assert res["wa_link"].startswith("https://wa.me/91")
        assert res["sms_link"].startswith("sms:+91")
        assert res["body"].startswith("അസ്സലാമു അലൈക്കും")

    def test_outbox_lists_and_has_links(self, admin_hdr):
        r = requests.get(f"{API}/notifications/outbox", headers=admin_hdr, timeout=10)
        assert r.status_code == 200
        rows = r.json()
        assert isinstance(rows, list)
        if rows:
            m = rows[0]
            assert "wa_link" in m and m["wa_link"].startswith("https://wa.me/")
            assert "sms_link" in m and m["sms_link"].startswith("sms:")

    def test_member_forbidden_on_outbox(self, member_hdr):
        r = requests.get(f"{API}/notifications/outbox", headers=member_hdr, timeout=10)
        assert r.status_code == 403
        r2 = requests.post(f"{API}/notifications/outbox/clear", headers=member_hdr, timeout=10)
        assert r2.status_code == 403

    def test_outbox_mark_sent_and_clear(self, admin_hdr):
        # Ensure at least one queued exists via custom message
        houses = requests.get(f"{API}/houses", headers=admin_hdr, timeout=10).json()
        temp = [h for h in houses if h.get("house_no") == "TEST99"]
        if temp:
            requests.post(f"{API}/notifications/custom",
                          json={"body": "TEST message", "house_ids": [temp[0]["id"]], "channel": "whatsapp"},
                          headers=admin_hdr, timeout=15)
        # broadcast is background; poll
        import time
        for _ in range(6):
            rows = requests.get(f"{API}/notifications/outbox", headers=admin_hdr, timeout=10).json()
            if rows:
                break
            time.sleep(0.5)
        if not rows:
            pytest.skip("No queued messages to mark sent")
        mid = rows[0]["id"]
        r = requests.post(f"{API}/notifications/outbox/{mid}/sent", headers=admin_hdr, timeout=10)
        assert r.status_code == 200
        # clear the rest
        r2 = requests.post(f"{API}/notifications/outbox/clear", headers=admin_hdr, timeout=10)
        assert r2.status_code == 200
        # outbox empty now
        rows2 = requests.get(f"{API}/notifications/outbox", headers=admin_hdr, timeout=10).json()
        assert rows2 == []


# ---------------- Provider settings ----------------
class TestProviderSettings:
    def test_switch_to_twilio_and_back(self, admin_hdr):
        import time
        # Fetch current settings so we can preserve mandatory fields (mahal_name is required by SettingsIn)
        cur = requests.get(f"{API}/settings", headers=admin_hdr, timeout=10).json()
        base = {"mahal_name": cur.get("mahal_name", "OMJ")}
        # Switch to twilio
        payload = {**base,
                   "notify_provider": "twilio",
                   "twilio_sid": "ACtest",
                   "twilio_token": "tok",
                   "twilio_whatsapp_from": "+14155238886",
                   "twilio_sms_from": "+15005550006"}
        r = requests.put(f"{API}/settings", json=payload, headers=admin_hdr, timeout=10)
        assert r.status_code == 200, r.text
        # cache 5s
        time.sleep(6)
        s = requests.get(f"{API}/notifications/status", headers=admin_hdr, timeout=10).json()
        assert s["mode"] == "live"
        assert s["configured"] is True
        assert s["whatsapp_enabled"] is True
        assert s["sms_enabled"] is True

        # Send custom -> should not crash; message row eventually 'failed' with error
        houses = requests.get(f"{API}/houses", headers=admin_hdr, timeout=10).json()
        temp = [h for h in houses if h.get("house_no") == "TEST99"]
        if temp:
            r2 = requests.post(f"{API}/notifications/custom",
                               json={"body": "TEST twilio fail", "house_ids": [temp[0]["id"]], "channel": "whatsapp"},
                               headers=admin_hdr, timeout=15)
            assert r2.status_code == 200
            time.sleep(3)
            msgs = requests.get(f"{API}/notifications?limit=50", headers=admin_hdr, timeout=10).json()
            failed = [m for m in msgs if m.get("body", "").startswith("TEST twilio fail")]
            if failed:
                assert failed[0]["status"] in ("failed", "queued")  # accept queued if bg not done

        # Restore
        restore = {**base,
                   "notify_provider": "phone",
                   "twilio_sid": "",
                   "twilio_token": "",
                   "twilio_whatsapp_from": "",
                   "twilio_sms_from": ""}
        r3 = requests.put(f"{API}/settings", json=restore, headers=admin_hdr, timeout=10)
        assert r3.status_code == 200
        time.sleep(6)
        s2 = requests.get(f"{API}/notifications/status", headers=admin_hdr, timeout=10).json()
        assert s2["mode"] == "phone"
        # clear leftover queued
        requests.post(f"{API}/notifications/outbox/clear", headers=admin_hdr, timeout=10)


# ---------------- Events with new fields + guest photos ----------------
class TestEventsAndGuests:
    def test_create_event_with_new_fields(self, admin_hdr):
        tomorrow = (date.today() + timedelta(days=3)).isoformat()
        payload = {
            "title": "TEST_Programme",
            "title_ml": "പരിപാടി",
            "title_kn": "ಕಾರ್ಯಕ್ರಮ",
            "date": tomorrow,
            "time": "18:00",
            "venue": "Hall",
            "category": "programme",
            "chair": "TEST_Chair",
            "organizer": "TEST_Organizer",
            "leader": "TEST_Leader",
            "women_facility": True,
            "women_note": "പ്രത്യേക സൗകര്യം",
            "guests": "Guest A\nGuest B",
        }
        r = requests.post(f"{API}/events", json=payload, headers=admin_hdr, timeout=15)
        assert r.status_code == 201, r.text
        ev = r.json()
        for k in ("chair", "organizer", "leader", "women_note", "title_kn"):
            assert ev[k] == payload[k]
        assert ev["women_facility"] is True

        # GET back
        g = requests.get(f"{API}/events/{ev['id']}", headers=admin_hdr, timeout=10).json()
        assert g["chair"] == "TEST_Chair"
        assert g["title_kn"] == "ಕಾರ್ಯಕ್ರಮ"

        # Guest photo upload
        png = _tiny_png_bytes()
        r2 = requests.post(
            f"{API}/events/{ev['id']}/guests",
            data={"name": "TEST_Guest", "role": "Speaker"},
            files={"photo": ("g.png", png, "image/png")},
            headers=admin_hdr, timeout=15,
        )
        assert r2.status_code == 201, r2.text
        guest = r2.json()
        assert guest["name"] == "TEST_Guest"
        assert guest["url"].startswith("/api/files/")

        # Fetch file bytes
        fr = requests.get(f"{BASE_URL}{guest['url']}", timeout=15)
        assert fr.status_code == 200
        assert fr.headers.get("content-type", "").startswith("image/")

        # Event now has guest_photos
        ev2 = requests.get(f"{API}/events/{ev['id']}", headers=admin_hdr, timeout=10).json()
        assert any(gp["id"] == guest["id"] for gp in ev2.get("guest_photos", []))

        # Non-image upload -> 400
        r3 = requests.post(
            f"{API}/events/{ev['id']}/guests",
            data={"name": "bad", "role": ""},
            files={"photo": ("t.txt", b"hello", "text/plain")},
            headers=admin_hdr, timeout=15,
        )
        assert r3.status_code == 400

        # Delete guest
        r4 = requests.delete(f"{API}/events/{ev['id']}/guests/{guest['id']}", headers=admin_hdr, timeout=10)
        assert r4.status_code == 200

        # Cleanup event
        requests.delete(f"{API}/events/{ev['id']}", headers=admin_hdr, timeout=10)

    def test_member_forbidden_on_guest_upload(self, admin_hdr, member_hdr):
        # Create event as admin
        tomorrow = (date.today() + timedelta(days=4)).isoformat()
        r = requests.post(f"{API}/events",
                          json={"title": "TEST_perm", "date": tomorrow, "category": "programme"},
                          headers=admin_hdr, timeout=10)
        ev = r.json()
        try:
            png = _tiny_png_bytes()
            r2 = requests.post(f"{API}/events/{ev['id']}/guests",
                               data={"name": "x", "role": ""},
                               files={"photo": ("g.png", png, "image/png")},
                               headers=member_hdr, timeout=15)
            assert r2.status_code == 403
        finally:
            requests.delete(f"{API}/events/{ev['id']}", headers=admin_hdr, timeout=10)


# ---------------- Public display ----------------
class TestPublicDisplay:
    def test_display_no_auth_and_fields(self):
        r = requests.get(f"{API}/public/display", timeout=10)
        assert r.status_code == 200
        rows = r.json()
        assert isinstance(rows, list)
        today_s = date.today().isoformat()
        # Existing 'Sandy' event predates new fields; only assert core keys
        for ev in rows:
            assert ev["date"] >= today_s
            assert "created_by" not in ev
            assert "notified_at" not in ev
            for k in ("title", "date"):
                assert k in ev

    def test_past_event_excluded(self, admin_hdr):
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        r = requests.post(f"{API}/events",
                          json={"title": "TEST_past", "date": yesterday, "category": "programme"},
                          headers=admin_hdr, timeout=10)
        assert r.status_code == 201
        ev = r.json()
        try:
            rows = requests.get(f"{API}/public/display", timeout=10).json()
            assert not any(e["id"] == ev["id"] for e in rows)
        finally:
            requests.delete(f"{API}/events/{ev['id']}", headers=admin_hdr, timeout=10)
