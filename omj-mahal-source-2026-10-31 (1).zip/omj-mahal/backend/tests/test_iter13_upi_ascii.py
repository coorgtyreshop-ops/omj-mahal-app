"""Iteration 13: UPI ASCII sanitisation for pn/tn (bugfix for GPay/PhonePe 'technical issue')."""
import os
import re
import uuid
import bcrypt
import pytest
import requests
from datetime import datetime, timezone
from urllib.parse import unquote
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv("/app/backend/.env")

BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/") if False else "https://anoo-platform.preview.emergentagent.com"
API = f"{BASE_URL}/api"
MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = os.environ["DB_NAME"]

TEMP_ADMIN_LOGIN = "ADMIN-QA13"
TEMP_ADMIN_PWD = "qa12345"
TEMP_HOUSE_NO = "TMP-QA13"

state = {"admin_token": None, "admin_user_id": None, "house_id": None, "member_token": None, "original_upi_name": None}


@pytest.fixture(scope="module", autouse=True)
def setup_teardown():
    mc = MongoClient(MONGO_URL)
    db = mc[DB_NAME]
    # cleanup any leftover
    db.users.delete_many({"login_id": TEMP_ADMIN_LOGIN})
    db.houses.delete_many({"house_no": TEMP_HOUSE_NO})
    # create temp admin
    uid = str(uuid.uuid4())
    db.users.insert_one({
        "id": uid,
        "phone": "9999999901",
        "name": "QA Admin 13",
        "role": "admin",
        "login_id": TEMP_ADMIN_LOGIN,
        "house_id": None,
        "language": "ml",
        "password_hash": bcrypt.hashpw(TEMP_ADMIN_PWD.encode(), bcrypt.gensalt()).decode(),
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    state["admin_user_id"] = uid
    # login
    r = requests.post(f"{API}/auth/login", json={"login_id": TEMP_ADMIN_LOGIN, "password": TEMP_ADMIN_PWD})
    assert r.status_code == 200, r.text
    state["admin_token"] = r.json()["token"]

    # save original upi_name
    s = db.settings.find_one({"key": "main"}) or {}
    state["original_upi_name"] = s.get("upi_name")
    state["original_upi_id"] = s.get("upi_id")

    yield

    # cleanup
    if state.get("house_id"):
        requests.delete(f"{API}/houses/{state['house_id']}", headers={"Authorization": f"Bearer {state['admin_token']}"})
    # restore upi_name
    if state["original_upi_name"] is not None:
        requests.put(f"{API}/finance/fees", json={"upi_name": state["original_upi_name"]}, headers={"Authorization": f"Bearer {state['admin_token']}"})
    db.users.delete_one({"id": state["admin_user_id"]})
    db.houses.delete_many({"house_no": TEMP_HOUSE_NO})
    mc.close()


def _admin_headers():
    return {"Authorization": f"Bearer {state['admin_token']}"}


def _has_non_ascii_percent(link: str) -> bool:
    # percent-encoded bytes >= 0x80
    return bool(re.search(r"%[89A-Fa-f][0-9A-Fa-f]", link))


def test_1_upi_link_ascii_note():
    r = requests.get(f"{API}/finance/upi-link", params={"amount": 1000, "note": "building"}, headers=_admin_headers())
    assert r.status_code == 200, r.text
    link = r.json()["link"]
    print("LINK:", link)
    assert link.startswith("upi://pay?"), link
    assert "pa=coorgtyreshop-1%40okhdfcbank" in link, f"pa mismatch: {link}"
    assert "am=1000.00" in link
    assert "cu=INR" in link
    assert not _has_non_ascii_percent(link), f"non-ASCII bytes present: {link}"
    # tn decoded ascii-only [A-Za-z0-9 .-]
    m = re.search(r"tn=([^&]+)", link)
    assert m, "tn missing"
    tn_dec = unquote(m.group(1))
    assert re.fullmatch(r"[A-Za-z0-9 .\-]*", tn_dec), f"tn has bad chars: {tn_dec!r}"


def test_2_upi_link_strips_malayalam_note():
    r = requests.get(f"{API}/finance/upi-link", params={"amount": 250, "note": "ബിൽഡിംഗ് ഫണ്ട്"}, headers=_admin_headers())
    assert r.status_code == 200, r.text
    link = r.json()["link"]
    print("LINK ML:", link)
    assert not _has_non_ascii_percent(link), f"non-ASCII bytes present: {link}"
    assert "am=250.00" in link
    m = re.search(r"tn=([^&]+)", link)
    tn_dec = unquote(m.group(1))
    assert re.fullmatch(r"[A-Za-z0-9 .\-]*", tn_dec), f"bad tn: {tn_dec!r}"
    assert tn_dec.strip() != "", "tn must not be empty (fallback expected)"


def test_3_upi_name_fallback_when_malayalam():
    # set upi_name to malayalam
    r = requests.put(f"{API}/finance/fees", json={"upi_name": "ഓ എം ജെ മഹൽ"}, headers=_admin_headers())
    assert r.status_code == 200, r.text
    r = requests.get(f"{API}/finance/upi-link", params={"amount": 100, "note": "test"}, headers=_admin_headers())
    assert r.status_code == 200
    link = r.json()["link"]
    print("LINK PN-ml:", link)
    assert not _has_non_ascii_percent(link)
    m = re.search(r"pn=([^&]+)", link)
    pn_dec = unquote(m.group(1))
    assert pn_dec == "Mahal", f"expected fallback 'Mahal', got {pn_dec!r}"
    # restore
    r = requests.put(f"{API}/finance/fees", json={"upi_name": "coorg tyre shop"}, headers=_admin_headers())
    assert r.status_code == 200
    r = requests.get(f"{API}/finance/upi-link", params={"amount": 100, "note": "test"}, headers=_admin_headers())
    link = r.json()["link"]
    m = re.search(r"pn=([^&]+)", link)
    assert unquote(m.group(1)) == "coorg tyre shop", link


def test_4_create_temp_house_and_member_upi():
    # create temp house
    r = requests.post(f"{API}/houses", json={"house_no": TEMP_HOUSE_NO, "head_name": "QA Test", "phone": "9888800009", "start_month": "2026-01"}, headers=_admin_headers())
    assert r.status_code in (200, 201), r.text
    house = r.json()
    state["house_id"] = house["id"]
    # release so member can see collections
    rr = requests.post(f"{API}/houses/{house['id']}/release", headers=_admin_headers())
    print("release:", rr.status_code, rr.text[:200])
    # create member login
    lr = requests.post(f"{API}/houses/{house['id']}/login", json={"password": "qa12345", "send_whatsapp": False}, headers=_admin_headers())
    assert lr.status_code in (200, 201), lr.text
    login_id = lr.json().get("login_id") or lr.json().get("member_no")
    print("member login_id:", login_id)
    # login as member
    mr = requests.post(f"{API}/auth/login", json={"login_id": login_id, "password": "qa12345"})
    assert mr.status_code == 200, mr.text
    state["member_token"] = mr.json()["token"]
    # member upi-link
    r = requests.get(f"{API}/finance/upi-link", params={"amount": 1000, "note": "building"}, headers={"Authorization": f"Bearer {state['member_token']}"})
    assert r.status_code == 200, r.text
    link = r.json()["link"]
    print("member LINK:", link)
    assert "pa=coorgtyreshop-1%40okhdfcbank" in link
    assert "am=1000.00" in link
    assert not _has_non_ascii_percent(link)
    # note should include house_no
    m = re.search(r"tn=([^&]+)", link)
    tn_dec = unquote(m.group(1))
    assert "TMP-QA13" in tn_dec or "TMPQA13" in tn_dec.replace(" ", ""), f"tn should include house_no: {tn_dec!r}"


def test_5_notices_upi_link_ascii():
    r = requests.get(f"{API}/finance/notices", params={"house_id": state["house_id"]}, headers=_admin_headers())
    # This endpoint may require finance or admin — admin should work
    assert r.status_code == 200, r.text
    data = r.json()
    print("notices keys:", list(data.keys()) if isinstance(data, dict) else type(data))
    # find any upi_link fields recursively
    found = []

    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if k == "upi_link" and isinstance(v, str) and v:
                    found.append(v)
                walk(v)
        elif isinstance(x, list):
            for i in x:
                walk(i)
    walk(data)
    print("upi_links found:", len(found))
    for l in found:
        assert not _has_non_ascii_percent(l), f"non-ASCII in notices upi_link: {l}"


def test_6_final_settings_intact():
    r = requests.get(f"{API}/finance/fees", headers=_admin_headers())
    assert r.status_code == 200
    d = r.json()
    # These are the expected values per user's task
    print("final upi_id:", d.get("upi_id"), "upi_name:", d.get("upi_name"))
    assert d.get("upi_id") == "coorgtyreshop-1@okhdfcbank"
