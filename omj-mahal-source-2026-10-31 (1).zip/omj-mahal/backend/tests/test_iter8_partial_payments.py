"""Iteration 8: partial/instalment payments, receipt balance_after, old-balance items."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip().rstrip("/")

HOUSE_ID = "ef8af1bf-e64d-4d95-9205-b28e80e997fb"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"login_id": "ADMIN-001", "password": "admin123"})
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def member_token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"login_id": "OMJ-0099", "password": "member123"})
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def ah(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def mh(member_token):
    return {"Authorization": f"Bearer {member_token}"}


created_payment_ids = []
created_ob_items = []


@pytest.fixture(scope="module", autouse=True)
def cleanup_at_end(ah):
    yield
    # Delete all payments created during tests
    for pid in list(created_payment_ids):
        requests.delete(f"{BASE_URL}/api/payments/{pid}", headers=ah)
    # Remove all old-balance items for TEST-99
    r = requests.get(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/summary", headers=ah)
    if r.ok:
        items = r.json().get("collections", {}).get("old_balance", {}).get("items", [])
        for it in items:
            requests.delete(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/old-balance/{it['id']}", headers=ah)
    # Clear outbox
    requests.post(f"{BASE_URL}/api/notifications/outbox/clear", headers=ah)


def _summary(ah):
    r = requests.get(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/summary", headers=ah)
    assert r.status_code == 200, r.text
    return r.json()


# -------- Test 1: partial building --------
def test_1_partial_building(ah):
    r = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                      json={"house_id": HOUSE_ID, "type": "building", "amount": 500, "mode": "cash"})
    assert r.status_code == 201, r.text
    d = r.json()
    created_payment_ids.append(d["id"])
    assert d.get("receipt_no")
    ba = d["balance_after"]
    assert ba["head_due"] == 5000
    assert ba["head_paid"] == 500
    assert ba["head_pending"] == 4500

    s = _summary(ah)
    b = s["collections"]["building"]
    assert b["paid"] == 500 and b["pending"] == 4500

    # second payment 1500
    r2 = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                       json={"house_id": HOUSE_ID, "type": "building", "amount": 1500, "mode": "cash"})
    assert r2.status_code == 201, r2.text
    d2 = r2.json()
    created_payment_ids.append(d2["id"])
    assert d2["balance_after"]["head_paid"] == 2000
    assert d2["balance_after"]["head_pending"] == 3000

    lst = requests.get(f"{BASE_URL}/api/payments?house_id={HOUSE_ID}", headers=ah).json()
    building_rows = [p for p in lst if p["type"] == "building"]
    assert len(building_rows) >= 2
    assert all("balance_after" in p for p in building_rows)


# -------- Test 2: partial varisankhya --------
def test_2_partial_varisankhya(ah):
    s0 = _summary(ah)
    vs0 = s0["collections"]["varisankhya"]
    initial_pending = vs0["pending"]

    r = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                      json={"house_id": HOUSE_ID, "type": "varisankhya", "amount": 100, "mode": "cash"})
    assert r.status_code == 201, r.text
    d = r.json()
    created_payment_ids.append(d["id"])
    assert d.get("months") == [] or isinstance(d.get("months"), list)
    assert d.get("partial") is True
    ba = d["balance_after"]
    # subscription 250, paid 100, so head_pending should be initial+... but we can just verify decrement
    assert ba["head_paid"] >= 100

    s1 = _summary(ah)
    vs1 = s1["collections"]["varisankhya"]
    assert vs1["pending"] == initial_pending - 100

    # Ensure current month still in pending_periods (not fully covered)
    # (may be if first month has other payments, we skip strict check)

    r2 = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                       json={"house_id": HOUSE_ID, "type": "varisankhya", "amount": 150, "mode": "cash"})
    assert r2.status_code == 201, r2.text
    created_payment_ids.append(r2.json()["id"])

    s2 = _summary(ah)
    vs2 = s2["collections"]["varisankhya"]
    assert vs2["pending"] == initial_pending - 250

    # Now advance 300
    r3 = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                       json={"house_id": HOUSE_ID, "type": "varisankhya", "amount": 300, "mode": "cash"})
    assert r3.status_code == 201, r3.text
    created_payment_ids.append(r3.json()["id"])


# -------- Test 3: partial yearly (nabidinam) --------
def test_3_partial_nabidinam(ah):
    r = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                      json={"house_id": HOUSE_ID, "type": "nabidinam", "amount": 40, "mode": "cash"})
    assert r.status_code == 201, r.text
    d = r.json()
    created_payment_ids.append(d["id"])
    assert d["balance_after"]["head_pending"] >= 60  # at least 60 pending (may be more if multiple years)

    r2 = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                       json={"house_id": HOUSE_ID, "type": "nabidinam", "amount": 60, "mode": "cash"})
    assert r2.status_code == 201, r2.text
    d2 = r2.json()
    created_payment_ids.append(d2["id"])

    s = _summary(ah)
    n = s["collections"]["nabidinam"]
    # After paying 100 total: at least current year should be covered
    from datetime import date
    cur_y = str(date.today().year)
    assert cur_y in n["paid_periods"]


# -------- Test 4: receipt outbox text --------
def test_4_receipt_outbox_text(ah):
    import time
    # Trigger a payment
    r = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                      json={"house_id": HOUSE_ID, "type": "building", "amount": 100, "mode": "cash"})
    assert r.status_code == 201
    created_payment_ids.append(r.json()["id"])
    time.sleep(2)
    ob = requests.get(f"{BASE_URL}/api/notifications/outbox", headers=ah)
    assert ob.status_code == 200, ob.text
    msgs = ob.json()
    assert len(msgs) > 0
    # Newest first typically
    latest = msgs[0]
    body = latest.get("body", "")
    assert "ഇതുവരെ അടച്ചത്" in body, body
    assert "ബാക്കി" in body, body
    assert "എല്ലാ വകകളിലും കൂടി" in body, body


def test_5_receipt_fully_paid_text(ah):
    import time
    # Pay remaining building fully
    s = _summary(ah)
    remaining = s["collections"]["building"]["pending"]
    if remaining <= 0:
        pytest.skip("building already fully paid")
    r = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                      json={"house_id": HOUSE_ID, "type": "building", "amount": remaining, "mode": "cash"})
    assert r.status_code == 201, r.text
    created_payment_ids.append(r.json()["id"])
    time.sleep(2)
    ob = requests.get(f"{BASE_URL}/api/notifications/outbox", headers=ah).json()
    latest = ob[0]
    assert "പൂർണ്ണമായി അടച്ചു" in latest.get("body", ""), latest.get("body")


# -------- Test 6: old balance items --------
def test_6_old_balance_items(ah, mh):
    r = requests.post(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/old-balance", headers=ah,
                      json={"type": "nabidinam", "amount": 300, "note": "2025"})
    assert r.status_code == 201, r.text
    d = r.json()
    assert d["total"] == 300 and len(d["items"]) == 1

    r2 = requests.post(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/old-balance", headers=ah,
                       json={"type": "building", "amount": 2000, "note": ""})
    assert r2.status_code == 201
    assert r2.json()["total"] == 2300

    # invalid type
    r3 = requests.post(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/old-balance", headers=ah,
                      json={"type": "bogus", "amount": 10})
    assert r3.status_code == 400

    # amount 0
    r4 = requests.post(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/old-balance", headers=ah,
                      json={"type": "nabidinam", "amount": 0})
    assert r4.status_code == 400

    s = _summary(ah)
    ob = s["collections"]["old_balance"]
    assert ob["due"] == 2300
    assert isinstance(ob["items"], list) and len(ob["items"]) == 2

    # partial payment against old_balance
    rp = requests.post(f"{BASE_URL}/api/payments", headers=ah,
                       json={"house_id": HOUSE_ID, "type": "old_balance", "amount": 800, "mode": "cash"})
    assert rp.status_code == 201, rp.text
    created_payment_ids.append(rp.json()["id"])
    assert rp.json()["balance_after"]["head_pending"] == 1500

    # Delete one item
    item_id = s["collections"]["old_balance"]["items"][0]["id"]
    rd = requests.delete(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/old-balance/{item_id}", headers=ah)
    assert rd.status_code == 200
    s2 = _summary(ah)
    assert s2["collections"]["old_balance"]["due"] < 2300

    # member forbidden
    rf = requests.post(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/old-balance", headers=mh,
                      json={"type": "nabidinam", "amount": 5})
    assert rf.status_code == 403

    # Legacy PUT replaces
    rp2 = requests.put(f"{BASE_URL}/api/finance/house/{HOUSE_ID}/old-balance", headers=ah,
                       json={"amount": 100, "note": "x"})
    assert rp2.status_code == 200
    assert rp2.json()["total"] == 100
    assert len(rp2.json()["items"]) == 1


# -------- Test 7: regression --------
def test_7_regression_endpoints(ah):
    r = requests.get(f"{BASE_URL}/api/ledger/books", headers=ah)
    assert r.status_code == 200
    # login by member id
    lr = requests.post(f"{BASE_URL}/api/auth/login", json={"login_id": "OMJ-0099", "password": "member123"})
    assert lr.status_code == 200
