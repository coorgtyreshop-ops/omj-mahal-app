"""Iteration 6 backend tests: Member-ID login, OTP, send-id, ledger CRUD, salath managers, public/display."""
import os
import time
import requests
import pytest
from pymongo import MongoClient

BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/") if os.environ.get("REACT_APP_BACKEND_URL") else "https://anoo-platform.preview.emergentagent.com"
API = f"{BASE_URL}/api"

MONGO_URL = "mongodb://localhost:27017"
DB_NAME = "test_database"

ADMIN_ID = "ADMIN-001"
ADMIN_PHONE = "9999999999"
ADMIN_PW = "admin123"
MEMBER_ID = "OMJ-0099"
MEMBER_PHONE = "8888888888"
MEMBER_PW = "member123"
MEMBER_USER_ID = "5306d59f-e137-4101-8fb5-ccae52697b67"
HOUSE_ID = "ef8af1bf-e64d-4d95-9205-b28e80e997fb"


@pytest.fixture(scope="module")
def mongo():
    c = MongoClient(MONGO_URL)
    yield c[DB_NAME]
    c.close()


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{API}/auth/login", json={"login_id": ADMIN_ID, "password": ADMIN_PW})
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def member_token():
    r = requests.post(f"{API}/auth/login", json={"login_id": MEMBER_ID, "password": MEMBER_PW})
    if r.status_code != 200:
        pytest.skip(f"Member login failed: {r.text}")
    return r.json()["token"]


def H(t):
    return {"Authorization": f"Bearer {t}"}


# ---- AUTH: login variants ----
class TestLogin:
    def test_admin_login_id(self):
        r = requests.post(f"{API}/auth/login", json={"login_id": ADMIN_ID, "password": ADMIN_PW})
        assert r.status_code == 200
        u = r.json()["user"]
        assert u["login_id"] == ADMIN_ID
        assert u["ledger_scope"] == "all"

    def test_admin_phone_login(self):
        r = requests.post(f"{API}/auth/login", json={"login_id": ADMIN_PHONE, "password": ADMIN_PW})
        assert r.status_code == 200
        assert r.json()["user"]["role"] == "admin"

    def test_admin_lowercase(self):
        r = requests.post(f"{API}/auth/login", json={"login_id": "admin-001", "password": ADMIN_PW})
        assert r.status_code == 200
        assert r.json()["user"]["login_id"] == ADMIN_ID

    def test_member_login_id(self):
        r = requests.post(f"{API}/auth/login", json={"login_id": MEMBER_ID, "password": MEMBER_PW})
        assert r.status_code == 200, r.text
        u = r.json()["user"]
        assert u["house_id"] == HOUSE_ID
        assert u["ledger_scope"] == "salath"

    def test_member_phone_rejected(self):
        r = requests.post(f"{API}/auth/login", json={"login_id": MEMBER_PHONE, "password": MEMBER_PW})
        assert r.status_code == 401
        assert "Member ID" in r.json().get("detail", "")

    def test_wrong_password(self):
        r = requests.post(f"{API}/auth/login", json={"login_id": MEMBER_ID, "password": "wrongxxx"})
        assert r.status_code == 401
        assert "Invalid Member ID or password" in r.json().get("detail", "")

    def test_legacy_phone_body(self):
        r = requests.post(f"{API}/auth/login", json={"phone": ADMIN_ID, "password": ADMIN_PW})
        assert r.status_code == 200


# ---- Brute force ----
class TestBruteForce:
    def test_brute_lock(self, mongo):
        key = "BRUTE-TEST-X"
        mongo.login_attempts.delete_one({"key": key})
        for i in range(5):
            r = requests.post(f"{API}/auth/login", json={"login_id": key, "password": "bad"})
            assert r.status_code == 401
        r6 = requests.post(f"{API}/auth/login", json={"login_id": key, "password": "bad"})
        assert r6.status_code == 429
        mongo.login_attempts.delete_one({"key": key})


# ---- OTP ----
class TestOtp:
    def test_otp_request_and_verify(self):
        r = requests.post(f"{API}/auth/otp/request", json={"login_id": MEMBER_ID, "channel": "whatsapp"})
        assert r.status_code == 200, r.text
        d = r.json()
        assert "XXXX" in d["sent_to"]
        assert d.get("demo_code")
        r2 = requests.post(f"{API}/auth/otp/verify", json={"login_id": MEMBER_ID, "code": d["demo_code"]})
        assert r2.status_code == 200
        assert r2.json().get("token")

    def test_otp_unknown(self):
        r = requests.post(f"{API}/auth/otp/request", json={"login_id": "OMJ-9999", "channel": "whatsapp"})
        assert r.status_code == 404

    def test_otp_phone_hint(self):
        r = requests.post(f"{API}/auth/otp/request", json={"login_id": MEMBER_PHONE, "channel": "whatsapp"})
        assert r.status_code == 404
        assert "Member ID" in r.json().get("detail", "")


# ---- /me & /users ----
class TestMeUsers:
    def test_me_admin(self, admin_token):
        r = requests.get(f"{API}/auth/me", headers=H(admin_token))
        assert r.status_code == 200
        d = r.json()
        assert d["login_id"] == ADMIN_ID
        assert d["ledger_scope"] == "all"

    def test_users_login_ids(self, admin_token):
        r = requests.get(f"{API}/users", headers=H(admin_token))
        assert r.status_code == 200
        rows = r.json()
        by_phone = {u["phone"]: u for u in rows}
        assert by_phone[MEMBER_PHONE]["login_id"] == MEMBER_ID
        assert by_phone[ADMIN_PHONE]["login_id"] == ADMIN_ID


# ---- Send IDs ----
class TestSendId:
    def test_send_house_id(self, admin_token):
        r = requests.post(f"{API}/houses/{HOUSE_ID}/login/send-id", json={"app_url": "https://x.test"}, headers=H(admin_token))
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["status"] == "queued"
        assert f"Member ID: {MEMBER_ID}" in d["body"]
        assert d["body"].startswith("അസ്സലാമു അലൈക്കും")
        assert d["wa_link"].startswith("https://wa.me/")

    def test_bulk_send_ids(self, admin_token):
        r = requests.post(f"{API}/users/send-ids", json={}, headers=H(admin_token))
        assert r.status_code == 200
        assert r.json()["sent"] >= 1

    def test_member_cannot_send(self, member_token):
        r = requests.post(f"{API}/houses/{HOUSE_ID}/login/send-id", json={}, headers=H(member_token))
        assert r.status_code == 403

    def test_clear_outbox(self, admin_token):
        r = requests.post(f"{API}/notifications/outbox/clear", headers=H(admin_token))
        assert r.status_code == 200


# ---- House detail ----
class TestHouse:
    def test_house_login_id(self, admin_token):
        r = requests.get(f"{API}/houses/{HOUSE_ID}", headers=H(admin_token))
        assert r.status_code == 200
        d = r.json()
        assert d.get("login", {}).get("login_id") == MEMBER_ID

    def test_house_reset(self, admin_token):
        r = requests.post(f"{API}/houses/{HOUSE_ID}/login/reset", json={}, headers=H(admin_token))
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("login_id") == MEMBER_ID
        assert d.get("password")
        # restore member password to member123
        rr = requests.put(f"{API}/users/{MEMBER_USER_ID}", json={"password": MEMBER_PW}, headers=H(admin_token))
        assert rr.status_code == 200


# ---- Ledger ----
class TestLedger:
    main_book = None
    salath_book = None

    def test_meta_member(self, member_token):
        r = requests.get(f"{API}/ledger/meta", headers=H(member_token))
        assert r.status_code == 200
        assert r.json()["scope"] == "salath"

    def test_admin_create_main_book(self, admin_token):
        r = requests.post(f"{API}/ledger/books",
                          json={"name": "Test Nabidinam", "committee": "main", "date": "2026-09-26"},
                          headers=H(admin_token))
        assert r.status_code == 201, r.text
        TestLedger.main_book = r.json()["id"]

    def test_add_entries(self, admin_token):
        b = TestLedger.main_book
        # income kind (qty>0 amount=0) - allowed
        r = requests.post(f"{API}/ledger/books/{b}/entries",
                         json={"kind": "income", "category": "kind", "qty": 10, "unit": "kg", "amount": 0},
                         headers=H(admin_token))
        assert r.status_code == 201, r.text
        # income tin 2500
        r = requests.post(f"{API}/ledger/books/{b}/entries",
                         json={"kind": "income", "category": "tin", "amount": 2500},
                         headers=H(admin_token))
        assert r.status_code == 201
        # expense food 1800
        r = requests.post(f"{API}/ledger/books/{b}/entries",
                         json={"kind": "expense", "category": "food", "amount": 1800, "party": "Caterer"},
                         headers=H(admin_token))
        assert r.status_code == 201
        self.expense_entry_id = r.json()["id"]

    def test_invalid_entries(self, admin_token):
        b = TestLedger.main_book
        # invalid category
        r = requests.post(f"{API}/ledger/books/{b}/entries",
                         json={"kind": "income", "category": "bogus", "amount": 100},
                         headers=H(admin_token))
        assert r.status_code == 400
        # zero amount and qty
        r = requests.post(f"{API}/ledger/books/{b}/entries",
                         json={"kind": "income", "category": "tin", "amount": 0, "qty": 0},
                         headers=H(admin_token))
        assert r.status_code == 400
        # bad kind
        r = requests.post(f"{API}/ledger/books/{b}/entries",
                         json={"kind": "x", "category": "tin", "amount": 100},
                         headers=H(admin_token))
        assert r.status_code == 400

    def test_book_detail(self, admin_token):
        b = TestLedger.main_book
        r = requests.get(f"{API}/ledger/books/{b}", headers=H(admin_token))
        assert r.status_code == 200
        d = r.json()
        s = d["summary"]
        assert s["income"] == 2500
        assert s["expense"] == 1800
        assert s["balance"] == 700
        assert s["income_by"]["tin"] == 2500
        assert len(s["kind_items"]) == 1
        assert s["donors"] >= 0
        assert d["can_edit"] is True

    def test_book_list_year(self, admin_token):
        r = requests.get(f"{API}/ledger/books?committee=main&year=2026", headers=H(admin_token))
        assert r.status_code == 200
        rows = r.json()
        assert any(bk["id"] == TestLedger.main_book and bk["balance"] == 700 for bk in rows)

    def test_update_delete_entry(self, admin_token):
        b = TestLedger.main_book
        entries = requests.get(f"{API}/ledger/books/{b}", headers=H(admin_token)).json()["entries"]
        food = [e for e in entries if e["category"] == "food"][0]
        r = requests.put(f"{API}/ledger/entries/{food['id']}",
                        json={"kind": "expense", "category": "food", "amount": 1900, "party": "Caterer"},
                        headers=H(admin_token))
        assert r.status_code == 200
        assert r.json()["amount"] == 1900
        r = requests.delete(f"{API}/ledger/entries/{food['id']}", headers=H(admin_token))
        assert r.status_code == 200

    def test_book_rename(self, admin_token):
        b = TestLedger.main_book
        r = requests.put(f"{API}/ledger/books/{b}",
                        json={"name": "Test Nabidinam Renamed", "committee": "main", "date": "2026-09-26"},
                        headers=H(admin_token))
        assert r.status_code == 200
        assert r.json()["name"] == "Test Nabidinam Renamed"

    def test_member_forbidden_main(self, member_token):
        r = requests.post(f"{API}/ledger/books",
                         json={"name": "Bad", "committee": "main", "date": "2026-09-01"},
                         headers=H(member_token))
        assert r.status_code == 403

    def test_member_creates_salath(self, member_token):
        r = requests.post(f"{API}/ledger/books",
                         json={"name": "Test Salath Month", "committee": "salath", "month": "2026-09"},
                         headers=H(member_token))
        assert r.status_code == 201, r.text
        d = r.json()
        assert d["date"] == "2026-09-01"
        TestLedger.salath_book = d["id"]

    def test_member_read_main(self, member_token):
        r = requests.get(f"{API}/ledger/books/{TestLedger.main_book}", headers=H(member_token))
        assert r.status_code == 200
        assert r.json()["can_edit"] is False

    def test_member_cannot_delete_main(self, member_token):
        r = requests.delete(f"{API}/ledger/books/{TestLedger.main_book}", headers=H(member_token))
        assert r.status_code == 403

    def test_cleanup_books(self, admin_token):
        for bid in [TestLedger.main_book, TestLedger.salath_book]:
            if bid:
                r = requests.delete(f"{API}/ledger/books/{bid}", headers=H(admin_token))
                assert r.status_code == 200


# ---- Salath managers toggle ----
class TestSalathManagers:
    def test_toggle_and_leave_on(self, admin_token):
        # toggle off
        r = requests.put(f"{API}/ledger/salath-managers",
                        json={"user_id": MEMBER_USER_ID, "on": False},
                        headers=H(admin_token))
        assert r.status_code == 200
        assert MEMBER_USER_ID not in r.json()["salath_manager_ids"]
        # settings shows it
        s = requests.get(f"{API}/settings", headers=H(admin_token)).json()
        assert MEMBER_USER_ID not in s.get("salath_manager_ids", [])
        # toggle on (final state)
        r = requests.put(f"{API}/ledger/salath-managers",
                        json={"user_id": MEMBER_USER_ID, "on": True},
                        headers=H(admin_token))
        assert r.status_code == 200
        assert MEMBER_USER_ID in r.json()["salath_manager_ids"]


# ---- Public display ----
class TestPublic:
    def test_display_no_auth(self):
        r = requests.get(f"{API}/public/display")
        assert r.status_code == 200
        text = str(r.json())
        assert "Sandy" in text or "Majlissunnor" in text
        assert "poster_url" in text
