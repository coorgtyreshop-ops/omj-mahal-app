"""
Backend tests for OTP auth + notifications (mock gateway).
"""
import os
import time
import pytest
import requests

BASE = (os.environ.get("REACT_APP_BACKEND_URL") or "https://anoo-platform.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"

ADMIN = {"phone": "9999999999", "password": "admin123"}
MEMBER_PHONE = "8888888888"
MEMBER_PASSWORD = "member123"


def _login(creds):
    r = requests.post(f"{API}/auth/login", json=creds)
    r.raise_for_status()
    return r.json()["token"]


@pytest.fixture(scope="session")
def admin_h():
    return {"Authorization": f"Bearer {_login(ADMIN)}"}


@pytest.fixture(scope="session")
def member_h():
    return {"Authorization": f"Bearer {_login({'phone': MEMBER_PHONE, 'password': MEMBER_PASSWORD})}"}


# -------------------- OTP request --------------------
class TestOtpRequest:
    def test_whatsapp_channel_uses_house_whatsapp(self):
        r = requests.post(f"{API}/auth/otp/request", json={
            "phone": MEMBER_PHONE, "channel": "whatsapp"
        })
        assert r.status_code == 200, r.text
        j = r.json()
        assert j["status"] == "mock"
        assert j["to"] == "+919847000001", j
        assert "demo_code" in j and len(j["demo_code"]) == 6 and j["demo_code"].isdigit()

    def test_sms_channel_uses_member_phone(self):
        r = requests.post(f"{API}/auth/otp/request", json={
            "phone": MEMBER_PHONE, "channel": "sms"
        })
        assert r.status_code == 200
        j = r.json()
        assert j["to"] == "+918888888888"
        assert j["status"] == "mock"

    def test_unregistered_phone_404(self):
        r = requests.post(f"{API}/auth/otp/request", json={
            "phone": "7777770000", "channel": "sms"
        })
        assert r.status_code == 404

    def test_bad_channel_400(self):
        r = requests.post(f"{API}/auth/otp/request", json={
            "phone": MEMBER_PHONE, "channel": "xx"
        })
        assert r.status_code == 400


# -------------------- OTP verify --------------------
class TestOtpVerify:
    def test_verify_ok_and_wrong_and_reuse(self):
        r = requests.post(f"{API}/auth/otp/request", json={
            "phone": MEMBER_PHONE, "channel": "whatsapp"
        })
        code = r.json()["demo_code"]

        # Wrong code
        bad = requests.post(f"{API}/auth/otp/verify", json={"phone": MEMBER_PHONE, "code": "000000" if code != "000000" else "111111"})
        assert bad.status_code == 401

        # Correct code
        ok = requests.post(f"{API}/auth/otp/verify", json={"phone": MEMBER_PHONE, "code": code})
        assert ok.status_code == 200, ok.text
        j = ok.json()
        assert "token" in j and j["user"]["phone"] == MEMBER_PHONE

        # Reuse — consumed
        reuse = requests.post(f"{API}/auth/otp/verify", json={"phone": MEMBER_PHONE, "code": code})
        assert reuse.status_code == 401


# -------------------- Forgot-password OTP reset --------------------
class TestOtpResetPassword:
    def test_reset_and_restore(self):
        # 1. Request reset OTP via SMS
        r = requests.post(f"{API}/auth/otp/request", json={
            "phone": MEMBER_PHONE, "channel": "sms", "purpose": "reset"
        })
        assert r.status_code == 200
        code = r.json()["demo_code"]

        # 2. Short password rejected
        short = requests.post(f"{API}/auth/otp/reset-password", json={
            "phone": MEMBER_PHONE, "code": code, "new_password": "abc"
        })
        assert short.status_code == 400

        # 3. Reset to member456
        reset = requests.post(f"{API}/auth/otp/reset-password", json={
            "phone": MEMBER_PHONE, "code": code, "new_password": "member456"
        })
        assert reset.status_code == 200, reset.text

        # 4. Login with new password works
        r2 = requests.post(f"{API}/auth/login", json={"phone": MEMBER_PHONE, "password": "member456"})
        assert r2.status_code == 200

        # 5. Restore back to member123
        r3 = requests.post(f"{API}/auth/otp/request", json={
            "phone": MEMBER_PHONE, "channel": "sms", "purpose": "reset"
        })
        code2 = r3.json()["demo_code"]
        r4 = requests.post(f"{API}/auth/otp/reset-password", json={
            "phone": MEMBER_PHONE, "code": code2, "new_password": MEMBER_PASSWORD
        })
        assert r4.status_code == 200

        # 6. Login works with restored password
        r5 = requests.post(f"{API}/auth/login", json={"phone": MEMBER_PHONE, "password": MEMBER_PASSWORD})
        assert r5.status_code == 200


# -------------------- Notifications endpoints --------------------
class TestNotifications:
    def test_status_mock(self, admin_h):
        r = requests.get(f"{API}/notifications/status", headers=admin_h)
        assert r.status_code == 200
        j = r.json()
        assert j["mode"] == "mock"
        for k in ("notify_channel", "notify_on_announcement", "notify_on_payment"):
            assert k in j

    def test_member_forbidden_list(self, member_h):
        r = requests.get(f"{API}/notifications", headers=member_h)
        assert r.status_code == 403

    def test_member_forbidden_dues_reminder(self, member_h):
        r = requests.post(f"{API}/notifications/dues-reminder", headers=member_h, json={})
        assert r.status_code == 403

    def test_clear_then_dues_reminder(self, admin_h):
        # Clear log
        c = requests.delete(f"{API}/notifications/clear", headers=admin_h)
        assert c.status_code == 200

        # Fire dues-reminder with empty body dict
        r = requests.post(f"{API}/notifications/dues-reminder", headers=admin_h, json={})
        assert r.status_code == 200, r.text
        n = r.json()["houses_notified"]
        assert n > 0

        # Verify N whatsapp dues_reminder mock messages exist
        lst = requests.get(f"{API}/notifications?kind=dues_reminder&channel=whatsapp", headers=admin_h).json()
        assert len(lst) >= n
        for m in lst[:n]:
            assert m["kind"] == "dues_reminder"
            assert m["channel"] == "whatsapp"
            assert m["status"] == "mock"

    def test_dues_reminder_no_body(self, admin_h):
        r = requests.post(f"{API}/notifications/dues-reminder", headers=admin_h)
        assert r.status_code == 200
        assert r.json()["houses_notified"] > 0

    def test_custom_message(self, admin_h):
        requests.delete(f"{API}/notifications/clear", headers=admin_h)
        r = requests.post(f"{API}/notifications/custom", headers=admin_h, json={"body": "Test message"})
        assert r.status_code == 200
        j = r.json()
        assert j["ok"] and j["houses"] >= 1
        time.sleep(2)
        lst = requests.get(f"{API}/notifications?kind=custom", headers=admin_h).json()
        assert len(lst) >= 1

    def test_summary(self, admin_h):
        r = requests.get(f"{API}/notifications/summary", headers=admin_h)
        assert r.status_code == 200
        j = r.json()
        assert "total" in j and "by_status" in j and "by_kind" in j


# -------------------- Broadcast on announcement / payment --------------------
def _get_settings():
    return requests.get(f"{API}/settings").json()


def _put_settings(admin_h, patch):
    cur = _get_settings()
    cur.update(patch)
    r = requests.put(f"{API}/settings", headers=admin_h, json=cur)
    assert r.status_code == 200, r.text


class TestBroadcastHooks:
    def test_announcement_triggers_broadcast(self, admin_h):
        requests.delete(f"{API}/notifications/clear", headers=admin_h)
        # Ensure announcement notify on and channel whatsapp
        _put_settings(admin_h, {"notify_on_announcement": True, "notify_channel": "whatsapp"})

        r = requests.post(f"{API}/announcements", headers=admin_h, json={
            "title": "TEST_Broadcast", "content": "hi", "category": "general"
        })
        assert r.status_code == 201
        ann_id = r.json()["id"]

        time.sleep(2)
        lst = requests.get(f"{API}/notifications?kind=announcement", headers=admin_h).json()
        assert len(lst) >= 1

        # Cleanup announcement
        requests.delete(f"{API}/announcements/{ann_id}", headers=admin_h)

    def test_announcement_off_no_broadcast(self, admin_h):
        _put_settings(admin_h, {"notify_on_announcement": False, "notify_channel": "whatsapp"})
        requests.delete(f"{API}/notifications/clear", headers=admin_h)

        r = requests.post(f"{API}/announcements", headers=admin_h, json={
            "title": "TEST_Silent", "content": "hi", "category": "general"
        })
        assert r.status_code == 201
        ann_id = r.json()["id"]
        time.sleep(1.5)
        lst = requests.get(f"{API}/notifications?kind=announcement", headers=admin_h).json()
        assert len(lst) == 0

        requests.delete(f"{API}/announcements/{ann_id}", headers=admin_h)
        # Restore
        _put_settings(admin_h, {"notify_on_announcement": True})

    def test_channel_both_creates_two(self, admin_h):
        _put_settings(admin_h, {"notify_on_announcement": True, "notify_channel": "both"})
        requests.delete(f"{API}/notifications/clear", headers=admin_h)
        r = requests.post(f"{API}/announcements", headers=admin_h, json={
            "title": "TEST_Both", "content": "hi", "category": "general"
        })
        ann_id = r.json()["id"]
        time.sleep(2)
        lst_sms = requests.get(f"{API}/notifications?kind=announcement&channel=sms", headers=admin_h).json()
        lst_wa = requests.get(f"{API}/notifications?kind=announcement&channel=whatsapp", headers=admin_h).json()
        assert len(lst_sms) >= 1
        assert len(lst_wa) >= 1

        requests.delete(f"{API}/announcements/{ann_id}", headers=admin_h)
        _put_settings(admin_h, {"notify_channel": "whatsapp"})

    def test_payment_creates_receipt_message(self, admin_h):
        requests.delete(f"{API}/notifications/clear", headers=admin_h)
        # Find a house with pending months
        houses = requests.get(f"{API}/houses?with_dues=true", headers=admin_h).json()
        target = next((h for h in houses if h["dues"]["pending_months"]), None)
        assert target, "expected a house with dues"
        months = target["dues"]["pending_months"][:1]
        p = requests.post(f"{API}/payments", headers=admin_h, json={
            "house_id": target["id"], "months": months, "amount": 100, "mode": "cash"
        })
        assert p.status_code == 201, p.text
        pay_id = p.json()["id"]

        time.sleep(1.5)
        lst = requests.get(f"{API}/notifications?kind=receipt", headers=admin_h).json()
        assert len(lst) >= 1

        requests.delete(f"{API}/payments/{pay_id}", headers=admin_h)


# -------------------- House WhatsApp field --------------------
class TestHouseWhatsapp:
    def test_whatsapp_field_roundtrip(self, admin_h):
        house_no = f"TEST-WA-{int(time.time())}"
        payload = {
            "house_no": house_no, "head_name": "TEST_WA",
            "phone": "9000000000", "whatsapp": "9000000001",
            "subscription_amount": 100, "start_month": "2026-07",
        }
        c = requests.post(f"{API}/houses", headers=admin_h, json=payload)
        assert c.status_code == 201, c.text
        hid = c.json()["id"]
        assert c.json().get("whatsapp") == "9000000001"

        # Search by whatsapp
        s = requests.get(f"{API}/houses?q=9000000001", headers=admin_h).json()
        assert any(h["id"] == hid for h in s)

        # Update
        u = requests.put(f"{API}/houses/{hid}", headers=admin_h, json={**payload, "whatsapp": "9000000002"})
        assert u.status_code == 200
        assert u.json()["whatsapp"] == "9000000002"

        # Delete
        d = requests.delete(f"{API}/houses/{hid}", headers=admin_h)
        assert d.status_code == 200
