"""
Backend API tests for Mahal App.
Covers: auth, houses, members, payments, funds/donations, expenses,
reports, dashboard, announcements, committee, settings, certificates, users.
"""
import os
import pytest
import requests
from datetime import datetime, timezone

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://anoo-platform.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"

ADMIN = {"phone": "9999999999", "password": "admin123"}
MEMBER = {"phone": "8888888888", "password": "member123"}


# ---------- fixtures ----------
@pytest.fixture(scope="session")
def admin_token():
    r = requests.post(f"{API}/auth/login", json=ADMIN)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def member_token():
    r = requests.post(f"{API}/auth/login", json=MEMBER)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def admin_h():
    return {"Authorization": f"Bearer {token_for(ADMIN)}"}


@pytest.fixture(scope="session")
def member_h():
    return {"Authorization": f"Bearer {token_for(MEMBER)}"}


def token_for(creds):
    r = requests.post(f"{API}/auth/login", json=creds)
    r.raise_for_status()
    return r.json()["token"]


# ---------- Auth ----------
class TestAuth:
    def test_admin_login(self):
        r = requests.post(f"{API}/auth/login", json=ADMIN)
        assert r.status_code == 200
        j = r.json()
        assert "token" in j and j["user"]["role"] == "admin"
        assert "password_hash" not in j["user"]

    def test_member_login(self):
        r = requests.post(f"{API}/auth/login", json=MEMBER)
        assert r.status_code == 200
        assert r.json()["user"]["role"] == "member"

    def test_wrong_password(self):
        r = requests.post(f"{API}/auth/login", json={"phone": "9999999999", "password": "bad"})
        assert r.status_code == 401

    def test_me(self, admin_h):
        r = requests.get(f"{API}/auth/me", headers=admin_h)
        assert r.status_code == 200
        assert r.json()["role"] == "admin"

    def test_me_no_token(self):
        r = requests.get(f"{API}/auth/me")
        assert r.status_code == 401

    def test_change_password_wrong_current(self, admin_h):
        r = requests.post(f"{API}/auth/change-password", headers=admin_h,
                          json={"current_password": "wrong", "new_password": "newpass1"})
        assert r.status_code == 400

    def test_change_language_valid(self, admin_h):
        r = requests.patch(f"{API}/auth/language", headers=admin_h, json={"language": "ml"})
        assert r.status_code == 200
        # revert
        requests.patch(f"{API}/auth/language", headers=admin_h, json={"language": "en"})

    def test_change_language_invalid(self, admin_h):
        r = requests.patch(f"{API}/auth/language", headers=admin_h, json={"language": "xx"})
        assert r.status_code == 400


# ---------- Houses ----------
class TestHouses:
    created_id = None
    created_no = f"TEST-{int(datetime.now(timezone.utc).timestamp())}"

    def test_list_houses_admin(self, admin_h):
        r = requests.get(f"{API}/houses", headers=admin_h)
        assert r.status_code == 200
        assert isinstance(r.json(), list) and len(r.json()) >= 1

    def test_list_houses_with_dues(self, admin_h):
        r = requests.get(f"{API}/houses?with_dues=true", headers=admin_h)
        assert r.status_code == 200
        assert "dues" in r.json()[0]

    def test_wards(self, admin_h):
        r = requests.get(f"{API}/houses/wards", headers=admin_h)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_member_scoped_list(self, member_h):
        r = requests.get(f"{API}/houses", headers=member_h)
        assert r.status_code == 200
        assert len(r.json()) == 1

    def test_create_house(self, admin_h):
        payload = {"house_no": TestHouses.created_no, "head_name": "TEST_Head",
                   "address": "Test addr", "ward": "TestWard", "phone": "9000000001",
                   "subscription_amount": 100, "start_month": "2026-07"}
        r = requests.post(f"{API}/houses", headers=admin_h, json=payload)
        assert r.status_code == 201, r.text
        j = r.json()
        assert j["house_no"] == TestHouses.created_no
        TestHouses.created_id = j["id"]

    def test_duplicate_house_no(self, admin_h):
        payload = {"house_no": TestHouses.created_no, "head_name": "dup"}
        r = requests.post(f"{API}/houses", headers=admin_h, json=payload)
        assert r.status_code == 400

    def test_get_house_detail(self, admin_h):
        r = requests.get(f"{API}/houses/{TestHouses.created_id}", headers=admin_h)
        assert r.status_code == 200
        j = r.json()
        assert "members" in j and "dues" in j and "payments" in j

    def test_member_scoped_other_house(self, member_h):
        # Member requesting another house should get own house (scoped)
        r = requests.get(f"{API}/houses/{TestHouses.created_id}", headers=member_h)
        assert r.status_code == 200
        assert r.json()["id"] != TestHouses.created_id

    def test_update_house(self, admin_h):
        payload = {"house_no": TestHouses.created_no, "head_name": "TEST_Head_Updated"}
        r = requests.put(f"{API}/houses/{TestHouses.created_id}", headers=admin_h, json=payload)
        assert r.status_code == 200
        assert r.json()["head_name"] == "TEST_Head_Updated"

    def test_member_cannot_create_house(self, member_h):
        r = requests.post(f"{API}/houses", headers=member_h,
                          json={"house_no": "X", "head_name": "y"})
        assert r.status_code == 403


# ---------- Members ----------
class TestMembers:
    created_id = None

    def test_create_member(self, admin_h):
        r = requests.post(f"{API}/members", headers=admin_h, json={
            "house_id": TestHouses.created_id, "name": "TEST_Member", "relation": "son"
        })
        assert r.status_code == 201, r.text
        TestMembers.created_id = r.json()["id"]

    def test_list_members(self, admin_h):
        r = requests.get(f"{API}/members", headers=admin_h)
        assert r.status_code == 200
        assert any(m["id"] == TestMembers.created_id for m in r.json())

    def test_list_members_member_scoped(self, member_h):
        r = requests.get(f"{API}/members", headers=member_h)
        assert r.status_code == 200
        # all returned members should be within member's house
        for m in r.json():
            assert m["house_id"] is not None

    def test_delete_member(self, admin_h):
        r = requests.delete(f"{API}/members/{TestMembers.created_id}", headers=admin_h)
        assert r.status_code == 200


# ---------- Payments / Dues ----------
class TestPayments:
    payment_id = None

    def test_dues_list_admin(self, admin_h):
        r = requests.get(f"{API}/payments/dues", headers=admin_h)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_empty_months_400(self, admin_h):
        r = requests.post(f"{API}/payments", headers=admin_h, json={
            "house_id": TestHouses.created_id, "months": [], "amount": 100
        })
        assert r.status_code == 400

    def test_create_payment(self, admin_h):
        # get dues for our test house
        r = requests.get(f"{API}/houses/{TestHouses.created_id}", headers=admin_h)
        pending = r.json()["dues"]["pending_months"]
        assert pending, "expected some pending months"
        months = pending[:2]
        r = requests.post(f"{API}/payments", headers=admin_h, json={
            "house_id": TestHouses.created_id, "months": months, "amount": 200,
            "mode": "cash"
        })
        assert r.status_code == 201, r.text
        j = r.json()
        assert j["receipt_no"].startswith("RCT-")
        TestPayments.payment_id = j["id"]
        TestPayments.paid_months = months

    def test_duplicate_month(self, admin_h):
        r = requests.post(f"{API}/payments", headers=admin_h, json={
            "house_id": TestHouses.created_id, "months": TestPayments.paid_months, "amount": 100
        })
        assert r.status_code == 400

    def test_dues_decreased(self, admin_h):
        r = requests.get(f"{API}/houses/{TestHouses.created_id}", headers=admin_h)
        pending = r.json()["dues"]["pending_months"]
        for m in TestPayments.paid_months:
            assert m not in pending

    def test_member_cannot_create_payment(self, member_h):
        r = requests.post(f"{API}/payments", headers=member_h, json={
            "house_id": TestHouses.created_id, "months": ["2026-09"], "amount": 100
        })
        assert r.status_code == 403

    def test_list_payments(self, admin_h):
        r = requests.get(f"{API}/payments", headers=admin_h)
        assert r.status_code == 200

    def test_delete_payment(self, admin_h):
        r = requests.delete(f"{API}/payments/{TestPayments.payment_id}", headers=admin_h)
        assert r.status_code == 200


# ---------- Funds/Donations ----------
class TestFundsDonations:
    fund_id = None
    donation_id = None

    def test_create_fund(self, admin_h):
        r = requests.post(f"{API}/funds", headers=admin_h, json={
            "name": "TEST_Fund", "description": "t", "target": 10000
        })
        assert r.status_code == 201
        TestFundsDonations.fund_id = r.json()["id"]

    def test_list_funds(self, admin_h):
        r = requests.get(f"{API}/funds", headers=admin_h)
        assert r.status_code == 200
        f = next((f for f in r.json() if f["id"] == TestFundsDonations.fund_id), None)
        assert f and "raised" in f and "donor_count" in f

    def test_create_donation(self, admin_h):
        r = requests.post(f"{API}/donations", headers=admin_h, json={
            "fund_id": TestFundsDonations.fund_id, "donor_name": "TEST_Donor",
            "house_id": TestHouses.created_id, "amount": 500
        })
        assert r.status_code == 201, r.text
        j = r.json()
        assert j["receipt_no"].startswith("DON-")
        TestFundsDonations.donation_id = j["id"]

    def test_get_donation(self, admin_h):
        r = requests.get(f"{API}/donations/{TestFundsDonations.donation_id}", headers=admin_h)
        assert r.status_code == 200
        assert r.json()["fund_name"] == "TEST_Fund"

    def test_delete_donation(self, admin_h):
        r = requests.delete(f"{API}/donations/{TestFundsDonations.donation_id}", headers=admin_h)
        assert r.status_code == 200

    def test_delete_fund(self, admin_h):
        r = requests.delete(f"{API}/funds/{TestFundsDonations.fund_id}", headers=admin_h)
        assert r.status_code == 200


# ---------- Expenses ----------
class TestExpenses:
    expense_id = None

    def test_member_cannot_list_expenses(self, member_h):
        r = requests.get(f"{API}/expenses", headers=member_h)
        assert r.status_code == 403

    def test_create_expense(self, admin_h):
        r = requests.post(f"{API}/expenses", headers=admin_h, json={
            "category": "TEST_Utilities", "amount": 250, "description": "t"
        })
        assert r.status_code == 201
        TestExpenses.expense_id = r.json()["id"]

    def test_list_expenses(self, admin_h):
        r = requests.get(f"{API}/expenses", headers=admin_h)
        assert r.status_code == 200

    def test_delete_expense(self, admin_h):
        r = requests.delete(f"{API}/expenses/{TestExpenses.expense_id}", headers=admin_h)
        assert r.status_code == 200


# ---------- Reports & Dashboard ----------
class TestReports:
    def test_summary_year(self, admin_h):
        r = requests.get(f"{API}/reports/summary?year=2026", headers=admin_h)
        assert r.status_code == 200
        j = r.json()
        assert "income" in j and "expenses" in j and "balance" in j
        assert len(j["monthly"]) == 12
        assert "donations_by_fund" in j

    def test_summary_month(self, admin_h):
        r = requests.get(f"{API}/reports/summary?month=2026-09", headers=admin_h)
        assert r.status_code == 200
        assert r.json()["monthly"] == []

    def test_dashboard_admin(self, admin_h):
        r = requests.get(f"{API}/dashboard", headers=admin_h)
        assert r.status_code == 200
        j = r.json()
        for k in ("houses", "members", "this_month_collection", "pending_amount",
                  "pending_houses", "year_balance", "announcements", "funds"):
            assert k in j, f"missing {k}"

    def test_dashboard_member(self, member_h):
        r = requests.get(f"{API}/dashboard", headers=member_h)
        assert r.status_code == 200
        j = r.json()
        assert j["role"] == "member"
        assert "house" in j and "dues" in j and "member_count" in j


# ---------- Announcements/Committee/Settings ----------
class TestContent:
    ann_id = None
    com_id = None

    def test_create_announcement(self, admin_h):
        r = requests.post(f"{API}/announcements", headers=admin_h, json={
            "title": "TEST_Ann", "content": "hello", "category": "janazah"
        })
        assert r.status_code == 201
        TestContent.ann_id = r.json()["id"]

    def test_list_announcements(self, admin_h):
        r = requests.get(f"{API}/announcements?category=janazah", headers=admin_h)
        assert r.status_code == 200

    def test_delete_announcement(self, admin_h):
        r = requests.delete(f"{API}/announcements/{TestContent.ann_id}", headers=admin_h)
        assert r.status_code == 200

    def test_create_committee(self, admin_h):
        r = requests.post(f"{API}/committee", headers=admin_h, json={
            "name": "TEST_Member", "designation": "Secretary"
        })
        assert r.status_code == 201
        TestContent.com_id = r.json()["id"]

    def test_delete_committee(self, admin_h):
        r = requests.delete(f"{API}/committee/{TestContent.com_id}", headers=admin_h)
        assert r.status_code == 200

    def test_get_settings(self):
        r = requests.get(f"{API}/settings")
        assert r.status_code == 200
        assert "mahal_name" in r.json()

    def test_update_settings(self, admin_h):
        cur = requests.get(f"{API}/settings").json()
        r = requests.put(f"{API}/settings", headers=admin_h, json=cur)
        assert r.status_code == 200


# ---------- Certificates ----------
class TestCertificates:
    cert_id = None

    def test_invalid_type(self, admin_h):
        r = requests.post(f"{API}/certificates", headers=admin_h, json={
            "type": "bogus", "data": {}
        })
        assert r.status_code == 400

    def test_create_membership(self, admin_h):
        r = requests.post(f"{API}/certificates", headers=admin_h, json={
            "type": "membership", "data": {"name": "TEST_X", "house_no": "H-01"}
        })
        assert r.status_code == 201
        j = r.json()
        assert j["cert_no"].startswith("CERT-")
        TestCertificates.cert_id = j["id"]

    def test_get_cert(self, admin_h):
        r = requests.get(f"{API}/certificates/{TestCertificates.cert_id}", headers=admin_h)
        assert r.status_code == 200
        assert "settings" in r.json()

    def test_delete_cert(self, admin_h):
        r = requests.delete(f"{API}/certificates/{TestCertificates.cert_id}", headers=admin_h)
        assert r.status_code == 200


# ---------- Users ----------
class TestUsers:
    user_id = None

    def test_list_users_admin_only(self, admin_h, member_h):
        r = requests.get(f"{API}/users", headers=admin_h)
        assert r.status_code == 200
        r2 = requests.get(f"{API}/users", headers=member_h)
        assert r2.status_code == 403

    def test_create_user_dup_phone(self, admin_h):
        r = requests.post(f"{API}/users", headers=admin_h, json={
            "name": "TEST_Dup", "phone": "9999999999", "password": "x"
        })
        assert r.status_code == 400

    def test_create_user(self, admin_h):
        r = requests.post(f"{API}/users", headers=admin_h, json={
            "name": "TEST_NewUser", "phone": "7000000099", "password": "pass1234",
            "role": "member", "house_id": TestHouses.created_id
        })
        assert r.status_code == 201
        TestUsers.user_id = r.json()["id"]

    def test_update_user(self, admin_h):
        r = requests.put(f"{API}/users/{TestUsers.user_id}", headers=admin_h, json={
            "name": "TEST_Updated", "password": "newpass"
        })
        assert r.status_code == 200
        assert r.json()["name"] == "TEST_Updated"

    def test_cannot_delete_self(self, admin_h):
        me = requests.get(f"{API}/auth/me", headers=admin_h).json()
        r = requests.delete(f"{API}/users/{me['id']}", headers=admin_h)
        assert r.status_code == 400

    def test_delete_user(self, admin_h):
        r = requests.delete(f"{API}/users/{TestUsers.user_id}", headers=admin_h)
        assert r.status_code == 200


# ---------- Cleanup ----------
def test_zzz_cleanup_house(admin_h=None):
    """Delete the test house (runs last)."""
    tok = token_for(ADMIN)
    hdrs = {"Authorization": f"Bearer {tok}"}
    if TestHouses.created_id:
        requests.delete(f"{API}/houses/{TestHouses.created_id}", headers=hdrs)
