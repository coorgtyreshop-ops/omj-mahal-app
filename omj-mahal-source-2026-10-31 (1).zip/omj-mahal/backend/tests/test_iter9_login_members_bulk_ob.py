"""Iteration 9 backend tests: forgiving login, second-member classification, bulk old balance."""
import os
import pytest
import requests

def _load_backend_url():
    p = "/app/frontend/.env"
    if os.path.exists(p):
        for ln in open(p):
            if ln.startswith("REACT_APP_BACKEND_URL="):
                return ln.split("=", 1)[1].strip()
    return os.environ.get("REACT_APP_BACKEND_URL", "")

BASE = _load_backend_url().rstrip("/") + "/api"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE}/auth/login", json={"login_id": "ADMIN-099", "password": "test1234"})
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_h(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def temp_house(admin_h):
    # Ensure clean state
    r = requests.get(f"{BASE}/houses?q=TST-77", headers=admin_h)
    for h in r.json():
        if h["house_no"] == "TST-77":
            requests.delete(f"{BASE}/houses/{h['id']}", headers=admin_h)
    # Delete any existing user with phone 7000000077
    for u in requests.get(f"{BASE}/users", headers=admin_h).json():
        if u.get("phone") == "7000000077":
            requests.delete(f"{BASE}/users/{u['id']}", headers=admin_h)
    # Create house
    r = requests.post(f"{BASE}/houses", headers=admin_h, json={
        "house_no": "TST-77", "head_name": "Temp Head",
        "phone": "7000000077", "subscription_amount": 250,
    })
    assert r.status_code == 201, r.text
    house = r.json()
    # Create login
    r = requests.post(f"{BASE}/houses/{house['id']}/login", headers=admin_h, json={})
    assert r.status_code == 201, r.text
    login = r.json()
    yield {"house": house, "login_id": login["login_id"], "password": login["password"]}
    # Teardown
    requests.delete(f"{BASE}/houses/{house['id']}", headers=admin_h)
    for u in requests.get(f"{BASE}/users", headers=admin_h).json():
        if u.get("phone") == "7000000077":
            requests.delete(f"{BASE}/users/{u['id']}", headers=admin_h)
    requests.post(f"{BASE}/notifications/outbox/clear", headers=admin_h)


# =========== Forgiving login ===========
class TestForgivingLogin:
    def test_exact(self, temp_house):
        r = requests.post(f"{BASE}/auth/login", json={"login_id": temp_house["login_id"], "password": temp_house["password"]})
        assert r.status_code == 200
        assert r.json()["user"]["login_id"] == temp_house["login_id"]

    def test_lowercase(self, temp_house):
        r = requests.post(f"{BASE}/auth/login", json={"login_id": temp_house["login_id"].lower(), "password": temp_house["password"]})
        assert r.status_code == 200

    def test_no_dash(self, temp_house):
        r = requests.post(f"{BASE}/auth/login", json={"login_id": temp_house["login_id"].replace("-", ""), "password": temp_house["password"]})
        assert r.status_code == 200

    def test_zero_for_o(self, temp_house):
        # OMJ- → 0MJ-
        variant = temp_house["login_id"].replace("OMJ", "0MJ")
        r = requests.post(f"{BASE}/auth/login", json={"login_id": variant, "password": temp_house["password"]})
        assert r.status_code == 200

    def test_short_number(self, temp_house):
        # e.g. OMJ-0123 → OMJ-123
        import re
        m = re.match(r"^([A-Z]+)-0*(\d+)$", temp_house["login_id"])
        if not m:
            pytest.skip("login_id not in expected format")
        variant = f"{m.group(1)}-{m.group(2)}"
        r = requests.post(f"{BASE}/auth/login", json={"login_id": variant, "password": temp_house["password"]})
        assert r.status_code == 200

    def test_house_no_resolves_wrong_password_returns_invalid(self, temp_house):
        # Login with house_no '001' resolves to house 001, wrong pwd → 401 Invalid ..., NOT the phone hint
        r = requests.post(f"{BASE}/auth/login", json={"login_id": "001", "password": "definitely_wrong_pw_xyz"})
        assert r.status_code == 401
        detail = r.json().get("detail", "")
        assert "Members must sign in with their Member ID" not in detail
        assert "Invalid Member ID or password" in detail


# =========== Second-member classification ===========
class TestClassify:
    @pytest.fixture(scope="class")
    def house_id(self, temp_house):
        return temp_house["house"]["id"]

    def _add(self, admin_h, house_id, name, gender, dob, status, relation=""):
        r = requests.post(f"{BASE}/members", headers=admin_h, json={
            "house_id": house_id, "name": f"TEST_{name}", "relation": relation,
            "dob": dob, "gender": gender, "status": status,
        })
        assert r.status_code == 201, r.text
        return r.json()

    def test_working_adult_male_is_sub(self, admin_h, house_id):
        m = self._add(admin_h, house_id, "WorkingMale", "male", "1990-01-01", "working")
        assert m["member_type"] == "sub"

    def test_student_male_is_family(self, admin_h, house_id):
        m = self._add(admin_h, house_id, "StudentMale", "male", "1990-01-01", "student")
        assert m["member_type"] == "family"

    def test_under18_working_male_is_family(self, admin_h, house_id):
        m = self._add(admin_h, house_id, "MinorMale", "male", "2015-01-01", "working")
        assert m["member_type"] == "family"

    def test_working_female_is_family(self, admin_h, house_id):
        m = self._add(admin_h, house_id, "WorkingFemale", "female", "1985-01-01", "working")
        assert m["member_type"] == "family"

    def test_house_get_reflects_types(self, admin_h, house_id):
        r = requests.get(f"{BASE}/houses/{house_id}", headers=admin_h)
        assert r.status_code == 200
        members = r.json()["members"]
        head = [m for m in members if m["member_type"] == "head"]
        subs = [m for m in members if m["member_type"] == "sub"]
        assert len(head) == 1
        assert len(subs) == 1
        assert subs[0]["name"] == "TEST_WorkingMale"


# =========== Bulk old balance ===========
class TestBulkOldBalance:
    def test_bulk_add_and_summary(self, admin_h, temp_house):
        hid = temp_house["house"]["id"]
        r = requests.post(f"{BASE}/finance/old-balance/bulk", headers=admin_h, json={
            "rows": [
                {"house_id": hid, "amount": 1200, "type": "building", "note": "2024"},
                {"house_id": hid, "amount": 0, "type": "other"},
            ]
        })
        assert r.status_code == 200, r.text
        assert r.json()["added"] == 1
        # Summary
        r = requests.get(f"{BASE}/finance/house/{hid}/summary", headers=admin_h)
        assert r.status_code == 200
        ob = r.json()["collections"]["old_balance"]
        assert ob["due"] == 1200
        assert ob["items"][0]["type"] == "building"

    def test_invalid_type_skipped(self, admin_h, temp_house):
        hid = temp_house["house"]["id"]
        r = requests.post(f"{BASE}/finance/old-balance/bulk", headers=admin_h, json={
            "rows": [{"house_id": hid, "amount": 500, "type": "bogus_type"}]
        })
        assert r.status_code == 200
        assert r.json()["added"] == 0
        assert any(s.get("reason") == "invalid type" for s in r.json()["skipped"])

    def test_member_forbidden(self, temp_house):
        r = requests.post(f"{BASE}/auth/login", json={"login_id": temp_house["login_id"], "password": temp_house["password"]})
        member_token = r.json()["token"]
        r = requests.post(
            f"{BASE}/finance/old-balance/bulk",
            headers={"Authorization": f"Bearer {member_token}"},
            json={"rows": [{"house_id": temp_house["house"]["id"], "amount": 100, "type": "other"}]},
        )
        assert r.status_code == 403

    def test_overview_includes_old_balance_due(self, admin_h, temp_house):
        r = requests.get(f"{BASE}/finance/overview", headers=admin_h)
        assert r.status_code == 200
        rows = r.json() if isinstance(r.json(), list) else r.json().get("rows", [])
        hit = [row for row in rows if row.get("house_no") == "TST-77"]
        assert hit and hit[0].get("old_balance_due") == 1200

    def test_cleanup_ob_items(self, admin_h, temp_house):
        hid = temp_house["house"]["id"]
        r = requests.get(f"{BASE}/finance/house/{hid}/summary", headers=admin_h)
        for it in r.json()["collections"]["old_balance"]["items"]:
            requests.delete(f"{BASE}/finance/house/{hid}/old-balance/{it['id']}", headers=admin_h)
