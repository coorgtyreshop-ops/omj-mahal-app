"""Phase 2 backend tests: Hijri events, poster (skipped by default), notifications Salaam,
committee login, settings hijri_adjustment & bank fields, public endpoints.

Cleanup rule: NEVER touch house 001 / user 9900316275 / user's real announcement.
Only mutate TEST-99 house / TEST_* prefixed data. Restore hijri_adjustment=0 and bank_* empty.
"""
import os
import time
import pytest
import requests

def _load_env():
    for p in ("/app/frontend/.env",):
        try:
            with open(p) as f:
                for ln in f:
                    if ln.startswith("REACT_APP_BACKEND_URL="):
                        return ln.split("=", 1)[1].strip()
        except OSError:
            pass
    return os.environ.get("REACT_APP_BACKEND_URL", "")

BASE_URL = _load_env().rstrip("/") + "/api"
ADMIN = {"phone": "9999999999", "password": "admin123"}
MEMBER = {"phone": "8888888888", "password": "member123"}


def _login(creds):
    r = requests.post(f"{BASE_URL}/auth/login", json=creds, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"], r.json()["user"]


@pytest.fixture(scope="module")
def admin():
    tok, user = _login(ADMIN)
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {tok}", "Content-Type": "application/json"})
    s.user = user
    return s


@pytest.fixture(scope="module")
def member():
    tok, user = _login(MEMBER)
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {tok}", "Content-Type": "application/json"})
    s.user = user
    return s


@pytest.fixture(scope="module")
def test99_house_id(admin):
    """Locate TEST-99 house (must exist per test spec)."""
    r = admin.get(f"{BASE_URL}/houses")
    assert r.status_code == 200
    for h in r.json():
        if h.get("house_no") == "TEST-99":
            return h["id"]
    pytest.skip("TEST-99 house not present; skipping tests requiring it")


# ---------------- Hijri & Events ----------------
class TestHijri:
    def test_hijri_today(self, admin):
        r = admin.get(f"{BASE_URL}/events/hijri")
        assert r.status_code == 200
        j = r.json()
        assert "label" in j and "label_ml" in j
        assert j["adjustment"] == 0
        assert j["month"] and j["year"]

    def test_hijri_adjustment_effect(self, admin):
        # set +1
        r = admin.put(f"{BASE_URL}/settings", json={"mahal_name": "OMJ Mahal", "hijri_adjustment": 1})
        assert r.status_code == 200
        j = admin.get(f"{BASE_URL}/events/hijri").json()
        assert j["adjustment"] == 1
        # restore
        admin.put(f"{BASE_URL}/settings", json={"mahal_name": "OMJ Mahal", "hijri_adjustment": 0})
        j2 = admin.get(f"{BASE_URL}/events/hijri").json()
        assert j2["adjustment"] == 0
        # day should differ by 1 (mod month rollover; use label)
        assert j["label"] != j2["label"]


class TestEventsCRUD:
    created_ids = []

    def test_admin_create_event(self, admin):
        payload = {"title": "TEST_ProgrammeA", "title_ml": "പ്രോഗ്രാം",
                   "date": "2026-12-15", "time": "19:00", "venue": "Hall",
                   "description": "desc", "category": "programme", "notify_members": False}
        r = admin.post(f"{BASE_URL}/events", json=payload)
        assert r.status_code == 201, r.text
        ev = r.json()
        assert ev["hijri"]["label"]
        assert ev["category"] == "programme"
        TestEventsCRUD.created_ids.append(ev["id"])

    def test_invalid_category(self, admin):
        r = admin.post(f"{BASE_URL}/events", json={"title": "x", "date": "2026-12-16", "category": "bogus"})
        assert r.status_code == 400

    def test_list_and_today(self, admin):
        r = admin.get(f"{BASE_URL}/events", params={"from": "2026-12-01", "to": "2026-12-31"})
        assert r.status_code == 200
        assert any(e["id"] in TestEventsCRUD.created_ids for e in r.json())
        r2 = admin.get(f"{BASE_URL}/events/today")
        assert r2.status_code == 200
        j = r2.json()
        assert "hijri" in j and "today" in j and "upcoming" in j

    def test_member_forbidden_write(self, member):
        r = member.post(f"{BASE_URL}/events", json={"title": "x", "date": "2026-12-20", "category": "programme"})
        assert r.status_code == 403
        r2 = member.get(f"{BASE_URL}/events")
        assert r2.status_code == 200

    def test_update_and_delete(self, admin):
        # Create then update
        r = admin.post(f"{BASE_URL}/events", json={"title": "TEST_ToUpdate", "date": "2026-12-17", "category": "meeting"})
        eid = r.json()["id"]
        r2 = admin.put(f"{BASE_URL}/events/{eid}", json={"title": "TEST_Updated", "date": "2026-12-17", "category": "meeting"})
        assert r2.status_code == 200
        assert r2.json()["title"] == "TEST_Updated"
        r3 = admin.delete(f"{BASE_URL}/events/{eid}")
        assert r3.status_code == 200
        r4 = admin.get(f"{BASE_URL}/events/{eid}")
        assert r4.status_code == 404

    def test_notify_event_and_log(self, admin):
        # Create then notify
        r = admin.post(f"{BASE_URL}/events", json={"title": "TEST_Notify", "date": "2026-12-18", "category": "programme", "notify_members": True})
        eid = r.json()["id"]
        TestEventsCRUD.created_ids.append(eid)
        rn = admin.post(f"{BASE_URL}/events/{eid}/notify")
        assert rn.status_code == 200
        body = rn.json()
        assert body["ok"] is True and "houses" in body
        # give background time
        time.sleep(2)
        # notifications list (admin sees all)
        rl = admin.get(f"{BASE_URL}/notifications", params={"kind": "event", "limit": 50})
        assert rl.status_code == 200
        assert any(m.get("ref") == eid for m in rl.json())
        # notified_at set
        ev = admin.get(f"{BASE_URL}/events/{eid}").json()
        assert ev.get("notified_at")

    def test_zzz_cleanup(self, admin):
        for eid in TestEventsCRUD.created_ids:
            admin.delete(f"{BASE_URL}/events/{eid}")


# ---------------- Public endpoints ----------------
class TestPublic:
    def test_public_events(self, admin):
        # enable guest mode temporarily
        s0 = admin.get(f"{BASE_URL}/settings").json()
        prev_guest = s0.get("guest_mode_enabled", True)
        admin.put(f"{BASE_URL}/settings", json={"mahal_name": s0.get("mahal_name", "OMJ Mahal"), "guest_mode_enabled": True})
        # ensure at least one future event exists
        r = admin.post(f"{BASE_URL}/events", json={"title": "TEST_Public", "date": "2026-10-15", "category": "programme"})
        eid = r.json()["id"]
        try:
            pr = requests.get(f"{BASE_URL}/public/events", timeout=10)
            assert pr.status_code == 200, pr.text
            events = pr.json()
            match = [e for e in events if e["id"] == eid]
            assert match, "created event should appear in /public/events"
            assert "hijri" in match[0]
            assert "created_by" not in match[0]
        finally:
            admin.delete(f"{BASE_URL}/events/{eid}")
            admin.put(f"{BASE_URL}/settings", json={"mahal_name": s0.get("mahal_name", "OMJ Mahal"), "guest_mode_enabled": prev_guest})

    def test_public_ticker_merges_events(self, admin):
        r = admin.post(f"{BASE_URL}/events", json={"title": "TEST_Ticker", "date": "2026-09-19", "category": "programme"})
        eid = r.json()["id"]
        try:
            pr = requests.get(f"{BASE_URL}/public/ticker", timeout=10)
            assert pr.status_code == 200
            data = pr.json()
            evs = [r for r in data if r.get("kind") == "event"]
            # may or may not be in date range; just ensure kind field exists on any event entry
            assert isinstance(data, list)
            _ = evs  # not asserting length as depends on current date window
        finally:
            admin.delete(f"{BASE_URL}/events/{eid}")


# ---------------- Settings: bank fields ----------------
class TestSettingsBank:
    def test_bank_roundtrip_and_summary(self, admin, member, test99_house_id):
        # set
        r = admin.put(f"{BASE_URL}/settings", json={"mahal_name": "OMJ Mahal", "bank_name": "TEST Bank",
                                                    "bank_account_name": "OMJ", "bank_account_no": "1234567890", "bank_ifsc": "TEST0001"})
        assert r.status_code == 200
        r2 = admin.get(f"{BASE_URL}/settings")
        assert r2.json()["bank_account_no"] == "1234567890"
        # /finance/fees exposes bank
        rf = admin.get(f"{BASE_URL}/finance/fees")
        assert rf.status_code == 200
        assert rf.json().get("bank_name") == "TEST Bank"
        # member summary has bank object
        rs = member.get(f"{BASE_URL}/finance/house/{test99_house_id}/summary")
        assert rs.status_code == 200
        js = rs.json()
        assert "upi_id" in js
        assert js.get("bank") and js["bank"]["bank_account_no"] == "1234567890"
        # restore
        admin.put(f"{BASE_URL}/settings", json={"mahal_name": "OMJ Mahal", "bank_name": "", "bank_account_name": "",
                                                "bank_account_no": "", "bank_ifsc": ""})
        rs2 = member.get(f"{BASE_URL}/finance/house/{test99_house_id}/summary")
        assert rs2.json().get("bank") in (None, {})


# ---------------- Notifications Salaam-first ----------------
class TestNotificationsSalaam:
    def test_pay_request_and_reject_notify(self, admin, member):
        # create pay_request as member
        payload = {"type": "eid_adha", "amount": 200, "upi_ref": "REF1TEST"}
        r = member.post(f"{BASE_URL}/finance/pay-requests", json=payload)
        assert r.status_code == 201, r.text
        req_id = r.json()["id"]
        time.sleep(2)
        # member notifications: newest kind pay_request starts with അസ്സലാമു അലൈക്കും Test Member
        rn = member.get(f"{BASE_URL}/notifications/mine")
        assert rn.status_code == 200
        assert rn.json(), "member should have at least one notification"
        newest = rn.json()[0]
        assert newest["kind"] == "pay_request"
        assert newest["body"].startswith("അസ്സലാമു അലൈക്കും Test Member"), newest["body"][:120]

        # reject
        rr = admin.post(f"{BASE_URL}/finance/pay-requests/{req_id}/reject", json={"reason": "test reject"})
        assert rr.status_code == 200
        time.sleep(2)
        rn2 = member.get(f"{BASE_URL}/notifications/mine").json()
        assert rn2[0]["kind"] == "pay_rejected"
        assert rn2[0]["body"].startswith("അസ്സലാമു അലൈക്കും"), rn2[0]["body"][:120]

    def test_approve_creates_receipt_salaam(self, admin, member):
        r = member.post(f"{BASE_URL}/finance/pay-requests", json={"type": "eid_adha", "amount": 200, "upi_ref": "REF2TEST"})
        assert r.status_code == 201
        req_id = r.json()["id"]
        ra = admin.post(f"{BASE_URL}/finance/pay-requests/{req_id}/approve")
        assert ra.status_code == 200, ra.text
        receipt_no = ra.json()["receipt_no"]
        time.sleep(3)
        rn = member.get(f"{BASE_URL}/notifications/mine").json()
        # find newest kind receipt
        receipts = [m for m in rn if m["kind"] == "receipt"]
        assert receipts, f"no receipt notification found; got kinds: {[m['kind'] for m in rn[:5]]}"
        rmsg = receipts[0]
        assert rmsg["body"].startswith("അസ്സലാമു അലൈക്കും"), rmsg["body"][:120]
        assert "രസീത് നമ്പർ" in rmsg["body"]
        # cleanup: delete the created payment by receipt_no
        pays = admin.get(f"{BASE_URL}/payments").json()
        for p in pays:
            if p.get("receipt_no") == receipt_no:
                admin.delete(f"{BASE_URL}/payments/{p['id']}")
                break

    def test_auto_reminder_salaam(self, admin):
        r = admin.post(f"{BASE_URL}/notifications/auto-reminder/run")
        assert r.status_code == 200
        time.sleep(2)
        rl = admin.get(f"{BASE_URL}/notifications", params={"kind": "auto_reminder", "limit": 20})
        assert rl.status_code == 200
        for m in rl.json()[:5]:
            assert m["body"].startswith("അസ്സലാമു അലൈക്കും"), m["body"][:100]

    def test_admin_no_house_returns_empty(self, admin):
        rn = admin.get(f"{BASE_URL}/notifications/mine")
        assert rn.status_code == 200
        assert rn.json() == []


# ---------------- Committee login ----------------
class TestCommitteeLogin:
    committee_id = None
    user_id = None

    def test_create_committee_with_login(self, admin):
        payload = {"name": "TEST_Sec", "designation": "Secretary", "phone": "7777777777", "create_login": True}
        r = admin.post(f"{BASE_URL}/committee", json=payload)
        assert r.status_code == 201, r.text
        j = r.json()
        assert "login" in j and "password" in j["login"]
        pwd = j["login"]["password"]
        assert len(pwd) == 6 and pwd.isdigit()
        assert j["login"]["sent"]["status"] == "mock"
        TestCommitteeLogin.committee_id = j["id"]
        TestCommitteeLogin.user_id = j["login"]["user"]["id"]
        # login with new password
        lr = requests.post(f"{BASE_URL}/auth/login", json={"phone": "7777777777", "password": pwd})
        assert lr.status_code == 200
        lj = lr.json()
        assert lj["user"]["role"] == "admin"
        assert lj["user"].get("must_change_password") is True

    def test_reset_password(self, admin):
        cid = TestCommitteeLogin.committee_id
        r = admin.post(f"{BASE_URL}/committee/{cid}/login")
        assert r.status_code == 200
        new_pwd = r.json()["password"]
        assert new_pwd.isdigit() and len(new_pwd) == 6
        lr = requests.post(f"{BASE_URL}/auth/login", json={"phone": "7777777777", "password": new_pwd})
        assert lr.status_code == 200

    def test_no_phone_400_on_login_endpoint(self, admin):
        r = admin.post(f"{BASE_URL}/committee", json={"name": "TEST_NoPhone", "designation": "x"})
        cid = r.json()["id"]
        try:
            r2 = admin.post(f"{BASE_URL}/committee/{cid}/login")
            assert r2.status_code == 400
        finally:
            admin.delete(f"{BASE_URL}/committee/{cid}")

    def test_zzz_cleanup_committee(self, admin):
        if TestCommitteeLogin.committee_id:
            admin.delete(f"{BASE_URL}/committee/{TestCommitteeLogin.committee_id}")
        if TestCommitteeLogin.user_id:
            admin.delete(f"{BASE_URL}/users/{TestCommitteeLogin.user_id}")
