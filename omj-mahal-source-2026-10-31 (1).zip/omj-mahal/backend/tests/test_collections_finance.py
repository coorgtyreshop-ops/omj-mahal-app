"""
Iteration 3 backend tests: Collections/Finance module, treasurer permissions,
member classification (head/sub/family), OTP mock login, public verify.
"""
import os
import pytest
import requests

def _load_base():
    v = os.environ.get("REACT_APP_BACKEND_URL")
    if not v:
        try:
            for line in open("/app/frontend/.env"):
                if line.startswith("REACT_APP_BACKEND_URL="):
                    v = line.split("=", 1)[1].strip().strip('"')
                    break
        except Exception:
            pass
    if not v:
        raise RuntimeError("REACT_APP_BACKEND_URL not set")
    return v.rstrip("/") + "/api"


BASE = _load_base()
ADMIN = {"phone": "9999999999", "password": "admin123"}
MEMBER = {"phone": "8888888888", "password": "member123"}


def _login(phone, password):
    r = requests.post(f"{BASE}/auth/login", json={"phone": phone, "password": password}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture(scope="module")
def admin_token():
    return _login(**ADMIN)["token"]


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def member_login():
    return _login(**MEMBER)


@pytest.fixture(scope="module")
def member_headers(member_login):
    return {"Authorization": f"Bearer {member_login['token']}"}


@pytest.fixture(scope="module")
def member_user_id(member_login):
    return member_login["user"]["id"]


@pytest.fixture(scope="module")
def member_house_id(member_login):
    return member_login["user"].get("house_id")


# --- Member classification ---
class TestClassification:
    def test_stats_only_head_sub_family(self, admin_headers):
        r = requests.get(f"{BASE}/members/stats", headers=admin_headers)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "total" in data and "head" in data and "sub" in data and "family" in data
        assert "child" not in data
        # only allowed keys
        assert set(data.keys()) - {"total", "head", "sub", "family"} == set()

    def test_house_type_counts(self, admin_headers):
        houses = requests.get(f"{BASE}/houses", headers=admin_headers).json()
        assert len(houses) >= 1
        hid = houses[0]["id"]
        r = requests.get(f"{BASE}/houses/{hid}", headers=admin_headers)
        assert r.status_code == 200
        tc = r.json().get("type_counts", {})
        assert set(tc.keys()) == {"head", "sub", "family"}


# --- Finance fees ---
class TestFees:
    def test_get_fees_shape(self, admin_headers):
        r = requests.get(f"{BASE}/finance/fees", headers=admin_headers)
        assert r.status_code == 200, r.text
        d = r.json()
        for k in ("fee_eid_fitr", "fee_eid_adha", "fee_nabidinam", "fee_building", "upi_id", "upi_name", "finance_manager_id", "can_finance", "types"):
            assert k in d, f"missing {k}"
        assert d["can_finance"] is True
        assert set(d["types"]) >= {"varisankhya", "eid_fitr", "eid_adha", "nabidinam", "building", "donation"}

    def test_put_fees_updates_and_restore(self, admin_headers):
        orig = requests.get(f"{BASE}/finance/fees", headers=admin_headers).json()
        body = {"fee_eid_fitr": 250, "fee_eid_adha": 250, "fee_nabidinam": 150, "fee_building": 6000, "upi_id": orig["upi_id"], "upi_name": orig["upi_name"]}
        r = requests.put(f"{BASE}/finance/fees", headers=admin_headers, json=body)
        assert r.status_code == 200, r.text
        after = requests.get(f"{BASE}/finance/fees", headers=admin_headers).json()
        assert after["fee_eid_fitr"] == 250
        # restore
        restore = {"fee_eid_fitr": orig["fee_eid_fitr"], "fee_eid_adha": orig["fee_eid_adha"], "fee_nabidinam": orig["fee_nabidinam"], "fee_building": orig["fee_building"], "upi_id": orig["upi_id"], "upi_name": orig["upi_name"]}
        rr = requests.put(f"{BASE}/finance/fees", headers=admin_headers, json=restore)
        assert rr.status_code == 200


# --- Permissions: member 403; admin allowed ---
class TestFinancePermissions:
    def test_member_403_on_overview(self, member_headers):
        r = requests.get(f"{BASE}/finance/overview", headers=member_headers)
        assert r.status_code == 403

    def test_member_403_on_notices(self, member_headers):
        r = requests.get(f"{BASE}/finance/notices", headers=member_headers)
        assert r.status_code == 403

    def test_member_403_on_put_fees(self, member_headers):
        r = requests.put(f"{BASE}/finance/fees", headers=member_headers, json={"fee_eid_fitr": 1, "fee_eid_adha": 1, "fee_nabidinam": 1, "fee_building": 1, "upi_id": "x", "upi_name": "x"})
        assert r.status_code == 403

    def test_admin_overview_ok(self, admin_headers):
        r = requests.get(f"{BASE}/finance/overview", headers=admin_headers)
        assert r.status_code == 200
        d = r.json()
        assert "rows" in d and "totals" in d


# --- Treasurer appointment flow ---
class TestTreasurer:
    def test_appoint_treasurer_grants_and_reset(self, admin_headers, member_headers, member_user_id, member_house_id):
        # appoint
        r = requests.put(f"{BASE}/finance/manager", headers=admin_headers, json={"user_id": member_user_id})
        assert r.status_code == 200, r.text
        try:
            # treasurer can access overview & notices & fees
            r1 = requests.get(f"{BASE}/finance/overview", headers=member_headers)
            assert r1.status_code == 200
            r2 = requests.get(f"{BASE}/finance/notices", headers=member_headers)
            assert r2.status_code == 200
            r3 = requests.get(f"{BASE}/finance/fees", headers=member_headers)
            assert r3.status_code == 200 and r3.json()["can_finance"] is True
            # treasurer sees ALL houses
            houses = requests.get(f"{BASE}/houses", headers=member_headers).json()
            assert len(houses) > 1
            other = next((h for h in houses if h["id"] != member_house_id), None)
            assert other is not None
            r4 = requests.get(f"{BASE}/houses/{other['id']}", headers=member_headers)
            assert r4.status_code == 200
            # admin still has access
            assert requests.get(f"{BASE}/finance/overview", headers=admin_headers).status_code == 200
        finally:
            rr = requests.put(f"{BASE}/finance/manager", headers=admin_headers, json={"user_id": None})
            assert rr.status_code == 200
        # after reset, member 403 again
        assert requests.get(f"{BASE}/finance/overview", headers=member_headers).status_code == 403


# --- House summary ---
class TestHouseSummary:
    def test_own_house_summary(self, member_headers, member_house_id):
        r = requests.get(f"{BASE}/finance/house/{member_house_id}/summary", headers=member_headers)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "collections" in d and "upi_configured" in d
        for typ in ("varisankhya", "eid_fitr", "eid_adha", "nabidinam", "building", "donation"):
            assert typ in d["collections"]
            for k in ("rate", "due", "paid", "pending", "pending_periods"):
                assert k in d["collections"][typ]
        assert "total_pending" in d["collections"]

    def test_other_house_403(self, member_headers, admin_headers, member_house_id):
        houses = requests.get(f"{BASE}/houses", headers=admin_headers).json()
        other = next(h for h in houses if h["id"] != member_house_id)
        r = requests.get(f"{BASE}/finance/house/{other['id']}/summary", headers=member_headers)
        assert r.status_code == 403


# --- Payments by type ---
class TestPayments:
    def test_eid_fitr_year_and_duplicate(self, admin_headers, member_house_id):
        # create eid_fitr payment for 2026
        body = {"house_id": member_house_id, "type": "eid_fitr", "years": ["2026"], "amount": 200}
        r = requests.post(f"{BASE}/payments", headers=admin_headers, json=body)
        assert r.status_code == 201, r.text
        pid = r.json()["id"]
        try:
            # duplicate
            r2 = requests.post(f"{BASE}/payments", headers=admin_headers, json=body)
            assert r2.status_code == 400
            assert "Already paid" in r2.text
        finally:
            rd = requests.delete(f"{BASE}/payments/{pid}", headers=admin_headers)
            assert rd.status_code == 200

    def test_building_amount_only(self, admin_headers, member_house_id):
        body = {"house_id": member_house_id, "type": "building", "amount": 500}
        r = requests.post(f"{BASE}/payments", headers=admin_headers, json=body)
        assert r.status_code == 201, r.text
        pid = r.json()["id"]
        requests.delete(f"{BASE}/payments/{pid}", headers=admin_headers)

    def test_varisankhya_requires_months(self, admin_headers, member_house_id):
        r = requests.post(f"{BASE}/payments", headers=admin_headers, json={"house_id": member_house_id, "type": "varisankhya", "amount": 100})
        assert r.status_code == 400


# --- UPI Pay-request flow ---
class TestPayRequests:
    def test_full_flow(self, admin_headers, member_headers):
        # member posts a request
        r = requests.post(f"{BASE}/finance/pay-requests", headers=member_headers, json={"type": "eid_adha", "amount": 200, "upi_ref": "TEST123", "years": ["2026"]})
        assert r.status_code == 201, r.text
        req = r.json()
        assert req["status"] == "pending"
        req_id = req["id"]

        # upi link endpoint
        rl = requests.get(f"{BASE}/finance/upi-link", headers=member_headers, params={"amount": 200})
        assert rl.status_code == 200
        assert rl.json()["link"].startswith("upi://")

        # admin can list pending
        rp = requests.get(f"{BASE}/finance/pay-requests", headers=admin_headers, params={"status": "pending"})
        assert rp.status_code == 200
        assert any(x["id"] == req_id for x in rp.json())

        # approve
        ra = requests.post(f"{BASE}/finance/pay-requests/{req_id}/approve", headers=admin_headers)
        assert ra.status_code == 200, ra.text
        assert "receipt_no" in ra.json()

        # find created payment via listing and cleanup
        pays = requests.get(f"{BASE}/payments", headers=admin_headers, params={"type": "eid_adha"}).json()
        pids = [p["id"] for p in pays if "TEST123" in (p.get("note") or "") and p.get("amount") == 200]
        for pid in pids:
            requests.delete(f"{BASE}/payments/{pid}", headers=admin_headers)

        # a second request then reject
        r2 = requests.post(f"{BASE}/finance/pay-requests", headers=member_headers, json={"type": "eid_adha", "amount": 200, "upi_ref": "TEST456", "years": ["2027"]})
        assert r2.status_code == 201
        rid2 = r2.json()["id"]
        rj = requests.post(f"{BASE}/finance/pay-requests/{rid2}/reject", headers=admin_headers, json={"reason": "test reject"})
        assert rj.status_code == 200
        # verify status
        all_reqs = requests.get(f"{BASE}/finance/pay-requests", headers=admin_headers).json()
        rec = next(x for x in all_reqs if x["id"] == rid2)
        assert rec["status"] == "rejected"


# --- Notices ---
class TestNotices:
    def test_notices_list_and_single(self, admin_headers, member_house_id):
        r = requests.get(f"{BASE}/finance/notices", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        for row in data:
            assert row["collections"]["total_pending"] > 0
            assert "upi_link" in row
        r2 = requests.get(f"{BASE}/finance/notices", headers=admin_headers, params={"house_id": member_house_id})
        assert r2.status_code == 200
        d2 = r2.json()
        assert len(d2) == 1
        assert d2[0]["house"]["id"] == member_house_id


# --- OTP ---
class TestOtp:
    def test_otp_mock_and_verify(self):
        r = requests.post(f"{BASE}/auth/otp/request", json={"phone": "8888888888", "purpose": "login", "channel": "sms"})
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("mode") == "mock"
        code = d.get("demo_code")
        assert code and len(code) == 6
        rv = requests.post(f"{BASE}/auth/otp/verify", json={"phone": "8888888888", "code": code, "purpose": "login"})
        assert rv.status_code == 200
        assert "token" in rv.json()


# --- Password login ---
class TestPasswordLogin:
    def test_admin_and_member_login(self):
        for p, pw in [("9999999999", "admin123"), ("8888888888", "member123")]:
            r = requests.post(f"{BASE}/auth/login", json={"phone": p, "password": pw})
            assert r.status_code == 200, f"{p}: {r.text}"


# --- Public verify ---
class TestPublicVerify:
    def test_no_auth_and_no_leak(self, admin_headers):
        houses = requests.get(f"{BASE}/houses", headers=admin_headers).json()
        # find a member_no via members endpoint
        members = requests.get(f"{BASE}/members", headers=admin_headers).json()
        m = next((x for x in members if x.get("member_no")), None)
        assert m, "no member with member_no found"
        r = requests.get(f"{BASE}/public/verify/{m['member_no']}")
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["valid"] is True
        # should NOT leak other household member data or phone of member
        assert "phone" not in d["member"]
        assert "dob" not in d["member"]
        assert "members" not in d  # no roster of household
