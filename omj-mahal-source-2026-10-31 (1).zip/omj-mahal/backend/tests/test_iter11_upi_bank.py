"""Iteration 11: verify partial-save fix for PUT /api/finance/fees + UPI validation + upi-link + notices."""
import os
import pytest
import requests

BASE = os.environ["REACT_APP_BACKEND_URL"].rstrip("/") if os.environ.get("REACT_APP_BACKEND_URL") else "https://anoo-platform.preview.emergentagent.com"
API = f"{BASE}/api"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{API}/auth/login", json={"login_id": "ADMIN-090", "password": "qa12345"}, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def house_001_id(admin_headers):
    r = requests.get(f"{API}/houses", headers=admin_headers, timeout=15)
    assert r.status_code == 200
    hs = r.json()
    if not hs:
        pytest.skip("No houses")
    return hs[0]["id"]


# ---------- partial save: bank only ----------
def test_partial_save_bank_only_preserves_fees(admin_headers):
    body = {"bank_account_no": "12345678901", "bank_ifsc": "sbin0001234 ", "bank_name": "SBI", "bank_account_name": "OMJ Mahal"}
    r = requests.put(f"{API}/finance/fees", headers=admin_headers, json=body, timeout=15)
    assert r.status_code == 200, r.text
    g = requests.get(f"{API}/finance/fees", headers=admin_headers, timeout=15).json()
    assert g["bank_account_no"] == "12345678901"
    assert g["bank_ifsc"] == "SBIN0001234", f"IFSC not trimmed/uppercased: {g['bank_ifsc']!r}"
    assert g["bank_name"] == "SBI"
    assert g["bank_account_name"] == "OMJ Mahal"
    # Existing fees unchanged
    assert float(g["fee_building"]) == 5000.0
    assert float(g["fee_nabidinam"]) == 1600.0
    assert float(g["default_subscription"]) == 250.0


# ---------- partial save: upi only ----------
def test_partial_save_upi_only_preserves_bank(admin_headers, house_001_id):
    body = {"upi_id": "omjmahal@okicici", "upi_name": "OMJ Mahal", "upi_app": "gpay_icici"}
    r = requests.put(f"{API}/finance/fees", headers=admin_headers, json=body, timeout=15)
    assert r.status_code == 200, r.text
    g = requests.get(f"{API}/finance/fees", headers=admin_headers, timeout=15).json()
    assert g["upi_id"] == "omjmahal@okicici"
    assert g["upi_name"] == "OMJ Mahal"
    assert g["upi_app"] == "gpay_icici"
    # Bank retained
    assert g["bank_account_no"] == "12345678901"
    assert g["bank_ifsc"] == "SBIN0001234"
    # Fees retained
    assert float(g["fee_building"]) == 5000.0
    assert float(g["fee_nabidinam"]) == 1600.0

    # upi-link
    link = requests.get(f"{API}/finance/upi-link", headers=admin_headers, params={"amount": 100, "note": "Test"}, timeout=15)
    assert link.status_code == 200, link.text
    assert link.json()["link"].startswith("upi://pay?pa=omjmahal%40okicici")
    assert "am=100.00" in link.json()["link"]

    # notices for house 001
    nt = requests.get(f"{API}/finance/notices", headers=admin_headers, params={"house_id": house_001_id}, timeout=15)
    assert nt.status_code == 200
    arr = nt.json()
    assert len(arr) >= 1
    # upi_link non-empty only if house has pending — allow either; but must be a string
    assert isinstance(arr[0].get("upi_link", ""), str)


# ---------- validation ----------
def test_reject_upi_without_at(admin_headers):
    r = requests.put(f"{API}/finance/fees", headers=admin_headers, json={"upi_id": "9847000000"}, timeout=15)
    assert r.status_code == 400


def test_reject_upi_too_short(admin_headers):
    r = requests.put(f"{API}/finance/fees", headers=admin_headers, json={"upi_id": "a@ybl"}, timeout=15)
    assert r.status_code == 400


# ---------- non-finance member forbidden ----------
def test_non_finance_member_forbidden(admin_headers):
    # Create a temp house + login user (member)
    import uuid
    hn = f"TST-UPI-{uuid.uuid4().hex[:4]}"
    h = requests.post(f"{API}/houses", headers=admin_headers, json={"house_no": hn, "head_name": "T Head", "phone": "9000000123", "start_month": "2026-01"}, timeout=15)
    assert h.status_code in (200, 201), h.text
    hid = h.json()["id"]
    lg = requests.post(f"{API}/houses/{hid}/login", headers=admin_headers, json={"password": "test1234"}, timeout=15)
    assert lg.status_code in (200, 201), lg.text
    login_id = lg.json().get("login_id") or lg.json().get("user", {}).get("login_id")
    assert login_id
    m = requests.post(f"{API}/auth/login", json={"login_id": login_id, "password": "test1234"}, timeout=15)
    assert m.status_code == 200, m.text
    mtok = m.json()["token"]
    r = requests.put(f"{API}/finance/fees", headers={"Authorization": f"Bearer {mtok}"}, json={"upi_name": "hack"}, timeout=15)
    assert r.status_code == 403
    # Cleanup — delete house (should cascade or backend handles)
    d = requests.delete(f"{API}/houses/{hid}", headers=admin_headers, timeout=15)
    assert d.status_code in (200, 204), d.text
