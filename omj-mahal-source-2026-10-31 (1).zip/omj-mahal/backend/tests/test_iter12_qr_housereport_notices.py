"""Iteration 12: QR upload + house report + notices(include_all) + house summary UPI fields."""
import io
import os
import struct
import zlib
import pytest
import requests

def _read_env(key):
    from pathlib import Path
    for p in (Path("/app/frontend/.env"), Path(__file__).resolve().parents[2] / "frontend/.env"):
        if p.exists():
            for line in p.read_text().splitlines():
                if line.startswith(key + "="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None

BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or _read_env("REACT_APP_BACKEND_URL") or "").rstrip("/")
assert BASE_URL, "REACT_APP_BACKEND_URL not set"

ADMIN = {"login_id": "ADMIN-TMP", "password": "tmp12345"}
MEMBER = {"login_id": "OMJ-0198", "password": "tmp12345"}


def _login(creds):
    r = requests.post(f"{BASE_URL}/api/auth/login", json=creds, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_headers():
    return {"Authorization": f"Bearer {_login(ADMIN)}"}


@pytest.fixture(scope="module")
def member_headers():
    return {"Authorization": f"Bearer {_login(MEMBER)}"}


def _tiny_png_bytes() -> bytes:
    """1x1 red PNG."""
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
    raw = b"\x00\xff\x00\x00"
    idat = chunk(b"IDAT", zlib.compress(raw))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


# ---- Fees partial save preserves other fields ----

class TestFeesPartialSave:
    def test_fees_partial_upi_qr_preserves_others(self, admin_headers):
        # Snapshot current
        r = requests.get(f"{BASE_URL}/api/finance/fees", headers=admin_headers, timeout=15)
        assert r.status_code == 200
        before = r.json()

        # Partial PUT with only upi_qr_url
        r = requests.put(f"{BASE_URL}/api/finance/fees", headers=admin_headers,
                         json={"upi_qr_url": "/api/files/x"}, timeout=15)
        assert r.status_code == 200, r.text

        r = requests.get(f"{BASE_URL}/api/finance/fees", headers=admin_headers, timeout=15)
        after = r.json()
        assert after.get("upi_qr_url") == "/api/files/x"
        for k in ("upi_id", "upi_phone", "upi_name", "upi_app",
                  "bank_name", "bank_account_name", "bank_account_no", "bank_ifsc",
                  "fee_eid_fitr", "fee_eid_adha", "fee_nabidinam", "fee_building",
                  "fee_special", "default_subscription", "special_name"):
            assert after.get(k) == before.get(k), f"field {k} changed: {before.get(k)} -> {after.get(k)}"

        # Reset qr url
        r = requests.put(f"{BASE_URL}/api/finance/fees", headers=admin_headers,
                         json={"upi_qr_url": ""}, timeout=15)
        assert r.status_code == 200
        r = requests.get(f"{BASE_URL}/api/finance/fees", headers=admin_headers, timeout=15)
        assert r.json().get("upi_qr_url") == ""


# ---- House summary UPI fields ----

class TestHouseSummary:
    def test_house_summary_upi_fields(self, admin_headers):
        # Find TMP-901 (member's house)
        r = requests.get(f"{BASE_URL}/api/houses", headers=admin_headers, timeout=15)
        assert r.status_code == 200
        houses = r.json()
        tmp = next((h for h in houses if h.get("house_no") == "TMP-901"), None)
        assert tmp is not None, "TMP-901 house not found"
        hid = tmp["id"]
        r = requests.get(f"{BASE_URL}/api/finance/house/{hid}/summary", headers=admin_headers, timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        for k in ("upi_configured", "upi_id", "upi_phone", "upi_name", "upi_qr_url", "bank"):
            assert k in data, f"missing {k}"
        assert isinstance(data["upi_configured"], bool)


# ---- House report ----

class TestHouseReport:
    def test_house_report_shape(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/finance/report/houses", headers=admin_headers, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        for k in ("year", "groups", "counts", "totals", "date"):
            assert k in data
        for g in ("full", "partial", "none"):
            assert g in data["groups"]
            assert isinstance(data["groups"][g], list)
        for k in ("due", "paid", "pending", "houses", "year_received"):
            assert k in data["totals"]
        # Grouping rule validation
        for row in data["groups"]["full"]:
            assert row["pending"] <= 0
        for row in data["groups"]["partial"]:
            assert row["paid"] > 0 and row["pending"] > 0
        for row in data["groups"]["none"]:
            assert row["paid"] == 0 and row["pending"] > 0
        # Row shape
        all_rows = data["groups"]["full"] + data["groups"]["partial"] + data["groups"]["none"]
        if all_rows:
            row = all_rows[0]
            for k in ("house_no", "head_name", "due", "paid", "pending", "heads", "payments", "year_received", "last_paid"):
                assert k in row, f"row missing {k}"

    def test_house_report_year_param(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/finance/report/houses?year=2025", headers=admin_headers, timeout=30)
        assert r.status_code == 200
        assert r.json()["year"] == 2025

    def test_house_report_member_forbidden(self, member_headers):
        r = requests.get(f"{BASE_URL}/api/finance/report/houses", headers=member_headers, timeout=15)
        assert r.status_code == 403


# ---- Notices include_all ----

class TestNotices:
    def test_notices_include_all(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/finance/notices?include_all=true", headers=admin_headers, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        # count houses
        r2 = requests.get(f"{BASE_URL}/api/houses", headers=admin_headers, timeout=15)
        total_houses = len(r2.json())
        assert len(data) == total_houses, f"include_all should return all {total_houses} houses, got {len(data)}"
        # shape
        for row in data:
            assert "house" in row and "year" in row and "year_payments" in row and "collections" in row
            assert isinstance(row["year_payments"], list)

    def test_notices_default_only_pending(self, admin_headers):
        r_all = requests.get(f"{BASE_URL}/api/finance/notices?include_all=true", headers=admin_headers, timeout=30).json()
        r_def = requests.get(f"{BASE_URL}/api/finance/notices", headers=admin_headers, timeout=30).json()
        # each default row has total_pending>0
        for row in r_def:
            assert row["collections"]["total_pending"] > 0
        assert len(r_def) <= len(r_all)


# ---- QR upload ----

class TestUpiQrUpload:
    def test_upload_upi_qr_success(self, admin_headers):
        png = _tiny_png_bytes()
        r = requests.post(f"{BASE_URL}/api/upload/upi-qr",
                          headers=admin_headers,
                          files={"file": ("qr.png", io.BytesIO(png), "image/png")}, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "id" in data and "url" in data
        assert data["url"].startswith("/api/files/")
        # Fetch
        r2 = requests.get(f"{BASE_URL}{data['url']}", timeout=15)
        assert r2.status_code == 200
        assert r2.headers.get("content-type", "").startswith("image/")

    def test_upload_upi_qr_non_image_rejected(self, admin_headers):
        r = requests.post(f"{BASE_URL}/api/upload/upi-qr",
                          headers=admin_headers,
                          files={"file": ("qr.txt", io.BytesIO(b"nope"), "text/plain")}, timeout=15)
        assert r.status_code == 400

    def test_upload_upi_qr_member_forbidden(self, member_headers):
        png = _tiny_png_bytes()
        r = requests.post(f"{BASE_URL}/api/upload/upi-qr",
                          headers=member_headers,
                          files={"file": ("qr.png", io.BytesIO(png), "image/png")}, timeout=15)
        assert r.status_code == 403
