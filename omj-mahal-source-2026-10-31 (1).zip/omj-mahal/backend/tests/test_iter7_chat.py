"""Iteration 7 backend tests: Mahal Group chat, khatheeb appointment, staff login id, event->khatheeb notify."""
import io
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.strip().split("=", 1)[1].rstrip("/")

API = f"{BASE_URL}/api"

ADMIN = {"login_id": "ADMIN-001", "password": "admin123"}
MEMBER = {"login_id": "OMJ-0099", "password": "member123"}
KHATHEEB = {"login_id": "OMJ-S001", "password": "usthad123"}
KHATHEEB_USER_ID = "50d6cb3b-7ce9-41e2-875c-05206d90d6d7"


def _login(creds):
    r = requests.post(f"{API}/auth/login", json=creds, timeout=15)
    assert r.status_code == 200, f"login failed for {creds['login_id']}: {r.status_code} {r.text}"
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_h():
    return {"Authorization": f"Bearer {_login(ADMIN)}"}


@pytest.fixture(scope="module")
def member_h():
    return {"Authorization": f"Bearer {_login(MEMBER)}"}


@pytest.fixture(scope="module")
def khatheeb_h():
    # Ensure appointed first
    admin_tok = _login(ADMIN)
    requests.put(f"{API}/chat/khatheeb", json={"user_id": KHATHEEB_USER_ID},
                 headers={"Authorization": f"Bearer {admin_tok}"}, timeout=15)
    return {"Authorization": f"Bearer {_login(KHATHEEB)}"}


@pytest.fixture(scope="module", autouse=True)
def ensure_khatheeb_appointed(admin_h):
    requests.put(f"{API}/chat/khatheeb", json={"user_id": KHATHEEB_USER_ID}, headers=admin_h, timeout=15)
    yield
    # Restore appointment at the end
    requests.put(f"{API}/chat/khatheeb", json={"user_id": KHATHEEB_USER_ID}, headers=admin_h, timeout=15)
    # Cleanup outbox
    requests.post(f"{API}/notifications/outbox/clear", headers=admin_h, timeout=15)


# ---------- Rooms & access ----------
class TestChatRooms:
    def test_admin_rooms(self, admin_h):
        r = requests.get(f"{API}/chat/messages?room=all", headers=admin_h, timeout=15)
        assert r.status_code == 200
        j = r.json()
        assert j["room"] == "all"
        assert set(j["rooms"]) == {"all", "committee", "khatheeb"}
        assert j["locked"] is False
        assert isinstance(j["messages"], list)

    def test_member_rooms(self, member_h):
        r = requests.get(f"{API}/chat/messages?room=all", headers=member_h, timeout=15)
        assert r.status_code == 200
        assert r.json()["rooms"] == ["all"]

    def test_member_committee_forbidden(self, member_h):
        r = requests.get(f"{API}/chat/messages?room=committee", headers=member_h, timeout=15)
        assert r.status_code == 403

    def test_khatheeb_rooms(self, khatheeb_h):
        r = requests.get(f"{API}/chat/messages?room=all", headers=khatheeb_h, timeout=15)
        assert r.status_code == 200
        assert set(r.json()["rooms"]) == {"all", "khatheeb"}
        r2 = requests.get(f"{API}/chat/messages?room=khatheeb", headers=khatheeb_h, timeout=15)
        assert r2.status_code == 200
        r3 = requests.get(f"{API}/chat/messages?room=committee", headers=khatheeb_h, timeout=15)
        assert r3.status_code == 403

    def test_bogus_room(self, admin_h):
        r = requests.get(f"{API}/chat/messages?room=bogus", headers=admin_h, timeout=15)
        assert r.status_code == 400


# ---------- Post text ----------
class TestPostText:
    created = []

    def test_member_post(self, member_h):
        r = requests.post(f"{API}/chat/messages?room=all", json={"text": "test msg"}, headers=member_h, timeout=15)
        assert r.status_code == 201, r.text
        j = r.json()
        for k in ("id", "room", "user_id", "name", "house_no", "role", "text", "created_at"):
            assert k in j, f"missing {k}"
        assert j["room"] == "all"
        assert j["role"] == "member"
        assert j["house_no"] == "TEST-99"
        assert j["text"] == "test msg"
        TestPostText.created.append(j["id"])

    def test_empty(self, member_h):
        r = requests.post(f"{API}/chat/messages?room=all", json={"text": "   "}, headers=member_h, timeout=15)
        assert r.status_code == 400

    def test_too_long(self, member_h):
        r = requests.post(f"{API}/chat/messages?room=all", json={"text": "x" * 2001}, headers=member_h, timeout=15)
        assert r.status_code == 400

    def test_member_committee(self, member_h):
        r = requests.post(f"{API}/chat/messages?room=committee", json={"text": "hi"}, headers=member_h, timeout=15)
        assert r.status_code == 403

    def test_admin_khatheeb_room_visible_to_khatheeb(self, admin_h, khatheeb_h):
        r = requests.post(f"{API}/chat/messages?room=khatheeb", json={"text": "admin->khatheeb"}, headers=admin_h, timeout=15)
        assert r.status_code == 201
        TestPostText.created.append(r.json()["id"])
        r2 = requests.get(f"{API}/chat/messages?room=khatheeb", headers=khatheeb_h, timeout=15)
        assert r2.status_code == 200
        ids = [m["id"] for m in r2.json()["messages"]]
        assert TestPostText.created[-1] in ids

    def test_khatheeb_post_khatheeb(self, khatheeb_h):
        r = requests.post(f"{API}/chat/messages?room=khatheeb", json={"text": "khatheeb hello"}, headers=khatheeb_h, timeout=15)
        assert r.status_code == 201
        TestPostText.created.append(r.json()["id"])


# ---------- Polling ----------
class TestPolling:
    def test_after(self, member_h):
        r1 = requests.post(f"{API}/chat/messages?room=all", json={"text": "poll-anchor"}, headers=member_h, timeout=15)
        assert r1.status_code == 201
        anchor = r1.json()
        time.sleep(1.1)
        r2 = requests.post(f"{API}/chat/messages?room=all", json={"text": "poll-new"}, headers=member_h, timeout=15)
        newer_id = r2.json()["id"]
        r3 = requests.get(f"{API}/chat/messages", params={"room": "all", "after": anchor["created_at"]}, headers=member_h, timeout=15)
        msgs = r3.json()["messages"]
        ids = [m["id"] for m in msgs]
        assert newer_id in ids
        assert anchor["id"] not in ids
        # Ascending
        ts = [m["created_at"] for m in msgs]
        assert ts == sorted(ts)
        TestPostText.created.extend([anchor["id"], newer_id])


# ---------- Voice ----------
class TestVoice:
    voice_msg_id = None
    audio_url = None

    def test_upload(self, member_h):
        data = b"\x1a\x45\xdf\xa3" + os.urandom(2000)  # fake webm
        files = {"file": ("voice.webm", io.BytesIO(data), "audio/webm")}
        r = requests.post(f"{API}/chat/voice?room=all", files=files, data={"duration": "3.4"}, headers=member_h, timeout=20)
        assert r.status_code == 201, r.text
        j = r.json()
        assert j["audio_url"].startswith("/api/files/")
        assert j["duration"] == 3.4
        TestVoice.voice_msg_id = j["id"]
        TestVoice.audio_url = j["audio_url"]

    def test_fetch_audio(self, member_h):
        r = requests.get(f"{BASE_URL}{TestVoice.audio_url}", headers=member_h, timeout=15)
        assert r.status_code == 200
        assert "audio/webm" in r.headers.get("content-type", "")

    def test_bad_type(self, member_h):
        files = {"file": ("bad.txt", io.BytesIO(b"hello"), "text/plain")}
        r = requests.post(f"{API}/chat/voice?room=all", files=files, data={"duration": "1"}, headers=member_h, timeout=15)
        assert r.status_code == 400

    def test_empty(self, member_h):
        files = {"file": ("v.webm", io.BytesIO(b""), "audio/webm")}
        r = requests.post(f"{API}/chat/voice?room=all", files=files, data={"duration": "1"}, headers=member_h, timeout=15)
        assert r.status_code == 400


# ---------- Delete ----------
class TestDelete:
    def test_member_delete_own(self, member_h):
        r = requests.post(f"{API}/chat/messages?room=all", json={"text": "del-me"}, headers=member_h, timeout=15)
        mid = r.json()["id"]
        d = requests.delete(f"{API}/chat/messages/{mid}", headers=member_h, timeout=15)
        assert d.status_code == 200
        g = requests.get(f"{API}/chat/messages?room=all", headers=member_h, timeout=15)
        msg = next((m for m in g.json()["messages"] if m["id"] == mid), None)
        assert msg is not None
        assert msg["deleted"] is True
        assert msg["text"] == ""
        assert msg["audio_url"] is None

    def test_member_delete_admin_msg(self, admin_h, member_h):
        r = requests.post(f"{API}/chat/messages?room=all", json={"text": "admin msg"}, headers=admin_h, timeout=15)
        mid = r.json()["id"]
        d = requests.delete(f"{API}/chat/messages/{mid}", headers=member_h, timeout=15)
        assert d.status_code == 403
        # cleanup
        requests.delete(f"{API}/chat/messages/{mid}", headers=admin_h, timeout=15)

    def test_admin_delete_member(self, admin_h, member_h):
        r = requests.post(f"{API}/chat/messages?room=all", json={"text": "delete by admin"}, headers=member_h, timeout=15)
        mid = r.json()["id"]
        d = requests.delete(f"{API}/chat/messages/{mid}", headers=admin_h, timeout=15)
        assert d.status_code == 200

    def test_delete_voice(self, member_h):
        # self-contained: upload then delete
        data = b"\x1a\x45\xdf\xa3" + os.urandom(1500)
        files = {"file": ("dv.webm", io.BytesIO(data), "audio/webm")}
        r = requests.post(f"{API}/chat/voice?room=all", files=files, data={"duration": "1.0"}, headers=member_h, timeout=20)
        assert r.status_code == 201
        j = r.json()
        d = requests.delete(f"{API}/chat/messages/{j['id']}", headers=member_h, timeout=15)
        assert d.status_code == 200
        r = requests.get(f"{BASE_URL}{j['audio_url']}", headers=member_h, timeout=15)
        assert r.status_code == 404


# ---------- Lock ----------
class TestLock:
    def test_lock_flow(self, admin_h, member_h, khatheeb_h):
        try:
            r = requests.put(f"{API}/chat/lock", json={"locked": True}, headers=admin_h, timeout=15)
            assert r.status_code == 200
            # Member cannot post
            m = requests.post(f"{API}/chat/messages?room=all", json={"text": "blocked"}, headers=member_h, timeout=15)
            assert m.status_code == 403
            assert "lock" in m.json().get("detail", "").lower()
            # Admin can post
            a = requests.post(f"{API}/chat/messages?room=all", json={"text": "admin locked-post"}, headers=admin_h, timeout=15)
            assert a.status_code == 201
            requests.delete(f"{API}/chat/messages/{a.json()['id']}", headers=admin_h, timeout=15)
            # Khatheeb can post to khatheeb room
            k = requests.post(f"{API}/chat/messages?room=khatheeb", json={"text": "k-post"}, headers=khatheeb_h, timeout=15)
            assert k.status_code == 201
            requests.delete(f"{API}/chat/messages/{k.json()['id']}", headers=khatheeb_h, timeout=15)
            # Settings show chat_locked
            s = requests.get(f"{API}/settings", headers=admin_h, timeout=15)
            assert s.status_code == 200
            assert s.json().get("chat_locked") is True
        finally:
            requests.put(f"{API}/chat/lock", json={"locked": False}, headers=admin_h, timeout=15)


# ---------- Khatheeb appointment ----------
class TestKhatheebAppt:
    def test_appt(self, admin_h):
        r = requests.put(f"{API}/chat/khatheeb", json={"user_id": KHATHEEB_USER_ID}, headers=admin_h, timeout=15)
        assert r.status_code == 200
        s = requests.get(f"{API}/settings", headers=admin_h, timeout=15).json()
        assert s.get("khatheeb_user_id") == KHATHEEB_USER_ID

    def test_unknown(self, admin_h):
        r = requests.put(f"{API}/chat/khatheeb", json={"user_id": "nonexistent-id-xyz"}, headers=admin_h, timeout=15)
        assert r.status_code == 404

    def test_member_forbidden(self, member_h):
        r = requests.put(f"{API}/chat/khatheeb", json={"user_id": KHATHEEB_USER_ID}, headers=member_h, timeout=15)
        assert r.status_code == 403


# ---------- Event -> khatheeb notify ----------
class TestEventNotify:
    def test_flow(self, admin_h, khatheeb_h):
        # Create event
        r = requests.post(f"{API}/events", json={"title": "KTest", "date": "2026-10-05", "time": "7 PM",
                                                  "venue": "Masjid", "category": "programme"}, headers=admin_h, timeout=15)
        assert r.status_code == 201, r.text
        ev_id = r.json()["id"]
        try:
            # Small wait
            time.sleep(1)
            n = requests.get(f"{API}/notifications/mine", headers=khatheeb_h, timeout=15).json()
            khat_items = [x for x in n if x.get("kind") == "event_khatheeb" and "KTest" in x.get("body", "")]
            assert khat_items, f"no event_khatheeb notification; got: {n[:3]}"
            assert khat_items[0]["body"].lstrip().startswith("അസ്സലാമു അലൈക്കും")
            # Outbox
            ob = requests.get(f"{API}/notifications/outbox", headers=admin_h, timeout=15).json()
            assert any(m.get("to") in ("7777777777", "+917777777777", "917777777777") for m in ob), f"outbox missing khatheeb phone: {[m.get('to') for m in ob[:5]]}"
            # Update event time
            u = requests.put(f"{API}/events/{ev_id}", json={"title": "KTest", "date": "2026-10-05", "time": "8 PM",
                                                              "venue": "Masjid", "category": "programme"}, headers=admin_h, timeout=15)
            assert u.status_code == 200
            time.sleep(1)
            n2 = requests.get(f"{API}/notifications/mine", headers=khatheeb_h, timeout=15).json()
            khat2 = [x for x in n2 if x.get("kind") == "event_khatheeb" and "KTest" in x.get("body", "")]
            assert len(khat2) >= 2, f"expected 2 khatheeb notifications, got {len(khat2)}"
        finally:
            requests.delete(f"{API}/events/{ev_id}", headers=admin_h, timeout=15)
            requests.post(f"{API}/notifications/outbox/clear", headers=admin_h, timeout=15)


# ---------- Staff login id ----------
class TestStaffLogin:
    def test_create(self, admin_h):
        r = requests.post(f"{API}/users", json={"name": "Staff X", "phone": "7000000001",
                                                 "password": "staff123", "role": "member"}, headers=admin_h, timeout=15)
        assert r.status_code == 201, r.text
        j = r.json()
        login_id = j.get("login_id")
        assert login_id and login_id.startswith("OMJ-S"), f"expected OMJ-S..., got {login_id}"
        try:
            lr = requests.post(f"{API}/auth/login", json={"login_id": login_id, "password": "staff123"}, timeout=15)
            assert lr.status_code == 200
        finally:
            uid = j.get("id")
            if uid:
                requests.delete(f"{API}/users/{uid}", headers=admin_h, timeout=15)


# ---------- Regression ----------
class TestRegression:
    def test_member_id_login(self):
        r = requests.post(f"{API}/auth/login", json=MEMBER, timeout=15)
        assert r.status_code == 200

    def test_ledger_books(self, admin_h):
        r = requests.get(f"{API}/ledger/books", headers=admin_h, timeout=15)
        assert r.status_code == 200
        titles = [b.get("name", "") for b in r.json()]
        assert any("Nabidinam 2026 (Demo)" in t for t in titles), titles
        assert any("Salath" in t and "September 2026" in t for t in titles), titles


# Cleanup created chat messages
def test_zz_cleanup(admin_h):
    for mid in TestPostText.created:
        requests.delete(f"{API}/chat/messages/{mid}", headers=admin_h, timeout=15)
    requests.post(f"{API}/notifications/outbox/clear", headers=admin_h, timeout=15)
