const en = {
  intro: "Mahal App helps the committee keep houses, members, Varisankhya, donations, accounts and announcements in one place. Members can see their own house and dues. Works on phone and computer through the browser.",
  admin: [
    { title: "Login", steps: ["Open the app link and enter the admin phone number and password.", "Change the default password from My Profile → Change Password."] },
    { title: "Settings", steps: ["Go to Settings. Fill the Mahal name (English, Malayalam, Kannada), address, phone and registration number.", "Set the default monthly Varisankhya and receipt number prefix.", "Choose a logo or upload your own. Add president and secretary names — they appear on certificates."] },
    { title: "Add houses", steps: ["Houses → Add House. Enter house number, head of family, address, ward, phone and WhatsApp number.", "Set the monthly Varisankhya for this house and the month from which subscription starts.", "Use search and ward filter to find houses. Export CSV to open in Excel."] },
    { title: "Add family members", steps: ["Open a house → Add Member. Enter name, relation, date of birth (required), gender, occupation, education, blood group.", "The Members page lists everyone across all houses with search and export."] },
    { title: "Record Varisankhya & print receipt", steps: ["Varisankhya → Record Payment. Pick the house; pending months are highlighted — tap the months being paid.", "The total is calculated automatically (you can edit it). Choose Cash / UPI / Bank and save.", "A receipt number is generated. Print it or save as PDF from the receipt window.", "The Payments tab lists all receipts; filter by month or reprint any receipt."] },
    { title: "Dues & reminders", steps: ["The Dues tab shows every house with pending months and amount.", "Tap Record next to a house to collect, or Send dues reminders to message all pending houses on WhatsApp/SMS."] },
    { title: "Donations & funds", steps: ["Donations → Create Fund (e.g. Masjid renovation) with a target amount.", "Record Donation: choose fund, house (optional), donor name, amount. A donation receipt is generated.", "Progress bars show how much of the target is collected."] },
    { title: "Expenses & accounts", steps: ["Expenses → Add Expense with category (salary, electricity, maintenance…), amount and date.", "Reports shows income vs expense for any month or year, with a printable Income & Expenditure statement."] },
    { title: "Announcements", steps: ["Announcements → New Announcement. Choose category: General, Janazah, Event or Meeting.", "Members see it on their dashboard. If WhatsApp/SMS is connected, all houses receive the message."] },
    { title: "Committee & certificates", steps: ["Committee → add office bearers with designation, phone and term.", "Certificates → Issue Certificate: Membership, Nikah, Death or Birth. Fill the form, then print or save as PDF."] },
    { title: "Give members a login", steps: ["Open a house → Member Login → Create login. The house phone becomes the login number; type a password or leave blank for an auto 6-digit password.", "Share the details or tap Send via WhatsApp. Members are asked to change the password on first login.", "To create logins for all houses at once: User Accounts → Bulk create logins. Print the list.", "Forgot password? Open the house → Reset password and share the new one."] },
  ],
  member: [
    { title: "Login", steps: ["Open the app link, enter your phone number and the password given by the committee.", "Change your password from My Profile after the first login."] },
    { title: "My House & dues", steps: ["Dashboard shows your house, family members, monthly Varisankhya and pending months.", "My House lists your family details and every payment with receipt numbers. Tap the print icon to see or save a receipt."] },
    { title: "Announcements & committee", steps: ["Announcements shows all notices from the committee, including Janazah news and meetings.", "Committee shows office bearers with phone numbers — tap to call."] },
    { title: "Language", steps: ["Tap EN / മ / ಕ at the top to switch between English, Malayalam and Kannada. Your choice is remembered."] },
  ],
  faq: [
    { q: "I forgot my password. What should I do?", a: "Contact the committee (secretary/treasurer). The admin can reset your password from your house page or User Accounts and share the new one." },
    { q: "How do I add the app to my phone's home screen?", a: "Android: open the link in Chrome → menu (⋮) → Add to Home screen / Install app. iPhone: open in Safari → Share → Add to Home Screen. See the Install section below." },
    { q: "How do I save a receipt or certificate as PDF?", a: "Open the receipt/certificate and tap Print. In the print window choose 'Save as PDF' as the printer." },
    { q: "WhatsApp/SMS messages are not being delivered. Why?", a: "The messaging gateway (Twilio) is not connected yet, so the app is in demo mode — messages are only logged in the Messages page. Once the committee adds Twilio credentials, messages go out for real." },
    { q: "Can members edit their own details?", a: "No. Members can only view. Ask the committee to update names, phone numbers or family members." },
    { q: "Can I use it on a computer?", a: "Yes. The same link works in any browser on a computer, tablet or phone." },
  ],
  install: {
    android: ["Open the app link in Chrome.", "Tap the ⋮ menu at the top-right.", "Tap 'Add to Home screen' or 'Install app'.", "Tap Install. The app icon appears on your home screen."],
    ios: ["Open the app link in Safari.", "Tap the Share button (square with an arrow) at the bottom.", "Scroll and tap 'Add to Home Screen'.", "Tap Add. The app icon appears on your home screen."],
  },
};

const ml = {
  intro: "വീടുകൾ, അംഗങ്ങൾ, വരിസംഖ്യ, സംഭാവന, കണക്ക്, അറിയിപ്പുകൾ — എല്ലാം ഒരിടത്ത് കൈകാര്യം ചെയ്യാൻ കമ്മിറ്റിയെ സഹായിക്കുന്ന app ആണ് Mahal App. അംഗങ്ങൾക്ക് സ്വന്തം വീടും കുടിശ്ശികയും കാണാം. Phone-ലും computer-ലും browser വഴി ഉപയോഗിക്കാം.",
  admin: [
    { title: "Login", steps: ["App link തുറന്ന് admin phone number-ഉം password-ഉം നൽകുക.", "My Profile → Change Password എന്നതിൽ default password മാറ്റുക."] },
    { title: "Settings", steps: ["Settings-ൽ പോയി മഹലിന്റെ പേര് (English, മലയാളം, ಕನ್ನಡ), വിലാസം, phone, registration number ചേർക്കുക.", "സാധാരണ മാസ വരിസംഖ്യയും രസീത് നമ്പർ prefix-ഉം സെറ്റ് ചെയ്യുക.", "ലോഗോ തിരഞ്ഞെടുക്കുക അല്ലെങ്കിൽ സ്വന്തം ലോഗോ upload ചെയ്യുക. President, Secretary പേരുകൾ ചേർക്കുക — certificate-ൽ വരും."] },
    { title: "വീട് ചേർക്കൽ", steps: ["വീടുകൾ → വീട് ചേർക്കുക. വീട് നമ്പർ, കുടുംബനാഥൻ, വിലാസം, വാർഡ്, phone, WhatsApp നമ്പർ നൽകുക.", "ഈ വീടിന്റെ മാസ വരിസംഖ്യയും വരിസംഖ്യ ആരംഭിക്കുന്ന മാസവും സെറ്റ് ചെയ്യുക.", "Search-ഉം ward filter-ഉം ഉപയോഗിച്ച് വീട് കണ്ടെത്താം. CSV download ചെയ്ത് Excel-ൽ തുറക്കാം."] },
    { title: "കുടുംബാംഗങ്ങളെ ചേർക്കൽ", steps: ["ഒരു വീട് തുറന്ന് → അംഗം ചേർക്കുക. പേര്, ബന്ധം, ജനന തീയതി (നിർബന്ധം), ലിംഗം, തൊഴിൽ, വിദ്യാഭ്യാസം, രക്തഗ്രൂപ്പ് നൽകുക.", "അംഗങ്ങൾ page-ൽ എല്ലാ വീട്ടിലെയും അംഗങ്ങളെ search ചെയ്യാനും export ചെയ്യാനും കഴിയും."] },
    { title: "വരിസംഖ്യ രേഖപ്പെടുത്തി രസീത് print", steps: ["വരിസംഖ്യ → വരിസംഖ്യ രേഖപ്പെടുത്തുക. വീട് തിരഞ്ഞെടുക്കുക; ബാക്കിയുള്ള മാസങ്ങൾ highlight ആയി കാണാം — അടയ്ക്കുന്ന മാസങ്ങൾ tap ചെയ്യുക.", "ആകെ തുക automatic ആയി വരും (മാറ്റാം). Cash / UPI / Bank തിരഞ്ഞെടുത്ത് save ചെയ്യുക.", "രസീത് നമ്പർ automatic ആയി ഉണ്ടാകും. രസീത് window-ൽ നിന്ന് print ചെയ്യുക അല്ലെങ്കിൽ PDF ആയി save ചെയ്യുക.", "അടച്ചവ tab-ൽ എല്ലാ രസീതുകളും കാണാം; മാസം അനുസരിച്ച് filter ചെയ്യാം, വീണ്ടും print ചെയ്യാം."] },
    { title: "കുടിശ്ശികയും reminder-ഉം", steps: ["കുടിശ്ശിക tab-ൽ ബാക്കിയുള്ള മാസങ്ങളും തുകയും ഉള്ള എല്ലാ വീടും കാണാം.", "വീടിന്റെ അടുത്തുള്ള 'രേഖപ്പെടുത്തുക' അമർത്തി പിരിക്കാം; അല്ലെങ്കിൽ 'കുടിശ്ശിക reminder അയക്കുക' അമർത്തിയാൽ ബാക്കിയുള്ള എല്ലാ വീട്ടിലേക്കും WhatsApp/SMS പോകും."] },
    { title: "സംഭാവനയും പിരിവുകളും", steps: ["സംഭാവന → പിരിവ് ആരംഭിക്കുക (ഉദാ: മസ്ജിദ് നിർമാണം) ലക്ഷ്യ തുകയോടെ.", "സംഭാവന രേഖപ്പെടുത്തുക: പിരിവ്, വീട് (നിർബന്ധമില്ല), ദാതാവിന്റെ പേര്, തുക. രസീത് ഉണ്ടാകും.", "ലക്ഷ്യത്തിന്റെ എത്ര ശതമാനം കിട്ടി എന്ന് progress bar-ൽ കാണാം."] },
    { title: "ചെലവും കണക്കും", steps: ["ചെലവുകൾ → ചെലവ് ചേർക്കുക: വിഭാഗം (ശമ്പളം, വൈദ്യുതി, maintenance…), തുക, തീയതി.", "കണക്ക് page-ൽ ഏത് മാസത്തെയും വർഷത്തെയും വരവ്-ചെലവ് കാണാം; print ചെയ്യാവുന്ന വരവ് ചെലവ് കണക്കും ഉണ്ട്."] },
    { title: "അറിയിപ്പുകൾ", steps: ["അറിയിപ്പുകൾ → പുതിയ അറിയിപ്പ്. വിഭാഗം: പൊതു, മരണവാർത്ത, പരിപാടി, മീറ്റിംഗ്.", "അംഗങ്ങൾക്ക് dashboard-ൽ കാണാം. WhatsApp/SMS connect ചെയ്തിട്ടുണ്ടെങ്കിൽ എല്ലാ വീട്ടിലേക്കും message പോകും."] },
    { title: "കമ്മിറ്റിയും certificate-ഉം", steps: ["കമ്മിറ്റി → ഭാരവാഹികളെ സ്ഥാനം, phone, കാലാവധി എന്നിവയോടെ ചേർക്കുക.", "സർട്ടിഫിക്കറ്റ് → സർട്ടിഫിക്കറ്റ് നൽകുക: അംഗത്വം, നികാഹ്, മരണം, ജനനം. Form പൂരിപ്പിച്ച് print / PDF."] },
    { title: "അംഗങ്ങൾക്ക് login കൊടുക്കൽ", steps: ["ഒരു വീട് തുറന്ന് → അംഗത്തിന്റെ Login → Login ഉണ്ടാക്കുക. വീടിന്റെ phone number login number ആകും; password type ചെയ്യുക അല്ലെങ്കിൽ ഒഴിച്ചിട്ടാൽ 6 അക്ക password automatic.", "വിവരങ്ങൾ അംഗത്തിന് നൽകുക അല്ലെങ്കിൽ 'WhatsApp-ൽ അയക്കുക' അമർത്തുക. ആദ്യ login-ൽ password മാറ്റാൻ ഓർമ്മപ്പെടുത്തും.", "എല്ലാ വീടിനും ഒരുമിച്ച് login ഉണ്ടാക്കാൻ: അക്കൗണ്ടുകൾ → ഒരുമിച്ച് login ഉണ്ടാക്കുക. പട്ടിക print ചെയ്യുക.", "Password മറന്നോ? വീട് തുറന്ന് → പാസ്‌വേഡ് reset ചെയ്ത് പുതിയത് നൽകുക."] },
  ],
  member: [
    { title: "Login", steps: ["App link തുറന്ന് നിങ്ങളുടെ phone number-ഉം കമ്മിറ്റി നൽകിയ password-ഉം നൽകുക.", "ആദ്യ login-ന് ശേഷം My Profile-ൽ നിന്ന് password മാറ്റുക."] },
    { title: "എന്റെ വീടും കുടിശ്ശികയും", steps: ["Dashboard-ൽ നിങ്ങളുടെ വീട്, കുടുംബാംഗങ്ങൾ, മാസ വരിസംഖ്യ, ബാക്കി മാസങ്ങൾ കാണാം.", "എന്റെ വീട് page-ൽ കുടുംബ വിവരങ്ങളും രസീത് നമ്പർ സഹിതം എല്ലാ payment-ഉം കാണാം. Print icon അമർത്തിയാൽ രസീത് കാണാം / save ചെയ്യാം."] },
    { title: "അറിയിപ്പുകളും കമ്മിറ്റിയും", steps: ["അറിയിപ്പുകൾ page-ൽ കമ്മിറ്റിയുടെ എല്ലാ അറിയിപ്പുകളും — മരണവാർത്ത, മീറ്റിംഗ് ഉൾപ്പെടെ — കാണാം.", "കമ്മിറ്റി page-ൽ ഭാരവാഹികളുടെ phone number ഉണ്ട് — tap ചെയ്താൽ വിളിക്കാം."] },
    { title: "ഭാഷ", steps: ["മുകളിലെ EN / മ / ಕ അമർത്തി English, മലയാളം, ಕನ್ನಡ മാറ്റാം. തിരഞ്ഞെടുത്ത ഭാഷ ഓർത്തുവയ്ക്കും."] },
  ],
  faq: [
    { q: "Password മറന്നു. എന്ത് ചെയ്യണം?", a: "കമ്മിറ്റിയെ (സെക്രട്ടറി/ട്രഷറർ) ബന്ധപ്പെടുക. Admin-ന് നിങ്ങളുടെ വീടിന്റെ page-ൽ നിന്നോ അക്കൗണ്ടുകൾ page-ൽ നിന്നോ password reset ചെയ്ത് പുതിയത് നൽകാം." },
    { q: "Phone-ന്റെ home screen-ൽ app എങ്ങനെ ചേർക്കും?", a: "Android: Chrome-ൽ link തുറക്കുക → menu (⋮) → Add to Home screen / Install app. iPhone: Safari-ൽ തുറക്കുക → Share → Add to Home Screen. താഴെ Install ഭാഗം കാണുക." },
    { q: "രസീത് / certificate PDF ആയി save ചെയ്യുന്നത് എങ്ങനെ?", a: "രസീത്/certificate തുറന്ന് Print അമർത്തുക. Print window-ൽ printer ആയി 'Save as PDF' തിരഞ്ഞെടുക്കുക." },
    { q: "WhatsApp/SMS message പോകുന്നില്ല. എന്തുകൊണ്ട്?", a: "Messaging gateway (Twilio) ഇതുവരെ connect ചെയ്തിട്ടില്ല; app demo mode-ൽ ആണ് — message-കൾ Messages page-ൽ log ആകുന്നു മാത്രം. കമ്മിറ്റി Twilio വിവരങ്ങൾ ചേർത്താൽ ശരിക്കും അയക്കാൻ തുടങ്ങും." },
    { q: "അംഗങ്ങൾക്ക് സ്വന്തം വിവരങ്ങൾ മാറ്റാമോ?", a: "ഇല്ല. അംഗങ്ങൾക്ക് കാണാൻ മാത്രമേ കഴിയൂ. പേര്, phone number, കുടുംബാംഗങ്ങൾ മാറ്റാൻ കമ്മിറ്റിയോട് പറയുക." },
    { q: "Computer-ൽ ഉപയോഗിക്കാമോ?", a: "അതെ. അതേ link computer, tablet, phone — ഏത് browser-ലും പ്രവർത്തിക്കും." },
  ],
  install: {
    android: ["Chrome-ൽ app link തുറക്കുക.", "മുകളിൽ വലത്തുള്ള ⋮ menu അമർത്തുക.", "'Add to Home screen' അല്ലെങ്കിൽ 'Install app' അമർത്തുക.", "Install അമർത്തുക. Home screen-ൽ app icon വരും."],
    ios: ["Safari-ൽ app link തുറക്കുക.", "താഴെയുള്ള Share button (അമ്പുള്ള ചതുരം) അമർത്തുക.", "Scroll ചെയ്ത് 'Add to Home Screen' അമർത്തുക.", "Add അമർത്തുക. Home screen-ൽ app icon വരും."],
  },
};

const kn = {
  intro: "ಮನೆಗಳು, ಸದಸ್ಯರು, ವರಿಸಂಖ್ಯೆ, ದೇಣಿಗೆ, ಲೆಕ್ಕಪತ್ರ ಮತ್ತು ಪ್ರಕಟಣೆಗಳನ್ನು ಒಂದೇ ಸ್ಥಳದಲ್ಲಿ ನಿರ್ವಹಿಸಲು ಸಮಿತಿಗೆ Mahal App ಸಹಾಯ ಮಾಡುತ್ತದೆ. ಸದಸ್ಯರು ತಮ್ಮ ಮನೆ ಮತ್ತು ಬಾಕಿ ನೋಡಬಹುದು. ಫೋನ್ ಮತ್ತು ಕಂಪ್ಯೂಟರ್‌ನಲ್ಲಿ ಬ್ರೌಸರ್ ಮೂಲಕ ಕೆಲಸ ಮಾಡುತ್ತದೆ.",
  admin: [
    { title: "ಲಾಗಿನ್", steps: ["ಆಪ್ ಲಿಂಕ್ ತೆರೆದು ಅಡ್ಮಿನ್ ಫೋನ್ ಸಂಖ್ಯೆ ಮತ್ತು ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ.", "My Profile → Change Password ನಲ್ಲಿ ಡೀಫಾಲ್ಟ್ ಪಾಸ್‌ವರ್ಡ್ ಬದಲಾಯಿಸಿ."] },
    { title: "ಸೆಟ್ಟಿಂಗ್‌ಗಳು", steps: ["ಸೆಟ್ಟಿಂಗ್‌ಗಳಿಗೆ ಹೋಗಿ. ಮಹಲ್ ಹೆಸರು (English, ಮಲಯಾಳಂ, ಕನ್ನಡ), ವಿಳಾಸ, ಫೋನ್, ನೋಂದಣಿ ಸಂಖ್ಯೆ ಭರ್ತಿ ಮಾಡಿ.", "ಡೀಫಾಲ್ಟ್ ಮಾಸಿಕ ವರಿಸಂಖ್ಯೆ ಮತ್ತು ರಸೀದಿ ಸಂಖ್ಯೆ prefix ಹೊಂದಿಸಿ.", "ಲೋಗೋ ಆಯ್ಕೆಮಾಡಿ ಅಥವಾ ನಿಮ್ಮದೇ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ. ಅಧ್ಯಕ್ಷ ಮತ್ತು ಕಾರ್ಯದರ್ಶಿ ಹೆಸರು ಸೇರಿಸಿ — ಪ್ರಮಾಣಪತ್ರಗಳಲ್ಲಿ ಬರುತ್ತದೆ."] },
    { title: "ಮನೆಗಳನ್ನು ಸೇರಿಸಿ", steps: ["ಮನೆಗಳು → ಮನೆ ಸೇರಿಸಿ. ಮನೆ ಸಂಖ್ಯೆ, ಕುಟುಂಬದ ಮುಖ್ಯಸ್ಥ, ವಿಳಾಸ, ವಾರ್ಡ್, ಫೋನ್, WhatsApp ಸಂಖ್ಯೆ ನಮೂದಿಸಿ.", "ಈ ಮನೆಯ ಮಾಸಿಕ ವರಿಸಂಖ್ಯೆ ಮತ್ತು ಚಂದಾ ಆರಂಭ ತಿಂಗಳು ಹೊಂದಿಸಿ.", "ಹುಡುಕಾಟ ಮತ್ತು ವಾರ್ಡ್ ಫಿಲ್ಟರ್ ಬಳಸಿ. CSV ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ Excel ನಲ್ಲಿ ತೆರೆಯಿರಿ."] },
    { title: "ಕುಟುಂಬ ಸದಸ್ಯರನ್ನು ಸೇರಿಸಿ", steps: ["ಮನೆ ತೆರೆಯಿರಿ → ಸದಸ್ಯ ಸೇರಿಸಿ. ಹೆಸರು, ಸಂಬಂಧ, ಜನ್ಮ ದಿನಾಂಕ (ಅಗತ್ಯ), ಲಿಂಗ, ಉದ್ಯೋಗ, ಶಿಕ್ಷಣ, ರಕ್ತದ ಗುಂಪು ನಮೂದಿಸಿ.", "ಸದಸ್ಯರ ಪುಟದಲ್ಲಿ ಎಲ್ಲಾ ಮನೆಗಳ ಸದಸ್ಯರನ್ನು ಹುಡುಕಬಹುದು ಮತ್ತು ರಫ್ತು ಮಾಡಬಹುದು."] },
    { title: "ವರಿಸಂಖ್ಯೆ ದಾಖಲಿಸಿ ರಸೀದಿ ಮುದ್ರಿಸಿ", steps: ["ವರಿಸಂಖ್ಯೆ → ಪಾವತಿ ದಾಖಲಿಸಿ. ಮನೆ ಆಯ್ಕೆಮಾಡಿ; ಬಾಕಿ ತಿಂಗಳುಗಳು ಹೈಲೈಟ್ ಆಗಿರುತ್ತವೆ — ಪಾವತಿಸುವ ತಿಂಗಳುಗಳನ್ನು ಟ್ಯಾಪ್ ಮಾಡಿ.", "ಒಟ್ಟು ಮೊತ್ತ ಸ್ವಯಂ ಲೆಕ್ಕವಾಗುತ್ತದೆ (ಬದಲಾಯಿಸಬಹುದು). ನಗದು / UPI / ಬ್ಯಾಂಕ್ ಆಯ್ಕೆಮಾಡಿ ಉಳಿಸಿ.", "ರಸೀದಿ ಸಂಖ್ಯೆ ಸ್ವಯಂ ರಚನೆಯಾಗುತ್ತದೆ. ರಸೀದಿ ವಿಂಡೋದಿಂದ ಮುದ್ರಿಸಿ ಅಥವಾ PDF ಆಗಿ ಉಳಿಸಿ.", "ಪಾವತಿಗಳ ಟ್ಯಾಬ್‌ನಲ್ಲಿ ಎಲ್ಲಾ ರಸೀದಿಗಳು; ತಿಂಗಳ ಪ್ರಕಾರ ಫಿಲ್ಟರ್, ಮರುಮುದ್ರಣ."] },
    { title: "ಬಾಕಿ ಮತ್ತು ಜ್ಞಾಪನೆಗಳು", steps: ["ಬಾಕಿ ಟ್ಯಾಬ್ ಬಾಕಿ ತಿಂಗಳು ಮತ್ತು ಮೊತ್ತ ಇರುವ ಪ್ರತಿ ಮನೆಯನ್ನು ತೋರಿಸುತ್ತದೆ.", "ಮನೆಯ ಪಕ್ಕದ 'ದಾಖಲಿಸಿ' ಒತ್ತಿ ಸಂಗ್ರಹಿಸಿ, ಅಥವಾ 'ಬಾಕಿ ಜ್ಞಾಪನೆ ಕಳುಹಿಸಿ' ಒತ್ತಿ ಎಲ್ಲಾ ಬಾಕಿ ಮನೆಗಳಿಗೆ WhatsApp/SMS ಕಳುಹಿಸಿ."] },
    { title: "ದೇಣಿಗೆ ಮತ್ತು ನಿಧಿಗಳು", steps: ["ದೇಣಿಗೆ → ನಿಧಿ ರಚಿಸಿ (ಉದಾ: ಮಸ್ಜಿದ್ ನವೀಕರಣ) ಗುರಿ ಮೊತ್ತದೊಂದಿಗೆ.", "ದೇಣಿಗೆ ದಾಖಲಿಸಿ: ನಿಧಿ, ಮನೆ (ಐಚ್ಛಿಕ), ದಾನಿ ಹೆಸರು, ಮೊತ್ತ. ರಸೀದಿ ರಚನೆಯಾಗುತ್ತದೆ.", "ಗುರಿಯ ಎಷ್ಟು ಸಂಗ್ರಹವಾಯಿತು ಎಂದು ಪ್ರೋಗ್ರೆಸ್ ಬಾರ್ ತೋರಿಸುತ್ತದೆ."] },
    { title: "ಖರ್ಚು ಮತ್ತು ಲೆಕ್ಕ", steps: ["ಖರ್ಚುಗಳು → ಖರ್ಚು ಸೇರಿಸಿ: ವರ್ಗ (ಸಂಬಳ, ವಿದ್ಯುತ್, ನಿರ್ವಹಣೆ…), ಮೊತ್ತ, ದಿನಾಂಕ.", "ಲೆಕ್ಕಪತ್ರ ಪುಟ ಯಾವುದೇ ತಿಂಗಳು/ವರ್ಷದ ಆದಾಯ-ಖರ್ಚು ತೋರಿಸುತ್ತದೆ; ಮುದ್ರಿಸಬಹುದಾದ ಆದಾಯ-ವೆಚ್ಚ ಲೆಕ್ಕವಿದೆ."] },
    { title: "ಪ್ರಕಟಣೆಗಳು", steps: ["ಪ್ರಕಟಣೆಗಳು → ಹೊಸ ಪ್ರಕಟಣೆ. ವರ್ಗ: ಸಾಮಾನ್ಯ, ಮರಣ ವಾರ್ತೆ, ಕಾರ್ಯಕ್ರಮ, ಸಭೆ.", "ಸದಸ್ಯರು ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ ನೋಡುತ್ತಾರೆ. WhatsApp/SMS ಸಂಪರ್ಕವಿದ್ದರೆ ಎಲ್ಲಾ ಮನೆಗಳಿಗೆ ಸಂದೇಶ ಹೋಗುತ್ತದೆ."] },
    { title: "ಸಮಿತಿ ಮತ್ತು ಪ್ರಮಾಣಪತ್ರಗಳು", steps: ["ಸಮಿತಿ → ಪದಾಧಿಕಾರಿಗಳನ್ನು ಹುದ್ದೆ, ಫೋನ್, ಅವಧಿಯೊಂದಿಗೆ ಸೇರಿಸಿ.", "ಪ್ರಮಾಣಪತ್ರಗಳು → ಪ್ರಮಾಣಪತ್ರ ನೀಡಿ: ಸದಸ್ಯತ್ವ, ನಿಕಾಹ್, ಮರಣ, ಜನನ. ಫಾರ್ಮ್ ಭರ್ತಿ ಮಾಡಿ ಮುದ್ರಿಸಿ / PDF."] },
    { title: "ಸದಸ್ಯರಿಗೆ ಲಾಗಿನ್ ನೀಡಿ", steps: ["ಮನೆ ತೆರೆಯಿರಿ → ಸದಸ್ಯರ ಲಾಗಿನ್ → ಲಾಗಿನ್ ರಚಿಸಿ. ಮನೆಯ ಫೋನ್ ಲಾಗಿನ್ ಸಂಖ್ಯೆ ಆಗುತ್ತದೆ; ಪಾಸ್‌ವರ್ಡ್ ಟೈಪ್ ಮಾಡಿ ಅಥವಾ ಖಾಲಿ ಬಿಟ್ಟರೆ 6 ಅಂಕಿಯ ಪಾಸ್‌ವರ್ಡ್ ಸ್ವಯಂ.", "ವಿವರಗಳನ್ನು ಹಂಚಿ ಅಥವಾ 'WhatsApp ಮೂಲಕ ಕಳುಹಿಸಿ' ಒತ್ತಿ. ಮೊದಲ ಲಾಗಿನ್‌ನಲ್ಲಿ ಪಾಸ್‌ವರ್ಡ್ ಬದಲಾಯಿಸಲು ಕೇಳಲಾಗುತ್ತದೆ.", "ಎಲ್ಲಾ ಮನೆಗಳಿಗೆ ಒಟ್ಟಿಗೆ: ಖಾತೆಗಳು → ಒಟ್ಟಿಗೆ ಲಾಗಿನ್ ರಚಿಸಿ. ಪಟ್ಟಿ ಮುದ್ರಿಸಿ.", "ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿರಾ? ಮನೆ ತೆರೆದು → ಪಾಸ್‌ವರ್ಡ್ ರೀಸೆಟ್ ಮಾಡಿ ಹೊಸದನ್ನು ಹಂಚಿ."] },
  ],
  member: [
    { title: "ಲಾಗಿನ್", steps: ["ಆಪ್ ಲಿಂಕ್ ತೆರೆದು ನಿಮ್ಮ ಫೋನ್ ಸಂಖ್ಯೆ ಮತ್ತು ಸಮಿತಿ ನೀಡಿದ ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ.", "ಮೊದಲ ಲಾಗಿನ್ ನಂತರ My Profile ನಲ್ಲಿ ಪಾಸ್‌ವರ್ಡ್ ಬದಲಾಯಿಸಿ."] },
    { title: "ನನ್ನ ಮನೆ ಮತ್ತು ಬಾಕಿ", steps: ["ಡ್ಯಾಶ್‌ಬೋರ್ಡ್ ನಿಮ್ಮ ಮನೆ, ಕುಟುಂಬ ಸದಸ್ಯರು, ಮಾಸಿಕ ವರಿಸಂಖ್ಯೆ, ಬಾಕಿ ತಿಂಗಳುಗಳನ್ನು ತೋರಿಸುತ್ತದೆ.", "ನನ್ನ ಮನೆ ಪುಟದಲ್ಲಿ ಕುಟುಂಬ ವಿವರ ಮತ್ತು ರಸೀದಿ ಸಂಖ್ಯೆಯೊಂದಿಗೆ ಪ್ರತಿ ಪಾವತಿ. ಮುದ್ರಣ ಐಕಾನ್ ಒತ್ತಿ ರಸೀದಿ ನೋಡಿ/ಉಳಿಸಿ."] },
    { title: "ಪ್ರಕಟಣೆಗಳು ಮತ್ತು ಸಮಿತಿ", steps: ["ಪ್ರಕಟಣೆಗಳು ಪುಟದಲ್ಲಿ ಸಮಿತಿಯ ಎಲ್ಲಾ ಸೂಚನೆಗಳು — ಮರಣ ವಾರ್ತೆ, ಸಭೆ ಸೇರಿ.", "ಸಮಿತಿ ಪುಟದಲ್ಲಿ ಪದಾಧಿಕಾರಿಗಳ ಫೋನ್ ಸಂಖ್ಯೆ — ಟ್ಯಾಪ್ ಮಾಡಿ ಕರೆ ಮಾಡಿ."] },
    { title: "ಭಾಷೆ", steps: ["ಮೇಲಿನ EN / മ / ಕ ಒತ್ತಿ English, ಮಲಯಾಳಂ, ಕನ್ನಡ ಬದಲಾಯಿಸಿ. ನಿಮ್ಮ ಆಯ್ಕೆ ನೆನಪಿಡಲಾಗುತ್ತದೆ."] },
  ],
  faq: [
    { q: "ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿದ್ದೇನೆ. ಏನು ಮಾಡಬೇಕು?", a: "ಸಮಿತಿಯನ್ನು (ಕಾರ್ಯದರ್ಶಿ/ಖಜಾಂಚಿ) ಸಂಪರ್ಕಿಸಿ. ಅಡ್ಮಿನ್ ನಿಮ್ಮ ಮನೆ ಪುಟ ಅಥವಾ ಖಾತೆಗಳ ಪುಟದಿಂದ ಪಾಸ್‌ವರ್ಡ್ ರೀಸೆಟ್ ಮಾಡಿ ಹೊಸದನ್ನು ನೀಡಬಹುದು." },
    { q: "ಫೋನ್ ಹೋಮ್ ಸ್ಕ್ರೀನ್‌ಗೆ ಆಪ್ ಹೇಗೆ ಸೇರಿಸುವುದು?", a: "Android: Chrome ನಲ್ಲಿ ಲಿಂಕ್ ತೆರೆಯಿರಿ → ಮೆನು (⋮) → Add to Home screen / Install app. iPhone: Safari ನಲ್ಲಿ → Share → Add to Home Screen. ಕೆಳಗಿನ ಇನ್‌ಸ್ಟಾಲ್ ವಿಭಾಗ ನೋಡಿ." },
    { q: "ರಸೀದಿ / ಪ್ರಮಾಣಪತ್ರ PDF ಆಗಿ ಉಳಿಸುವುದು ಹೇಗೆ?", a: "ರಸೀದಿ/ಪ್ರಮಾಣಪತ್ರ ತೆರೆದು Print ಒತ್ತಿ. ಪ್ರಿಂಟ್ ವಿಂಡೋದಲ್ಲಿ ಪ್ರಿಂಟರ್ ಆಗಿ 'Save as PDF' ಆಯ್ಕೆಮಾಡಿ." },
    { q: "WhatsApp/SMS ಸಂದೇಶಗಳು ಹೋಗುತ್ತಿಲ್ಲ. ಯಾಕೆ?", a: "ಮೆಸೇಜಿಂಗ್ ಗೇಟ್‌ವೇ (Twilio) ಇನ್ನೂ ಸಂಪರ್ಕವಾಗಿಲ್ಲ; ಆಪ್ ಡೆಮೊ ಮೋಡ್‌ನಲ್ಲಿದೆ — ಸಂದೇಶಗಳು Messages ಪುಟದಲ್ಲಿ ಲಾಗ್ ಆಗುತ್ತವೆ ಮಾತ್ರ. ಸಮಿತಿ Twilio ವಿವರ ಸೇರಿಸಿದ ನಂತರ ನಿಜವಾಗಿ ಕಳುಹಿಸಲಾಗುತ್ತದೆ." },
    { q: "ಸದಸ್ಯರು ತಮ್ಮ ವಿವರಗಳನ್ನು ಬದಲಾಯಿಸಬಹುದೇ?", a: "ಇಲ್ಲ. ಸದಸ್ಯರು ನೋಡಬಹುದು ಮಾತ್ರ. ಹೆಸರು, ಫೋನ್, ಕುಟುಂಬ ಸದಸ್ಯರನ್ನು ಬದಲಾಯಿಸಲು ಸಮಿತಿಯನ್ನು ಕೇಳಿ." },
    { q: "ಕಂಪ್ಯೂಟರ್‌ನಲ್ಲಿ ಬಳಸಬಹುದೇ?", a: "ಹೌದು. ಅದೇ ಲಿಂಕ್ ಕಂಪ್ಯೂಟರ್, ಟ್ಯಾಬ್ಲೆಟ್, ಫೋನ್ — ಯಾವುದೇ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ಕೆಲಸ ಮಾಡುತ್ತದೆ." },
  ],
  install: {
    android: ["Chrome ನಲ್ಲಿ ಆಪ್ ಲಿಂಕ್ ತೆರೆಯಿರಿ.", "ಮೇಲಿನ ಬಲಭಾಗದ ⋮ ಮೆನು ಒತ್ತಿ.", "'Add to Home screen' ಅಥವಾ 'Install app' ಒತ್ತಿ.", "Install ಒತ್ತಿ. ಹೋಮ್ ಸ್ಕ್ರೀನ್‌ನಲ್ಲಿ ಆಪ್ ಐಕಾನ್ ಬರುತ್ತದೆ."],
    ios: ["Safari ನಲ್ಲಿ ಆಪ್ ಲಿಂಕ್ ತೆರೆಯಿರಿ.", "ಕೆಳಗಿನ Share ಬಟನ್ (ಬಾಣದ ಚೌಕ) ಒತ್ತಿ.", "ಸ್ಕ್ರಾಲ್ ಮಾಡಿ 'Add to Home Screen' ಒತ್ತಿ.", "Add ಒತ್ತಿ. ಹೋಮ್ ಸ್ಕ್ರೀನ್‌ನಲ್ಲಿ ಆಪ್ ಐಕಾನ್ ಬರುತ್ತದೆ."],
  },
};

export const helpContent = { en, ml, kn };
