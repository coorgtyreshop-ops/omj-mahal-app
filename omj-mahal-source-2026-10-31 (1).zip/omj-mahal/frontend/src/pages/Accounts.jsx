import { useCallback, useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Plus, BookOpen, Moon, ChevronRight, Building2 } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { fmtDate, inr, monthLabel } from "@/lib/format";
import { PageHeader, EmptyState, StatCard } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BookForm } from "@/components/ledger/LedgerForms";
import { cn } from "@/lib/utils";

const canWrite = (scope, committee) => scope === "all" || (scope === "salath" && committee === "salath");

const BookCard = ({ b, lang, months }) => (
  <Link to={`/accounts/${b.id}`} className="rounded-xl border border-[#e6dbc9] bg-card p-4 shadow-sm hover:shadow-md hover:border-[#d4af37] transition-all flex flex-col gap-2" data-testid={`book-card-${b.id}`}>
    <div className="flex items-start gap-3">
      <span className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-full", b.committee === "salath" ? "bg-[#1c2420] text-[#d4af37]" : b.committee === "rent" ? "bg-[#8a6d1d]/15 text-[#8a6d1d]" : "bg-primary/10 text-primary")}>{b.committee === "salath" ? <Moon className="h-5 w-5" /> : b.committee === "rent" ? <Building2 className="h-5 w-5" /> : <BookOpen className="h-5 w-5" />}</span>
      <div className="min-w-0 flex-1">
        <p className="font-bold leading-tight truncate">{lang === "ml" && b.name_ml ? b.name_ml : b.name}</p>
        <p className="text-xs text-muted-foreground">{b.month ? monthLabel(b.month, months) : fmtDate(b.date)}{b.note ? ` · ${b.note}` : ""}</p>
      </div>
      <ChevronRight className="h-4 w-4 text-muted-foreground" />
    </div>
    <div className="grid grid-cols-3 gap-2 text-center text-xs">
      <div className="rounded-lg bg-primary/5 p-2"><p className="text-muted-foreground">↓</p><p className="font-bold text-primary">{inr(b.income)}</p></div>
      <div className="rounded-lg bg-red-50 p-2"><p className="text-muted-foreground">↑</p><p className="font-bold text-red-700">{inr(b.expense)}</p></div>
      <div className="rounded-lg bg-[#d4af37]/15 p-2"><p className="text-muted-foreground">=</p><p className={cn("font-bold", b.balance < 0 ? "text-red-700" : "text-[#8a6d1d]")}>{inr(b.balance)}</p></div>
    </div>
  </Link>
);

export default function Accounts() {
  const { t, lang, months } = useLang();
  const { user } = useAuth();
  const [params, setParams] = useSearchParams();
  const scope = user?.ledger_scope || "none";
  const committee = scope === "salath" ? "salath" : ["salath", "rent"].includes(params.get("tab")) ? params.get("tab") : "main";
  const [forbidden, setForbidden] = useState(false);
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const [rows, setRows] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const load = useCallback(() => api.get("/ledger/books", { params: { committee, year: year === "all" ? undefined : year } }).then((r) => setRows(r.data)).catch((e) => { setRows([]); setForbidden(e?.response?.status === 403); }), [committee, year]);
  useEffect(() => { load(); }, [load]);
  const y = new Date().getFullYear();
  const totals = (rows || []).reduce((a, b) => ({ income: a.income + b.income, expense: a.expense + b.expense }), { income: 0, expense: 0 });
  return (
    <div data-testid="accounts-page">
      <PageHeader title={t("ledger.title")} subtitle={t("ledger.subtitle")} actions={canWrite(scope, committee) && <Button onClick={() => setFormOpen(true)} className="h-11" data-testid="new-book-button"><Plus className="h-4 w-4 mr-2" />{t("ledger.newBook")}</Button>} />
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-5">
        <Tabs value={committee} onValueChange={(v) => setParams({ tab: v })} className="flex-1">
          <TabsList className="grid grid-cols-3 h-12 w-full sm:max-w-xl">
            <TabsTrigger value="main" disabled={scope === "salath"} className="h-10" data-testid="accounts-tab-main"><BookOpen className="h-4 w-4 mr-2" />{t("ledger.main")}</TabsTrigger>
            <TabsTrigger value="salath" className="h-10" data-testid="accounts-tab-salath"><Moon className="h-4 w-4 mr-2" />{t("ledger.salath")}</TabsTrigger>
            <TabsTrigger value="rent" disabled={scope === "salath"} className="h-10" data-testid="accounts-tab-rent"><Building2 className="h-4 w-4 mr-2" />{t("ledger.rent")}</TabsTrigger>
          </TabsList>
        </Tabs>
        <Select value={year} onValueChange={setYear}>
          <SelectTrigger className="h-11 w-full sm:w-36" data-testid="accounts-year-select"><SelectValue /></SelectTrigger>
          <SelectContent>{["all", y + 1, y, y - 1, y - 2].map((v) => <SelectItem key={v} value={String(v)}>{v === "all" ? t("ledger.all") : v}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      {!canWrite(scope, committee) && <p className="text-xs text-muted-foreground mb-4" data-testid="accounts-readonly">{t("ledger.readOnly")}</p>}
      <div className="grid grid-cols-3 gap-3 sm:gap-5 mb-6">
        <StatCard label={t("ledger.income")} value={inr(totals.income)} testId="accounts-total-income" />
        <StatCard label={t("ledger.expense")} value={inr(totals.expense)} tone="red" testId="accounts-total-expense" delay={60} />
        <StatCard label={t("ledger.balance")} value={inr(totals.income - totals.expense)} tone="gold" testId="accounts-total-balance" delay={120} />
      </div>
      {rows === null ? <p className="text-muted-foreground">{t("common.loading")}</p> : forbidden ? <EmptyState text={t("ledger.forbidden")} testId="accounts-forbidden" /> : rows.length === 0 ? <EmptyState text={t("ledger.noBooks")} testId="accounts-empty" /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4" data-testid="books-grid">{rows.map((b) => <BookCard key={b.id} b={b} lang={lang} months={months} />)}</div>
      )}
      <BookForm open={formOpen} onOpenChange={setFormOpen} committee={committee} onSaved={load} />
    </div>
  );
}
