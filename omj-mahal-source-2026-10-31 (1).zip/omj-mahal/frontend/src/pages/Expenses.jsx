import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Download } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { inr, fmtDate, todayStr, currentMonth, downloadCsv } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete, TextField, SelectField, SubmitRow } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const CATS = ["salary", "electricity", "maintenance", "madrasa", "water", "other"];
const empty = { category: "other", amount: "", date: todayStr(), description: "", mode: "cash", paid_to: "" };

const ExpenseForm = ({ open, onOpenChange, expense, onSaved }) => {
  const { t } = useLang();
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) setForm(expense ? { ...empty, ...expense } : { ...empty, date: todayStr() }); }, [open, expense]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const payload = { category: form.category, amount: Number(form.amount), date: form.date, description: form.description, mode: form.mode, paid_to: form.paid_to };
      expense?.id ? await api.put(`/expenses/${expense.id}`, payload) : await api.post("/expenses", payload);
      toast.success(t("common.saved")); onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="expense-form-dialog">
        <DialogHeader><DialogTitle>{expense?.id ? t("expenses.edit") : t("expenses.add")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="grid grid-cols-2 gap-4">
          <SelectField label={t("expenses.category")} value={form.category} onChange={set("category")} testId="expense-category-select" options={CATS.map((c) => ({ value: c, label: t(`expenses.categories.${c}`) }))} />
          <TextField label={t("common.amount")} type="number" min="1" value={form.amount} onChange={set("amount")} required testId="expense-amount-input" />
          <TextField label={t("common.date")} type="date" value={form.date} onChange={set("date")} testId="expense-date-input" />
          <SelectField label={t("common.mode")} value={form.mode} onChange={set("mode")} testId="expense-mode-select" options={["cash", "upi", "bank"].map((m) => ({ value: m, label: t(`paymentModes.${m}`) }))} />
          <TextField label={t("expenses.paidTo")} value={form.paid_to} onChange={set("paid_to")} testId="expense-paidto-input" />
          <TextField label={t("common.description")} value={form.description} onChange={set("description")} testId="expense-description-input" />
          <div className="col-span-2"><SubmitRow loading={loading} onCancel={() => onOpenChange(false)} /></div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default function Expenses() {
  const { t } = useLang();
  const [params, setParams] = useSearchParams();
  const [rows, setRows] = useState([]);
  const [month, setMonth] = useState(currentMonth());
  const [cat, setCat] = useState("all");
  const [formOpen, setFormOpen] = useState(params.get("new") === "1");
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const load = useCallback(async () => {
    const { data } = await api.get("/expenses", { params: { month: month || undefined, category: cat !== "all" ? cat : undefined } });
    setRows(data);
  }, [month, cat]);
  useEffect(() => { load(); }, [load]);

  const total = rows.reduce((s, r) => s + r.amount, 0);
  const closeForm = (o) => { setFormOpen(o); if (!o && params.get("new")) setParams({}); };
  const remove = async () => { try { await api.delete(`/expenses/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load(); } catch (e) { toast.error(apiError(e)); } };
  const exportCsv = () => downloadCsv(`expenses-${month || "all"}.csv`, ["Date", "Category", "Paid To", "Description", "Mode", "Amount"], rows.map((r) => [r.date, r.category, r.paid_to, r.description, r.mode, r.amount]));

  return (
    <div data-testid="expenses-page">
      <PageHeader title={t("expenses.title")} subtitle={`${t("expenses.total")}: ${inr(total)}`} actions={<>
        <Button variant="outline" onClick={exportCsv} className="h-11" data-testid="expenses-export-button"><Download className="h-4 w-4 mr-2" />{t("common.export")}</Button>
        <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="h-11" data-testid="add-expense-button"><Plus className="h-4 w-4 mr-2" />{t("expenses.add")}</Button>
      </>} />
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="h-11 sm:w-52" data-testid="expenses-month-filter" />
        <SelectField label="" value={cat} onChange={setCat} testId="expenses-category-filter" className="sm:w-56 [&>label]:hidden" options={[{ value: "all", label: t("common.all") }, ...CATS.map((c) => ({ value: c, label: t(`expenses.categories.${c}`) }))]} />
        {month && <Button variant="ghost" onClick={() => setMonth("")} className="h-11" data-testid="expenses-month-clear">{t("common.all")}</Button>}
      </div>
      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        {rows.length === 0 ? <EmptyState text={t("expenses.noExpenses")} /> : (
          <Table data-testid="expenses-table">
            <TableHeader><TableRow className="bg-accent/60">
              <TableHead>{t("common.date")}</TableHead><TableHead>{t("expenses.category")}</TableHead><TableHead className="hidden md:table-cell">{t("expenses.paidTo")}</TableHead>
              <TableHead className="hidden sm:table-cell">{t("common.description")}</TableHead><TableHead className="text-right">{t("common.amount")}</TableHead><TableHead />
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id} data-testid={`expense-row-${r.id}`}>
                  <TableCell>{fmtDate(r.date)}</TableCell>
                  <TableCell><span className="rounded-full bg-accent px-2.5 py-0.5 text-xs font-semibold text-accent-foreground">{t(`expenses.categories.${r.category}`)}</span></TableCell>
                  <TableCell className="hidden md:table-cell">{r.paid_to}</TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground">{r.description}</TableCell>
                  <TableCell className="text-right font-semibold text-destructive">{inr(r.amount)}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setFormOpen(true); }} data-testid={`edit-expense-${r.id}`}><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" className="text-destructive" onClick={() => setDeleting(r)} data-testid={`delete-expense-${r.id}`}><Trash2 className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
      <ExpenseForm open={formOpen} onOpenChange={closeForm} expense={editing} onSaved={load} />
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
    </div>
  );
}
