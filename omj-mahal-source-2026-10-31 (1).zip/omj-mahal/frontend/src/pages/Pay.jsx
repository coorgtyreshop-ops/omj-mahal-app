import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { QrCode, ExternalLink, Wallet, Copy } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { useCached } from "@/lib/cache";
import { inr, monthLabel, fmtDate, fmtPhone } from "@/lib/format";
import { PageHeader, EmptyState, TextField, SelectField, SubmitRow, StatusBadge } from "@/components/shared";
import { useQr } from "@/components/MemberCard";
import { QrBlock } from "@/components/finance/QrPoster";
import { ReviewPendingCard } from "@/components/finance/ReleaseStatement";
import { fileUrl } from "@/lib/branding";
import { allTypes, typeLabel } from "@/components/forms/CollectionPaymentForm";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

const rateLabel = (t, c) => (c.kind === "monthly" ? `${inr(c.rate)} ${t("fin.perMonth")} · ${inr(c.yearly_total)} ${t("fin.perYear")}` : c.kind === "yearly" ? `${inr(c.rate)} ${t("fin.perYear")}` : c.kind === "one_time" ? `${t("fin.target")}: ${inr(c.rate)}` : t("fin.anyAmount"));

const GpayNumberBox = ({ phone }) => {
  const { t } = useLang();
  const copy = async () => { try { await navigator.clipboard.writeText(phone); toast.success(t("fin.gpay.copied")); } catch { toast.error(t("common.error")); } };
  return (
    <div className="rounded-xl border border-[#e6dbc9] bg-[#faf8f5] p-4" data-testid="gpay-number-box">
      <p className="text-xs text-muted-foreground">{t("fin.gpay.number")}</p>
      <div className="flex items-center justify-between gap-2 mt-1">
        <span className="text-2xl font-bold font-mono tracking-wide" data-testid="gpay-number">{fmtPhone(phone)}</span>
        <Button type="button" size="sm" variant="outline" className="h-9" onClick={copy} data-testid="gpay-copy-button"><Copy className="h-4 w-4 mr-1" />{t("fin.gpay.copy")}</Button>
      </div>
      <p className="text-xs text-muted-foreground mt-2">{t("fin.gpay.payTo")}</p>
    </div>
  );
};

const PayDialog = ({ type, col, upiConfigured, gpayPhone, qrUrl, bank, onClose, onDone }) => {
  const { t } = useLang();
  const [amount, setAmount] = useState(type === "donation" ? "" : String(col?.pending || ""));
  const [ref, setRef] = useState("");
  const [note, setNote] = useState("");
  const [funds, setFunds] = useState([]);
  const [fundId, setFundId] = useState("");
  const [upi, setUpi] = useState(null);
  const [loading, setLoading] = useState(false);
  const [attempt, setAttempt] = useState(null);
  const qr = useQr(upi?.link || "");

  useEffect(() => { if (type === "donation") api.get("/funds").then((r) => { setFunds(r.data); if (r.data[0]) setFundId(r.data[0].id); }); }, [type]);
  useEffect(() => {
    const amt = Number(amount);
    if (!upiConfigured || !amt || amt <= 0) return setUpi(null);
    const id = setTimeout(() => api.get("/finance/upi-link", { params: { amount: amt, note: type } }).then((r) => setUpi(r.data)).catch(() => setUpi(null)), 300);
    return () => clearTimeout(id);
  }, [amount, type, upiConfigured, t]);
  // The QR carries this member's amount; record the attempt so the committee sees "who · which head · how much · when" even before the reference is typed.
  const recordAttempt = useCallback(async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0 || (!upiConfigured && !qrUrl)) return;
    try { const { data } = await api.post("/finance/pay-requests", { type, amount: amt, stage: "started", fund_id: fundId || null }); setAttempt(data); onDone?.(); } catch { /* silent */ }
  }, [amount, type, upiConfigured, qrUrl, fundId, onDone]);
  useEffect(() => { const id = setTimeout(recordAttempt, 6000); return () => clearTimeout(id); }, [recordAttempt]);

  const submit = async (e) => {
    e.preventDefault();
    if (!Number(amount) || Number(amount) <= 0) return toast.error(t("fin.amount"));
    setLoading(true);
    try {
      const periods = col?.kind === "monthly" ? { months: col.pending_periods.slice(0, Math.floor(Number(amount) / (col.rate || 1))) } : col?.kind === "yearly" ? { years: col.pending_periods.slice(0, Math.floor(Number(amount) / (col.rate || 1))) } : {};
      const payload = { type, amount: Number(amount), upi_ref: ref, note, fund_id: fundId || null, ...periods };
      if (attempt?.id) await api.put(`/finance/pay-requests/${attempt.id}`, payload); else await api.post("/finance/pay-requests", payload);
      toast.success(t("fin.submitted")); onDone(); onClose();
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md max-h-[92vh] overflow-y-auto" data-testid="pay-dialog">
        <DialogHeader><DialogTitle>{t("fin.payNow")} · {t(`fin.types.${type}`)}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          {col && col.pending > 0 && <p className="text-sm rounded-lg bg-[#c58b2b]/10 text-[#a06f1c] px-3 py-2">{t("fin.pending")}: <b>{inr(col.pending)}</b></p>}
          {type === "donation" && <SelectField label={t("fin.fund")} value={fundId} onChange={setFundId} testId="pay-fund-select" placeholder={t("fin.selectFund")} options={funds.map((f) => ({ value: f.id, label: f.name }))} />}
          <TextField label={t("fin.amount")} type="number" min="1" value={amount} onChange={setAmount} required testId="pay-amount-input" />
          {upiConfigured ? (
            <div className="rounded-xl border border-[#e6dbc9] bg-[#faf8f5] p-4 text-center" data-testid="upi-qr-box">
              {qr ? <img src={qr} alt="UPI QR" className="mx-auto h-44 w-44" data-testid="upi-qr-image" /> : <div className="mx-auto h-44 w-44 grid place-items-center text-muted-foreground"><QrCode className="h-10 w-10" /></div>}
              <p className="text-sm font-medium mt-2">{t("fin.scanPay")}</p>
              {upi && <p className="text-xs text-muted-foreground">{upi.upi_name} · <span className="font-mono">{upi.upi_id}</span></p>}
              {upi && <a href={upi.link} onClick={recordAttempt} className="inline-flex items-center gap-1 mt-2 text-sm text-primary font-semibold" data-testid="open-upi-app-link"><ExternalLink className="h-4 w-4" />{t("fin.openUpi")}</a>}
            </div>
          ) : qrUrl ? (
            <div className="rounded-xl border border-[#e6dbc9] bg-[#faf8f5] p-4 text-center" data-testid="upi-qr-image-box">
              <img src={fileUrl(qrUrl)} alt="UPI QR" className="mx-auto h-48 w-48 object-contain rounded bg-white" data-testid="upi-qr-uploaded-image" />
              <p className="text-sm font-medium mt-2">{t("fin.scanPay")}</p>
              <p className="text-xs text-muted-foreground">{t("fin.qr.imageOnly")}{gpayPhone && <> · {t("fin.gpay.number")}: <b className="font-mono">{fmtPhone(gpayPhone)}</b></>}</p>
            </div>
          ) : gpayPhone ? <GpayNumberBox phone={gpayPhone} /> : <p className="text-sm text-muted-foreground rounded-lg bg-accent px-3 py-2" data-testid="no-upi-note">{t("fin.noUpi")}</p>}
          {bank && (
            <div className="rounded-lg border border-[#e6dbc9] px-3 py-2 text-xs space-y-0.5" data-testid="bank-details-box">
              <p className="font-semibold text-sm">{t("fin.bank.title")}</p>
              {bank.bank_name && <p>{t("fin.bank.bank_name")}: <b>{bank.bank_name}</b></p>}
              {bank.bank_account_name && <p>{t("fin.bank.bank_account_name")}: <b>{bank.bank_account_name}</b></p>}
              <p>{t("fin.bank.bank_account_no")}: <b className="font-mono">{bank.bank_account_no}</b></p>
              {bank.bank_ifsc && <p>IFSC: <b className="font-mono">{bank.bank_ifsc}</b></p>}
            </div>
          )}
          <TextField label={t("fin.upiRef")} value={ref} onChange={setRef} placeholder="1234 5678 9012" testId="pay-upi-ref-input" />
          <TextField label={t("common.note")} value={note} onChange={setNote} testId="pay-note-input" />
          {attempt && <p className="text-xs rounded-lg bg-[#0d5c3a]/10 text-[#0d5c3a] px-3 py-2" data-testid="attempt-recorded-note">{t("fin.attemptNoted", { house: attempt.house_no, name: attempt.head_name, amount: inr(attempt.amount) })}</p>}
          <p className="text-xs text-muted-foreground">{t("fin.requestHint")}</p>
          <SubmitRow loading={loading} onCancel={onClose} label={t("fin.submit")} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default function Pay() {
  const { t, months } = useLang();
  const { user, settings } = useAuth();
  const [paying, setPaying] = useState(null);
  const fetchPay = useCallback(async () => {
    const [s, r] = await Promise.all([api.get(`/finance/house/${user.house_id}/summary`), api.get("/finance/pay-requests")]);
    return { summary: s.data, requests: r.data };
  }, [user.house_id]);
  const { data, reload: load } = useCached(user.house_id ? `pay:${user.house_id}:${user.id}` : null, fetchPay);
  const summary = data?.summary;
  const requests = data?.requests || [];

  if (!user.house_id) return <div data-testid="pay-page"><PageHeader title={t("fin.payNav")} /><EmptyState text={t("donations.noHouse")} /></div>;
  if (!summary) return <div data-testid="pay-page" className="text-muted-foreground p-6">{t("common.loading")}</div>;
  if (summary.released === false) return <div data-testid="pay-page"><PageHeader title={t("fin.payNav")} subtitle={`${t("houses.houseNo")} ${summary.house.house_no} · ${summary.house.head_name}`} /><ReviewPendingCard /></div>;
  const c = summary.collections;
  const visible = allTypes(settings).filter((k) => k === "varisankhya" || k === "donation" || (c[k]?.rate || 0) > 0);
  const label = (k) => typeLabel(t, k, settings);

  return (
    <div data-testid="pay-page">
      <PageHeader title={t("fin.mySummary")} subtitle={summary.member ? `${t("houses.houseNo")} ${summary.house.house_no} · ${summary.member.name} (${summary.member.member_no}) — ${t("mtype.sub")} · ${t("fin.ownShare")}` : `${t("houses.houseNo")} ${summary.house.house_no} · ${summary.house.head_name}`} />
      <div className={cn("rounded-2xl p-5 mb-6 text-white shadow-lg", c.total_pending > 0 ? "bg-[#a06f1c]" : "bg-primary")} data-testid="total-pending-banner">
        <p className="text-sm opacity-90 flex items-center gap-2"><Wallet className="h-4 w-4" />{t("fin.totalPending")}</p>
        <p className="text-4xl font-bold mt-1" data-testid="total-pending-amount">{inr(c.total_pending)}</p>
        {c.total_pending === 0 && <p className="text-sm mt-1 opacity-90">{t("fin.noDue")}</p>}
        {c.members?.sub > 0 && <p className="text-xs mt-2 opacity-90" data-testid="pay-units">{t("fin.units", { n: c.members.sub, u: c.members.units })}</p>}
      </div>

      {(summary.upi_configured || summary.upi_qr_url) && (
        <div className="rounded-2xl border border-[#d4af37]/60 bg-[#d4af37]/[0.06] p-5 mb-6 shadow-sm" data-testid="pay-qr-card">
          <p className="font-bold flex items-center gap-2 mb-3"><QrCode className="h-5 w-5 text-primary" />{t("fin.qr.scanTitle")}</p>
          <QrBlock upiId={summary.upi_id} upiName={summary.upi_name} qrUrl={summary.upi_qr_url} gpayPhone={summary.upi_phone} bank={summary.bank} />
          <p className="text-xs text-muted-foreground mt-3">{t("fin.qr.scanHint")}</p>
          <Button className="mt-3 h-11 w-full sm:w-auto" onClick={() => setPaying(Object.keys(c).find((k) => c[k]?.pending > 0) || "donation")} data-testid="i-have-paid-button"><Wallet className="h-4 w-4 mr-2" />{t("fin.qr.paidTell")}</Button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {visible.map((k, i) => {
          const col = c[k];
          return (
            <div key={k} className="stat-in rounded-xl border border-[#e6dbc9] bg-card p-4 shadow-sm" style={{ animationDelay: `${i * 60}ms` }} data-testid={`collection-card-${k}`}>
              <div className="flex items-start justify-between gap-3">
                <div><p className="font-bold">{label(k)}</p><p className="text-xs text-muted-foreground">{(k === "old_balance" || k === "auction") && col.note ? col.note : rateLabel(t, col)}</p></div>
                <Button size="sm" onClick={() => setPaying(k)} disabled={k !== "donation" && col.pending <= 0} className="h-10" data-testid={`pay-${k}-button`}><QrCode className="h-4 w-4 mr-1" />{t("fin.payNow")}</Button>
              </div>
              {k !== "donation" && (
                <div className="grid grid-cols-3 gap-2 mt-3 text-center text-sm">
                  <div className="rounded-lg bg-accent py-2"><p className="text-[11px] text-muted-foreground">{t("fin.expected")}</p><p className="font-semibold">{inr(col.due)}</p></div>
                  <div className="rounded-lg bg-primary/10 py-2"><p className="text-[11px] text-muted-foreground">{t("fin.paid")}</p><p className="font-semibold text-primary">{inr(col.paid)}</p></div>
                  <div className="rounded-lg bg-[#c58b2b]/10 py-2"><p className="text-[11px] text-muted-foreground">{t("fin.pending")}</p><p className="font-semibold text-[#a06f1c]" data-testid={`pending-${k}`}>{inr(col.pending)}</p></div>
                </div>
              )}
              {k === "donation" && <p className="mt-3 text-sm">{t("fin.paid")}: <b className="text-primary">{inr(col.paid)}</b></p>}
              {col.pending_periods?.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-3">{col.pending_periods.map((p) => <span key={p} className="rounded-full bg-[#c58b2b]/10 text-[#a06f1c] px-2 py-0.5 text-[11px] font-semibold">{k === "varisankhya" ? monthLabel(p, months, true) : p}</span>)}</div>
              )}
            </div>
          );
        })}
      </div>

      <h2 className="font-bold mb-3">{t("fin.myRequests")}</h2>
      {requests.length === 0 ? <EmptyState text={t("fin.noRequests")} testId="requests-empty" /> : (
        <div className="space-y-2" data-testid="my-requests-list">
          {requests.map((r) => (
            <div key={r.id} className="rounded-xl border border-[#e6dbc9] bg-card px-4 py-3 flex items-center justify-between gap-3" data-testid={`my-request-${r.id}`}>
              <div className="min-w-0"><p className="font-medium">{label(r.type)} · {inr(r.amount)}</p><p className="text-xs text-muted-foreground">{fmtDate(r.created_at.slice(0, 10))}{r.upi_ref && ` · ${r.upi_ref}`}{r.receipt_no && ` · ${t("common.receiptNo")} ${r.receipt_no}`}{r.reason && ` · ${r.reason}`}</p></div>
              <StatusBadge ok={r.status === "approved"}>{t(r.status === "pending" ? "fin.pendingStatus" : `fin.${r.status}`)}</StatusBadge>
            </div>
          ))}
        </div>
      )}
      {paying && <PayDialog type={paying} col={c[paying]} upiConfigured={summary.upi_configured} gpayPhone={summary.upi_phone} qrUrl={summary.upi_qr_url} bank={summary.bank} onClose={() => setPaying(null)} onDone={load} />}
    </div>
  );
}
