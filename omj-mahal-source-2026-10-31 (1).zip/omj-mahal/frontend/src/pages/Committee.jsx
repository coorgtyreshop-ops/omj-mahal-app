import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Phone, UserRound, KeyRound } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete, TextField, SelectField, SubmitRow } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const DESIGS = ["President", "Vice President", "Secretary", "Joint Secretary", "Treasurer", "Executive Member", "Imam", "Other"];
const empty = { name: "", designation: "Executive Member", phone: "", term_start: "", term_end: "", order: 0, create_login: true };

const CommitteeForm = ({ open, onOpenChange, item, onSaved }) => {
  const { t } = useLang();
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) setForm(item ? { ...empty, ...item } : empty); }, [open, item]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const payload = { name: form.name, designation: form.designation, phone: form.phone, term_start: form.term_start, term_end: form.term_end, order: Number(form.order || 0), create_login: !item?.id && !!form.create_login && !!form.phone };
      const { data } = item?.id ? await api.put(`/committee/${item.id}`, payload) : await api.post("/committee", payload);
      if (data?.login) toast.success(t("committee.loginSent", { phone: form.phone, password: data.login.password }), { duration: 12000 });
      else toast.success(t("common.saved"));
      onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="committee-form-dialog">
        <DialogHeader><DialogTitle>{item?.id ? t("committee.edit") : t("committee.add")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="grid grid-cols-2 gap-4">
          <TextField label={t("committee.name")} value={form.name} onChange={set("name")} required testId="committee-name-input" className="col-span-2" />
          <SelectField label={t("committee.designation")} value={form.designation} onChange={set("designation")} testId="committee-designation-select" options={DESIGS.map((d) => ({ value: d, label: t(`committee.designations.${d}`) }))} />
          <TextField label={t("committee.phone")} value={form.phone} onChange={set("phone")} testId="committee-phone-input" inputMode="tel" />
          <TextField label={t("committee.termStart")} type="date" value={form.term_start} onChange={set("term_start")} testId="committee-term-start-input" />
          <TextField label={t("committee.termEnd")} type="date" value={form.term_end} onChange={set("term_end")} testId="committee-term-end-input" />
          <TextField label={t("committee.order")} type="number" value={form.order} onChange={set("order")} testId="committee-order-input" />
          {!item?.id && <div className="col-span-2 flex items-center justify-between rounded-lg border p-3"><Label className="text-sm">{t("committee.createLogin")}</Label><Switch checked={!!form.create_login} onCheckedChange={set("create_login")} disabled={!form.phone} data-testid="committee-create-login-switch" /></div>}
          <div className="col-span-2"><SubmitRow loading={loading} onCancel={() => onOpenChange(false)} /></div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export const CommitteeCard = ({ c, i = 0, onEdit, onDelete, onSendLogin }) => {
  const { t } = useLang();
  return (
    <div className="stat-in relative rounded-xl border border-[#e6dbc9] bg-card p-5 shadow-sm hover:shadow-md transition-shadow overflow-hidden" style={{ animationDelay: `${i * 50}ms` }} data-testid={`committee-card-${c.id}`}>
      <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-[#0d5c3a] via-[#d4af37] to-[#0d5c3a]" />
      <div className="flex items-center gap-4">
        <span className="grid h-14 w-14 place-items-center rounded-full bg-primary/10 text-primary"><UserRound className="h-7 w-7" /></span>
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-bold uppercase tracking-[0.15em] text-[#8a6d1d]">{t(`committee.designations.${c.designation}`) || c.designation}</p>
          <h3 className="font-bold text-lg leading-tight truncate">{c.name}</h3>
          {c.phone && <a href={`tel:${c.phone}`} className="inline-flex items-center gap-1 text-sm text-primary mt-1 hover:underline" data-testid={`call-committee-${c.id}`}><Phone className="h-3.5 w-3.5" />{c.phone}</a>}
        </div>
      </div>
      {(onEdit || onDelete) && (
        <div className="mt-4 flex justify-end gap-1">
          {onSendLogin && c.phone && <Button size="sm" variant="outline" className="h-9 text-xs" onClick={() => onSendLogin(c)} data-testid={`send-login-committee-${c.id}`}><KeyRound className="h-3.5 w-3.5 mr-1" />{c.user_id ? t("committee.resendLogin") : t("committee.sendLogin")}</Button>}
          <Button size="icon" variant="ghost" onClick={() => onEdit(c)} data-testid={`edit-committee-${c.id}`}><Pencil className="h-4 w-4" /></Button>
          <Button size="icon" variant="ghost" className="text-destructive" onClick={() => onDelete(c)} data-testid={`delete-committee-${c.id}`}><Trash2 className="h-4 w-4" /></Button>
        </div>
      )}
    </div>
  );
};

export default function Committee() {
  const { t } = useLang();
  const { isAdmin } = useAuth();
  const [rows, setRows] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const load = useCallback(async () => { const { data } = await api.get("/committee"); setRows(data); }, []);
  useEffect(() => { load(); }, [load]);
  const sendLogin = async (c) => { try { const { data } = await api.post(`/committee/${c.id}/login`); toast.success(t("committee.loginSent", { phone: c.phone, password: data.password }), { duration: 12000 }); load(); } catch (e) { toast.error(apiError(e)); } };
  const remove = async () => { try { await api.delete(`/committee/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load(); } catch (e) { toast.error(apiError(e)); } };

  return (
    <div data-testid="committee-page">
      <PageHeader title={t("committee.title")} subtitle={rows[0]?.term_start ? `${t("committee.term")}: ${fmtDate(rows[0].term_start)} – ${fmtDate(rows[0].term_end)}` : undefined}
        actions={isAdmin && <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="h-11" data-testid="add-committee-button"><Plus className="h-4 w-4 mr-2" />{t("committee.add")}</Button>} />
      {rows.length === 0 ? <EmptyState text={t("committee.noCommittee")} /> : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="committee-grid">
          {rows.map((c, i) => <CommitteeCard key={c.id} c={c} i={i} onEdit={isAdmin ? (x) => { setEditing(x); setFormOpen(true); } : undefined} onDelete={isAdmin ? setDeleting : undefined} onSendLogin={isAdmin ? sendLogin : undefined} />)}
        </div>
      )}
      {isAdmin && <CommitteeForm open={formOpen} onOpenChange={setFormOpen} item={editing} onSaved={load} />}
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
    </div>
  );
}
