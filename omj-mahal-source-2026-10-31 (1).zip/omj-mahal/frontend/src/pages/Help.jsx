import { useState } from "react";
import { Link } from "react-router-dom";
import { Printer, ArrowLeft, Smartphone, HelpCircle, UserCog, Users, ChevronDown, Moon } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { helpContent } from "@/i18n/help";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { PrintDialog } from "@/components/print/Printables";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { logoSrc, mahalName } from "@/lib/branding";

const StepCard = ({ index, section }) => (
  <div className="rounded-xl border border-[#e6dbc9] bg-card p-4 sm:p-5 shadow-sm" data-testid={`help-section-${index}`}>
    <div className="flex items-center gap-3 mb-3">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground font-bold">{index + 1}</span>
      <h3 className="font-bold text-base sm:text-lg">{section.title}</h3>
    </div>
    <ol className="space-y-2 pl-1">
      {section.steps.map((s, i) => (
        <li key={i} className="flex gap-3 text-sm sm:text-[15px] leading-relaxed">
          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#d4af37]" />
          <span>{s}</span>
        </li>
      ))}
    </ol>
  </div>
);

const Faq = ({ items }) => {
  const [open, setOpen] = useState(0);
  return (
    <div className="space-y-2" data-testid="help-faq">
      {items.map((f, i) => (
        <div key={i} className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
          <button onClick={() => setOpen(open === i ? -1 : i)} className="w-full flex items-center justify-between gap-3 p-4 text-left font-semibold hover:bg-accent/50" data-testid={`faq-q-${i}`}>
            <span>{f.q}</span><ChevronDown className={cn("h-5 w-5 shrink-0 text-primary transition-transform", open === i && "rotate-180")} />
          </button>
          {open === i && <p className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed" data-testid={`faq-a-${i}`}>{f.a}</p>}
        </div>
      ))}
    </div>
  );
};

const PrintGuide = ({ c, t, settings, lang }) => (
  <div className="bg-white text-[#1e2923] p-6 max-w-[800px] mx-auto text-[13px] leading-relaxed">
    <div className="flex items-center gap-3 border-b-2 border-[#d4af37] pb-3 mb-4">
      <img src={logoSrc(settings)} alt="" className="h-12 w-12 rounded-full object-cover" />
      <div><h2 className="text-lg font-bold text-[#0d5c3a]">{mahalName(settings, lang)}</h2><p className="text-xs text-gray-600">{t("help.title")} — Mahal App</p></div>
    </div>
    <div className="grid grid-cols-2 gap-5">
      <div>
        <h3 className="font-bold text-[#0d5c3a] border-b mb-2">{t("help.forAdmin")}</h3>
        {c.admin.map((s, i) => <p key={i} className="mb-1.5"><b>{i + 1}. {s.title}:</b> {s.steps.join(" ")}</p>)}
      </div>
      <div>
        <h3 className="font-bold text-[#0d5c3a] border-b mb-2">{t("help.forMember")}</h3>
        {c.member.map((s, i) => <p key={i} className="mb-1.5"><b>{i + 1}. {s.title}:</b> {s.steps.join(" ")}</p>)}
        <h3 className="font-bold text-[#0d5c3a] border-b mb-2 mt-4">{t("help.install")}</h3>
        <p className="mb-1"><b>{t("help.android")}:</b> {c.install.android.join(" ")}</p>
        <p><b>{t("help.iphone")}:</b> {c.install.ios.join(" ")}</p>
        <h3 className="font-bold text-[#0d5c3a] border-b mb-2 mt-4">{t("help.faq")}</h3>
        {c.faq.slice(0, 3).map((f, i) => <p key={i} className="mb-1"><b>{f.q}</b> {f.a}</p>)}
      </div>
    </div>
  </div>
);

export default function Help({ standalone = false }) {
  const { t, lang } = useLang();
  const { settings } = useAuth();
  const c = helpContent[lang] || helpContent.en;
  const [printOpen, setPrintOpen] = useState(false);

  const body = (
    <div data-testid="help-page">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2"><HelpCircle className="h-7 w-7 text-primary" />{t("help.title")}</h1>
          <p className="text-muted-foreground mt-2 max-w-2xl text-sm sm:text-base">{c.intro}</p>
        </div>
        <Button onClick={() => setPrintOpen(true)} variant="outline" className="h-11" data-testid="help-print-button"><Printer className="h-4 w-4 mr-2" />{t("help.printGuide")}</Button>
      </div>

      <Tabs defaultValue="admin">
        <TabsList className="h-12 mb-5 flex-wrap">
          <TabsTrigger value="admin" className="h-10 px-4" data-testid="help-tab-admin"><UserCog className="h-4 w-4 mr-2" />{t("help.forAdmin")}</TabsTrigger>
          <TabsTrigger value="member" className="h-10 px-4" data-testid="help-tab-member"><Users className="h-4 w-4 mr-2" />{t("help.forMember")}</TabsTrigger>
          <TabsTrigger value="install" className="h-10 px-4" data-testid="help-tab-install"><Smartphone className="h-4 w-4 mr-2" />{t("help.install")}</TabsTrigger>
          <TabsTrigger value="faq" className="h-10 px-4" data-testid="help-tab-faq"><HelpCircle className="h-4 w-4 mr-2" />{t("help.faq")}</TabsTrigger>
        </TabsList>
        <TabsContent value="admin"><div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{c.admin.map((s, i) => <StepCard key={i} index={i} section={s} />)}</div></TabsContent>
        <TabsContent value="member"><div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{c.member.map((s, i) => <StepCard key={i} index={i} section={s} />)}</div></TabsContent>
        <TabsContent value="install">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4" data-testid="help-install">
            <StepCard index={0} section={{ title: t("help.android"), steps: c.install.android }} />
            <StepCard index={1} section={{ title: t("help.iphone"), steps: c.install.ios }} />
          </div>
        </TabsContent>
        <TabsContent value="faq"><Faq items={c.faq} /></TabsContent>
      </Tabs>

      <PrintDialog open={printOpen} onOpenChange={setPrintOpen} title={t("help.printGuide")} testId="help-print-dialog">
        <PrintGuide c={c} t={t} settings={settings} lang={lang} />
      </PrintDialog>
    </div>
  );

  if (!standalone) return body;
  return (
    <div className="min-h-screen bg-background">
      <header className="islamic-pattern text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          <Link to="/login" className="flex items-center gap-2 font-bold" data-testid="help-back-login">
            <span className="h-9 w-9 rounded-lg bg-[#d4af37] text-[#0d5c3a] grid place-items-center overflow-hidden">{settings?.logo_url || settings?.logo_preset ? <img src={logoSrc(settings)} alt="" className="h-full w-full object-cover" /> : <Moon className="h-4 w-4" />}</span>
            <span className="truncate">{mahalName(settings, lang)}</span>
          </Link>
          <div className="flex items-center gap-2">
            <LanguageSwitcher dark />
            <Button asChild variant="secondary" size="sm" className="h-9"><Link to="/login"><ArrowLeft className="h-4 w-4 mr-1" />{t("help.backToLogin")}</Link></Button>
          </div>
        </div>
      </header>
      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8">{body}</main>
    </div>
  );
}
