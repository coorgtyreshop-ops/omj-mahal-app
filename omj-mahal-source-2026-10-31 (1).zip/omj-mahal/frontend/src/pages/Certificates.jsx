import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Printer, Trash2, ScrollText } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete, TextField, SelectField, SubmitRow } from "@/components/shared";
import { PrintDialog, CertificateBody } from "@/components/print/Printables";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const TYPES = ["membership", "nikah", "death", "birth"];
const FIELDS = {
  membership: ["name", "father_name", "house_no", "address", "member_since", "purpose"],
  nikah: ["groom_name", "groom_father", "groom_address", "bride_name", "bride_father", "bride_address", "nikah_date", "nikah_place", "mahr", "wali", "witness1", "witness2", "qazi"],
  death: ["deceased_name", "age", "house_no", "address", "death_date", "death_place", "burial_place", "relative_name"],
  birth: ["child_name", "gender", "birth_date", "birth_place", "father_name", "mother_name", "house_no", "address"],
};
const DATE_FIELDS = ["nikah_date", "death_date", "birth_date"];

const CertForm = ({ open, onOpenChange, houses, onSaved }) => {
  const { t } = useLang();
  const [type, setType] = useState("membership");
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) { setType("membership"); setData({}); } }, [open]);
  const set = (k) => (v) => setData((d) => ({ ...d, [k]: v }));
  const pickHouse = (hid) => {
    const h = houses.find((x) => x.id === hid);
    if (h) setData((d) => ({ ...d, house_no: h.house_no, address: `${h.address}${h.ward ? ", " + h.ward : ""}`, name: d.name || h.head_name }));
  };
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const { data: cert } = await api.post("/certificates", { type, data });
      toast.success(t("certs.created")); onSaved(cert); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl max-h-[92vh] overflow-y-auto" data-testid="certificate-form-dialog">
        <DialogHeader><DialogTitle>{t("certs.issue")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <SelectField label={t("certs.type")} value={type} onChange={(v) => { setType(v); setData({}); }} testId="certificate-type-select" options={TYPES.map((x) => ({ value: x, label: t(`certs.types.${x}`) }))} />
            {FIELDS[type].includes("house_no") && <SelectField label={t("members.house")} value="" onChange={pickHouse} testId="certificate-house-select" placeholder={t("members.selectHouse")} options={houses.map((h) => ({ value: h.id, label: `${h.house_no} — ${h.head_name}` }))} />}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {FIELDS[type].map((f) => f === "gender" ? (
              <SelectField key={f} label={t(`certs.fields.${f}`)} value={data[f] || ""} onChange={set(f)} testId={`cert-field-${f}`} options={[{ value: t("members.male"), label: t("members.male") }, { value: t("members.female"), label: t("members.female") }]} />
            ) : (
              <TextField key={f} label={t(`certs.fields.${f}`)} type={DATE_FIELDS.includes(f) ? "date" : "text"} value={data[f] || ""} onChange={set(f)} testId={`cert-field-${f}`} className={["address", "groom_address", "bride_address", "purpose"].includes(f) ? "sm:col-span-2" : ""} />
            ))}
          </div>
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} label={t("certs.issue")} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default function Certificates() {
  const { t } = useLang();
  const { settings } = useAuth();
  const [rows, setRows] = useState([]);
  const [houses, setHouses] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [viewing, setViewing] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const load = useCallback(async () => { const { data } = await api.get("/certificates"); setRows(data); }, []);
  useEffect(() => { load(); api.get("/houses").then((r) => setHouses(r.data)); }, [load]);
  const remove = async () => { try { await api.delete(`/certificates/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load(); } catch (e) { toast.error(apiError(e)); } };
  const certTitle = (c) => c.data?.name || c.data?.groom_name || c.data?.deceased_name || c.data?.child_name || "";

  return (
    <div data-testid="certificates-page">
      <PageHeader title={t("certs.title")} actions={<Button onClick={() => setFormOpen(true)} className="h-11" data-testid="issue-certificate-button"><Plus className="h-4 w-4 mr-2" />{t("certs.issue")}</Button>} />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {TYPES.map((x) => (
          <button key={x} onClick={() => setFormOpen(true)} className="rounded-xl border border-[#e6dbc9] bg-card p-4 text-left shadow-sm hover:border-primary/40 hover:shadow-md transition-all" data-testid={`cert-type-card-${x}`}>
            <ScrollText className="h-6 w-6 text-[#8a6d1d] mb-2" />
            <p className="font-semibold text-sm leading-snug">{t(`certs.types.${x}`)}</p>
            <p className="text-xs text-muted-foreground mt-1">{rows.filter((r) => r.type === x).length} {t("certs.issued").toLowerCase()}</p>
          </button>
        ))}
      </div>
      <h2 className="text-lg font-bold mb-3">{t("certs.issued")}</h2>
      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        {rows.length === 0 ? <EmptyState text={t("certs.noCerts")} /> : (
          <Table data-testid="certificates-table">
            <TableHeader><TableRow className="bg-accent/60"><TableHead>{t("certs.certNo")}</TableHead><TableHead>{t("certs.type")}</TableHead><TableHead>{t("common.name")}</TableHead><TableHead className="hidden sm:table-cell">{t("certs.issuedOn")}</TableHead><TableHead /></TableRow></TableHeader>
            <TableBody>
              {rows.map((c) => (
                <TableRow key={c.id} data-testid={`certificate-row-${c.cert_no}`}>
                  <TableCell className="font-mono text-xs">{c.cert_no}</TableCell>
                  <TableCell><span className="rounded-full bg-accent px-2.5 py-0.5 text-xs font-semibold">{t(`certs.types.${c.type}`)}</span></TableCell>
                  <TableCell className="font-medium">{certTitle(c)}</TableCell>
                  <TableCell className="hidden sm:table-cell">{fmtDate(c.issued_on)}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    <Button size="icon" variant="ghost" onClick={() => setViewing(c)} data-testid={`print-certificate-${c.cert_no}`}><Printer className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" className="text-destructive" onClick={() => setDeleting(c)} data-testid={`delete-certificate-${c.cert_no}`}><Trash2 className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
      <CertForm open={formOpen} onOpenChange={setFormOpen} houses={houses} onSaved={(c) => { load(); setViewing(c); }} />
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
      <PrintDialog open={!!viewing} onOpenChange={(o) => !o && setViewing(null)} title={viewing ? t(`certs.types.${viewing.type}`) : ""} testId="certificate-dialog">
        {viewing && <CertificateBody cert={viewing} settings={settings} />}
      </PrintDialog>
    </div>
  );
}
