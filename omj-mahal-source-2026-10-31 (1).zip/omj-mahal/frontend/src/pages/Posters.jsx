import { useState } from "react";
import { CalendarDays, Clock, MapPin, Download, Share2, Info } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { fmtDate } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { PosterViewer, eventTitle, usePosterActions } from "@/components/events/PosterViewer";
import { useDisplayItems, useBadge } from "@/components/events/PosterShowcase";

const BASE = process.env.REACT_APP_BACKEND_URL;

const PosterCard = ({ ev, onOpen }) => {
  const { t, lang } = useLang();
  const badgeFor = useBadge();
  const title = eventTitle(ev, lang);
  const { download, share, busy, url } = usePosterActions(ev, title);
  return (
    <article className="rounded-2xl overflow-hidden shadow-lg text-white flex flex-col" style={{ background: "linear-gradient(160deg,#0d5c3a 0%,#083d27 70%,#1e2923 100%)" }} data-testid={`poster-card-${ev.id}`}>
      <button type="button" onClick={onOpen} className="relative bg-black/30 block w-full">
        {url ? <img src={url} alt={title} className="w-full max-h-[80vh] object-contain" /> : <div className="h-56 grid place-items-center text-xl font-bold px-6 text-center">{title}</div>}
        <span className="absolute left-3 top-3 rounded-full bg-[#d4af37] text-[#1e2923] px-3 py-1 text-xs font-bold uppercase tracking-wide shadow">{badgeFor(ev.date)}</span>
      </button>
      <div className="p-4 space-y-2 flex-1 flex flex-col">
        <h3 className="text-lg font-bold leading-tight">{title}</h3>
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-white/90">
          <span className="inline-flex items-center gap-1"><CalendarDays className="h-4 w-4 text-[#d4af37]" />{fmtDate(ev.date)}</span>
          {ev.time && <span className="inline-flex items-center gap-1"><Clock className="h-4 w-4 text-[#d4af37]" />{ev.time}</span>}
          {ev.venue && <span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4 text-[#d4af37]" />{ev.venue}</span>}
        </div>
        <div className="mt-auto pt-2 grid grid-cols-3 gap-2">
          <Button size="sm" onClick={onOpen} variant="outline" className="h-10 border-white/30 bg-white/5 text-white hover:bg-white/15" data-testid={`poster-details-${ev.id}`}><Info className="h-4 w-4 mr-1" />{t("posters.details")}</Button>
          <Button size="sm" onClick={download} disabled={!url || busy} className="h-10 bg-[#d4af37] text-[#1e2923] hover:bg-[#e2c053]" data-testid={`poster-download-${ev.id}`}><Download className="h-4 w-4 mr-1" />{t("common.download") || "Download"}</Button>
          <Button size="sm" onClick={share} disabled={busy} variant="outline" className="h-10 border-white/30 bg-white/5 text-white hover:bg-white/15" data-testid={`poster-share-${ev.id}`}><Share2 className="h-4 w-4 mr-1" />{t("posters.share")}</Button>
        </div>
      </div>
    </article>
  );
};

export default function Posters() {
  const { t } = useLang();
  const items = useDisplayItems();
  const [open, setOpen] = useState(null);
  return (
    <div data-testid="posters-page">
      <PageHeader title={t("posters.title")} subtitle={t("posters.untilDone")} />
      {items.length === 0 ? <EmptyState text={t("posters.none")} testId="posters-empty" /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5" data-testid="posters-grid">
          {items.map((ev) => <PosterCard key={ev.id} ev={ev} onOpen={() => setOpen(ev)} />)}
        </div>
      )}
      <PosterViewer ev={open} onClose={() => setOpen(null)} />
    </div>
  );
}
