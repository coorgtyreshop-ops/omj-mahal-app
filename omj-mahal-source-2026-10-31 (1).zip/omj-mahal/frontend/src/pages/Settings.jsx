import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { PageHeader, TextField, SelectField, SubmitRow } from "@/components/shared";
import { Switch } from "@/components/ui/switch";
import { LogoPicker } from "@/components/LogoPicker";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { QrCode, Landmark, ImageUp } from "lucide-react";
import { FeesDialog } from "@/pages/Collections";
import { BackupSection } from "@/components/settings/BackupSection";
import { PrintDialog } from "@/components/print/Printables";
import { QrPoster, genericUpiLink } from "@/components/finance/QrPoster";
import { useQr } from "@/components/MemberCard";

const KEYS = ["mahal_name", "mahal_name_ml", "mahal_name_kn", "address", "phone", "email", "registration_no", "logo_url", "default_subscription", "receipt_prefix", "donation_prefix", "default_language", "president_name", "secretary_name", "notify_channel", "notify_on_announcement", "notify_on_payment", "logo_preset", "short_name", "app_url", "member_prefix", "auto_reminder_enabled", "auto_reminder_threshold", "auto_reminder_days", "auto_reminder_channel", "guest_mode_enabled", "hijri_adjustment", "notify_provider", "twilio_sid", "twilio_token", "twilio_sms_from", "twilio_whatsapp_from", "notify_language"];

const Section = ({ title, children }) => (
  <section className="rounded-xl border border-[#e6dbc9] bg-card p-5 shadow-sm">
    <h2 className="font-bold text-base mb-4 text-primary">{title}</h2>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{children}</div>
  </section>
);

const PaymentSection = ({ t }) => {
  const { settings } = useAuth();
  const [fees, setFees] = useState(null);
  const [open, setOpen] = useState(false);
  const [focusQr, setFocusQr] = useState(false);
  const [poster, setPoster] = useState(false);
  const qr = useQr(genericUpiLink(fees?.upi_id, fees?.upi_name), 120);
  const load = () => api.get("/finance/fees").then((r) => setFees(r.data)).catch(() => setFees({}));
  useEffect(() => { load(); }, []);
  const openDialog = (qrFocus) => { setFocusQr(qrFocus); setOpen(true); };
  return (
    <section className="rounded-xl border border-[#d4af37]/60 bg-[#d4af37]/[0.06] p-5 shadow-sm" data-testid="settings-payment-section">
      <h2 className="font-bold text-base mb-1 text-primary flex items-center gap-2"><QrCode className="h-4 w-4" />{t("settings.payment.title")}</h2>
      <p className="text-xs text-muted-foreground mb-3">{t("settings.payment.hint")}</p>
      <div className="flex items-start gap-4 rounded-lg border border-[#0d5c3a]/30 bg-white/70 p-3 mb-4" data-testid="settings-upi-active">
        {qr ? <img src={qr} alt="QR" className="h-[120px] w-[120px] rounded bg-white shrink-0" data-testid="settings-upi-active-qr" /> : <div className="h-[120px] w-[120px] grid place-items-center rounded bg-accent text-muted-foreground shrink-0"><QrCode className="h-8 w-8" /></div>}
        <div className="text-sm min-w-0">
          <p className="text-xs text-muted-foreground">{t("settings.payment.active")}</p>
          {fees?.upi_id ? <><p className="font-bold text-lg leading-tight" data-testid="settings-upi-active-name">{fees.upi_name || "—"}</p><p className="font-mono text-primary break-all" data-testid="settings-upi-id">{fees.upi_id}</p></> : <p className="font-semibold text-destructive" data-testid="settings-upi-id">{t("settings.payment.none")}</p>}
          <p className="mt-1"><span className="text-muted-foreground">Google Pay:</span> <b className="font-mono" data-testid="settings-upi-phone">{fees?.upi_phone || "—"}</b></p>
          <p><span className="text-muted-foreground">{t("fin.bank.bank_name")}:</span> <b data-testid="settings-bank-name">{fees?.bank_name || "—"}</b> · <span className="text-muted-foreground">A/c</span> <b className="font-mono" data-testid="settings-bank-account">{fees?.bank_account_no || "—"}</b>{fees?.bank_ifsc && <span className="text-muted-foreground"> · IFSC {fees.bank_ifsc}</span>}</p>
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button type="button" onClick={() => openDialog(true)} className="h-11" data-testid="settings-change-qr-button"><ImageUp className="h-4 w-4 mr-2" />{t("settings.payment.changeQr")}</Button>
        <Button type="button" variant="outline" onClick={() => openDialog(false)} className="h-11" data-testid="settings-payment-edit-button"><Landmark className="h-4 w-4 mr-2" />{t("settings.payment.edit")}</Button>
        <Button type="button" variant="outline" onClick={() => setPoster(true)} disabled={!fees?.upi_id && !fees?.upi_qr_url} className="h-11" data-testid="settings-qr-poster-button"><QrCode className="h-4 w-4 mr-2" />{t("fin.qr.poster")}</Button>
      </div>
      <div className="mt-4 rounded-lg border border-[#e6dbc9] bg-white/60 p-3 text-sm" data-testid="settings-switch-steps">
        <p className="font-semibold mb-1">{t("settings.payment.stepsTitle")}</p>
        <ol className="list-decimal pl-5 space-y-1 text-xs text-muted-foreground">
          <li>{t("settings.payment.s1")}</li><li>{t("settings.payment.s2")}</li><li>{t("settings.payment.s3")}</li>
        </ol>
      </div>
      <FeesDialog open={open} onOpenChange={setOpen} fees={fees || {}} onSaved={load} focusQr={focusQr} />
      <PrintDialog open={poster} onOpenChange={setPoster} title={t("fin.qr.poster")} testId="qr-poster-dialog"><QrPoster settings={{ ...settings, ...(fees || {}) }} /></PrintDialog>
    </section>
  );
};

export default function Settings() {
  const { t } = useLang();
  const { settings, refreshSettings } = useAuth();
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (settings) setForm((f) => f || Object.fromEntries(KEYS.map((k) => [k, settings[k] ?? ""]))); }, [settings]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      await api.put("/settings", { ...form, default_subscription: Number(form.default_subscription || 0), default_language: form.default_language || "en", notify_channel: form.notify_channel || "whatsapp", notify_on_announcement: form.notify_on_announcement !== false, notify_on_payment: form.notify_on_payment !== false, auto_reminder_enabled: form.auto_reminder_enabled !== false, auto_reminder_threshold: Number(form.auto_reminder_threshold || 0), auto_reminder_days: Number(form.auto_reminder_days || 7), auto_reminder_channel: form.auto_reminder_channel || "both", guest_mode_enabled: form.guest_mode_enabled !== false, member_prefix: form.member_prefix || "OMJ", hijri_adjustment: Number(form.hijri_adjustment || 0), notify_provider: form.notify_provider || "phone", notify_language: form.notify_language || "ml" });
      await refreshSettings();
      toast.success(t("settings.saved"));
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };

  if (!form) return null;

  return (
    <div data-testid="settings-page">
      <PageHeader title={t("settings.title")} />
      <form onSubmit={submit} className="space-y-6 max-w-3xl">
        <Section title={t("settings.general")}>
          <TextField label={t("settings.mahalName")} value={form.mahal_name} onChange={set("mahal_name")} required testId="settings-mahal-name" />
          <TextField label={t("settings.mahalNameMl")} value={form.mahal_name_ml} onChange={set("mahal_name_ml")} testId="settings-mahal-name-ml" />
          <TextField label={t("settings.mahalNameKn")} value={form.mahal_name_kn} onChange={set("mahal_name_kn")} testId="settings-mahal-name-kn" />
          <TextField label={t("settings.regNo")} value={form.registration_no} onChange={set("registration_no")} testId="settings-reg-no" />
          <TextField label={t("settings.address")} value={form.address} onChange={set("address")} testId="settings-address" className="sm:col-span-2" />
          <TextField label={t("settings.phone")} value={form.phone} onChange={set("phone")} testId="settings-phone" />
          <TextField label={t("settings.committeeWa")} value={form.committee_whatsapp || ""} onChange={set("committee_whatsapp")} testId="settings-committee-whatsapp" inputMode="tel" placeholder="98470 00000" />
          <p className="sm:col-span-2 -mt-2 text-xs text-muted-foreground">{t("settings.committeeWaHint")}</p>
          <TextField label={t("settings.email")} type="email" value={form.email} onChange={set("email")} testId="settings-email" />
          <TextField label={t("settings.president")} value={form.president_name} onChange={set("president_name")} testId="settings-president" />
          <TextField label={t("settings.secretary")} value={form.secretary_name} onChange={set("secretary_name")} testId="settings-secretary" />
        </Section>
        <PaymentSection t={t} />
        <Section title={t("settings.finance")}>
          <TextField label={t("settings.defaultSub")} type="number" min="0" value={form.default_subscription} onChange={set("default_subscription")} testId="settings-default-subscription" />
          <TextField label={t("settings.receiptPrefix")} value={form.receipt_prefix} onChange={set("receipt_prefix")} testId="settings-receipt-prefix" />
          <TextField label={t("settings.donationPrefix")} value={form.donation_prefix} onChange={set("donation_prefix")} testId="settings-donation-prefix" />
        </Section>
        <Section title={t("cal.title")}>
          <SelectField label={t("cal.adjustment")} value={String(form.hijri_adjustment ?? 0)} onChange={(v) => set("hijri_adjustment")(Number(v))} testId="settings-hijri-adjustment" options={[-2, -1, 0, 1, 2].map((n) => ({ value: String(n), label: n === 0 ? "0" : `${n > 0 ? "+" : ""}${n} ${t("cal.days")}` }))} />
          <p className="text-xs text-muted-foreground sm:col-span-2">{t("cal.adjustmentHint")}</p>
        </Section>
        <Section title={t("settings.branding")}>
          <div className="sm:col-span-2"><LogoPicker value={{ logo_url: form.logo_url, logo_preset: form.logo_preset }} onChange={(v) => setForm((f) => ({ ...f, ...v }))} /></div>
          <TextField label={t("logo.shortName")} value={form.short_name} onChange={set("short_name")} testId="settings-short-name" maxLength={14} />
          <SelectField label={t("settings.defaultLang")} value={form.default_language || "en"} onChange={set("default_language")} testId="settings-default-language" options={["en", "ml", "kn"].map((l) => ({ value: l, label: t(`lang.${l}`) }))} />
          <TextField label={t("logo.appUrl")} value={form.app_url} onChange={set("app_url")} testId="settings-app-url" placeholder={window.location.origin} className="sm:col-span-2" />
          <TextField label={t("logo.memberPrefix")} value={form.member_prefix} onChange={set("member_prefix")} testId="settings-member-prefix" maxLength={8} />
          <div className="sm:col-span-2 flex items-center justify-between rounded-lg border p-3"><Label>{t("settings.guestMode")}</Label><Switch checked={form.guest_mode_enabled !== false} onCheckedChange={set("guest_mode_enabled")} data-testid="settings-guest-mode" /></div>
        </Section>
        <Section title={t("autoRem.title")}>
          <p className="sm:col-span-2 text-sm text-muted-foreground -mt-2">{t("autoRem.desc")}</p>
          <div className="sm:col-span-2 flex items-center justify-between rounded-lg border p-3"><Label>{t("autoRem.enabled")}</Label><Switch checked={form.auto_reminder_enabled !== false} onCheckedChange={set("auto_reminder_enabled")} data-testid="settings-auto-reminder-enabled" /></div>
          <TextField label={t("autoRem.threshold")} type="number" min="0" value={form.auto_reminder_threshold} onChange={set("auto_reminder_threshold")} testId="settings-auto-reminder-threshold" />
          <TextField label={t("autoRem.days")} type="number" min="1" value={form.auto_reminder_days} onChange={set("auto_reminder_days")} testId="settings-auto-reminder-days" />
          <SelectField label={t("autoRem.channel")} value={form.auto_reminder_channel || "both"} onChange={set("auto_reminder_channel")} testId="settings-auto-reminder-channel" options={["whatsapp", "sms", "both"].map((c) => ({ value: c, label: t(`notif.channels.${c}`) }))} />
        </Section>
        <Section title={t("provider.title")}>
          <SelectField label={t("provider.mode")} value={form.notify_provider || "phone"} onChange={set("notify_provider")} testId="settings-notify-provider" options={[{ value: "phone", label: t("provider.phone") }, { value: "twilio", label: t("provider.twilio") }]} />
          <p className="text-xs text-muted-foreground sm:col-span-2 -mt-2">{form.notify_provider === "twilio" ? t("provider.twilioHint") : t("provider.phoneHint")}</p>
          {form.notify_provider === "twilio" && (
            <>
              <TextField label="Twilio Account SID" value={form.twilio_sid || ""} onChange={set("twilio_sid")} placeholder="ACxxxxxxxx" testId="settings-twilio-sid" />
              <TextField label="Twilio Auth Token" type="password" value={form.twilio_token || ""} onChange={set("twilio_token")} testId="settings-twilio-token" />
              <TextField label={t("provider.waFrom")} value={form.twilio_whatsapp_from || ""} onChange={set("twilio_whatsapp_from")} placeholder="+14155238886" testId="settings-twilio-wa-from" />
              <TextField label={t("provider.smsFrom")} value={form.twilio_sms_from || ""} onChange={set("twilio_sms_from")} placeholder="+1xxxxxxxxxx" testId="settings-twilio-sms-from" />
            </>
          )}
        </Section>
        <Section title={t("notif.settingsTitle")}>
          <SelectField label={t("notif.notifyChannel")} value={form.notify_channel || "whatsapp"} onChange={set("notify_channel")} testId="settings-notify-channel" options={["whatsapp", "sms", "both"].map((c) => ({ value: c, label: t(`notif.channels.${c}`) }))} />
          <SelectField label={t("notif.language")} value={form.notify_language || "ml"} onChange={set("notify_language")} testId="settings-notify-language" options={["ml", "kn"].map((l) => ({ value: l, label: t(`lang.${l}`) }))} />
          <p className="text-xs text-muted-foreground sm:col-span-2 -mt-2">{t("notif.languageHint")}</p>
          <div className="sm:col-span-2 space-y-3">
            <div className="flex items-center justify-between rounded-lg border p-3"><Label>{t("notif.onAnnouncement")}</Label><Switch checked={form.notify_on_announcement !== false} onCheckedChange={set("notify_on_announcement")} data-testid="settings-notify-announcement" /></div>
            <div className="flex items-center justify-between rounded-lg border p-3"><Label>{t("notif.onPayment")}</Label><Switch checked={form.notify_on_payment !== false} onCheckedChange={set("notify_on_payment")} data-testid="settings-notify-payment" /></div>
          </div>
        </Section>
        <SubmitRow loading={loading} />
      </form>
      <div className="mt-6"><BackupSection /></div>
    </div>
  );
}
