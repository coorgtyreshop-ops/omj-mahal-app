import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Send, Trash2, Lock, Unlock, MessagesSquare, Play, Pause, Users, ShieldCheck, BookOpenText } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { PageHeader, ConfirmDelete } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { VoiceRecorder, fmtDur } from "@/components/chat/VoiceRecorder";
import { cn } from "@/lib/utils";

const BASE = process.env.REACT_APP_BACKEND_URL;
const POLL_MS = 5000;
const timeOf = (iso) => new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const dayOf = (iso) => new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });

const VoiceBubble = ({ url, duration, mine }) => {
  const ref = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0);
  const toggle = () => { const a = ref.current; if (!a) return; if (a.paused) a.play(); else a.pause(); };
  const total = duration || ref.current?.duration || 0;
  return (
    <div className="flex items-center gap-2 min-w-[200px]" data-testid="voice-bubble">
      <audio ref={ref} src={`${BASE}${url}`} preload="metadata" onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => { setPlaying(false); setPos(0); }} onTimeUpdate={(e) => setPos(e.target.currentTime)} />
      <button type="button" onClick={toggle} className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-full", mine ? "bg-white/20 text-white" : "bg-primary text-white")} data-testid="voice-play-button">{playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 ml-0.5" />}</button>
      <div className="flex-1">
        <div className={cn("h-1.5 rounded-full overflow-hidden", mine ? "bg-white/30" : "bg-muted")}><div className={cn("h-full rounded-full transition-[width]", mine ? "bg-white" : "bg-primary")} style={{ width: `${total ? Math.min(100, (pos / total) * 100) : 0}%` }} /></div>
        <p className={cn("text-[11px] mt-1 font-mono", mine ? "text-white/80" : "text-muted-foreground")}>{fmtDur(playing ? pos : total)}</p>
      </div>
    </div>
  );
};

const Bubble = ({ m, mine, isAdmin, onDelete, t }) => (
  <div className={cn("flex", mine ? "justify-end" : "justify-start")} data-testid={`chat-msg-${m.id}`}>
    <div className={cn("group relative max-w-[85%] sm:max-w-[70%] rounded-2xl px-3.5 py-2 shadow-sm", mine ? "bg-primary text-white rounded-br-sm" : "bg-card border border-[#e6dbc9] rounded-bl-sm")}>
      {!mine && <p className="text-xs font-bold text-[#8a6d1d] mb-0.5">{m.name}{m.house_no ? <span className="font-normal text-muted-foreground"> · {m.house_no}</span> : ""}{m.role === "admin" && <span className="ml-1 rounded-full bg-[#1c2420] text-[#d4af37] px-1.5 py-px text-[10px] font-bold">{t("chat.committee")}</span>}</p>}
      {m.deleted ? <p className={cn("text-sm italic", mine ? "text-white/70" : "text-muted-foreground")}>{t("chat.deleted")}</p> : m.audio_url ? <VoiceBubble url={m.audio_url} duration={m.duration} mine={mine} /> : <p className="text-sm whitespace-pre-wrap break-words">{m.text}</p>}
      <p className={cn("text-[10px] mt-1 text-right", mine ? "text-white/70" : "text-muted-foreground")}>{timeOf(m.created_at)}</p>
      {!m.deleted && (mine || isAdmin) && <button type="button" onClick={() => onDelete(m)} className={cn("absolute -top-2 rounded-full border bg-background p-1 text-destructive opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity", mine ? "-left-2" : "-right-2")} data-testid={`chat-delete-${m.id}`} aria-label={t("common.delete")}><Trash2 className="h-3.5 w-3.5" /></button>}
    </div>
  </div>
);

export default function Chat() {
  const { t } = useLang();
  const { user, isAdmin } = useAuth();
  const [msgs, setMsgs] = useState([]);
  const [room, setRoom] = useState("all");
  const [rooms, setRooms] = useState(["all"]);
  const [locked, setLocked] = useState(false);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const bottom = useRef(null);
  const last = useRef(null);

  const merge = (rows) => setMsgs((prev) => { const ids = new Set(prev.map((m) => m.id)); return [...prev, ...rows.filter((r) => !ids.has(r.id))]; });
  const load = useCallback(async () => {
    try {
      const { data } = await api.get("/chat/messages", { params: { room, ...(last.current ? { after: last.current } : { limit: 60 }) } });
      if (data.room !== room) return;
      if (data.messages.length) { merge(data.messages); last.current = data.messages[data.messages.length - 1].created_at; }
      setLocked(data.locked); setRooms(data.rooms || ["all"]);
    } catch { /* offline */ }
  }, [room]);
  useEffect(() => { setMsgs([]); last.current = null; load(); const id = setInterval(load, POLL_MS); return () => clearInterval(id); }, [load]);
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth" }); localStorage.setItem("chat_seen", new Date().toISOString()); }, [msgs.length]);

  const sendText = async (e) => {
    e?.preventDefault();
    if (!text.trim()) return;
    setSending(true);
    try { const { data } = await api.post("/chat/messages", { text }, { params: { room } }); merge([data]); last.current = data.created_at; setText(""); }
    catch (err) { toast.error(apiError(err)); } finally { setSending(false); }
  };
  const sendVoice = async (file, duration) => {
    const fd = new FormData(); fd.append("file", file); fd.append("duration", String(duration));
    try { const { data } = await api.post("/chat/voice", fd, { params: { room }, headers: { "Content-Type": "multipart/form-data" } }); merge([data]); last.current = data.created_at; }
    catch (err) { toast.error(apiError(err)); }
  };
  const remove = async () => {
    try { await api.delete(`/chat/messages/${deleting.id}`); setMsgs((p) => p.map((m) => (m.id === deleting.id ? { ...m, deleted: true, text: "", audio_url: null } : m))); setDeleting(null); }
    catch (err) { toast.error(apiError(err)); }
  };
  const toggleLock = async () => {
    try { const { data } = await api.put("/chat/lock", { locked: !locked }); setLocked(data.locked); toast.success(data.locked ? t("chat.lockedNow") : t("chat.unlockedNow")); }
    catch (err) { toast.error(apiError(err)); }
  };
  const canPost = isAdmin || !locked || room !== "all";
  const ROOM_ICONS = { all: Users, committee: ShieldCheck, khatheeb: BookOpenText };
  let lastDay = "";
  return (
    <div className="flex flex-col h-[calc(100dvh-9.5rem)] md:h-[calc(100dvh-8rem)]" data-testid="chat-page">
      <PageHeader title={t("chat.title")} subtitle={t("chat.subtitle")} actions={isAdmin && <Button variant="outline" onClick={toggleLock} className="h-11" data-testid="chat-lock-button">{locked ? <Unlock className="h-4 w-4 mr-2" /> : <Lock className="h-4 w-4 mr-2" />}{locked ? t("chat.unlock") : t("chat.lock")}</Button>} />
      {rooms.length > 1 && (
        <div className="flex gap-2 mb-3 overflow-x-auto" data-testid="chat-rooms">
          {rooms.map((r) => { const Icon = ROOM_ICONS[r] || Users; return (
            <button key={r} type="button" onClick={() => setRoom(r)} className={cn("inline-flex items-center gap-1.5 rounded-full px-4 h-10 text-sm font-semibold border transition-colors whitespace-nowrap", room === r ? "bg-primary text-white border-primary" : "bg-card border-[#e6dbc9] hover:border-[#d4af37]")} data-testid={`chat-room-${r}`}><Icon className="h-4 w-4" />{t(`chat.rooms.${r}`)}</button>
          ); })}
        </div>
      )}
      <div className="flex-1 overflow-y-auto rounded-2xl border border-[#e6dbc9] bg-[#efe8da] p-3 sm:p-4 space-y-2" style={{ backgroundImage: "radial-gradient(#d4af3722 1px, transparent 1px)", backgroundSize: "18px 18px" }} data-testid="chat-messages">
        {msgs.length === 0 && <div className="h-full grid place-items-center text-center text-muted-foreground"><div><MessagesSquare className="h-10 w-10 mx-auto mb-2 text-[#d4af37]" /><p className="text-sm">{room === "khatheeb" ? t("chat.khatheebEmpty") : room === "committee" ? t("chat.committeeEmpty") : t("chat.empty")}</p></div></div>}
        {msgs.map((m) => {
          const d = dayOf(m.created_at);
          const sep = d !== lastDay; lastDay = d;
          return (
            <div key={m.id} className="space-y-2">
              {sep && <p className="text-center"><span className="rounded-full bg-white/80 px-3 py-0.5 text-[11px] text-muted-foreground shadow-sm">{d}</span></p>}
              <Bubble m={m} mine={m.user_id === user?.id} isAdmin={isAdmin} onDelete={setDeleting} t={t} />
            </div>
          );
        })}
        <div ref={bottom} />
      </div>
      {canPost ? (
        <form onSubmit={sendText} className="mt-3 flex items-center gap-2" data-testid="chat-composer">
          <VoiceRecorder onSend={sendVoice} disabled={sending} />
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder={t("chat.placeholder")} maxLength={2000} className="flex-1 h-12 rounded-full border border-input bg-background px-4 text-base outline-none focus:ring-2 focus:ring-primary/40" data-testid="chat-text-input" />
          <button type="submit" disabled={sending || !text.trim()} className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-primary text-white hover:bg-primary/90 disabled:opacity-50" data-testid="chat-send-button" aria-label={t("common.send")}><Send className="h-5 w-5" /></button>
        </form>
      ) : <p className="mt-3 text-center text-sm text-muted-foreground rounded-full bg-muted px-4 py-3" data-testid="chat-locked-note"><Lock className="inline h-4 w-4 mr-1" />{t("chat.lockedNote")}</p>}
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
    </div>
  );
}
