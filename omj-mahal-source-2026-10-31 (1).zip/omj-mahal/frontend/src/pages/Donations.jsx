import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Printer, Trash2, Pencil, Target } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, fmtDate, todayStr } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete, TextField, SelectField, SubmitRow } from "@/components/shared";
import { PrintDialog, ReceiptBody } from "@/components/print/Printables";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const FundCard = ({ fund, onEdit, onDelete, onDonate }) => {
  const { t } = useLang();
  const pct = fund.target ? Math.min(100, Math.round((fund.raised / fund.target) * 100)) : 0;
  return (
    <div className="rounded-xl border border-[#e6dbc9] bg-card p-4 sm:p-5 shadow-sm hover:shadow-md transition-shadow" data-testid={`fund-card-${fund.id}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="font-semibold text-base leading-tight">{fund.name}</h3>
          {fund.description && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{fund.description}</p>}
        </div>
        <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold ${fund.active ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>{fund.active ? t("donations.active") : t("donations.closed")}</span>
      </div>
      {fund.raised !== undefined && <div className="mt-4">
        <div className="flex justify-between text-sm mb-1.5">
          <span className="font-bold text-primary" data-testid={`fund-raised-${fund.id}`}>{inr(fund.raised)}</span>
          {fund.target > 0 && <span className="text-muted-foreground">{pct}% {t("donations.progress")} {inr(fund.target)}</span>}
        </div>
        <div className="h-2.5 rounded-full bg-muted overflow-hidden"><div className="h-full rounded-full shimmer transition-[width] duration-700" style={{ width: `${fund.target ? pct : 100}%` }} /></div>
        <p className="text-xs text-muted-foreground mt-1.5">{fund.donor_count} {t("donations.donors")}</p>
      </div>}
      {(onEdit || onDonate) && (
        <div className="mt-4 flex gap-2">
          {onDonate && <Button size="sm" onClick={() => onDonate(fund)} className="h-9 flex-1" data-testid={`donate-fund-${fund.id}`}><Plus className="h-4 w-4 mr-1" />{t("donations.record")}</Button>}
          {onEdit && <Button size="icon" variant="outline" onClick={() => onEdit(fund)} className="h-9 w-9" data-testid={`edit-fund-${fund.id}`}><Pencil className="h-4 w-4" /></Button>}
          {onDelete && <Button size="icon" variant="outline" className="h-9 w-9 text-destructive" onClick={() => onDelete(fund)} data-testid={`delete-fund-${fund.id}`}><Trash2 className="h-4 w-4" /></Button>}
        </div>
      )}
    </div>
  );
};

const FundForm = ({ open, onOpenChange, fund, onSaved }) => {
  const { t } = useLang();
  const [form, setForm] = useState({ name: "", description: "", target: "", active: true });
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) setForm(fund ? { ...fund } : { name: "", description: "", target: "", active: true }); }, [open, fund]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const payload = { name: form.name, description: form.description, target: Number(form.target || 0), active: form.active };
      fund?.id ? await api.put(`/funds/${fund.id}`, payload) : await api.post("/funds", payload);
      toast.success(t("common.saved")); onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="fund-form-dialog">
        <DialogHeader><DialogTitle>{fund?.id ? t("donations.editFund") : t("donations.addFund")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <TextField label={t("donations.fundName")} value={form.name} onChange={set("name")} required testId="fund-name-input" />
          <div className="space-y-1.5"><Label>{t("common.description")}</Label><Textarea value={form.description} onChange={(e) => set("description")(e.target.value)} data-testid="fund-description-input" /></div>
          <TextField label={t("donations.target")} type="number" min="0" value={form.target} onChange={set("target")} testId="fund-target-input" />
          <div className="flex items-center justify-between rounded-lg border p-3"><Label>{t("donations.active")}</Label><Switch checked={!!form.active} onCheckedChange={set("active")} data-testid="fund-active-switch" /></div>
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

const DonationForm = ({ open, onOpenChange, funds, houses, presetFund, onSaved }) => {
  const { t } = useLang();
  const empty = { fund_id: presetFund || "", donor_name: "", house_id: "", amount: "", mode: "cash", date: todayStr(), note: "" };
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) setForm({ ...empty, fund_id: presetFund || "" }); }, [open, presetFund]); // eslint-disable-line
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const pickHouse = (hid) => { const h = houses.find((x) => x.id === hid); setForm((f) => ({ ...f, house_id: hid === "none" ? "" : hid, donor_name: f.donor_name || h?.head_name || "" })); };
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const { data } = await api.post("/donations", { ...form, house_id: form.house_id || null, amount: Number(form.amount) });
      toast.success(t("donations.recorded")); onSaved(data); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[92vh] overflow-y-auto" data-testid="donation-form-dialog">
        <DialogHeader><DialogTitle>{t("donations.record")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <SelectField label={t("donations.fund")} value={form.fund_id} onChange={set("fund_id")} required testId="donation-fund-select" options={funds.filter((f) => f.active || f.id === form.fund_id).map((f) => ({ value: f.id, label: f.name }))} />
          <SelectField label={t("donations.linkHouse")} value={form.house_id || "none"} onChange={pickHouse} testId="donation-house-select" options={[{ value: "none", label: t("donations.noHouse") }, ...houses.map((h) => ({ value: h.id, label: `${h.house_no} — ${h.head_name}` }))]} />
          <TextField label={t("donations.donor")} value={form.donor_name} onChange={set("donor_name")} required testId="donation-donor-input" />
          <div className="grid grid-cols-2 gap-4">
            <TextField label={t("common.amount")} type="number" min="1" value={form.amount} onChange={set("amount")} required testId="donation-amount-input" />
            <SelectField label={t("common.mode")} value={form.mode} onChange={set("mode")} testId="donation-mode-select" options={["cash", "upi", "bank"].map((m) => ({ value: m, label: t(`paymentModes.${m}`) }))} />
            <TextField label={t("common.date")} type="date" value={form.date} onChange={set("date")} testId="donation-date-input" />
            <TextField label={t("common.note")} value={form.note} onChange={set("note")} testId="donation-note-input" />
          </div>
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} label={t("subs.payNow")} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default function Donations() {
  const { t } = useLang();
  const { isAdmin, settings } = useAuth();
  const [funds, setFunds] = useState([]);
  const [donations, setDonations] = useState([]);
  const [houses, setHouses] = useState([]);
  const [fundOpen, setFundOpen] = useState(false);
  const [editingFund, setEditingFund] = useState(null);
  const [donOpen, setDonOpen] = useState(false);
  const [presetFund, setPresetFund] = useState("");
  const [receipt, setReceipt] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const load = useCallback(async () => {
    const [f, d] = await Promise.all([api.get("/funds"), api.get("/donations")]);
    setFunds(f.data); setDonations(d.data);
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (isAdmin) api.get("/houses").then((r) => setHouses(r.data)); }, [isAdmin]);

  const remove = async () => {
    try {
      await api.delete(deleting.kind === "fund" ? `/funds/${deleting.id}` : `/donations/${deleting.id}`);
      toast.success(t("common.deleted")); setDeleting(null); load();
    } catch (e) { toast.error(apiError(e)); }
  };

  return (
    <div data-testid="donations-page">
      <PageHeader title={t("donations.title")} actions={isAdmin && <>
        <Button variant="outline" onClick={() => { setEditingFund(null); setFundOpen(true); }} className="h-11" data-testid="add-fund-button"><Target className="h-4 w-4 mr-2" />{t("donations.addFund")}</Button>
        <Button onClick={() => { setPresetFund(""); setDonOpen(true); }} className="h-11" data-testid="record-donation-button"><Plus className="h-4 w-4 mr-2" />{t("donations.record")}</Button>
      </>} />

      <h2 className="text-lg font-bold mb-3">{t("donations.funds")}</h2>
      {funds.length === 0 ? <EmptyState text={t("donations.noFunds")} /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8" data-testid="funds-grid">
          {funds.map((f) => <FundCard key={f.id} fund={f}
            onEdit={isAdmin ? (x) => { setEditingFund(x); setFundOpen(true); } : undefined}
            onDelete={isAdmin ? (x) => setDeleting({ ...x, kind: "fund" }) : undefined}
            onDonate={isAdmin && f.active ? (x) => { setPresetFund(x.id); setDonOpen(true); } : undefined} />)}
        </div>
      )}

      <h2 className="text-lg font-bold mb-3">{t("donations.recent")}</h2>
      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        {donations.length === 0 ? <EmptyState text={t("donations.noDonations")} /> : (
          <Table data-testid="donations-table">
            <TableHeader><TableRow className="bg-accent/60">
              <TableHead>{t("common.receiptNo")}</TableHead><TableHead>{t("common.date")}</TableHead><TableHead>{t("donations.donor")}</TableHead>
              <TableHead className="hidden md:table-cell">{t("donations.fund")}</TableHead><TableHead className="hidden sm:table-cell">{t("common.mode")}</TableHead>
              <TableHead className="text-right">{t("common.amount")}</TableHead><TableHead />
            </TableRow></TableHeader>
            <TableBody>
              {donations.map((d) => (
                <TableRow key={d.id} data-testid={`donation-row-${d.receipt_no}`}>
                  <TableCell className="font-mono text-xs">{d.receipt_no}</TableCell>
                  <TableCell>{fmtDate(d.date)}</TableCell>
                  <TableCell className="font-medium">{d.donor_name}<p className="text-xs text-muted-foreground md:hidden">{d.fund_name}</p></TableCell>
                  <TableCell className="hidden md:table-cell">{d.fund_name}</TableCell>
                  <TableCell className="hidden sm:table-cell">{t(`paymentModes.${d.mode}`)}</TableCell>
                  <TableCell className="text-right font-semibold">{inr(d.amount)}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    <Button size="icon" variant="ghost" onClick={() => setReceipt(d)} data-testid={`print-donation-${d.receipt_no}`}><Printer className="h-4 w-4" /></Button>
                    {isAdmin && <Button size="icon" variant="ghost" className="text-destructive" onClick={() => setDeleting({ ...d, kind: "donation" })} data-testid={`delete-donation-${d.receipt_no}`}><Trash2 className="h-4 w-4" /></Button>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      {isAdmin && <>
        <FundForm open={fundOpen} onOpenChange={setFundOpen} fund={editingFund} onSaved={load} />
        <DonationForm open={donOpen} onOpenChange={setDonOpen} funds={funds} houses={houses} presetFund={presetFund} onSaved={(d) => { load(); setReceipt({ ...d, fund_name: funds.find((f) => f.id === d.fund_id)?.name }); }} />
      </>}
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
      <PrintDialog open={!!receipt} onOpenChange={(o) => !o && setReceipt(null)} title={t("common.receipt")} testId="receipt-dialog">
        {receipt && <ReceiptBody payment={receipt} kind="donation" settings={settings} />}
      </PrintDialog>
    </div>
  );
}
