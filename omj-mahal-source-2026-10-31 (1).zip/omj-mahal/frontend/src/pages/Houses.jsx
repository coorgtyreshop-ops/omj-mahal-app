import { useCallback, useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { Plus, Download, Search, Pencil, Trash2, Eye } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { inr, downloadCsv } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete, StatusBadge } from "@/components/shared";
import { HouseForm } from "@/components/forms/HouseMemberForms";
import { FamilyQuickAdd } from "@/components/forms/FamilyQuickAdd";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Houses() {
  const { t } = useLang();
  const [params, setParams] = useSearchParams();
  const [houses, setHouses] = useState([]);
  const [wards, setWards] = useState([]);
  const [q, setQ] = useState("");
  const [ward, setWard] = useState("all");
  const [formOpen, setFormOpen] = useState(params.get("new") === "1");
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [familyFor, setFamilyFor] = useState(null);

  const load = useCallback(async () => {
    const { data } = await api.get("/houses", { params: { q: q || undefined, ward: ward !== "all" ? ward : undefined, with_dues: true } });
    setHouses(data);
  }, [q, ward]);

  useEffect(() => { const id = setTimeout(load, 250); return () => clearTimeout(id); }, [load]);
  useEffect(() => { api.get("/houses/wards").then((r) => setWards(r.data)); }, [houses.length]);

  const openNew = () => { setEditing(null); setFormOpen(true); };
  const closeForm = (o) => { setFormOpen(o); if (!o && params.get("new")) setParams({}); };

  const remove = async () => {
    try {
      await api.delete(`/houses/${deleting.id}`);
      toast.success(t("houses.houseDeleted"));
      setDeleting(null);
      load();
    } catch (e) { toast.error(apiError(e)); }
  };

  const exportCsv = () =>
    downloadCsv("houses.csv", ["House No", "Head", "Address", "Ward", "Phone", "WhatsApp", "Subscription", "Members", "Pending Months", "Pending Amount"],
      houses.map((h) => [h.house_no, h.head_name, h.address, h.ward, h.phone, h.whatsapp, h.subscription_amount, h.member_count, h.dues?.pending_count ?? 0, h.dues?.pending_amount ?? 0]));

  return (
    <div data-testid="houses-page">
      <PageHeader title={t("houses.title")} actions={<>
        <Button variant="outline" onClick={exportCsv} className="h-11" data-testid="houses-export-button"><Download className="h-4 w-4 mr-2" />{t("common.export")}</Button>
        <Button onClick={openNew} className="h-11" data-testid="add-house-button"><Plus className="h-4 w-4 mr-2" />{t("houses.addHouse")}</Button>
      </>} />

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("houses.searchPlaceholder")} className="h-11 pl-10" data-testid="houses-search-input" />
        </div>
        <Select value={ward} onValueChange={setWard}>
          <SelectTrigger className="h-11 sm:w-56" data-testid="houses-ward-filter"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("houses.allWards")}</SelectItem>
            {wards.map((w) => <SelectItem key={w} value={w}>{w}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        {houses.length === 0 ? <EmptyState text={t("houses.noHouses")} testId="houses-empty" /> : (
          <Table data-testid="houses-table">
            <TableHeader>
              <TableRow className="bg-accent/60">
                <TableHead>{t("houses.houseNo")}</TableHead>
                <TableHead>{t("houses.headName")}</TableHead>
                <TableHead className="hidden md:table-cell">{t("houses.ward")}</TableHead>
                <TableHead className="hidden md:table-cell">{t("common.phone")}</TableHead>
                <TableHead className="text-right hidden sm:table-cell">{t("houses.subscription")}</TableHead>
                <TableHead className="text-center hidden sm:table-cell">{t("houses.members")}</TableHead>
                <TableHead>{t("houses.dues")}</TableHead>
                <TableHead className="hidden lg:table-cell">{t("hlogin.hasLogin")}</TableHead>
                <TableHead className="text-right">{t("common.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {houses.map((h) => (
                <TableRow key={h.id} data-testid={`house-row-${h.house_no}`}>
                  <TableCell className="font-bold text-primary"><Link to={`/houses/${h.id}`} className="hover:underline">{h.house_no}</Link></TableCell>
                  <TableCell>
                    <p className="font-medium">{h.head_name}</p>
                    <p className="text-xs text-muted-foreground md:hidden">{h.ward}{h.phone ? ` • ${h.phone}` : ""}</p>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">{h.ward}</TableCell>
                  <TableCell className="hidden md:table-cell"><p>{h.phone}</p>{h.whatsapp && h.whatsapp !== h.phone && <p className="text-xs text-[#128C7E]">WA: {h.whatsapp}</p>}</TableCell>
                  <TableCell className="text-right hidden sm:table-cell">{inr(h.subscription_amount)}</TableCell>
                  <TableCell className="text-center hidden sm:table-cell">{h.member_count}</TableCell>
                  <TableCell>
                    {h.dues?.pending_count ? <StatusBadge ok={false}>{inr(h.dues.pending_amount)} · {h.dues.pending_count}m</StatusBadge> : <StatusBadge ok>{t("common.paid")}</StatusBadge>}
                    <p className={`mt-1 text-[10px] font-semibold ${h.statement_released ? "text-[#0d5c3a]" : "text-[#a06f1c]"}`} data-testid={`release-state-${h.house_no}`}>{h.statement_released ? `✔ ${t("fin.release.badge")}` : `⏳ ${t("fin.release.badgeNo")}`}</p>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell" data-testid={`house-login-${h.house_no}`}>{h.has_login ? <StatusBadge ok>{t("hlogin.hasLogin")}</StatusBadge> : <span className="text-xs text-muted-foreground">{t("hlogin.noLogin")}</span>}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    <Button asChild size="icon" variant="ghost" data-testid={`view-house-${h.house_no}`}><Link to={`/houses/${h.id}`}><Eye className="h-4 w-4" /></Link></Button>
                    <Button size="icon" variant="ghost" onClick={() => { setEditing(h); setFormOpen(true); }} data-testid={`edit-house-${h.house_no}`}><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" className="text-destructive" onClick={() => setDeleting(h)} data-testid={`delete-house-${h.house_no}`}><Trash2 className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      <HouseForm open={formOpen} onOpenChange={closeForm} house={editing} onSaved={load} onCreated={setFamilyFor} />
      <FamilyQuickAdd open={!!familyFor} onOpenChange={(o) => !o && setFamilyFor(null)} house={familyFor} onSaved={load} />
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
    </div>
  );
}
