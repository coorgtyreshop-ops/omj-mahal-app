import { useEffect, useState } from "react";
import { Printer, Download } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { inr, monthLabel, downloadCsv } from "@/lib/format";
import { PageHeader, StatCard } from "@/components/shared";
import { PrintDialog } from "@/components/print/Printables";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, TrendingDown, Scale } from "lucide-react";

const years = Array.from({ length: 5 }, (_, i) => String(new Date().getFullYear() - i));

export default function Reports() {
  const { t, months, lang } = useLang();
  const { settings } = useAuth();
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const [month, setMonth] = useState("all");
  const [data, setData] = useState(null);
  const [printOpen, setPrintOpen] = useState(false);

  useEffect(() => {
    api.get("/reports/summary", { params: { year, month: month !== "all" ? `${year}-${month}` : undefined } }).then((r) => setData(r.data));
  }, [year, month]);

  const periodLabel = month === "all" ? `${t("reports.wholeYear")} ${year}` : monthLabel(`${year}-${month}`, months);
  const exportCsv = () => {
    if (!data) return;
    const rows = [["Income - Varisankhya", data.income.subscriptions], ["Income - Donations", data.income.donations], ["Total Income", data.income.total], ...data.expenses.by_category.map((c) => [`Expense - ${c.category}`, c.total]), ["Total Expenses", data.expenses.total], ["Balance", data.balance]];
    downloadCsv(`report-${data.period}.csv`, ["Item", "Amount"], rows);
  };
  const mahalName = (lang === "ml" && settings?.mahal_name_ml) || (lang === "kn" && settings?.mahal_name_kn) || settings?.mahal_name;

  const Statement = () => (
    <div className="bg-white text-[#1e2923] p-6 rounded-lg border border-[#e6dbc9]" data-testid="report-statement">
      <div className="text-center border-b-2 border-[#d4af37] pb-3 mb-4">
        <h2 className="text-xl font-bold text-[#0d5c3a]">{mahalName}</h2>
        <p className="text-sm font-semibold mt-1">{t("reports.statement")}</p>
        <p className="text-xs text-gray-600">{t("reports.period")}: {periodLabel}</p>
      </div>
      <div className="grid md:grid-cols-2 gap-6 text-sm">
        <div>
          <h4 className="font-bold text-[#0d5c3a] border-b mb-2 pb-1">{t("reports.income")}</h4>
          <div className="flex justify-between py-1"><span>{t("reports.subscriptions")}</span><span>{inr(data.income.subscriptions)}</span></div>
          {data.donations_by_fund.map((f) => <div key={f.fund} className="flex justify-between py-1"><span>{t("reports.donations")} — {f.fund}</span><span>{inr(f.total)}</span></div>)}
          <div className="flex justify-between py-1 font-bold border-t mt-1"><span>{t("common.total")}</span><span data-testid="report-income-total">{inr(data.income.total)}</span></div>
        </div>
        <div>
          <h4 className="font-bold text-[#0d5c3a] border-b mb-2 pb-1">{t("reports.expense")}</h4>
          {data.expenses.by_category.map((c) => <div key={c.category} className="flex justify-between py-1"><span>{t(`expenses.categories.${c.category}`)}</span><span>{inr(c.total)}</span></div>)}
          <div className="flex justify-between py-1 font-bold border-t mt-1"><span>{t("common.total")}</span><span data-testid="report-expense-total">{inr(data.expenses.total)}</span></div>
        </div>
      </div>
      <div className="mt-6 flex justify-between items-center rounded-md bg-[#faf8f5] border border-[#e6dbc9] px-4 py-3">
        <span className="font-bold">{t("reports.balance")}</span>
        <span className={`text-2xl font-bold ${data.balance >= 0 ? "text-[#0d5c3a]" : "text-red-600"}`} data-testid="report-balance">{inr(data.balance)}</span>
      </div>
      <p className="mt-3 text-[10px] text-gray-400">{t("reports.openingNote")}</p>
    </div>
  );

  return (
    <div data-testid="reports-page">
      <PageHeader title={t("reports.title")} actions={<>
        <Button variant="outline" onClick={exportCsv} className="h-11" data-testid="report-export-button"><Download className="h-4 w-4 mr-2" />{t("common.export")}</Button>
        <Button onClick={() => setPrintOpen(true)} className="h-11" data-testid="report-print-button"><Printer className="h-4 w-4 mr-2" />{t("reports.printReport")}</Button>
      </>} />
      <div className="flex gap-3 mb-6">
        <Select value={year} onValueChange={setYear}><SelectTrigger className="h-11 w-32" data-testid="report-year-select"><SelectValue /></SelectTrigger><SelectContent>{years.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent></Select>
        <Select value={month} onValueChange={setMonth}><SelectTrigger className="h-11 w-48" data-testid="report-month-select"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{t("reports.wholeYear")}</SelectItem>{months.map((m, i) => <SelectItem key={m} value={String(i + 1).padStart(2, "0")}>{m}</SelectItem>)}</SelectContent></Select>
      </div>
      {data && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <StatCard label={t("reports.income")} value={inr(data.income.total)} icon={TrendingUp} hint={`${t("reports.subscriptions")} ${inr(data.income.subscriptions)} · ${t("reports.donations")} ${inr(data.income.donations)}`} testId="stat-income" />
            <StatCard label={t("reports.expense")} value={inr(data.expenses.total)} icon={TrendingDown} tone="red" testId="stat-expense" delay={60} />
            <StatCard label={t("reports.balance")} value={inr(data.balance)} icon={Scale} tone={data.balance >= 0 ? "gold" : "red"} testId="stat-balance" delay={120} />
          </div>
          {data.monthly.length > 0 && (
            <div className="rounded-xl border border-[#e6dbc9] bg-card p-4 sm:p-5 shadow-sm mb-6">
              <h3 className="font-semibold mb-4">{t("reports.incomeVsExpense")}</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.monthly.map((m) => ({ name: monthLabel(m.month, months, true).slice(0, 3), [t("reports.income")]: m.subscriptions + m.donations, [t("reports.expense")]: m.expenses }))} barGap={2}>
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => (v >= 1000 ? `${v / 1000}k` : v)} />
                    <Tooltip formatter={(v) => inr(v)} /><Legend />
                    <Bar dataKey={t("reports.income")} fill="#0d5c3a" radius={[4, 4, 0, 0]} /><Bar dataKey={t("reports.expense")} fill="#c58b2b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
          <Statement />
          <PrintDialog open={printOpen} onOpenChange={setPrintOpen} title={t("reports.statement")} testId="report-print-dialog"><Statement /></PrintDialog>
        </>
      )}
    </div>
  );
}
