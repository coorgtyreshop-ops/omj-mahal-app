import { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Plus, Clock, MapPin, Image as ImageIcon } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { fmtDate, todayStr } from "@/lib/format";
import { hijri, hijriRangeLabel, addDays } from "@/lib/hijri";
import { PageHeader, EmptyState } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { EventForm } from "@/components/events/EventForm";
import { EventDetail } from "@/components/events/EventDetail";
import { cn } from "@/lib/utils";

const CAT_TONE = { programme: "bg-primary", class: "bg-sky-600", meeting: "bg-slate-600", eid: "bg-[#c58b2b]", nabidinam: "bg-[#0d5c3a]", ramadan: "bg-indigo-700", other: "bg-muted-foreground" };
const monthStart = (ym) => `${ym}-01`;
const monthEnd = (ym) => { const [y, m] = ym.split("-").map(Number); return `${ym}-${String(new Date(Date.UTC(y, m, 0)).getUTCDate()).padStart(2, "0")}`; };
const shiftMonth = (ym, n) => { const [y, m] = ym.split("-").map(Number); const d = new Date(Date.UTC(y, m - 1 + n, 1)); return d.toISOString().slice(0, 7); };

export const EventChip = ({ ev, onClick, compact }) => {
  const { lang } = useLang();
  const title = lang === "ml" && ev.title_ml ? ev.title_ml : lang === "kn" && ev.title_kn ? ev.title_kn : ev.title;
  return (
    <span role="button" tabIndex={0} onClick={onClick} onKeyDown={(e) => e.key === "Enter" && onClick(e)} className={cn("block w-full text-left rounded-md text-white truncate cursor-pointer", compact ? "px-1.5 py-0.5 text-[10px] sm:text-[11px]" : "px-2 py-1 text-xs", CAT_TONE[ev.category] || CAT_TONE.other)} data-testid={`event-chip-${ev.id}`} title={title}>
      {ev.time && !compact && <span className="opacity-80 mr-1">{ev.time}</span>}{title}
    </span>
  );
};

export const EventRow = ({ ev, onClick, adjustment }) => {
  const { t, lang } = useLang();
  const h = hijri(ev.date, adjustment, lang);
  const title = lang === "ml" && ev.title_ml ? ev.title_ml : lang === "kn" && ev.title_kn ? ev.title_kn : ev.title;
  const isToday = ev.date === todayStr();
  return (
    <button type="button" onClick={onClick} className="w-full text-left flex gap-3 rounded-xl border border-[#e6dbc9] bg-card p-3 hover:shadow-md transition-shadow" data-testid={`event-row-${ev.id}`}>
      <div className={cn("shrink-0 w-14 rounded-lg text-center py-1.5", isToday ? "bg-[#d4af37] text-[#1e2923]" : "bg-primary/10 text-primary")}>
        <p className="text-xl font-bold leading-none">{ev.date.slice(8, 10)}</p>
        <p className="text-[10px] font-semibold uppercase">{fmtDate(ev.date).split(" ")[1]}</p>
      </div>
      <div className="min-w-0 flex-1">
        <p className="font-semibold truncate">{title}</p>
        <p className="text-xs text-[#8a6d1d] font-medium">{h.label}</p>
        <p className="text-xs text-muted-foreground flex flex-wrap gap-x-3 mt-0.5">
          {ev.time && <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{ev.time}</span>}
          {ev.venue && <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{ev.venue}</span>}
          <span className="inline-flex items-center gap-1 rounded-full bg-accent px-2">{t(`cal.categories.${ev.category}`)}</span>
        </p>
      </div>
      {ev.poster_url ? <img src={`${process.env.REACT_APP_BACKEND_URL}${ev.poster_url}`} alt="" className="h-14 w-11 rounded object-cover shrink-0" /> : <span className="h-14 w-11 rounded bg-accent grid place-items-center text-muted-foreground shrink-0"><ImageIcon className="h-4 w-4" /></span>}
    </button>
  );
};

export default function CalendarPage() {
  const { t, lang } = useLang();
  const { isAdmin, settings } = useAuth();
  const adj = settings?.hijri_adjustment || 0;
  const [ym, setYm] = useState(todayStr().slice(0, 7));
  const [events, setEvents] = useState([]);
  const [selected, setSelected] = useState(todayStr());
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [detail, setDetail] = useState(null);

  const load = useCallback(() => api.get("/events", { params: { from: addDays(monthStart(ym), -7), to: addDays(monthEnd(ym), 45) } }).then((r) => setEvents(r.data)), [ym]);
  useEffect(() => { load(); }, [load]);

  const byDate = useMemo(() => events.reduce((m, e) => ((m[e.date] = [...(m[e.date] || []), e]), m), {}), [events]);
  const cells = useMemo(() => {
    const start = monthStart(ym), end = monthEnd(ym);
    const lead = new Date(start + "T00:00:00Z").getUTCDay();
    const out = [];
    for (let i = 0; i < lead; i++) out.push(null);
    for (let d = start; d <= end; d = addDays(d, 1)) out.push(d);
    while (out.length % 7) out.push(null);
    return out;
  }, [ym]);
  const todayH = hijri(todayStr(), adj, lang);
  const upcoming = events.filter((e) => e.date >= todayStr()).slice(0, 8);
  const dayEvents = byDate[selected] || [];
  const selH = hijri(selected, adj, lang);
  const onSaved = () => { load(); setFormOpen(false); setEditing(null); };

  return (
    <div data-testid="calendar-page">
      <PageHeader title={t("cal.title")} subtitle={t("cal.subtitle")} actions={isAdmin && <Button onClick={() => { setEditing({ date: selected }); setFormOpen(true); }} className="h-11" data-testid="add-event-button"><Plus className="h-4 w-4 mr-2" />{t("cal.addEvent")}</Button>} />

      <div className="rounded-2xl bg-primary text-white p-4 sm:p-5 mb-6 flex flex-wrap items-center justify-between gap-3 shadow-lg" data-testid="hijri-today-banner">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] opacity-80">{t("cal.hijriToday")}</p>
          <p className="text-2xl sm:text-3xl font-bold" data-testid="hijri-today-label">{todayH.label}</p>
          <p className="text-sm opacity-90">{fmtDate(todayStr())}</p>
        </div>
        <Button variant="secondary" size="sm" onClick={() => { setYm(todayStr().slice(0, 7)); setSelected(todayStr()); }} className="h-9" data-testid="jump-today-button">{t("cal.jumpToday")}</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-3 py-3 border-b border-[#e6dbc9]">
            <Button size="icon" variant="ghost" onClick={() => setYm(shiftMonth(ym, -1))} data-testid="prev-month-button"><ChevronLeft className="h-5 w-5" /></Button>
            <div className="text-center">
              <p className="font-bold text-lg" data-testid="calendar-month-label">{new Date(ym + "-01T00:00:00Z").toLocaleDateString(lang === "ml" ? "ml-IN" : lang === "kn" ? "kn-IN" : "en-IN", { month: "long", year: "numeric", timeZone: "UTC" })}</p>
              <p className="text-xs text-[#8a6d1d] font-semibold" data-testid="calendar-hijri-range">{hijriRangeLabel(monthStart(ym), monthEnd(ym), adj, lang)}</p>
            </div>
            <Button size="icon" variant="ghost" onClick={() => setYm(shiftMonth(ym, 1))} data-testid="next-month-button"><ChevronRight className="h-5 w-5" /></Button>
          </div>
          <div className="grid grid-cols-7 text-center text-[11px] font-bold uppercase tracking-wide text-muted-foreground border-b border-[#e6dbc9]">
            {t("cal.weekdays").map((w, i) => <div key={w} className={cn("py-2", i === 5 && "text-primary")}>{w}</div>)}
          </div>
          <div className="grid grid-cols-7" data-testid="calendar-grid">
            {cells.map((d, i) => {
              if (!d) return <div key={`e${i}`} className="min-h-[64px] sm:min-h-[92px] border-b border-r border-[#f0e8da] bg-[#faf8f5]/60" />;
              const h = hijri(d, adj, lang);
              const isToday = d === todayStr(), isSel = d === selected, fri = i % 7 === 5;
              return (
                <button type="button" key={d} onClick={() => setSelected(d)} data-testid={`day-${d}`}
                  className={cn("min-h-[64px] sm:min-h-[92px] border-b border-r border-[#f0e8da] p-1 text-left flex flex-col transition-colors hover:bg-accent/60", isSel && "bg-[#d4af37]/15", fri && !isSel && "bg-primary/[0.04]")}>
                  <div className="flex items-start justify-between">
                    <span className={cn("grid h-6 w-6 place-items-center rounded-full text-sm font-semibold", isToday && "bg-primary text-white")}>{Number(d.slice(8, 10))}</span>
                    <span className={cn("text-[10px] font-bold", h.day === 1 ? "text-[#a06f1c]" : "text-[#8a6d1d]/80")}>{h.day === 1 ? `${h.day} ${h.monthName}` : h.day}</span>
                  </div>
                  <div className="mt-auto space-y-0.5 hidden sm:block">{(byDate[d] || []).slice(0, 2).map((ev) => <EventChip key={ev.id} ev={ev} compact onClick={(e) => { e.stopPropagation(); setDetail(ev); }} />)}{(byDate[d] || []).length > 2 && <p className="text-[10px] text-muted-foreground">+{byDate[d].length - 2}</p>}</div>
                  {(byDate[d] || []).length > 0 && <div className="sm:hidden mt-auto flex gap-0.5">{byDate[d].slice(0, 3).map((ev) => <span key={ev.id} className={cn("h-1.5 w-1.5 rounded-full", CAT_TONE[ev.category] || CAT_TONE.other)} />)}</div>}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-6">
          <section className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm p-4" data-testid="selected-day-panel">
            <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground">{fmtDate(selected)}</p>
            <p className="font-bold text-[#8a6d1d]" data-testid="selected-hijri-label">{selH.label}</p>
            <div className="mt-3 space-y-2">
              {dayEvents.length === 0 ? <p className="text-sm text-muted-foreground" data-testid="no-events-day">{t("cal.noEvents")}</p> : dayEvents.map((ev) => <EventRow key={ev.id} ev={ev} adjustment={adj} onClick={() => setDetail(ev)} />)}
            </div>
            {isAdmin && <Button variant="outline" size="sm" onClick={() => { setEditing({ date: selected }); setFormOpen(true); }} className="mt-3 h-9 w-full" data-testid="add-event-day-button"><Plus className="h-4 w-4 mr-1" />{t("cal.addEvent")}</Button>}
          </section>
          <section data-testid="upcoming-panel">
            <h2 className="font-bold mb-2">{t("cal.upcoming")}</h2>
            {upcoming.length === 0 ? <EmptyState text={t("cal.noUpcoming")} /> : <div className="space-y-2">{upcoming.map((ev) => <EventRow key={ev.id} ev={ev} adjustment={adj} onClick={() => setDetail(ev)} />)}</div>}
          </section>
        </div>
      </div>

      <EventForm open={formOpen} onOpenChange={(o) => { setFormOpen(o); if (!o) setEditing(null); }} item={editing} onSaved={onSaved} />
      {detail && <EventDetail eventId={detail.id} onClose={() => { setDetail(null); load(); }} onEdit={(ev) => { setDetail(null); setEditing(ev); setFormOpen(true); }} />}
    </div>
  );
}
