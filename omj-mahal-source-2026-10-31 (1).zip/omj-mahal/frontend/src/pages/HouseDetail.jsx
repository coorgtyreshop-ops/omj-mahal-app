import { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { toast } from "sonner";
import { ArrowLeft, Plus, Pencil, Trash2, Phone, MapPin, Printer, CreditCard, Users, Wallet, AlertCircle, UsersRound, KeyRound } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, monthLabel, fmtDate } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete, StatusBadge, StatCard } from "@/components/shared";
import { HouseForm, MemberForm } from "@/components/forms/HouseMemberForms";
import { FamilyQuickAdd } from "@/components/forms/FamilyQuickAdd";
import { PrintDialog, ReceiptBody } from "@/components/print/Printables";
import { Photo, TypeBadge } from "@/components/MemberCard";
import { MemberCardDialog } from "@/components/MemberCardDialog";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { HouseLoginCard } from "@/components/HouseLogin";
import { HouseCollections, EditPaymentDialog, PaymentRowActions } from "@/components/finance/HouseCollections";
import { typeLabel } from "@/components/forms/CollectionPaymentForm";
import { ReleaseButton, ReviewPendingCard } from "@/components/finance/ReleaseStatement";
import { SubMemberLoginDialog } from "@/components/SubMemberLogin";
import { occLabel, eduLabel } from "@/components/forms/HouseMemberForms";
import { cn } from "@/lib/utils";

const FamilyRow = ({ m, isAdmin, onEdit, onDelete, onCard, onLogin, share }) => {
  const { t } = useLang();
  const head = m.member_type === "head";
  const pays = head || m.member_type === "sub";
  return (
    <TableRow data-testid={`member-row-${m.id}`} className={cn(head && "bg-[#d4af37]/10")}>
      <TableCell>
        <div className="flex items-center gap-3">
          <Photo src={m.photo_url} name={m.name} className="h-10 w-9 rounded-lg ring-1" />
          <div className="min-w-0">
            <p className={cn("font-medium truncate", head && "font-bold")}>{m.name}</p>
            <p className="text-xs text-muted-foreground font-mono">{m.member_no}</p>
            {m.member_type === "sub" && m.phone && <p className="text-xs text-[#128C7E]" data-testid={`member-phone-${m.id}`}>📱 {m.phone}</p>}
          </div>
        </div>
      </TableCell>
      <TableCell><TypeBadge type={m.member_type} />{pays && share > 0 && <p className="text-[11px] text-[#a06f1c] font-semibold mt-1 whitespace-nowrap" data-testid={`member-share-${m.id}`}>{t("members.preview.perMonth", { amt: share })}</p>}</TableCell>
      <TableCell className="hidden sm:table-cell">{m.relation ? t(`members.relations.${m.relation}`) : ""}</TableCell>
      <TableCell className="hidden sm:table-cell" data-testid={`member-dob-${m.id}`}>{m.dob ? <><span>{fmtDate(m.dob)}</span><span className="text-xs text-muted-foreground ml-1">({m.age})</span></> : ""}</TableCell>
      <TableCell className="hidden md:table-cell">{m.status ? t(`mstatus.${m.status}`) : ""}{(m.occupation || m.education) ? <span className="text-xs text-muted-foreground block" data-testid={`member-work-${m.id}`}>{m.status === "student" ? eduLabel(t, m.education) : [occLabel(t, m.occupation), m.occupation_detail].filter(Boolean).join(" · ")}</span> : null}{m.member_type === "sub" && m.login_id && <span className="text-[10px] text-[#0d5c3a] block" data-testid={`member-login-${m.id}`}>🔑 {m.login_id}</span>}</TableCell>
      <TableCell className="hidden lg:table-cell">{m.blood_group}</TableCell>
      <TableCell className="text-right whitespace-nowrap">
        <Button size="icon" variant="ghost" onClick={() => onCard(m)} title={t("card.view")} data-testid={`card-member-${m.id}`}><CreditCard className="h-4 w-4" /></Button>
        {isAdmin && <>
          {m.member_type === "sub" && <Button size="icon" variant="ghost" className={m.login_id ? "text-[#0d5c3a]" : "text-[#a06f1c]"} onClick={() => onLogin(m)} title={t("members.subLogin.button")} data-testid={`login-member-${m.id}`}><KeyRound className="h-4 w-4" /></Button>}
          <Button size="icon" variant="ghost" onClick={() => onEdit(m)} data-testid={`edit-member-${m.id}`}><Pencil className="h-4 w-4" /></Button>
          <Button size="icon" variant="ghost" className="text-destructive" onClick={() => onDelete(m)} data-testid={`delete-member-${m.id}`}><Trash2 className="h-4 w-4" /></Button>
        </>}
      </TableCell>
    </TableRow>
  );
};

export default function HouseDetail() {
  const { id } = useParams();
  const { t, months } = useLang();
  const { isAdmin, user, settings } = useAuth();
  const houseId = id || user?.house_id;
  const [house, setHouse] = useState(null);
  const [memberOpen, setMemberOpen] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [houseOpen, setHouseOpen] = useState(false);
  const [familyOpen, setFamilyOpen] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [receipt, setReceipt] = useState(null);
  const [cardFor, setCardFor] = useState(null);
  const [loginFor, setLoginFor] = useState(null);
  const [editPay, setEditPay] = useState(null);
  const [delPay, setDelPay] = useState(null);

  const load = useCallback(async () => {
    if (!houseId) return setHouse({});
    const { data } = await api.get(`/houses/${houseId}`);
    setHouse(data);
  }, [houseId]);

  useEffect(() => { load(); }, [load]);

  const removePayment = async () => {
    try { await api.delete(`/payments/${delPay.id}`); toast.success(t("common.deleted")); setDelPay(null); load(); }
    catch (e) { toast.error(apiError(e)); }
  };
  const removeMember = async () => {
    try { await api.delete(`/members/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  if (!house) return <p className="text-muted-foreground">{t("common.loading")}</p>;
  if (!house.id) return <EmptyState text={t("houses.noHouses")} />;
  const tc = house.type_counts || {};

  return (
    <div data-testid="house-detail-page">
      {isAdmin && <Link to="/houses" className="inline-flex items-center gap-1 text-sm text-primary font-medium mb-3 hover:underline" data-testid="back-to-houses"><ArrowLeft className="h-4 w-4" />{t("common.back")}</Link>}
      <PageHeader
        title={<span><span className="text-primary">{house.house_no}</span> · {house.head_name}</span>}
        subtitle={<span className="flex flex-wrap gap-x-4 gap-y-1"><span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{house.address}{house.ward ? `, ${house.ward}` : ""}</span>{house.phone && <a href={`tel:${house.phone}`} className="inline-flex items-center gap-1 text-primary"><Phone className="h-3.5 w-3.5" />{house.phone}</a>}</span>}
        actions={isAdmin && <Button variant="outline" onClick={() => setHouseOpen(true)} className="h-11" data-testid="edit-house-button"><Pencil className="h-4 w-4 mr-2" />{t("houses.editHouse")}</Button>}
      />

      {isAdmin && (
        <div className="rounded-xl border border-[#e6dbc9] bg-card p-3 mb-6 flex flex-wrap items-center justify-between gap-3" data-testid="release-panel">
          <p className="text-sm font-semibold">{t("fin.release.status")}</p>
          <ReleaseButton house={house} onDone={load} />
        </div>
      )}

      {!isAdmin && !house.statement_released && <div className="mb-8"><ReviewPendingCard /></div>}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5 mb-8">
        <StatCard label={t("houses.subscription")} value={inr(house.subscription_amount)} icon={Wallet} tone="gold" testId="house-subscription" />
        <StatCard label={t("houses.members")} value={house.members.length} hint={`${tc.sub || 0} ${t("mtype.sub")} · ${tc.family || 0} ${t("mtype.family")}`} icon={Users} testId="house-member-count" delay={60} />
        {house.dues && <>
        <StatCard label={t("houses.dues")} value={inr(house.dues.pending_amount)} hint={house.dues.pending_count ? `${house.dues.pending_count} ${t("subs.monthsCount")}` : t("houses.clear")} icon={AlertCircle} tone={house.dues.pending_count ? "amber" : "emerald"} testId="house-dues" delay={120} />
        <div className="stat-in rounded-xl border border-[#e6dbc9] bg-card p-4 shadow-sm" style={{ animationDelay: "180ms" }}>
          <p className="text-xs sm:text-sm font-medium text-muted-foreground mb-2">{t("houses.pendingMonths")}</p>
          <div className="flex flex-wrap gap-1.5" data-testid="house-pending-months">
            {house.dues.pending_months.length ? house.dues.pending_months.map((m) => <span key={m} className="rounded-full bg-[#c58b2b]/10 text-[#a06f1c] px-2 py-0.5 text-[11px] font-semibold">{monthLabel(m, months, true)}</span>) : <StatusBadge ok>{t("houses.clear")}</StatusBadge>}
          </div>
        </div>
        </>}
      </div>

      {isAdmin && <div className="mb-8"><HouseLoginCard house={house} onChanged={load} /></div>}

      <section className="mb-8">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div>
            <h2 className="text-lg font-bold">{t("houses.familyMembers")}</h2>
            <p className="text-xs text-muted-foreground" data-testid="house-type-counts">{["head", "sub", "family"].map((k) => `${tc[k] || 0} ${t(`mtype.${k}`)}`).join(" · ")}</p>
          </div>
          {isAdmin && <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setFamilyOpen(true)} className="h-10" data-testid="add-family-button"><UsersRound className="h-4 w-4 mr-1" />{t("houses.addFamily")}</Button>
            <Button size="sm" onClick={() => { setEditingMember(null); setMemberOpen(true); }} className="h-10" data-testid="add-member-button"><Plus className="h-4 w-4 mr-1" />{t("houses.addMember")}</Button>
          </div>}
        </div>
        <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
          {house.members.length === 0 ? <EmptyState text={t("members.noMembers")} /> : (
            <Table data-testid="house-members-table">
              <TableHeader><TableRow className="bg-accent/60">
                <TableHead>{t("members.name")}</TableHead><TableHead>{t("card.type")}</TableHead>
                <TableHead className="hidden sm:table-cell">{t("members.relation")}</TableHead><TableHead className="hidden sm:table-cell">{t("members.dob")}</TableHead>
                <TableHead className="hidden md:table-cell">{t("mstatus.label")}</TableHead><TableHead className="hidden lg:table-cell">{t("members.bloodGroup")}</TableHead>
                <TableHead className="text-right">{t("common.actions")}</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {house.members.map((m) => <FamilyRow key={m.id} m={m} share={Number(house.subscription_amount) || 0} isAdmin={isAdmin} onCard={(x) => setCardFor(x.id)} onLogin={setLoginFor} onEdit={(x) => { setEditingMember(x); setMemberOpen(true); }} onDelete={setDeleting} />)}
              </TableBody>
            </Table>
          )}
        </div>
      </section>

      {isAdmin && <HouseCollections house={house} onChanged={load} />}

      {(isAdmin || house.statement_released) && <section>
        <h2 className="text-lg font-bold mb-3">{t("houses.paymentHistory")}</h2>
        <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
          {house.payments.length === 0 ? <EmptyState text={t("subs.noPayments")} /> : (
            <Table data-testid="house-payments-table">
              <TableHeader><TableRow className="bg-accent/60">
                <TableHead>{t("common.receiptNo")}</TableHead><TableHead>{t("common.date")}</TableHead><TableHead>{t("fin.type")}</TableHead><TableHead className="hidden md:table-cell">{t("subs.paidMonths")}</TableHead>
                <TableHead className="hidden sm:table-cell">{t("common.mode")}</TableHead><TableHead className="text-right">{t("common.amount")}</TableHead><TableHead />
              </TableRow></TableHeader>
              <TableBody>
                {house.payments.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="font-mono text-xs">{p.receipt_no}</TableCell>
                    <TableCell>{fmtDate(p.date)}</TableCell>
                    <TableCell className="text-sm font-medium">{typeLabel(t, p.type || "varisankhya", settings)}</TableCell>
                    <TableCell className="hidden md:table-cell text-sm">{(p.months || p.years || []).map((m) => (p.type && p.type !== "varisankhya" ? m : monthLabel(m, months, true))).join(", ")}</TableCell>
                    <TableCell className="hidden sm:table-cell">{t(`paymentModes.${p.mode}`)}</TableCell>
                    <TableCell className="text-right font-semibold">{inr(p.amount)}</TableCell>
                    <TableCell className="text-right whitespace-nowrap"><Button size="icon" variant="ghost" onClick={() => setReceipt({ ...p, house_no: house.house_no, head_name: house.head_name })} data-testid={`print-receipt-${p.receipt_no}`}><Printer className="h-4 w-4" /></Button>{isAdmin && <PaymentRowActions p={p} onEdit={setEditPay} onDelete={setDelPay} />}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </section>}

      <MemberForm open={memberOpen} onOpenChange={setMemberOpen} member={editingMember} houseId={house.id} onSaved={load} />
      <FamilyQuickAdd open={familyOpen} onOpenChange={setFamilyOpen} house={house} onSaved={load} />
      <HouseForm open={houseOpen} onOpenChange={setHouseOpen} house={house} onSaved={load} />
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={removeMember} />
      <ConfirmDelete open={!!delPay} onOpenChange={(o) => !o && setDelPay(null)} onConfirm={removePayment} />
      <EditPaymentDialog payment={editPay} onOpenChange={(o) => !o && setEditPay(null)} onSaved={load} />
      <MemberCardDialog memberId={cardFor} open={!!cardFor} onOpenChange={(o) => !o && setCardFor(null)} canEditPhoto onChanged={load} />
      <SubMemberLoginDialog key={loginFor?.id || "none"} member={loginFor} open={!!loginFor} onOpenChange={(o) => !o && setLoginFor(null)} onDone={load} />
      <PrintDialog open={!!receipt} onOpenChange={(o) => !o && setReceipt(null)} title={t("subs.receipt")} testId="receipt-dialog">
        {receipt && <ReceiptBody payment={receipt} settings={settings} />}
      </PrintDialog>
    </div>
  );
}
