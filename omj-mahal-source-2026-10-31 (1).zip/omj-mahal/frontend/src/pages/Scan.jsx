import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { Search, ImageUp, ScanLine } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { PageHeader } from "@/components/shared";
import { QrScanner, memberNoFrom } from "@/components/scan/QrScanner";
import { ScanResult, IdentityOnly } from "@/components/scan/ScanResult";
import { readQr } from "@/components/finance/UpiQrUpload";
import { CollectionPaymentForm } from "@/components/forms/CollectionPaymentForm";
import { PrintDialog, ReceiptBody } from "@/components/print/Printables";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const ERRORS = { committee_only: "scan.noAccess", not_released: "scan.notReleased" };

export default function Scan() {
  const { t } = useLang();
  const { settings } = useAuth();
  const [params, setParams] = useSearchParams();
  const [memberNo, setMemberNo] = useState((params.get("m") || "").toUpperCase());
  const [scope, setScope] = useState("auto");
  const [manual, setManual] = useState("");
  const [data, setData] = useState(null);
  const [identity, setIdentity] = useState(null);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [payFor, setPayFor] = useState(null);
  const [receipt, setReceipt] = useState(null);
  const fileRef = useRef(null);

  const load = useCallback(async (no, sc) => {
    if (!no) return;
    setLoading(true);
    try {
      const r = await api.get(`/finance/scan/${encodeURIComponent(no)}`, { params: { scope: sc } });
      setData(r.data); setIdentity(null); setMessage("");
    } catch (err) {
      setData(null);
      const detail = err?.response?.data?.detail;
      setMessage(err?.response?.status === 404 ? "" : ERRORS[detail] ? t(ERRORS[detail]) : apiError(err));
      try { const r = await api.get(`/public/verify/${encodeURIComponent(no)}`); setIdentity(r.data); } catch { setIdentity(null); }
    } finally { setLoading(false); }
  }, [t]);

  useEffect(() => { load(memberNo, scope); }, [memberNo, scope, load]);
  const live = !!data;
  useEffect(() => {
    if (!memberNo || !live) return undefined;
    const id = setInterval(() => load(memberNo, scope), 15000);
    return () => clearInterval(id);
  }, [memberNo, scope, live, load]);

  const found = useCallback((text) => {
    const no = memberNoFrom(text);
    if (!no) return toast.error(t("scan.notQr"));
    setScope("auto"); setData(null); setIdentity(null); setMessage("");
    setMemberNo(no); setParams({ m: no }, { replace: true });
    return undefined;
  }, [t, setParams]);
  const rescan = () => { setMemberNo(""); setData(null); setIdentity(null); setMessage(""); setManual(""); setParams({}, { replace: true }); };
  const onFile = async (e) => {
    const file = e.target.files?.[0]; e.target.value = "";
    if (!file) return;
    const text = await readQr(file);
    if (!text) return toast.error(t("scan.notQr"));
    found(text);
  };

  return (
    <div data-testid="scan-page">
      <PageHeader title={t("scan.title")} subtitle={t("scan.subtitle")} />
      {!memberNo ? (
        <div className="max-w-2xl space-y-4">
          <QrScanner active={!memberNo} onResult={found} />
          <form onSubmit={(e) => { e.preventDefault(); if (manual.trim()) found(manual.trim()); }} className="rounded-2xl border border-[#e6dbc9] bg-card p-4 shadow-sm space-y-3" data-testid="scan-manual">
            <p className="text-sm font-semibold">{t("scan.manualTitle")}</p>
            <div className="flex gap-2">
              <Input value={manual} onChange={(e) => setManual(e.target.value)} placeholder="OMJ-0001 / 001" className="h-11 font-mono uppercase" data-testid="scan-manual-input" />
              <Button type="submit" className="h-11" data-testid="scan-manual-button"><Search className="h-4 w-4 mr-1" />{t("scan.search")}</Button>
            </div>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onFile} data-testid="scan-file-input" />
            <Button type="button" variant="outline" className="h-11" onClick={() => fileRef.current?.click()} data-testid="scan-upload-button"><ImageUp className="h-4 w-4 mr-1" />{t("scan.upload")}</Button>
          </form>
        </div>
      ) : loading && !data && !identity ? (
        <p className="text-muted-foreground flex items-center gap-2" data-testid="scan-loading"><ScanLine className="h-4 w-4 animate-pulse" />{t("common.loading")} · <span className="font-mono">{memberNo}</span></p>
      ) : data ? (
        <ScanResult data={data} loading={loading} onRecord={setPayFor} onRescan={rescan} onScope={setScope} onRefresh={() => load(memberNo, scope)} />
      ) : (
        <IdentityOnly identity={identity} memberNo={memberNo} message={message} onRescan={rescan} />
      )}
      {data && (
        <CollectionPaymentForm open={!!payFor} onOpenChange={(o) => !o && setPayFor(null)} houses={[data.house]} presetHouse={data.house.id} presetType={payFor || "varisankhya"} presetMember={data.scope === "member" ? data.member.id : "head"}
          onSaved={(p, kind) => { load(memberNo, scope); setReceipt({ p, kind }); }} />
      )}
      <PrintDialog open={!!receipt} onOpenChange={(o) => !o && setReceipt(null)} title={t("subs.receipt")} testId="receipt-dialog">
        {receipt && <ReceiptBody payment={receipt.p} kind={receipt.kind} settings={settings} />}
      </PrintDialog>
    </div>
  );
}
