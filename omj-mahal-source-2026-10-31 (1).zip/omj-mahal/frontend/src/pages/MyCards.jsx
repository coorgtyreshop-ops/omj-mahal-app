import { useCallback, useEffect, useState } from "react";
import { CreditCard } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { PageHeader, EmptyState } from "@/components/shared";
import { Photo, TypeBadge } from "@/components/MemberCard";
import { MemberCardDialog } from "@/components/MemberCardDialog";
import { Button } from "@/components/ui/button";

export default function MyCards() {
  const { t } = useLang();
  const { user } = useAuth();
  const [members, setMembers] = useState([]);
  const [viewing, setViewing] = useState(null);

  const load = useCallback(async () => { const { data } = await api.get("/members", { params: { house_id: user.house_id } }); setMembers(data); }, [user.house_id]);
  useEffect(() => { if (user.house_id) load(); }, [load, user.house_id]);

  const order = { head: 0, sub: 1, family: 2 };
  const sorted = [...members].sort((a, b) => (order[a.member_type] ?? 9) - (order[b.member_type] ?? 9));

  return (
    <div data-testid="my-cards-page">
      <PageHeader title={t("card.my")} subtitle={t("mtype.legend")} />
      {sorted.length === 0 ? <EmptyState text={t("card.noCards")} /> : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {sorted.map((m, i) => (
            <div key={m.id} className="stat-in rounded-xl border border-[#e6dbc9] bg-card p-4 shadow-sm flex items-center gap-4" style={{ animationDelay: `${i * 50}ms` }} data-testid={`my-card-${m.id}`}>
              <Photo src={m.photo_url} name={m.name} className="h-16 w-14" />
              <div className="min-w-0 flex-1">
                <p className="font-bold truncate">{m.name}</p>
                <p className="font-mono text-xs text-muted-foreground">{m.member_no}</p>
                <div className="flex flex-wrap gap-1 mt-1"><TypeBadge type={m.member_type} />{m.relation && <span className="text-xs text-muted-foreground">{t(`members.relations.${m.relation}`)}</span>}</div>
              </div>
              <Button size="sm" onClick={() => setViewing(m.id)} className="h-10 shrink-0" data-testid={`view-card-${m.id}`}><CreditCard className="h-4 w-4 mr-1" />{t("card.view")}</Button>
            </div>
          ))}
        </div>
      )}
      <MemberCardDialog memberId={viewing} open={!!viewing} onOpenChange={(o) => !o && setViewing(null)} canEditPhoto onChanged={load} />
    </div>
  );
}
