import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Plus, Download, Search, Pencil, Trash2, CreditCard } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { downloadCsv, fmtDate } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete } from "@/components/shared";
import { MemberForm } from "@/components/forms/HouseMemberForms";
import { Photo, TypeBadge } from "@/components/MemberCard";
import { MemberCardDialog } from "@/components/MemberCardDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { cn } from "@/lib/utils";

const TYPES = ["head", "sub", "family"];
const isWidow = (m) => m.marital_status === "widowed" && m.gender !== "male";

export default function Members() {
  const { t } = useLang();
  const [members, setMembers] = useState([]);
  const [houses, setHouses] = useState([]);
  const [q, setQ] = useState("");
  const [houseFilter, setHouseFilter] = useState("all");
  const [type, setType] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [cardFor, setCardFor] = useState(null);

  const load = useCallback(async () => {
    const { data } = await api.get("/members", { params: { q: q || undefined, house_id: houseFilter !== "all" ? houseFilter : undefined } });
    setMembers(data);
  }, [q, houseFilter]);

  useEffect(() => { const id = setTimeout(load, 250); return () => clearTimeout(id); }, [load]);
  useEffect(() => { api.get("/houses").then((r) => setHouses(r.data)); }, []);

  const counts = useMemo(() => ({ ...TYPES.reduce((acc, k) => ({ ...acc, [k]: members.filter((m) => m.member_type === k).length }), {}), widows: members.filter(isWidow).length }), [members]);
  const rows = type === "all" ? members : type === "widows" ? members.filter(isWidow) : members.filter((m) => m.member_type === type);

  const remove = async () => {
    try { await api.delete(`/members/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  const exportCsv = () =>
    downloadCsv("members.csv", ["Member No", "Name", "House No", "Category", "Relation", "Gender", "DOB", "Age", "Status", "Occupation", "Marital Status", "Education", "Blood Group", "Phone"],
      rows.map((m) => [m.member_no, m.name, m.house_no, t(`mtype.${m.member_type}`), m.relation, m.gender, m.dob, m.age, m.status, m.occupation, m.marital_status, m.education, m.blood_group, m.phone]));

  return (
    <div data-testid="members-page">
      <PageHeader title={t("members.title")} subtitle={`${members.length} ${t("houses.members").toLowerCase()}`} actions={<>
        <Button variant="outline" onClick={exportCsv} className="h-11" data-testid="members-export-button"><Download className="h-4 w-4 mr-2" />{t("common.export")}</Button>
        <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="h-11" data-testid="add-member-button"><Plus className="h-4 w-4 mr-2" />{t("members.addMember")}</Button>
      </>} />

      <div className="flex flex-wrap gap-2 mb-4" data-testid="member-type-filters">
        {["all", ...TYPES, "widows"].map((k) => (
          <button key={k} type="button" onClick={() => setType(k)} data-testid={`type-filter-${k}`}
            className={cn("h-10 rounded-full border px-4 text-sm font-semibold transition-colors", type === k ? "bg-primary text-primary-foreground border-primary" : k === "widows" ? "bg-[#c58b2b]/10 border-[#c58b2b]/40 text-[#a06f1c] hover:bg-[#c58b2b]/20" : "bg-card hover:bg-accent")}>
            {k === "all" ? t("mtype.all") : t(`mtype.${k}`)} <span className={cn("ml-1 rounded-full px-1.5 text-xs", type === k ? "bg-white/20" : "bg-muted")} data-testid={`type-count-${k}`}>{k === "all" ? members.length : counts[k]}</span>
          </button>
        ))}
      </div>
      <p className="text-xs text-muted-foreground mb-4">{t("mtype.legend")}</p>

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("members.searchPlaceholder")} className="h-11 pl-10" data-testid="members-search-input" />
        </div>
        <Select value={houseFilter} onValueChange={setHouseFilter}>
          <SelectTrigger className="h-11 sm:w-64" data-testid="members-house-filter"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("common.all")}</SelectItem>
            {houses.map((h) => <SelectItem key={h.id} value={h.id}>{h.house_no} — {h.head_name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        {rows.length === 0 ? <EmptyState text={t("members.noMembers")} /> : (
          <Table data-testid="members-table">
            <TableHeader><TableRow className="bg-accent/60">
              <TableHead>{t("members.name")}</TableHead><TableHead>{t("card.type")}</TableHead><TableHead>{t("members.house")}</TableHead>
              <TableHead className="hidden sm:table-cell">{t("members.relation")}</TableHead><TableHead className="hidden md:table-cell">{t("members.dob")}</TableHead>
              <TableHead className="hidden md:table-cell">{t("mstatus.label")}</TableHead>
              <TableHead className="text-right">{t("common.actions")}</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((m) => (
                <TableRow key={m.id} data-testid={`member-row-${m.id}`}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Photo src={m.photo_url} name={m.name} className="h-10 w-9 rounded-lg ring-1" />
                      <div className="min-w-0"><p className="font-medium truncate">{m.name}{isWidow(m) && <span className="ml-2 rounded-full bg-[#c58b2b]/15 px-2 text-[10px] font-semibold text-[#a06f1c]" data-testid={`widow-badge-${m.id}`}>{t("mtype.widow")}</span>}</p><p className="text-xs text-muted-foreground font-mono" data-testid={`member-no-${m.id}`}>{m.member_no}</p></div>
                    </div>
                  </TableCell>
                  <TableCell><TypeBadge type={m.member_type} /></TableCell>
                  <TableCell><Link to={`/houses/${m.house_id}`} className="text-primary font-semibold hover:underline">{m.house_no}</Link><span className="text-xs text-muted-foreground ml-1 hidden md:inline">{m.ward}</span></TableCell>
                  <TableCell className="hidden sm:table-cell">{m.relation ? t(`members.relations.${m.relation}`) : ""}</TableCell>
                  <TableCell className="hidden md:table-cell" data-testid={`member-dob-${m.id}`}>{m.dob ? <><span>{fmtDate(m.dob)}</span><span className="text-xs text-muted-foreground ml-1">({m.age})</span></> : ""}</TableCell>
                  <TableCell className="hidden md:table-cell">{m.status ? t(`mstatus.${m.status}`) : m.occupation}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    <Button size="icon" variant="ghost" onClick={() => setCardFor(m.id)} title={t("card.view")} data-testid={`card-member-${m.id}`}><CreditCard className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => { setEditing(m); setFormOpen(true); }} data-testid={`edit-member-${m.id}`}><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" className="text-destructive" onClick={() => setDeleting(m)} data-testid={`delete-member-${m.id}`}><Trash2 className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      <MemberForm open={formOpen} onOpenChange={setFormOpen} member={editing} houses={houses} onSaved={load} />
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
      <MemberCardDialog memberId={cardFor} open={!!cardFor} onOpenChange={(o) => !o && setCardFor(null)} canEditPhoto onChanged={load} />
    </div>
  );
}
