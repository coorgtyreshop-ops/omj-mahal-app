import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { IdCard, Lock, HelpCircle, Eye } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { apiError } from "@/lib/api";
import { logoSrc, mahalName, appName } from "@/lib/branding";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { OtpPanel } from "@/components/OtpPanel";
import { Ticker } from "@/components/Ticker";
import { PosterShowcase } from "@/components/events/PosterShowcase";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const PasswordForm = ({ onForgot }) => {
  const { t } = useLang();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      await login(loginId.trim().toUpperCase(), password);
      navigate("/");
    } catch (err) {
      setError(err?.response?.status === 401 ? t("invalidLogin") : apiError(err, t("common.error")));
    } finally { setLoading(false); }
  };

  return (
    <form onSubmit={submit} className="space-y-5" data-testid="login-form">
      <div className="space-y-2">
        <Label htmlFor="login-id">{t("loginId")}</Label>
        <div className="relative">
          <IdCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="login-id" data-testid="login-id-input" autoCapitalize="characters" autoComplete="username" value={loginId} onChange={(e) => setLoginId(e.target.value.toUpperCase())} className="h-12 pl-10 text-base font-mono tracking-wider uppercase" placeholder={t("loginIdPlaceholder")} required />
        </div>
        <p className="text-xs text-muted-foreground" data-testid="login-id-hint">{t("loginIdHint")}</p>
      </div>
      <div className="space-y-2">
        <div className="flex items-center justify-between"><Label htmlFor="password">{t("password")}</Label><button type="button" onClick={onForgot} className="text-xs font-semibold text-primary hover:underline" data-testid="forgot-password-link">{t("otp.forgot")}</button></div>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="password" data-testid="login-password-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="h-12 pl-10 text-base" required />
        </div>
      </div>
      {error && <p className="text-sm text-destructive bg-destructive/5 border border-destructive/20 rounded-md px-3 py-2" data-testid="login-error">{error}</p>}
      <Button type="submit" disabled={loading} className="w-full h-12 text-base font-semibold" data-testid="login-submit-button">{loading ? t("signingIn") : t("signIn")}</Button>
    </form>
  );
};

export default function Login() {
  const { t, lang } = useLang();
  const { settings } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState("login");
  const [tab, setTab] = useState("password");
  const name = mahalName(settings, lang);
  const short = appName(settings);
  const guestOn = settings?.guest_mode_enabled !== false;

  return (
    <div className="min-h-screen grid lg:grid-cols-[1.1fr_1fr]">
      <div className="hidden lg:flex flex-col justify-between islamic-pattern text-white p-12 relative overflow-hidden">
        <div className="flex items-center gap-3">
          <img src={logoSrc(settings)} alt="" className="h-14 w-14 rounded-full ring-2 ring-[#d4af37] bg-white object-cover" data-testid="login-logo" />
          <span className="text-xs uppercase tracking-[0.25em] text-[#d4af37]">{short}</span>
        </div>
        <div className="max-w-md">
          <h1 className="text-5xl xl:text-6xl font-bold leading-tight" data-testid="login-app-name">{short}</h1>
          <p className="text-xl text-white/85 mt-3">{name}</p>
          <div className="gold-rule my-6 w-40 !bg-[linear-gradient(90deg,#d4af37,transparent)]" />
          <p className="text-white/80 text-lg leading-relaxed">{t("loginSubtitle")}</p>
          <div className="mt-6"><PosterShowcase to="/guest?tab=events" compact className="ring-1 ring-white/15" /></div>
          <div className="mt-8 flex gap-4 text-sm text-white/70"><span>English</span><span className="text-[#d4af37]">•</span><span>മലയാളം</span><span className="text-[#d4af37]">•</span><span>ಕನ್ನಡ</span></div>
        </div>
        <p className="text-xs text-white/50">© {new Date().getFullYear()} {settings?.mahal_name || "Mahal Committee"}</p>
      </div>

      <div className="flex flex-col bg-background">
        <Ticker to="/guest?tab=announcements" />
        <div className="lg:hidden px-4 pt-3"><PosterShowcase to="/guest?tab=events" compact /></div>
        <div className="flex justify-between items-center p-4 sm:p-6">
          <div className="lg:hidden flex items-center gap-2 min-w-0">
            <img src={logoSrc(settings)} alt="" className="h-10 w-10 rounded-full ring-2 ring-[#d4af37] bg-white object-cover" />
            <div className="min-w-0"><p className="font-bold leading-tight">{short}</p><p className="text-xs text-muted-foreground truncate">{name}</p></div>
          </div>
          <LanguageSwitcher className="ml-auto" />
        </div>
        <div className="flex-1 flex items-center justify-center px-5 pb-12">
          <div className="w-full max-w-md space-y-6">
            {mode === "forgot" ? (
              <>
                <div><h2 className="text-3xl font-bold tracking-tight">{t("otp.resetTitle")}</h2></div>
                <OtpPanel purpose="reset" onDone={() => { setMode("login"); setTab("password"); }} onBack={() => setMode("login")} />
              </>
            ) : (
              <>
                <div>
                  <h2 className="text-3xl font-bold tracking-tight">{t("login")}</h2>
                  <p className="text-muted-foreground mt-1">{tab === "otp" ? t("otp.subtitle") : t("loginSubtitle")}</p>
                </div>
                <Tabs value={tab} onValueChange={setTab}>
                  <TabsList className="grid grid-cols-2 h-12 w-full">
                    <TabsTrigger value="password" className="h-10" data-testid="login-tab-password">{t("otp.passwordTab")}</TabsTrigger>
                    <TabsTrigger value="otp" className="h-10" data-testid="login-tab-otp">{t("otp.tab")}</TabsTrigger>
                  </TabsList>
                  <TabsContent value="password" className="mt-5"><PasswordForm onForgot={() => setMode("forgot")} /><p className="mt-4 text-[11px] text-muted-foreground rounded-md bg-accent px-3 py-2" data-testid="admin-only-note">{t("adminOnly")}</p></TabsContent>
                  <TabsContent value="otp" className="mt-5"><OtpPanel purpose="login" onDone={() => navigate("/")} /></TabsContent>
                </Tabs>
              </>
            )}
            <p className="text-center text-sm text-muted-foreground">{t("loginHelp")}</p>
            <div className="flex flex-col sm:flex-row gap-2">
              {guestOn && <Button type="button" variant="outline" onClick={() => navigate("/guest")} className="h-11 flex-1" data-testid="guest-continue-button"><Eye className="h-4 w-4 mr-2" />{t("guest.continue")}</Button>}
              <Button asChild variant="ghost" className="h-11 flex-1 text-primary"><Link to="/guide" data-testid="login-help-link"><HelpCircle className="h-4 w-4 mr-2" />{t("help.loginLink")}</Link></Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
