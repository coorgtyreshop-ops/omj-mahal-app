import { useEffect, useState } from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { ShieldCheck, ShieldX, ArrowLeft } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { logoSrc, mahalName, appName } from "@/lib/branding";
import { Photo, TypeBadge } from "@/components/MemberCard";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";

export default function Verify() {
  const { memberNo } = useParams();
  const { t, lang } = useLang();
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    api.get(`/public/verify/${encodeURIComponent(memberNo)}`).then((r) => setData(r.data)).catch(() => setError(true));
  }, [memberNo]);

  // Card scanned with the phone camera while logged in (committee / member) → straight to the live dues view.
  if (user) return <Navigate to={`/scan?m=${encodeURIComponent(memberNo)}`} replace />;
  const s = data?.settings || {};
  return (
    <div className="min-h-screen islamic-pattern flex flex-col items-center justify-center p-4 text-white" data-testid="verify-page">
      <div className="absolute top-4 right-4"><LanguageSwitcher dark /></div>
      <div className="w-full max-w-sm rounded-2xl bg-[#fbf7ee] text-[#1e2923] shadow-2xl overflow-hidden">
        <div className="p-5 flex items-center gap-3 border-b border-[#e6dbc9]">
          <img src={logoSrc(s)} alt="" className="h-12 w-12 rounded-full ring-2 ring-[#d4af37] bg-white object-cover" />
          <div className="min-w-0"><p className="font-bold leading-tight">{appName(s)}</p><p className="text-xs text-muted-foreground truncate">{mahalName(s, lang)}</p></div>
        </div>
        <div className="p-6 text-center space-y-4">
          <p className="text-xs uppercase tracking-[0.2em] text-[#8a6d1d] font-bold">{t("card.verifyTitle")}</p>
          {error ? (
            <div className="space-y-2" data-testid="verify-invalid">
              <ShieldX className="h-14 w-14 mx-auto text-destructive" />
              <p className="font-bold text-lg">{t("card.notFound")}</p>
              <p className="font-mono text-sm text-muted-foreground">{memberNo}</p>
            </div>
          ) : !data ? <p className="text-muted-foreground">{t("common.loading")}</p> : (
            <div className="space-y-3" data-testid="verify-valid">
              <div className="flex justify-center"><Photo src={data.member.photo_url} name={data.member.name} className="h-28 w-24" /></div>
              <div>
                <p className="text-xl font-bold" data-testid="verify-name">{data.member.name}</p>
                <p className="font-mono text-sm tracking-wide" data-testid="verify-member-no">{data.member.member_no}</p>
              </div>
              <TypeBadge type={data.member.member_type} />
              <p className="text-sm text-muted-foreground">{t("card.houseNo")}: <b className="text-foreground">{data.house_no}</b> · {data.head_name}{data.ward ? ` · ${data.ward}` : ""}</p>
              {data.member_since && <p className="text-xs text-muted-foreground">{t("card.since")} {data.member_since}</p>}
              <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 text-primary px-4 py-2 text-sm font-bold" data-testid="verify-badge"><ShieldCheck className="h-5 w-5" />{t("card.verified", { name: appName(s) })}</div>
            </div>
          )}
          <Link to="/login" className="inline-flex items-center gap-1 text-sm text-primary font-semibold hover:underline" data-testid="verify-back"><ArrowLeft className="h-4 w-4" />{t("otp.back")}</Link>
          <p className="text-[11px] text-muted-foreground" data-testid="verify-login-hint">{t("scan.loginHint")}</p>
        </div>
      </div>
    </div>
  );
}
