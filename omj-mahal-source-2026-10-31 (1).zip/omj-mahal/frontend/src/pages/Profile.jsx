import { useState } from "react";
import { toast } from "sonner";
import { UserCircle, Phone, Home, KeyRound } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { PageHeader, TextField, SubmitRow } from "@/components/shared";
import { LANGS } from "@/i18n/translations";
import { cn } from "@/lib/utils";

export default function Profile() {
  const { t, lang, setLang } = useLang();
  const { user } = useAuth();
  const [form, setForm] = useState({ current: "", next: "", confirm: "" });
  const [loading, setLoading] = useState(false);

  const chooseLang = async (l) => {
    setLang(l);
    localStorage.setItem("mahal_lang_manual", "1");
    try { await api.patch("/auth/language", { language: l }); toast.success(t("profile.langSaved")); } catch {}
  };

  const submit = async (e) => {
    e.preventDefault();
    if (form.next !== form.confirm) return toast.error(t("profile.mismatch"));
    setLoading(true);
    try {
      await api.post("/auth/change-password", { current_password: form.current, new_password: form.next });
      toast.success(t("profile.changed")); setForm({ current: "", next: "", confirm: "" });
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };

  return (
    <div data-testid="profile-page">
      <PageHeader title={t("profile.title")} />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-4xl">
        <section className="rounded-xl border border-[#e6dbc9] bg-card p-6 shadow-sm">
          <div className="flex items-center gap-4 mb-6">
            <span className="grid h-16 w-16 place-items-center rounded-full bg-primary/10 text-primary"><UserCircle className="h-10 w-10" /></span>
            <div>
              <h2 className="text-xl font-bold" data-testid="profile-name">{user.name}</h2>
              <span className="rounded-full bg-[#d4af37]/25 text-[#8a6d1d] px-2.5 py-0.5 text-xs font-bold uppercase">{t(`role.${user.role}`)}</span>
            </div>
          </div>
          {user.login_id && <p className="flex items-center gap-2 text-sm mb-2"><KeyRound className="h-4 w-4 text-muted-foreground" /> {t("loginId")}: <b className="font-mono tracking-wider" data-testid="profile-login-id">{user.login_id}</b></p>}
          <p className="flex items-center gap-2 text-sm mb-2"><Phone className="h-4 w-4 text-muted-foreground" /> <span data-testid="profile-phone">{user.phone}</span></p>
          {user.house_id && <p className="flex items-center gap-2 text-sm"><Home className="h-4 w-4 text-muted-foreground" /> {t("nav.myHouse")}</p>}
          <div className="mt-6">
            <p className="text-sm font-medium mb-2">{t("profile.language")}</p>
            <div className="grid grid-cols-3 gap-2">
              {LANGS.map((l) => (
                <button key={l} type="button" onClick={() => chooseLang(l)} data-testid={`profile-lang-${l}`}
                  className={cn("h-12 rounded-lg border font-semibold transition-colors", lang === l ? "bg-primary text-primary-foreground border-primary" : "bg-card hover:bg-accent")}>{t(`lang.${l}`)}</button>
              ))}
            </div>
          </div>
        </section>
        <section className="rounded-xl border border-[#e6dbc9] bg-card p-6 shadow-sm">
          <h2 className="font-bold text-base mb-4 text-primary">{t("profile.changePassword")}</h2>
          <form onSubmit={submit} className="space-y-4">
            <TextField label={t("profile.current")} type="password" value={form.current} onChange={(v) => setForm((f) => ({ ...f, current: v }))} required testId="current-password-input" />
            <TextField label={t("profile.newPass")} type="password" value={form.next} onChange={(v) => setForm((f) => ({ ...f, next: v }))} required minLength={4} testId="new-password-input" />
            <TextField label={t("profile.confirm")} type="password" value={form.confirm} onChange={(v) => setForm((f) => ({ ...f, confirm: v }))} required testId="confirm-password-input" />
            <SubmitRow loading={loading} label={t("profile.changePassword")} />
          </form>
        </section>
      </div>
    </div>
  );
}
