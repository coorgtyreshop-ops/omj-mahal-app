import { useCallback, useState } from "react";
import { SetupChecklist, BirthdaysCard, MustChangeBanner, TodayCard } from "@/components/DashboardExtras";
import { PosterShowcase } from "@/components/events/PosterShowcase";
import { Link } from "react-router-dom";
import { Home, Users, Wallet, AlertCircle, HandCoins, Receipt, Scale, Megaphone, Plus, CreditCard, Inbox, Pencil, MessageCircle, ScanLine, RefreshCw } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { useCached } from "@/lib/cache";
import { inr, monthLabel, fmtDate } from "@/lib/format";
import { PageHeader, StatCard, EmptyState } from "@/components/shared";
import { AnnouncementCard } from "@/pages/Announcements";
import { typeLabel } from "@/components/forms/CollectionPaymentForm";
import { FeesDialog } from "@/pages/Collections";
import { FundCard } from "@/pages/Donations";
import { IncomingPayments } from "@/components/finance/IncomingPayments";
import { ReviewPendingCard } from "@/components/finance/ReleaseStatement";
import { UnreleasedHouses } from "@/components/finance/UnreleasedHouses";
import { openChatLink } from "@/lib/whatsapp";
import { Button } from "@/components/ui/button";

const CollectionsCard = ({ rows }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [feesOpen, setFeesOpen] = useState(false);
  const [fees, setFees] = useState(null);
  const openFees = async () => { try { const { data } = await api.get("/finance/fees"); setFees(data); setFeesOpen(true); } catch { /* ignore */ } };
  return (
    <section className="mt-8" data-testid="dashboard-collections">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <h2 className="text-lg font-bold">{t("dashboard.collectionsYear")}</h2>
        <div className="flex items-center gap-3">
          <Button size="sm" variant="outline" className="h-9" onClick={openFees} data-testid="dashboard-edit-collections"><Pencil className="h-4 w-4 mr-1" />{t("dashboard.editCollections")}</Button>
          <Link to="/collections" className="text-sm font-semibold text-primary hover:underline" data-testid="view-collections">{t("dashboard.viewAll")}</Link>
        </div>
      </div>
      {fees && <FeesDialog open={feesOpen} onOpenChange={setFeesOpen} fees={fees} onSaved={() => window.location.reload()} />}
      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="bg-accent/60 text-left"><th className="px-3 py-2">{t("fin.type")}</th><th className="px-3 py-2 text-right">{t("fin.report.houses")}</th><th className="px-3 py-2 text-right">{t("fin.report.due")}</th><th className="px-3 py-2 text-right">{t("fin.report.received")}</th><th className="px-3 py-2 text-right">{t("fin.report.pending")}</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.type} className="border-t" data-testid={`dash-col-${r.type}`}>
                <td className="px-3 py-2 font-semibold">{typeLabel(t, r.type, settings)}</td>
                <td className="px-3 py-2 text-right">{r.houses}</td>
                <td className="px-3 py-2 text-right">{r.type === "donation" ? "—" : inr(r.due)}</td>
                <td className="px-3 py-2 text-right text-[#0d5c3a] font-semibold">{inr(r.paid)}</td>
                <td className={`px-3 py-2 text-right font-bold ${r.pending > 0 ? "text-[#a06f1c]" : "text-[#0d5c3a]"}`}>{r.type === "donation" ? "—" : inr(r.pending)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
};

const InboxCard = ({ inbox }) => {
  const { t } = useLang();
  const items = inbox?.items || [];
  return (
    <div className="rounded-xl border border-[#c58b2b]/40 bg-[#c58b2b]/[0.06] p-4" data-testid="inbox-card">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-base font-bold flex items-center gap-2"><Inbox className="h-4 w-4 text-[#a06f1c]" />{t("dashboard.inbox")}{inbox?.new_suggestions > 0 && <span className="rounded-full bg-[#a06f1c] px-2 text-xs text-white" data-testid="inbox-new-count">{inbox.new_suggestions}</span>}</h2>
        <Link to="/suggestions" className="text-sm font-semibold text-primary hover:underline" data-testid="inbox-view-all">{t("dashboard.viewAll")}</Link>
      </div>
      {items.length === 0 ? <p className="text-xs text-muted-foreground" data-testid="inbox-empty">{t("dashboard.inboxEmpty")}</p> : (
        <ul className="space-y-2" data-testid="inbox-list">
          {items.map((it) => (
            <li key={it.id}><Link to={it.kind === "chat" ? "/group" : "/suggestions"} className="block rounded-lg bg-card border px-3 py-2 hover:bg-accent/60 transition-colors" data-testid={`inbox-item-${it.id}`}>
              <p className="text-sm line-clamp-2">{it.text}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">{it.name}{it.house_no && ` · ${t("houses.houseNo")} ${it.house_no}`} · {fmtDate(it.created_at.slice(0, 10))} · {it.kind === "chat" ? t("nav.group") : t("nav.suggestions")}{it.status === "new" && <span className="ml-1 text-[#a06f1c] font-semibold">· {t("dashboard.inboxNew")}</span>}</p>
            </Link></li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default function Dashboard() {
  const { t, months } = useLang();
  const { user, isAdmin, settings } = useAuth();
  const fetchDashboard = useCallback(() => api.get("/dashboard").then((r) => r.data), []);
  const { data, fresh, reload } = useCached(user?.id ? `dashboard:${user.id}` : null, fetchDashboard);

  if (!data) return <p className="text-muted-foreground" data-testid="dashboard-loading">{t("common.loading")}</p>;

  return (
    <div data-testid="dashboard-page">
      <PageHeader title={`${t("dashboard.welcome")}, ${user?.name}`} subtitle={fresh ? t("dashboard.title") : <span className="inline-flex items-center gap-1" data-testid="dashboard-refreshing"><RefreshCw className="h-3 w-3 animate-spin" />{t("common.refreshing")}</span>} />
      {user?.must_change_password && <MustChangeBanner />}
      {isAdmin && data.setup && <SetupChecklist setup={data.setup} />}
      <PosterShowcase />
      <TodayCard />

      {isAdmin ? (
        <>
          <IncomingPayments onChange={reload} />
          <UnreleasedHouses />
          {settings?.committee_whatsapp && (
            <div className="rounded-xl border border-[#128C7E]/40 bg-[#128C7E]/10 p-3 mb-6 flex flex-wrap items-center justify-between gap-2" data-testid="admin-committee-whatsapp">
              <span className="text-sm flex items-center gap-2"><MessageCircle className="h-4 w-4 text-[#128C7E]" />{t("dashboard.waCommitteeAdmin")}: <b className="font-mono">{settings.committee_whatsapp}</b></span>
              <Button size="sm" className="h-9 bg-[#128C7E] hover:bg-[#0f7a6d]" onClick={() => openChatLink(`https://wa.me/${settings.committee_whatsapp.replace(/\D/g, "").replace(/^(\d{10})$/, "91$1")}`, t("outbox.tapOpen"))} data-testid="admin-committee-whatsapp-open"><MessageCircle className="h-4 w-4 mr-1" />WhatsApp</Button>
            </div>
          )}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
            <StatCard label={t("dashboard.totalHouses")} value={data.houses} icon={Home} testId="stat-houses" />
            <StatCard label={t("dashboard.totalMembers")} value={data.members} hint={`${data.member_types?.sub ?? 0} ${t("mtype.sub")} · ${data.member_types?.family ?? 0} ${t("mtype.family")} · ${data.member_types?.widows ?? 0} ${t("mtype.widows")}`} icon={Users} testId="stat-members" delay={60} />
            <StatCard label={t("dashboard.collectedThisMonth")} value={inr(data.this_month_collection)} icon={Wallet} tone="gold" testId="stat-collected" delay={120} />
            <StatCard label={t("dashboard.pendingDues")} value={inr(data.pending_amount)} hint={`${data.pending_houses} ${t("dashboard.pendingHouses")}`} icon={AlertCircle} tone="amber" testId="stat-pending" delay={180} />
            <StatCard label={t("dashboard.donationsThisMonth")} value={inr(data.this_month_donations)} icon={HandCoins} tone="gold" testId="stat-donations" delay={240} />
            <StatCard label={t("dashboard.expensesThisMonth")} value={inr(data.this_month_expenses)} icon={Receipt} tone="red" testId="stat-expenses" delay={300} />
            <StatCard label={t("dashboard.yearBalance")} value={inr(data.year_balance)} icon={Scale} testId="stat-balance" delay={360} />
            <div className="stat-in rounded-xl border border-[#e6dbc9] bg-card p-4 sm:p-5 shadow-sm" style={{ animationDelay: "420ms" }}>
              <p className="text-xs sm:text-sm font-medium text-muted-foreground mb-3">{t("dashboard.quickActions")}</p>
              <div className="grid grid-cols-2 gap-2">
                <Button asChild size="sm" className="h-10 text-xs col-span-2 bg-[#1e2923] hover:bg-[#2b3a32]" data-testid="quick-scan-card"><Link to="/scan"><ScanLine className="h-3.5 w-3.5 mr-1" />{t("scan.nav")}</Link></Button>
                <Button asChild size="sm" className="h-10 text-xs" data-testid="quick-record-payment"><Link to="/collections"><Wallet className="h-3.5 w-3.5 mr-1" />{t("subs.payNow")}</Link></Button>
                <Button asChild size="sm" variant="outline" className="h-10 text-xs" data-testid="quick-add-house"><Link to="/houses?new=1"><Plus className="h-3.5 w-3.5 mr-1" />{t("nav.houses")}</Link></Button>
                <Button asChild size="sm" variant="outline" className="h-10 text-xs" data-testid="quick-add-announcement"><Link to="/announcements?new=1"><Megaphone className="h-3.5 w-3.5 mr-1" />{t("nav.announcements")}</Link></Button>
                <Button asChild size="sm" variant="outline" className="h-10 text-xs" data-testid="quick-add-expense"><Link to="/expenses?new=1"><Receipt className="h-3.5 w-3.5 mr-1" />{t("nav.expenses")}</Link></Button>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
          <StatCard label={t("dashboard.myHouse")} value={data.house?.house_no || "—"} hint={data.member ? `${data.member.name} (${data.member.member_no}) — ${t("mtype.sub")}` : data.house?.head_name} icon={Home} testId="stat-my-house" />
          <Link to="/cards" data-testid="dashboard-cards-link"><StatCard label={t("card.my")} value={data.member_count} hint={t("card.view")} icon={CreditCard} testId="stat-family" delay={60} /></Link>
          {data.released ? (
            <>
              <StatCard label={t("dashboard.monthlyAmount")} value={inr(data.house?.subscription_amount)} icon={Wallet} tone="gold" testId="stat-monthly" delay={120} />
              <Link to="/pay" data-testid="dashboard-pay-link"><StatCard label={t("dashboard.myDues")} value={inr(data.dues?.pending_amount)} hint={data.dues?.pending_count ? `${data.dues.pending_count} ${t("subs.monthsCount")} · ${t("fin.payNow")}` : t("dashboard.allClear")} icon={AlertCircle} tone={data.dues?.pending_count ? "amber" : "emerald"} testId="stat-my-dues" delay={180} /></Link>
            </>
          ) : <div className="col-span-2"><ReviewPendingCard compact /></div>}
          {settings?.committee_whatsapp && (
            <button type="button" onClick={() => openChatLink(`https://wa.me/${settings.committee_whatsapp.replace(/\D/g, "").replace(/^(\d{10})$/, "91$1")}?text=${encodeURIComponent(`${t("dashboard.waPrefill")} ${data.house?.house_no || ""} · ${data.member?.name || data.house?.head_name || ""}: `)}`, t("outbox.tapOpen"))}
              className="col-span-2 lg:col-span-4 rounded-xl border border-[#128C7E]/40 bg-[#128C7E]/10 p-4 text-left flex items-center gap-3 hover:bg-[#128C7E]/15" data-testid="committee-whatsapp-button">
              <MessageCircle className="h-6 w-6 text-[#128C7E]" />
              <span><b className="block text-sm">{t("dashboard.waCommittee")}</b><span className="text-xs text-muted-foreground">{t("dashboard.waCommitteeHint")} · {settings.committee_whatsapp}</span></span>
            </button>
          )}
          {data.released && data.dues?.pending_count > 0 && (
            <div className="col-span-2 lg:col-span-4 rounded-xl border border-[#c58b2b]/40 bg-[#c58b2b]/5 p-4" data-testid="member-pending-months">
              <p className="text-sm font-semibold text-[#a06f1c] mb-2">{t("dashboard.pendingMonths")}</p>
              <div className="flex flex-wrap gap-2">
                {data.dues.pending_months.map((m) => <span key={m} className="rounded-full bg-white border border-[#c58b2b]/40 px-3 py-1 text-xs font-medium">{monthLabel(m, months, true)}</span>)}
              </div>
            </div>
          )}
        </div>
      )}

      {isAdmin && data.collections && <CollectionsCard rows={data.collections} />}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
        <section className="lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold">{t("dashboard.recentAnnouncements")}</h2>
            <Link to="/announcements" className="text-sm font-semibold text-primary hover:underline" data-testid="view-all-announcements">{t("dashboard.viewAll")}</Link>
          </div>
          <div className="space-y-3">
            {data.announcements?.length ? data.announcements.map((a) => <AnnouncementCard key={a.id} a={a} compact />) : <EmptyState text={t("ann.noAnn")} />}
          </div>
        </section>
        <section className="space-y-6">
          {isAdmin && <InboxCard inbox={data.inbox} />}
          {isAdmin && <BirthdaysCard items={data.birthdays || []} />}
          <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold">{t("dashboard.activeFunds")}</h2>
            <Link to="/donations" className="text-sm font-semibold text-primary hover:underline" data-testid="view-all-funds">{t("dashboard.viewAll")}</Link>
          </div>
          <div className="space-y-3">
            {data.funds?.filter((f) => f.active).slice(0, 3).map((f) => <FundCard key={f.id} fund={f} />)}
            {!data.funds?.length && <EmptyState text={t("donations.noFunds")} />}
          </div>
          </div>
        </section>
      </div>
    </div>
  );
}
