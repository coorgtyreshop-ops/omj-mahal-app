import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { Plus, Printer, Trash2, Download, BellRing } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, monthLabel, fmtDate, downloadCsv } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete } from "@/components/shared";
import { PrintDialog, ReceiptBody } from "@/components/print/Printables";
import { CollectionPaymentForm } from "@/components/forms/CollectionPaymentForm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Subscriptions() {
  const { t, months } = useLang();
  const { isAdmin, canFinance, settings } = useAuth();
  const [params, setParams] = useSearchParams();
  const [payments, setPayments] = useState([]);
  const [dues, setDues] = useState([]);
  const [houses, setHouses] = useState([]);
  const [month, setMonth] = useState("");
  const [formOpen, setFormOpen] = useState(params.get("new") === "1");
  const [presetHouse, setPresetHouse] = useState("");
  const [receipt, setReceipt] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const load = useCallback(async () => {
    const [p, d] = await Promise.all([api.get("/payments", { params: { month: month || undefined, type: "varisankhya" } }), api.get("/payments/dues")]);
    setPayments(p.data); setDues(d.data);
  }, [month]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (canFinance) api.get("/houses").then((r) => setHouses(r.data)); }, [canFinance]);

  const openNew = (hid = "") => { setPresetHouse(hid); setFormOpen(true); };
  const closeForm = (o) => { setFormOpen(o); if (!o && params.get("new")) setParams({}); };
  const onSaved = (p) => { load(); setReceipt(p); };
  const remove = async () => {
    try { await api.delete(`/payments/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load(); } catch (e) { toast.error(apiError(e)); }
  };
  const sendReminders = async () => {
    try { const { data } = await api.post("/notifications/dues-reminder", {}); toast.success(t("notif.reminderSent", { n: data.houses_notified })); } catch (e) { toast.error(apiError(e)); }
  };
  const exportCsv = () => downloadCsv("payments.csv", ["Receipt", "Date", "House", "Head", "Months", "Mode", "Amount"], payments.map((p) => [p.receipt_no, p.date, p.house_no, p.head_name, (p.months || []).join(" "), p.mode, p.amount]));

  return (
    <div data-testid="subscriptions-page">
      <PageHeader title={t("subs.title")} actions={canFinance && <>
        {isAdmin && <Button variant="outline" onClick={sendReminders} disabled={!dues.length} className="h-11" data-testid="send-dues-reminder-button"><BellRing className="h-4 w-4 mr-2" />{t("notif.sendDuesReminder")}</Button>}
        <Button variant="outline" onClick={exportCsv} className="h-11" data-testid="payments-export-button"><Download className="h-4 w-4 mr-2" />{t("common.export")}</Button>
        <Button onClick={() => openNew()} className="h-11" data-testid="record-payment-button"><Plus className="h-4 w-4 mr-2" />{t("subs.record")}</Button>
      </>} />

      <Tabs defaultValue="dues">
        <TabsList className="h-11 mb-4">
          <TabsTrigger value="dues" className="h-9 px-5" data-testid="tab-dues">{t("subs.dues")} <span className="ml-2 rounded-full bg-[#c58b2b]/20 text-[#a06f1c] px-2 text-xs">{dues.length}</span></TabsTrigger>
          <TabsTrigger value="payments" className="h-9 px-5" data-testid="tab-payments">{t("subs.payments")}</TabsTrigger>
        </TabsList>

        <TabsContent value="dues">
          <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
            {dues.length === 0 ? <EmptyState text={t("subs.noPending")} testId="dues-empty" /> : (
              <Table data-testid="dues-table">
                <TableHeader><TableRow className="bg-accent/60">
                  <TableHead>{t("houses.houseNo")}</TableHead><TableHead>{t("houses.headName")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("subs.pendingSince")}</TableHead><TableHead className="text-right">{t("common.amount")}</TableHead>{canFinance && <TableHead />}
                </TableRow></TableHeader>
                <TableBody>
                  {dues.map((d) => (
                    <TableRow key={d.id} data-testid={`due-row-${d.house_no}`}>
                      <TableCell className="font-bold text-primary">{d.house_no}</TableCell>
                      <TableCell><p className="font-medium">{d.head_name}</p><p className="text-xs text-muted-foreground">{d.phone}</p></TableCell>
                      <TableCell className="hidden md:table-cell"><div className="flex flex-wrap gap-1">{d.pending_months.map((m) => <span key={m} className="rounded-full bg-[#c58b2b]/10 text-[#a06f1c] px-2 py-0.5 text-[11px] font-semibold">{monthLabel(m, months, true)}</span>)}</div></TableCell>
                      <TableCell className="text-right"><span className="font-bold">{inr(d.pending_amount)}</span><p className="text-xs text-muted-foreground">{d.pending_count} {t("subs.monthsCount")}</p></TableCell>
                      {canFinance && <TableCell className="text-right"><Button size="sm" onClick={() => openNew(d.id)} className="h-9" data-testid={`pay-due-${d.house_no}`}>{t("subs.payNow")}</Button></TableCell>}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>

        <TabsContent value="payments">
          <div className="flex gap-3 mb-4">
            <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="h-11 w-52" data-testid="payments-month-filter" />
            {month && <Button variant="ghost" onClick={() => setMonth("")} className="h-11" data-testid="payments-month-clear">{t("subs.allMonths")}</Button>}
          </div>
          <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
            {payments.length === 0 ? <EmptyState text={t("subs.noPayments")} /> : (
              <Table data-testid="payments-table">
                <TableHeader><TableRow className="bg-accent/60">
                  <TableHead>{t("common.receiptNo")}</TableHead><TableHead>{t("common.date")}</TableHead><TableHead>{t("houses.houseNo")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("subs.paidMonths")}</TableHead><TableHead className="hidden sm:table-cell">{t("common.mode")}</TableHead>
                  <TableHead className="text-right">{t("common.amount")}</TableHead><TableHead />
                </TableRow></TableHeader>
                <TableBody>
                  {payments.map((p) => (
                    <TableRow key={p.id} data-testid={`payment-row-${p.receipt_no}`}>
                      <TableCell className="font-mono text-xs">{p.receipt_no}</TableCell>
                      <TableCell>{fmtDate(p.date)}</TableCell>
                      <TableCell><span className="font-bold text-primary">{p.house_no}</span><p className="text-xs text-muted-foreground">{p.head_name}</p></TableCell>
                      <TableCell className="hidden md:table-cell text-sm">{(p.months || []).map((m) => monthLabel(m, months, true)).join(", ")}</TableCell>
                      <TableCell className="hidden sm:table-cell">{t(`paymentModes.${p.mode}`)}</TableCell>
                      <TableCell className="text-right font-semibold">{inr(p.amount)}</TableCell>
                      <TableCell className="text-right whitespace-nowrap">
                        <Button size="icon" variant="ghost" onClick={() => setReceipt(p)} data-testid={`print-receipt-${p.receipt_no}`}><Printer className="h-4 w-4" /></Button>
                        {canFinance && <Button size="icon" variant="ghost" className="text-destructive" onClick={() => setDeleting(p)} data-testid={`delete-payment-${p.receipt_no}`}><Trash2 className="h-4 w-4" /></Button>}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {canFinance && <CollectionPaymentForm fixedType="varisankhya" open={formOpen} onOpenChange={closeForm} houses={houses} presetHouse={presetHouse} onSaved={onSaved} />}
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
      <PrintDialog open={!!receipt} onOpenChange={(o) => !o && setReceipt(null)} title={t("subs.receipt")} testId="receipt-dialog">
        {receipt && <ReceiptBody payment={receipt} settings={settings} />}
      </PrintDialog>
    </div>
  );
}
