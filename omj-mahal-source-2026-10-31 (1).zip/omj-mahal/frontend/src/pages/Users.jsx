import { useCallback, useEffect, useState } from "react";
import { openChatLink } from "@/lib/whatsapp";
import { toast } from "sonner";
import { Plus, Trash2, KeyRound, UsersRound, Printer, Download, Landmark, Moon, Send, BookOpenText } from "lucide-react";
import { PrintDialog } from "@/components/print/Printables";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { downloadCsv } from "@/lib/format";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { PageHeader, EmptyState, ConfirmDelete, TextField, SelectField, SubmitRow } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const empty = { name: "", phone: "", password: "", role: "member", house_id: "", language: "en" };

const UserForm = ({ open, onOpenChange, item, houses, onSaved }) => {
  const { t } = useLang();
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) setForm(item ? { ...empty, ...item, password: "" } : empty); }, [open, item]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const payload = { name: form.name, phone: form.phone, role: form.role, house_id: form.house_id === "none" ? null : form.house_id || null, language: form.language };
      if (form.password) payload.password = form.password;
      if (item?.id) await api.put(`/users/${item.id}`, payload);
      else { if (!form.password) throw new Error(t("common.required")); await api.post("/users", payload); }
      toast.success(item?.id ? t("common.saved") : t("users.created")); onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="user-form-dialog">
        <DialogHeader><DialogTitle>{item?.id ? t("users.edit") : t("users.add")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <TextField label={t("users.name")} value={form.name} onChange={set("name")} required testId="user-name-input" />
          <TextField label={t("users.phone")} value={form.phone} onChange={set("phone")} required testId="user-phone-input" inputMode="tel" />
          <TextField label={item?.id ? t("users.newPassword") : t("users.password")} type="text" value={form.password} onChange={set("password")} required={!item?.id} testId="user-password-input" />
          <div className="grid grid-cols-2 gap-4">
            <SelectField label={t("users.role")} value={form.role} onChange={set("role")} testId="user-role-select" options={[{ value: "member", label: t("role.member") }, { value: "admin", label: t("role.admin") }]} />
            <SelectField label={t("users.language")} value={form.language} onChange={set("language")} testId="user-language-select" options={["en", "ml", "kn"].map((l) => ({ value: l, label: t(`lang.${l}`) }))} />
          </div>
          <SelectField label={t("users.house")} value={form.house_id || "none"} onChange={set("house_id")} testId="user-house-select" options={[{ value: "none", label: "—" }, ...houses.map((h) => ({ value: h.id, label: `${h.house_no} — ${h.head_name}` }))]} />
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

const BulkDialog = ({ open, onOpenChange, onDone }) => {
  const { t } = useLang();
  const [mode, setMode] = useState("house_no");
  const [suffix, setSuffix] = useState("1234");
  const [fixed, setFixed] = useState("");
  const [send, setSend] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [printOpen, setPrintOpen] = useState(false);
  const run = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const { data } = await api.post("/users/bulk-logins", { mode, suffix, fixed_password: fixed, send_whatsapp: send });
      setResult(data); toast.success(t("bulk.created", { n: data.created.length })); onDone();
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  const csv = () => downloadCsv("logins.csv", ["House", "Name", "Login ID", "Phone", "Password"], result.created.map((r) => [r.house_no, r.head_name, r.login_id, r.phone, r.password]));
  const List = () => (
    <table className="w-full text-sm border-collapse" data-testid="bulk-result-table">
      <thead><tr className="bg-[#faf8f5] text-left"><th className="p-2 border">{t("houses.houseNo")}</th><th className="p-2 border">{t("houses.headName")}</th><th className="p-2 border">{t("loginId")}</th><th className="p-2 border">{t("phone")}</th><th className="p-2 border">{t("password")}</th></tr></thead>
      <tbody>{result.created.map((r) => <tr key={r.house_no}><td className="p-2 border font-bold">{r.house_no}</td><td className="p-2 border">{r.head_name}</td><td className="p-2 border font-mono font-bold text-[#8a6d1d]">{r.login_id}</td><td className="p-2 border font-mono">{r.phone}</td><td className="p-2 border font-mono font-bold">{r.password}</td></tr>)}</tbody>
    </table>
  );
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto" data-testid="bulk-login-dialog">
        <DialogHeader><DialogTitle>{t("bulk.title")}</DialogTitle></DialogHeader>
        {result ? (
          <div className="space-y-3">
            <p className="text-sm font-semibold text-primary" data-testid="bulk-result-count">{t("bulk.created", { n: result.created.length })} — {t("bulk.result")}</p>
            {result.created.length > 0 && <List />}
            {result.skipped.length > 0 && <p className="text-xs text-muted-foreground">{t("bulk.skipped")}: {result.skipped.map((s) => `${s.house_no} (${s.reason})`).join(", ")}</p>}
            <div className="flex flex-wrap gap-2 justify-end">
              <Button variant="outline" onClick={csv} className="h-10" data-testid="bulk-csv-button"><Download className="h-4 w-4 mr-1" />{t("common.export")}</Button>
              <Button variant="outline" onClick={() => setPrintOpen(true)} className="h-10" data-testid="bulk-print-button"><Printer className="h-4 w-4 mr-1" />{t("bulk.printList")}</Button>
              <Button onClick={() => onOpenChange(false)} className="h-10" data-testid="bulk-close-button">{t("common.close")}</Button>
            </div>
            <PrintDialog open={printOpen} onOpenChange={setPrintOpen} title={t("bulk.printList")} testId="bulk-print-dialog"><div className="p-4 bg-white"><h3 className="font-bold mb-3">{t("bulk.result")}</h3><List /></div></PrintDialog>
          </div>
        ) : (
          <form onSubmit={run} className="space-y-4">
            <p className="text-sm text-muted-foreground">{t("bulk.desc")}</p>
            <SelectField label={t("bulk.mode")} value={mode} onChange={setMode} testId="bulk-mode-select" options={[{ value: "house_no", label: t("bulk.modeHouse") }, { value: "fixed", label: t("bulk.modeFixed") }]} />
            {mode === "house_no" ? <TextField label={t("bulk.suffix")} value={suffix} onChange={setSuffix} required testId="bulk-suffix-input" /> : <TextField label={t("bulk.fixed")} value={fixed} onChange={setFixed} required minLength={4} testId="bulk-fixed-input" />}
            <div className="flex items-center justify-between rounded-lg border p-3"><Label>{t("bulk.sendAll")}</Label><Switch checked={send} onCheckedChange={setSend} data-testid="bulk-send-switch" /></div>
            <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} label={t("bulk.run")} />
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default function Users() {
  const { t } = useLang();
  const { user, settings, refreshSettings } = useAuth();
  const [rows, setRows] = useState([]);
  const [houses, setHouses] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [bulkOpen, setBulkOpen] = useState(false);

  const load = useCallback(async () => { const { data } = await api.get("/users"); setRows(data); }, []);
  useEffect(() => { load(); api.get("/houses").then((r) => setHouses(r.data)); }, [load]);
  const remove = async () => { try { await api.delete(`/users/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load(); } catch (e) { toast.error(apiError(e)); } };
  const houseLabel = (id) => { const h = houses.find((x) => x.id === id); return h ? `${h.house_no} — ${h.head_name}` : "—"; };
  const treasurerId = settings?.finance_manager_id;
  const salathIds = settings?.salath_manager_ids || [];
  const khatheebId = settings?.khatheeb_user_id;
  const toggleKhatheeb = async (u) => { try { await api.put("/chat/khatheeb", { user_id: khatheebId === u.id ? null : u.id }); await refreshSettings(); toast.success(t("users.khatheebSet")); } catch (e) { toast.error(apiError(e)); } };
  const [sendingIds, setSendingIds] = useState(false);
  const setTreasurer = async (id) => { try { await api.put("/finance/manager", { user_id: id }); await refreshSettings(); toast.success(t("fin.treasurerSet")); } catch (e) { toast.error(apiError(e)); } };
  const toggleSalath = async (u) => { try { await api.put("/ledger/salath-managers", { user_id: u.id, on: !salathIds.includes(u.id) }); await refreshSettings(); toast.success(t("users.salathSet")); } catch (e) { toast.error(apiError(e)); } };
  const sendId = async (u) => { try { const { data } = await api.post(`/houses/${u.house_id}/login/send-id`, { app_url: settings?.app_url || window.location.origin }); toast.success(t("hlogin.idSent")); if (data.wa_link && data.status !== "sent") openChatLink(data.wa_link, t("outbox.tapOpen")); } catch (e) { toast.error(apiError(e)); } };
  const sendAllIds = async () => { setSendingIds(true); try { const { data } = await api.post("/users/send-ids", { app_url: settings?.app_url || window.location.origin }); toast.success(`${data.sent} — ${t("hlogin.idSent")}`); } catch (e) { toast.error(apiError(e)); } finally { setSendingIds(false); } };

  return (
    <div data-testid="users-page">
      <PageHeader title={t("users.title")} actions={<>
        <Button variant="outline" onClick={sendAllIds} disabled={sendingIds} className="h-11 border-[#128C7E]/40 text-[#128C7E]" data-testid="send-all-ids-button"><Send className="h-4 w-4 mr-2" />{t("hlogin.sendIdsAll")}</Button>
        <Button variant="outline" onClick={() => setBulkOpen(true)} className="h-11" data-testid="bulk-login-button"><UsersRound className="h-4 w-4 mr-2" />{t("bulk.button")}</Button>
        <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="h-11" data-testid="add-user-button"><Plus className="h-4 w-4 mr-2" />{t("users.add")}</Button>
      </>} />
      <p className="text-sm text-muted-foreground mb-3 flex items-center gap-2"><Landmark className="h-4 w-4 text-[#8a6d1d]" />{t("fin.treasurerHint")}</p>
      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        {rows.length === 0 ? <EmptyState text={t("users.noUsers")} /> : (
          <Table data-testid="users-table">
            <TableHeader><TableRow className="bg-accent/60"><TableHead>{t("users.name")}</TableHead><TableHead>{t("users.loginId")}</TableHead><TableHead className="hidden sm:table-cell">{t("users.phone")}</TableHead><TableHead>{t("users.role")}</TableHead><TableHead className="hidden md:table-cell">{t("users.house")}</TableHead><TableHead className="hidden sm:table-cell">{t("users.language")}</TableHead><TableHead /></TableRow></TableHeader>
            <TableBody>
              {rows.map((u) => (
                <TableRow key={u.id} data-testid={`user-row-${u.phone}`}>
                  <TableCell className="font-medium">{u.name}{u.id === user.id && <span className="ml-2 text-[10px] text-muted-foreground">(you)</span>}</TableCell>
                  <TableCell className="font-mono text-sm font-bold text-[#8a6d1d] tracking-wider" data-testid={`user-login-id-${u.phone}`}>{u.login_id || "—"}</TableCell>
                  <TableCell className="hidden sm:table-cell font-mono text-sm">{u.phone}</TableCell>
                  <TableCell><span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${u.role === "admin" ? "bg-[#d4af37]/25 text-[#8a6d1d]" : "bg-primary/10 text-primary"}`}>{t(`role.${u.role}`)}</span>{treasurerId === u.id && <span className="ml-1 rounded-full bg-[#1c2420] text-[#d4af37] px-2.5 py-0.5 text-xs font-bold" data-testid={`treasurer-badge-${u.phone}`}>{t("fin.treasurer")}</span>}{salathIds.includes(u.id) && <span className="ml-1 rounded-full bg-[#0d5c3a] text-white px-2.5 py-0.5 text-xs font-bold" data-testid={`salath-badge-${u.phone}`}>{t("users.salath")}</span>}{khatheebId === u.id && <span className="ml-1 rounded-full bg-[#8a6d1d] text-white px-2.5 py-0.5 text-xs font-bold" data-testid={`khatheeb-badge-${u.phone}`}>{t("users.khatheeb")}</span>}</TableCell>
                  <TableCell className="hidden md:table-cell text-sm">{houseLabel(u.house_id)}</TableCell>
                  <TableCell className="hidden sm:table-cell">{t(`lang.${u.language || "en"}`)}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    {u.house_id && <Button size="icon" variant="ghost" onClick={() => sendId(u)} data-testid={`send-id-${u.phone}`} title={t("hlogin.sendId")} className="text-[#128C7E]"><Send className="h-4 w-4" /></Button>}
                    <Button size="icon" variant="ghost" onClick={() => toggleKhatheeb(u)} data-testid={`khatheeb-toggle-${u.phone}`} title={t("users.khatheebHint")} className={khatheebId === u.id ? "text-[#8a6d1d]" : ""}><BookOpenText className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => toggleSalath(u)} data-testid={`salath-toggle-${u.phone}`} title={t("users.salathHint")} className={salathIds.includes(u.id) ? "text-[#0d5c3a]" : ""}><Moon className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => setTreasurer(treasurerId === u.id ? null : u.id)} data-testid={`treasurer-toggle-${u.phone}`} title={treasurerId === u.id ? t("fin.removeTreasurer") : t("fin.setTreasurer")} className={treasurerId === u.id ? "text-[#8a6d1d]" : ""}><Landmark className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => { setEditing(u); setFormOpen(true); }} data-testid={`edit-user-${u.phone}`} title={t("users.resetHint")}><KeyRound className="h-4 w-4" /></Button>
                    {u.id !== user.id && <Button size="icon" variant="ghost" className="text-destructive" onClick={() => setDeleting(u)} data-testid={`delete-user-${u.phone}`}><Trash2 className="h-4 w-4" /></Button>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
      <UserForm open={formOpen} onOpenChange={setFormOpen} item={editing} houses={houses} onSaved={load} />
      {bulkOpen && <BulkDialog open onOpenChange={setBulkOpen} onDone={load} />}
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
    </div>
  );
}
