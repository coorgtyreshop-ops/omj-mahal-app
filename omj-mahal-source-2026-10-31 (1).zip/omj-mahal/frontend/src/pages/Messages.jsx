import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { BellRing, Send, Trash2, MessageSquare, Radio, RefreshCw } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { PageHeader, EmptyState, StatCard, SelectField, ConfirmDelete } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { AiButton } from "@/components/AiComposer";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { AutoReminderPanel } from "@/components/AutoReminderPanel";
import { Outbox } from "@/components/Outbox";
import { Link } from "react-router-dom";

const KINDS = ["otp_login", "otp_reset", "dues_reminder", "auto_reminder", "receipt", "pay_request", "announcement", "event", "credentials", "custom"];

export const GatewayBanner = ({ status }) => {
  const { t } = useLang();
  if (!status) return null;
  const live = status.mode === "live";
  return (
    <div className={cn("rounded-xl border px-4 py-3 text-sm flex items-start gap-3", live ? "bg-primary/5 border-primary/30 text-primary" : "bg-[#d4af37]/10 border-[#d4af37]/50 text-[#8a6d1d]")} data-testid="gateway-banner">
      <Radio className="h-5 w-5 shrink-0 mt-0.5" />
      <div>
        <p className="font-semibold" data-testid="gateway-mode">{live ? t("notif.live") : t("notif.phoneMode")}</p>
        {!live && <p className="text-xs mt-0.5 opacity-80">{t("notif.phoneModeHint")} <Link to="/settings" className="underline font-semibold">{t("nav.settings")}</Link></p>}
      </div>
    </div>
  );
};

export default function Messages() {
  const [refreshKey, setRefreshKey] = useState(0);
  const { t } = useLang();
  const [status, setStatus] = useState(null);
  const [rows, setRows] = useState([]);
  const [summary, setSummary] = useState(null);
  const [kind, setKind] = useState("all");
  const [channel, setChannel] = useState("all");
  const [custom, setCustom] = useState("");
  const [busy, setBusy] = useState("");
  const [clearing, setClearing] = useState(false);

  const load = useCallback(async () => {
    setRefreshKey((k) => k + 1);
    const [s, m, sm] = await Promise.all([
      api.get("/notifications/status"),
      api.get("/notifications", { params: { kind: kind !== "all" ? kind : undefined, channel: channel !== "all" ? channel : undefined } }),
      api.get("/notifications/summary"),
    ]);
    setStatus(s.data); setRows(m.data); setSummary(sm.data);
  }, [kind, channel]);
  useEffect(() => { load(); }, [load]);

  const sendReminders = async () => {
    setBusy("rem");
    try { const { data } = await api.post("/notifications/dues-reminder", {}); toast.success(t("notif.reminderSent", { n: data.houses_notified })); load(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(""); }
  };
  const sendCustom = async () => {
    if (!custom.trim()) return;
    setBusy("custom");
    try { const { data } = await api.post("/notifications/custom", { body: custom }); toast.success(t("notif.sentAll", { n: data.houses })); setCustom(""); setTimeout(load, 800); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(""); }
  };
  const clear = async () => { await api.delete("/notifications/clear"); setClearing(false); load(); };

  return (
    <div data-testid="messages-page">
      <PageHeader title={t("notif.title")} actions={<Button variant="ghost" onClick={load} className="h-11" data-testid="messages-refresh-button"><RefreshCw className="h-4 w-4 mr-2" />{t("common.view")}</Button>} />
      <div className="space-y-6">
        <GatewayBanner status={status} />
        <Outbox key={refreshKey} />

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
          <StatCard label={t("notif.total")} value={summary?.total ?? 0} icon={MessageSquare} testId="stat-messages-total" />
          <StatCard label={t("notif.kinds.dues_reminder")} value={summary?.by_kind?.dues_reminder ?? 0} icon={BellRing} tone="amber" testId="stat-messages-reminders" delay={60} />
          <StatCard label={t("notif.kinds.announcement")} value={summary?.by_kind?.announcement ?? 0} icon={Send} tone="gold" testId="stat-messages-announcements" delay={120} />
          <StatCard label={t("notif.kinds.receipt")} value={summary?.by_kind?.receipt ?? 0} icon={MessageSquare} testId="stat-messages-receipts" delay={180} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-xl border border-[#e6dbc9] bg-card p-5 shadow-sm flex flex-col gap-3">
            <h3 className="font-bold flex items-center gap-2"><BellRing className="h-5 w-5 text-[#c58b2b]" />{t("notif.sendDuesReminder")}</h3>
            <p className="text-sm text-muted-foreground flex-1">{t("subs.dues")} → {t(`notif.channels.${status?.notify_channel || "whatsapp"}`)}</p>
            <Button onClick={sendReminders} disabled={busy === "rem"} className="h-11 self-start" data-testid="send-dues-reminder-button"><BellRing className="h-4 w-4 mr-2" />{t("notif.sendDuesReminder")}</Button>
          </div>
          <div className="rounded-xl border border-[#e6dbc9] bg-card p-5 shadow-sm flex flex-col gap-3">
            <h3 className="font-bold flex items-center gap-2"><Send className="h-5 w-5 text-primary" />{t("notif.customMessage")}</h3>
            <Textarea rows={3} value={custom} onChange={(e) => setCustom(e.target.value)} placeholder={t("notif.customPlaceholder")} data-testid="custom-message-input" />
            <div className="flex flex-wrap gap-2">
              <AiButton value={custom} purpose="WhatsApp message" onUse={setCustom} />
              <Button onClick={sendCustom} disabled={busy === "custom" || !custom.trim()} className="h-11" data-testid="send-custom-message-button"><Send className="h-4 w-4 mr-2" />{t("notif.send")}</Button>
            </div>
          </div>
        </div>

        <AutoReminderPanel onSent={load} />

        <div>
          <div className="flex flex-col sm:flex-row sm:items-end gap-3 mb-3">
            <SelectField label={t("notif.kind")} value={kind} onChange={setKind} testId="messages-kind-filter" className="sm:w-56" options={[{ value: "all", label: t("common.all") }, ...KINDS.map((k) => ({ value: k, label: t(`notif.kinds.${k}`) }))]} />
            <SelectField label={t("notif.channel")} value={channel} onChange={setChannel} testId="messages-channel-filter" className="sm:w-48" options={[{ value: "all", label: t("common.all") }, { value: "whatsapp", label: "WhatsApp" }, { value: "sms", label: "SMS" }]} />
            <Button variant="outline" onClick={() => setClearing(true)} className="h-11 sm:ml-auto text-destructive" data-testid="clear-messages-button"><Trash2 className="h-4 w-4 mr-2" />{t("notif.clearLog")}</Button>
          </div>
          <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
            {rows.length === 0 ? <EmptyState text={t("notif.noMessages")} testId="messages-empty" /> : (
              <Table data-testid="messages-table">
                <TableHeader><TableRow className="bg-accent/60">
                  <TableHead>{t("notif.sentAt")}</TableHead><TableHead>{t("notif.kind")}</TableHead><TableHead>{t("notif.channel")}</TableHead>
                  <TableHead>{t("notif.to")}</TableHead><TableHead className="hidden md:table-cell">{t("notif.body")}</TableHead><TableHead>{t("notif.statusCol")}</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {rows.map((m) => (
                    <TableRow key={m.id} data-testid={`message-row-${m.id}`}>
                      <TableCell className="text-xs whitespace-nowrap">{new Date(m.created_at).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</TableCell>
                      <TableCell><span className="rounded-full bg-accent px-2.5 py-0.5 text-xs font-semibold">{t(`notif.kinds.${m.kind}`)}</span></TableCell>
                      <TableCell><span className={cn("rounded-full px-2.5 py-0.5 text-xs font-bold", m.channel === "whatsapp" ? "bg-[#25D366]/15 text-[#128C7E]" : "bg-[#1c2420]/10 text-[#1c2420]")}>{m.channel === "whatsapp" ? "WhatsApp" : "SMS"}</span></TableCell>
                      <TableCell className="text-sm"><p className="font-medium">{m.recipient_name}</p><p className="text-xs text-muted-foreground font-mono">{m.to}</p></TableCell>
                      <TableCell className="hidden md:table-cell text-xs text-muted-foreground max-w-md"><p className="line-clamp-2 whitespace-pre-line" title={m.body}>{m.body}</p></TableCell>
                      <TableCell><span className={cn("rounded-full px-2.5 py-0.5 text-xs font-semibold", m.status === "sent" ? "bg-primary/10 text-primary" : m.status === "failed" ? "bg-destructive/10 text-destructive" : "bg-[#d4af37]/20 text-[#8a6d1d]")} title={m.error}>{t(`notif.statuses.${m.status}`)}</span></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </div>
      </div>
      <ConfirmDelete open={clearing} onOpenChange={setClearing} onConfirm={clear} />
    </div>
  );
}
