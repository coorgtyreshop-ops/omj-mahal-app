import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Megaphone, CalendarDays, Users, Moon } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { fmtDate, todayStr } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete, TextField, SelectField, SubmitRow, Field } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { AiButton } from "@/components/AiComposer";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

const CATS = ["general", "janazah", "event", "meeting"];
const ICONS = { general: Megaphone, janazah: Moon, event: CalendarDays, meeting: Users };
const STYLES = {
  general: "bg-primary/10 text-primary",
  janazah: "bg-[#1c2420] text-[#d4af37]",
  event: "bg-[#d4af37]/20 text-[#8a6d1d]",
  meeting: "bg-[#c58b2b]/15 text-[#a06f1c]",
};

export const AnnouncementCard = ({ a, compact, onEdit, onDelete }) => {
  const { t } = useLang();
  const Icon = ICONS[a.category] || Megaphone;
  const janazah = a.category === "janazah";
  return (
    <article className={cn("rounded-xl border p-4 sm:p-5 shadow-sm hover:shadow-md transition-shadow", janazah ? "bg-[#1c2420] text-white border-[#15803d]/60" : "bg-card border-[#e6dbc9]")} data-testid={`announcement-card-${a.id}`}>
      <div className="flex items-start gap-3">
        <span className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-lg", janazah ? "bg-[#15803d]/30 text-[#d4af37]" : STYLES[a.category])}><Icon className="h-5 w-5" /></span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <span className={cn("rounded-full px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide", janazah ? "bg-[#d4af37] text-[#1c2420]" : STYLES[a.category])}>{t(`ann.categories.${a.category}`)}</span>
            <span className={cn("text-xs", janazah ? "text-white/60" : "text-muted-foreground")}>{fmtDate(a.date)}</span>
          </div>
          <h3 className="font-bold text-base sm:text-lg leading-snug">{a.title}</h3>
          <p className={cn("mt-1 text-sm whitespace-pre-line", janazah ? "text-white/80" : "text-muted-foreground", compact && "line-clamp-2")}>{a.content}</p>
          {a.image_url && !compact && <img src={a.image_url} alt="" className="mt-3 rounded-lg max-h-72 object-cover w-full" />}
        </div>
        {(onEdit || onDelete) && (
          <div className="flex flex-col gap-1 shrink-0">
            {onEdit && <Button size="icon" variant="ghost" className={janazah ? "text-white hover:bg-white/10" : ""} onClick={() => onEdit(a)} data-testid={`edit-announcement-${a.id}`}><Pencil className="h-4 w-4" /></Button>}
            {onDelete && <Button size="icon" variant="ghost" className="text-destructive" onClick={() => onDelete(a)} data-testid={`delete-announcement-${a.id}`}><Trash2 className="h-4 w-4" /></Button>}
          </div>
        )}
      </div>
    </article>
  );
};

const empty = { title: "", content: "", category: "general", date: todayStr(), image_url: "" };

const AnnForm = ({ open, onOpenChange, ann, onSaved }) => {
  const { t } = useLang();
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) setForm(ann ? { ...empty, ...ann } : { ...empty, date: todayStr() }); }, [open, ann]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const payload = { title: form.title, content: form.content, category: form.category, date: form.date, image_url: form.image_url };
      ann?.id ? await api.put(`/announcements/${ann.id}`, payload) : await api.post("/announcements", payload);
      toast.success(t("ann.posted")); onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid="announcement-form-dialog">
        <DialogHeader><DialogTitle>{ann?.id ? t("ann.edit") : t("ann.add")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <TextField label={t("ann.heading")} value={form.title} onChange={set("title")} required testId="announcement-title-input" />
          <Field label={t("ann.content")} required><Textarea rows={5} value={form.content} onChange={(e) => set("content")(e.target.value)} required data-testid="announcement-content-input" /><AiButton value={form.content} purpose="announcement" onUse={(v) => set("content")(v)} className="mt-2" /></Field>
          <div className="grid grid-cols-2 gap-4">
            <SelectField label={t("ann.category")} value={form.category} onChange={set("category")} testId="announcement-category-select" options={CATS.map((c) => ({ value: c, label: t(`ann.categories.${c}`) }))} />
            <TextField label={t("common.date")} type="date" value={form.date} onChange={set("date")} testId="announcement-date-input" />
          </div>
          <TextField label={t("ann.imageUrl")} value={form.image_url} onChange={set("image_url")} testId="announcement-image-input" placeholder="https://" />
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default function Announcements() {
  const { t } = useLang();
  const { isAdmin } = useAuth();
  const [params, setParams] = useSearchParams();
  const [rows, setRows] = useState([]);
  const [cat, setCat] = useState("all");
  const [formOpen, setFormOpen] = useState(params.get("new") === "1");
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const load = useCallback(async () => {
    const { data } = await api.get("/announcements", { params: { category: cat !== "all" ? cat : undefined } });
    setRows(data);
  }, [cat]);
  useEffect(() => { load(); }, [load]);

  const closeForm = (o) => { setFormOpen(o); if (!o && params.get("new")) setParams({}); };
  const remove = async () => { try { await api.delete(`/announcements/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load(); } catch (e) { toast.error(apiError(e)); } };

  return (
    <div data-testid="announcements-page">
      <PageHeader title={t("ann.title")} actions={isAdmin && <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="h-11" data-testid="add-announcement-button"><Plus className="h-4 w-4 mr-2" />{t("ann.add")}</Button>} />
      <Tabs value={cat} onValueChange={setCat} className="mb-4">
        <TabsList className="h-11 flex-wrap">
          <TabsTrigger value="all" className="h-9" data-testid="ann-filter-all">{t("common.all")}</TabsTrigger>
          {CATS.map((c) => <TabsTrigger key={c} value={c} className="h-9" data-testid={`ann-filter-${c}`}>{t(`ann.categories.${c}`)}</TabsTrigger>)}
        </TabsList>
      </Tabs>
      {rows.length === 0 ? <EmptyState text={t("ann.noAnn")} /> : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4" data-testid="announcements-list">
          {rows.map((a) => <AnnouncementCard key={a.id} a={a} onEdit={isAdmin ? (x) => { setEditing(x); setFormOpen(true); } : undefined} onDelete={isAdmin ? setDeleting : undefined} />)}
        </div>
      )}
      {isAdmin && <AnnForm open={formOpen} onOpenChange={closeForm} ann={editing} onSaved={load} />}
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
    </div>
  );
}
