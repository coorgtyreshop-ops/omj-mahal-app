import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Megaphone, UsersRound, HandCoins, LogIn, Lock, CalendarDays } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { logoSrc, mahalName, appName } from "@/lib/branding";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { AnnouncementCard } from "@/pages/Announcements";
import { CommitteeCard } from "@/pages/Committee";
import { FundCard } from "@/pages/Donations";
import { EmptyState } from "@/components/shared";
import { Ticker } from "@/components/Ticker";
import { PosterShowcase } from "@/components/events/PosterShowcase";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const GuestEventCard = ({ ev }) => {
  const { lang } = useLang();
  const title = lang === "ml" && ev.title_ml ? ev.title_ml : lang === "kn" && ev.title_kn ? ev.title_kn : ev.title;
  return (
    <div className="stat-in flex gap-4 rounded-xl border border-[#e6dbc9] bg-card p-4 shadow-sm" data-testid={`guest-event-${ev.id}`}>
      {ev.poster_url && <img src={`${process.env.REACT_APP_BACKEND_URL}${ev.poster_url}`} alt="" className="h-28 w-20 rounded-lg object-cover shrink-0" />}
      <div className="min-w-0">
        <p className="text-[11px] font-bold uppercase tracking-[0.15em] text-[#8a6d1d]">{ev.hijri?.[lang === "ml" ? "label_ml" : lang === "kn" ? "label_kn" : "label"]}</p>
        <h3 className="font-bold text-lg leading-tight">{title}</h3>
        <p className="text-sm text-muted-foreground mt-1">{ev.date}{ev.time && ` · ${ev.time}`}{ev.venue && ` · ${ev.venue}`}</p>
        {ev.description && <p className="text-sm mt-2 line-clamp-3">{ev.description}</p>}
      </div>
    </div>
  );
};

const TABS = [
  { key: "announcements", icon: Megaphone, path: "/public/announcements" },
  { key: "events", icon: CalendarDays, path: "/public/events" },
  { key: "committee", icon: UsersRound, path: "/public/committee" },
  { key: "funds", icon: HandCoins, path: "/public/funds" },
];

export default function Guest() {
  const { t, lang } = useLang();
  const { settings } = useAuth();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const tab = TABS.some((x) => x.key === params.get("tab")) ? params.get("tab") : "announcements";
  const [rows, setRows] = useState(null);
  const [blocked, setBlocked] = useState(false);

  useEffect(() => {
    setRows(null);
    api.get(TABS.find((x) => x.key === tab).path).then((r) => setRows(r.data)).catch((e) => { setRows([]); if (e?.response?.status === 403) setBlocked(true); });
  }, [tab]);

  return (
    <div className="min-h-screen bg-background flex flex-col" data-testid="guest-page">
      <header className="islamic-pattern text-white">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-3">
          <img src={logoSrc(settings)} alt="" className="h-11 w-11 rounded-full bg-white object-cover ring-2 ring-[#d4af37]" />
          <div className="min-w-0 flex-1">
            <p className="font-bold leading-tight" data-testid="guest-app-name">{appName(settings)}</p>
            <p className="text-xs text-white/80 truncate">{mahalName(settings, lang)}</p>
          </div>
          <span className="hidden sm:inline-flex rounded-full bg-[#d4af37]/20 text-[#d4af37] px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide">{t("guest.badge")}</span>
          <LanguageSwitcher dark />
          <Button size="sm" onClick={() => navigate("/login")} className="h-10 bg-[#d4af37] text-[#1e2923] hover:bg-[#e2c053] font-semibold" data-testid="guest-login-button"><LogIn className="h-4 w-4 mr-1" />{t("guest.login")}</Button>
        </div>
        <nav className="max-w-5xl mx-auto px-4 flex gap-1 overflow-x-auto">
          {TABS.map(({ key, icon: Icon }) => (
            <button key={key} onClick={() => setParams({ tab: key })} data-testid={`guest-tab-${key}`}
              className={cn("flex items-center gap-2 px-4 h-11 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors", tab === key ? "border-[#d4af37] text-[#d4af37]" : "border-transparent text-white/75 hover:text-white")}>
              <Icon className="h-4 w-4" />{t(`guest.tabs.${key}`)}
            </button>
          ))}
        </nav>
      </header>
      <Ticker to="/guest?tab=announcements" />

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6 space-y-4">
        <Link to="/login" className="flex items-center gap-3 rounded-xl border border-[#d4af37]/50 bg-[#d4af37]/10 px-4 py-3 text-sm hover:bg-[#d4af37]/20 transition-colors" data-testid="guest-login-hint">
          <Lock className="h-5 w-5 text-[#8a6d1d] shrink-0" /><span className="font-medium">{t("guest.hint")}</span>
        </Link>
        <PosterShowcase to={null} />
        {blocked ? <EmptyState text={t("common.error")} testId="guest-blocked" /> : rows === null ? <p className="text-muted-foreground">{t("common.loading")}</p> : rows.length === 0 ? <EmptyState text={t("common.noData")} /> : (
          <div className={cn("grid gap-4", tab === "announcements" || tab === "events" ? "grid-cols-1 lg:grid-cols-2" : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3")} data-testid={`guest-list-${tab}`}>
            {tab === "announcements" && rows.map((a) => <AnnouncementCard key={a.id} a={a} />)}
            {tab === "events" && rows.map((ev) => <GuestEventCard key={ev.id} ev={ev} />)}
            {tab === "committee" && rows.map((c, i) => <CommitteeCard key={c.id} c={c} i={i} />)}
            {tab === "funds" && rows.map((f) => <FundCard key={f.id} fund={f} />)}
          </div>
        )}
      </main>
      <footer className="text-center text-xs text-muted-foreground py-4">© {new Date().getFullYear()} {settings?.mahal_name}</footer>
    </div>
  );
}
