import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Plus, Settings2, Printer, Check, X, FileText, History, BookOpen, MessageCircle, Gavel, BarChart3, QrCode, ScanLine } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, fmtDate } from "@/lib/format";
import { PageHeader, EmptyState, StatCard, TextField, SelectField, SubmitRow } from "@/components/shared";
import { PrintDialog, ReceiptBody } from "@/components/print/Printables";
import { BalanceNotice } from "@/components/print/BalanceNotice";
import { CollectionPaymentForm, allTypes, HOUSE_TYPES, typeLabel } from "@/components/forms/CollectionPaymentForm";
import { OldBalanceDialog, StatementDialog, BulkOldBalanceDialog } from "@/components/finance/FinanceDialogs";
import { ReportDialog } from "@/components/finance/CollectionReport";
import { CalculatorButton } from "@/components/finance/Calculator";
import { UpiQrUpload } from "@/components/finance/UpiQrUpload";
import { QrPoster } from "@/components/finance/QrPoster";
import { ReleaseAllButton } from "@/components/finance/ReleaseStatement";
import { openChatLink } from "@/lib/whatsapp";
import { useQr } from "@/components/MemberCard";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const FEE_FIELDS = ["fee_eid_fitr", "fee_eid_adha", "fee_nabidinam", "fee_building", "fee_special"];
const BANK_FIELDS = ["bank_name", "bank_account_name", "bank_account_no", "bank_ifsc"];
// Only apps whose UPI ID really is <mobile>@handle get auto-built from the phone number.
// Google Pay IDs are name-based (e.g. mahal@okicici) and must be copied from the GPay app.
const UPI_APPS = [
  { value: "phonepe", label: "PhonePe", suffix: "ybl", byPhone: true },
  { value: "paytm", label: "Paytm", suffix: "paytm", byPhone: true },
  { value: "bhim", label: "BHIM", suffix: "upi", byPhone: true },
  { value: "gpay_sbi", label: "Google Pay (SBI)", suffix: "oksbi" },
  { value: "gpay_axis", label: "Google Pay (Axis)", suffix: "okaxis" },
  { value: "gpay_hdfc", label: "Google Pay (HDFC)", suffix: "okhdfcbank" },
  { value: "gpay_icici", label: "Google Pay (ICICI)", suffix: "okicici" },
  { value: "custom", label: "UPI ID", suffix: "" },
];
const buildUpi = (phone, app) => { const a = UPI_APPS.find((x) => x.value === app); const p = (phone || "").replace(/\D/g, "").slice(-10); return a?.byPhone && p.length === 10 ? `${p}@${a.suffix}` : ""; };
const isGpay = (app) => (app || "").startsWith("gpay");
const UpiTestQr = ({ upiId, name }) => {
  const { t } = useLang();
  const link = upiId && upiId.includes("@") ? `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(name || "Mahal")}&am=1.00&cu=INR&tn=Test` : "";
  const qr = useQr(link);
  if (!link) return null;
  return (
    <div className="flex items-center gap-3 rounded-md border border-[#0d5c3a]/30 bg-[#0d5c3a]/5 p-2" data-testid="upi-test-qr">
      {qr ? <img src={qr} alt="UPI test QR" className="h-24 w-24 rounded bg-white" data-testid="upi-test-qr-image" /> : <div className="h-24 w-24" />}
      <p className="text-xs text-muted-foreground">{t("fin.upiTest")}</p>
    </div>
  );
};
const FEE_LABEL = { fee_eid_fitr: "eid_fitr", fee_eid_adha: "eid_adha", fee_nabidinam: "nabidinam", fee_building: "building", fee_special: "special" };

export const FeesDialog = ({ open, onOpenChange, fees, onSaved, focusQr = false }) => {
  const { t } = useLang();
  const { refreshSettings } = useAuth();
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open && focusQr) setTimeout(() => document.getElementById("upi-qr-upload")?.scrollIntoView({ behavior: "smooth", block: "center" }), 250); }, [open, focusQr]);
  useEffect(() => { if (open && fees) setForm({ fee_eid_fitr: fees.fee_eid_fitr, fee_eid_adha: fees.fee_eid_adha, fee_nabidinam: fees.fee_nabidinam, fee_building: fees.fee_building, fee_special: fees.fee_special || 0, special_name: fees.special_name || "", default_subscription: fees.default_subscription ?? "", upi_id: fees.upi_id || "", upi_name: fees.upi_name || "", upi_phone: fees.upi_phone || "", upi_app: fees.upi_app || (fees.upi_id ? "custom" : "phonepe"), upi_qr_url: fees.upi_qr_url || "", ...Object.fromEntries(BANK_FIELDS.map((k) => [k, fees[k] || ""])), custom_heads: (fees.custom_heads || []).map((h) => ({ ...h })) }); }, [open, fees]);
  const set = (k) => (v) => setForm((f) => {
    const next = { ...f, [k]: v };
    if (k === "upi_phone" || k === "upi_app") { const built = buildUpi(next.upi_phone, next.upi_app); if (built) next.upi_id = built; }
    return next;
  });
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      await api.put("/finance/fees", { ...form, ...Object.fromEntries(FEE_FIELDS.map((k) => [k, Number(form[k] || 0)])), default_subscription: form.default_subscription === "" ? null : Number(form.default_subscription), custom_heads: (form.custom_heads || []).filter((h) => h.name?.trim() && Number(h.amount) > 0).map((h) => ({ ...h, amount: Number(h.amount) })) });
      toast.success(t("fin.feesSaved")); refreshSettings(); onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto" data-testid="fees-dialog">
        <DialogHeader><DialogTitle>{t("fin.fees")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <p className="text-xs text-muted-foreground">{t("fin.feeHint")}</p>
          <div className="grid grid-cols-2 gap-4">
            <TextField label={t("fin.monthlyDefault")} type="number" min="0" value={form.default_subscription ?? ""} onChange={(v) => setForm((f) => ({ ...f, default_subscription: v }))} testId="fee-monthly-input" />
            <TextField label={t("fin.yearlyDefault")} type="number" min="0" value={form.default_subscription === "" || form.default_subscription == null ? "" : Math.round(Number(form.default_subscription) * 12)} onChange={(v) => setForm((f) => ({ ...f, default_subscription: v === "" ? "" : Math.round((Number(v) / 12) * 100) / 100 }))} testId="fee-yearly-input" />
            {FEE_FIELDS.map((k) => <TextField key={k} label={`${k === "fee_special" && form.special_name ? form.special_name : t(`fin.types.${FEE_LABEL[k]}`)} (${k === "fee_building" || k === "fee_special" ? t("fin.target") : t("fin.perYear")})`} type="number" min="0" value={form[k] ?? ""} onChange={set(k)} testId={`fee-${FEE_LABEL[k]}-input`} />)}
            <TextField label={t("fin.specialName")} value={form.special_name ?? ""} onChange={set("special_name")} placeholder={t("fin.types.special")} testId="fee-special-name-input" />
            <p className="text-xs text-muted-foreground col-span-2 -mt-2">{t("fin.specialHint")}</p>
          </div>
          <div className="rounded-lg border border-[#d4af37]/50 bg-[#d4af37]/5 p-3" data-testid="custom-heads-editor">
            <div className="flex items-center justify-between mb-1">
              <p className="text-sm font-semibold">{t("fin.customHeads.title")}</p>
              <Button type="button" size="sm" variant="outline" className="h-9" onClick={() => setForm((f) => ({ ...f, custom_heads: [...(f.custom_heads || []), { id: "", name: "", kind: "yearly", amount: "" }] }))} data-testid="custom-head-add"><Plus className="h-4 w-4 mr-1" />{t("fin.customHeads.add")}</Button>
            </div>
            <p className="text-xs text-muted-foreground mb-2">{t("fin.customHeads.hint")}</p>
            {(form.custom_heads || []).length === 0 && <p className="text-xs text-muted-foreground italic" data-testid="custom-heads-empty">{t("fin.customHeads.none")}</p>}
            {(form.custom_heads || []).map((h, i) => (
              <div key={h.id || i} className="grid grid-cols-[1fr_auto_auto_auto] gap-2 items-end mb-2" data-testid={`custom-head-row-${i}`}>
                <TextField label={t("fin.customHeads.name")} value={h.name} onChange={(v) => setForm((f) => { const arr = [...f.custom_heads]; arr[i] = { ...arr[i], name: v }; return { ...f, custom_heads: arr }; })} placeholder={t("fin.customHeads.namePh")} testId={`custom-head-name-${i}`} />
                <SelectField label={t("fin.customHeads.kind")} value={h.kind || "yearly"} onChange={(v) => setForm((f) => { const arr = [...f.custom_heads]; arr[i] = { ...arr[i], kind: v }; return { ...f, custom_heads: arr }; })} testId={`custom-head-kind-${i}`} options={[{ value: "yearly", label: t("fin.perYear") }, { value: "one_time", label: t("fin.kinds.one_time") }]} className="w-36" />
                <TextField label={t("common.amount")} type="number" min="0" value={h.amount} onChange={(v) => setForm((f) => { const arr = [...f.custom_heads]; arr[i] = { ...arr[i], amount: v }; return { ...f, custom_heads: arr }; })} testId={`custom-head-amount-${i}`} className="w-28" />
                <Button type="button" size="icon" variant="ghost" className="text-destructive mb-0.5" onClick={() => setForm((f) => ({ ...f, custom_heads: f.custom_heads.filter((_, j) => j !== i) }))} data-testid={`custom-head-remove-${i}`}><X className="h-4 w-4" /></Button>
              </div>
            ))}
          </div>
          <p className="text-sm font-semibold pt-1">{t("fin.upiSection")}</p>
          <UpiQrUpload form={form} setForm={setForm} highlight={focusQr} />
          <div className="grid grid-cols-2 gap-4">
            <SelectField label={t("fin.upiApp")} value={form.upi_app ?? "phonepe"} onChange={set("upi_app")} testId="fee-upi-app-select" options={UPI_APPS.map((a) => ({ value: a.value, label: a.value === "custom" ? t("fin.upiCustom") : a.label }))} />
            {(UPI_APPS.find((a) => a.value === form.upi_app)?.byPhone || isGpay(form.upi_app)) && <TextField label={isGpay(form.upi_app) ? t("fin.gpay.field") : t("fin.upiPhone")} value={form.upi_phone ?? ""} onChange={set("upi_phone")} placeholder="98470 00000" testId="fee-upi-phone-input" />}
            <TextField label={t("fin.upiId")} value={form.upi_id ?? ""} onChange={set("upi_id")} placeholder={isGpay(form.upi_app) ? "mahal@okicici" : "mahal@upi"} testId="fee-upi-id-input" className={UPI_APPS.find((a) => a.value === form.upi_app)?.byPhone || isGpay(form.upi_app) ? "" : "col-span-2"} />
            {isGpay(form.upi_app) && <p className="text-xs rounded-md bg-[#c58b2b]/10 text-[#8a6d1d] px-3 py-2 col-span-2" data-testid="gpay-hint">{t("fin.gpayHint")}</p>}
            {UPI_APPS.find((a) => a.value === form.upi_app)?.byPhone && <p className="text-xs rounded-md bg-[#c58b2b]/10 text-[#8a6d1d] px-3 py-2 col-span-2" data-testid="phone-upi-hint">{t("fin.phoneUpiHint")}</p>}
            <TextField label={t("fin.upiName")} value={form.upi_name ?? ""} onChange={set("upi_name")} testId="fee-upi-name-input" className="col-span-2" />
          </div>
          {form.upi_id && <p className="text-xs rounded-md bg-primary/10 text-primary px-3 py-2" data-testid="upi-preview">{t("fin.upiPreview", { upi: form.upi_id })}</p>}
          <UpiTestQr upiId={form.upi_id} name={form.upi_name} />
          <p className="text-xs text-muted-foreground">{t("fin.upiHint")}</p>
          <p className="text-sm font-semibold pt-1">{t("fin.bank.title")}</p>
          <div className="grid grid-cols-2 gap-4">
            {BANK_FIELDS.map((k) => <TextField key={k} label={t(`fin.bank.${k}`)} value={form[k] ?? ""} onChange={set(k)} testId={`${k.replace(/_/g, "-")}-input`} />)}
          </div>
          <p className="text-xs text-muted-foreground">{t("fin.bank.hint")}</p>
          <p className="text-xs rounded-md bg-primary/10 text-primary px-3 py-2" data-testid="bank-editable-hint">{t("fin.gpay.sample")}</p>
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

const RequestsTable = ({ requests, onDone }) => {
  const { t } = useLang();
  const [rejecting, setRejecting] = useState(null);
  const [reason, setReason] = useState("");
  const approve = async (r) => {
    try { const { data } = await api.post(`/finance/pay-requests/${r.id}/approve`); toast.success(t("fin.approvedMsg", { receipt: data.receipt_no })); onDone(); } catch (e) { toast.error(apiError(e)); }
  };
  const reject = async () => {
    try { await api.post(`/finance/pay-requests/${rejecting.id}/reject`, { reason }); toast.success(t("fin.rejectedMsg")); setRejecting(null); setReason(""); onDone(); } catch (e) { toast.error(apiError(e)); }
  };
  if (!requests.length) return null;
  return (
    <section className="mb-6 rounded-xl border border-[#c58b2b]/40 bg-[#c58b2b]/5 shadow-sm overflow-hidden" data-testid="pay-requests-section">
      <div className="px-4 py-3 font-semibold flex items-center gap-2">{t("fin.requests")} <span className="rounded-full bg-[#c58b2b]/20 text-[#a06f1c] px-2 text-xs">{requests.length}</span></div>
      <Table data-testid="pay-requests-table">
        <TableHeader><TableRow className="bg-accent/60"><TableHead>{t("common.date")}</TableHead><TableHead>{t("houses.houseNo")}</TableHead><TableHead>{t("fin.type")}</TableHead><TableHead className="hidden sm:table-cell">{t("fin.upiRef")}</TableHead><TableHead className="text-right">{t("common.amount")}</TableHead><TableHead /></TableRow></TableHeader>
        <TableBody>
          {requests.map((r) => (
            <TableRow key={r.id} data-testid={`pay-request-row-${r.id}`}>
              <TableCell className="text-xs">{fmtDate(r.created_at.slice(0, 10))}</TableCell>
              <TableCell><span className="font-bold text-primary">{r.house_no}</span><p className="text-xs text-muted-foreground">{r.head_name}</p></TableCell>
              <TableCell className="text-sm">{t(`fin.types.${r.type}`)}</TableCell>
              <TableCell className="hidden sm:table-cell font-mono text-xs">{r.upi_ref || "—"}{r.note && <p className="text-muted-foreground">{r.note}</p>}</TableCell>
              <TableCell className="text-right font-semibold">{inr(r.amount)}</TableCell>
              <TableCell className="text-right whitespace-nowrap">
                <Button size="sm" onClick={() => approve(r)} className="h-9 mr-1" data-testid={`approve-request-${r.id}`}><Check className="h-4 w-4 mr-1" />{t("fin.approve")}</Button>
                <Button size="sm" variant="outline" onClick={() => setRejecting(r)} className="h-9 text-destructive" data-testid={`reject-request-${r.id}`}><X className="h-4 w-4" /></Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <Dialog open={!!rejecting} onOpenChange={(o) => !o && setRejecting(null)}>
        <DialogContent className="max-w-sm" data-testid="reject-dialog">
          <DialogHeader><DialogTitle>{t("fin.reject")}</DialogTitle></DialogHeader>
          <TextField label={t("fin.reason")} value={reason} onChange={setReason} testId="reject-reason-input" />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setRejecting(null)} className="h-11" data-testid="reject-cancel-button">{t("common.cancel")}</Button>
            <Button type="button" variant="destructive" onClick={reject} className="h-11" data-testid="reject-confirm-button">{t("fin.reject")}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default function Collections() {
  const { t } = useLang();
  const { settings } = useAuth();
  const [overview, setOverview] = useState({ rows: [], totals: {} });
  const [fees, setFees] = useState(null);
  const [requests, setRequests] = useState([]);
  const [houses, setHouses] = useState([]);
  const [feesOpen, setFeesOpen] = useState(false);
  const [form, setForm] = useState(null);
  const [receipt, setReceipt] = useState(null);
  const [notices, setNotices] = useState(null);
  const [oldBal, setOldBal] = useState(null);
  const [bulkOb, setBulkOb] = useState(false);
  const [stmtOpen, setStmtOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [posterOpen, setPosterOpen] = useState(false);

  const load = useCallback(async () => {
    const [o, f, r, h] = await Promise.all([api.get("/finance/overview"), api.get("/finance/fees"), api.get("/finance/pay-requests", { params: { status: "pending" } }), api.get("/houses")]);
    setOverview(o.data); setFees(f.data); setRequests(r.data); setHouses(h.data);
  }, []);
  useEffect(() => { load(); }, [load]);

  const whatsapp = async (r) => {
    try {
      const { data } = await api.post("/notifications/balance-reminder", { house_ids: [r.id], channel: "whatsapp" });
      const m = data.results.find((x) => x.wa_link);
      if (!m) return toast.info(t("fin.noDue"));
      if (m.status === "sent") toast.success(t("notif.reminderSent", { n: 1 }));
      else openChatLink(m.wa_link, t("outbox.tapOpen"));
    } catch (e) { toast.error(apiError(e)); }
  };
  const printNotices = async (houseId, all = false) => {
    try { const { data } = await api.get("/finance/notices", { params: houseId ? { house_id: houseId } : all ? { include_all: true } : {} }); if (!data.length) return toast.info(t("fin.noDue")); setNotices(data); } catch (e) { toast.error(apiError(e)); }
  };
  const hasType = (k) => (overview.totals[k]?.pending || 0) > 0 || (overview.totals[k]?.paid || 0) > 0 || (k === "special" && (fees?.fee_special || 0) > 0);
  const cols = allTypes(settings).filter((k) => k !== "donation" && (!HOUSE_TYPES.includes(k) || hasType(k)));
  const statTypes = allTypes(settings).filter((k) => !HOUSE_TYPES.includes(k) || hasType(k));
  const withBalance = overview.rows.filter((r) => r.total_pending > 0);

  return (
    <div data-testid="collections-page">
      <PageHeader title={t("fin.title")} subtitle={t("fin.subtitle")} actions={<>
        <Button asChild variant="outline" className="h-11 border-primary/50 text-primary" data-testid="scan-card-button"><Link to="/scan"><ScanLine className="h-4 w-4 mr-2" />{t("scan.nav")}</Link></Button>
        <Button variant="outline" onClick={() => setReportOpen(true)} className="h-11" data-testid="report-button"><BarChart3 className="h-4 w-4 mr-2" />{t("fin.report.button")}</Button>
        <CalculatorButton />
        <Button variant="outline" onClick={() => setFeesOpen(true)} className="h-11" data-testid="fees-button"><Settings2 className="h-4 w-4 mr-2" />{t("fin.fees")}</Button>
        <Button variant="outline" onClick={() => setBulkOb(true)} className="h-11" data-testid="bulk-old-balance-button"><History className="h-4 w-4 mr-2" />{t("fin.oldBalance.bulkTitle")}</Button>
        <Button variant="outline" onClick={() => setStmtOpen(true)} className="h-11" data-testid="statement-button"><BookOpen className="h-4 w-4 mr-2" />{t("fin.statement.title")}</Button>
        <Button variant="outline" onClick={() => printNotices()} disabled={!withBalance.length} className="h-11" data-testid="print-all-notices-button"><Printer className="h-4 w-4 mr-2" />{t("fin.notice.printAll")}</Button>
        <Button variant="outline" onClick={() => printNotices(null, true)} disabled={!overview.rows.length} className="h-11" data-testid="print-everyone-notices-button"><Printer className="h-4 w-4 mr-2" />{t("fin.notice.printEveryone")}</Button>
        <Button variant="outline" onClick={() => setPosterOpen(true)} disabled={!fees?.upi_id && !fees?.upi_qr_url} className="h-11" data-testid="qr-poster-button"><QrCode className="h-4 w-4 mr-2" />{t("fin.qr.poster")}</Button>
        <ReleaseAllButton onDone={load} />
        <Button onClick={() => setForm({})} className="h-11" data-testid="record-collection-button"><Plus className="h-4 w-4 mr-2" />{t("fin.record")}</Button>
      </>} />

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 mb-6" data-testid="collection-totals">
        {statTypes.map((k, i) => {
          const tot = overview.totals[k] || { paid: 0, pending: 0 };
          return <StatCard key={k} label={typeLabel(t, k, settings)} value={k === "donation" ? inr(tot.paid) : inr(tot.pending)} hint={k === "donation" ? t("fin.paid") : `${t("fin.paid")}: ${inr(tot.paid)}`} testId={`total-${k}`} delay={i * 50} />;
        })}
      </div>

      <RequestsTable requests={requests} onDone={load} />

      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        <div className="px-4 py-3 font-semibold flex items-center justify-between"><span>{t("fin.overview")}</span><span className="text-xs text-muted-foreground">{withBalance.length} {t("fin.housesWithBalance")}</span></div>
        {overview.rows.length === 0 ? <EmptyState text={t("houses.noHouses")} /> : (
          <div className="overflow-x-auto">
            <Table data-testid="collections-overview-table">
              <TableHeader><TableRow className="bg-accent/60">
                <TableHead>{t("houses.houseNo")}</TableHead>
                {cols.map((k) => <TableHead key={k} className="text-right hidden md:table-cell">{typeLabel(t, k, settings)}</TableHead>)}
                <TableHead className="text-right">{t("fin.totalPending")}</TableHead><TableHead />
              </TableRow></TableHeader>
              <TableBody>
                {overview.rows.map((r) => (
                  <TableRow key={r.id} data-testid={`overview-row-${r.house_no}`} className={r.total_pending > 0 ? "" : "opacity-60"}>
                    <TableCell><Link to={`/houses/${r.id}`} className="font-bold text-primary hover:underline">{r.house_no}</Link><p className="text-xs text-muted-foreground">{r.head_name}</p></TableCell>
                    {cols.map((k) => <TableCell key={k} className="text-right hidden md:table-cell text-sm">{r[k] > 0 ? <span className="text-[#a06f1c] font-medium">{inr(r[k])}</span> : <span className="text-muted-foreground">—</span>}</TableCell>)}
                    <TableCell className="text-right font-bold" data-testid={`overview-total-${r.house_no}`}>{inr(r.total_pending)}</TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      {r.total_pending > 0 && <Button size="icon" variant="ghost" onClick={() => whatsapp(r)} title="WhatsApp" className="text-[#25D366]" data-testid={`whatsapp-${r.house_no}`}><MessageCircle className="h-4 w-4" /></Button>}
                      <Button size="icon" variant="ghost" onClick={() => setOldBal(r)} title={t("fin.oldBalance.set")} data-testid={`old-balance-${r.house_no}`}><History className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => setOldBal({ ...r, head: "auction" })} title={t("fin.auction.title")} data-testid={`auction-${r.house_no}`}><Gavel className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => printNotices(r.id)} title={t("fin.notice.print")} data-testid={`print-notice-${r.house_no}`}><FileText className="h-4 w-4" /></Button>
                      <Button size="sm" onClick={() => setForm({ house: r.id })} className="h-9" data-testid={`record-for-${r.house_no}`}>{t("fin.record")}</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      <FeesDialog open={feesOpen} onOpenChange={setFeesOpen} fees={fees} onSaved={load} />
      <OldBalanceDialog row={oldBal} onOpenChange={(o) => !o && setOldBal(null)} onSaved={load} />
      <BulkOldBalanceDialog open={bulkOb} onOpenChange={setBulkOb} rows={(overview?.rows || []).map((r) => ({ ...r, old_balance: r.old_balance_due }))} onSaved={load} />
      <StatementDialog open={stmtOpen} onOpenChange={setStmtOpen} />
      <ReportDialog open={reportOpen} onOpenChange={setReportOpen} />
      <CollectionPaymentForm open={!!form} onOpenChange={(o) => !o && setForm(null)} houses={houses} presetHouse={form?.house} onSaved={(p, kind) => { load(); setReceipt({ p, kind }); }} />
      <PrintDialog open={!!receipt} onOpenChange={(o) => !o && setReceipt(null)} title={t("subs.receipt")} testId="receipt-dialog">
        {receipt && <ReceiptBody payment={receipt.p} kind={receipt.kind} settings={settings} />}
      </PrintDialog>
      <PrintDialog open={!!notices} onOpenChange={(o) => !o && setNotices(null)} title={t("fin.notice.title")} testId="notice-dialog">
        <div className="space-y-6">{(notices || []).map((n) => <BalanceNotice key={n.house.id} data={n} settings={settings} />)}</div>
      </PrintDialog>
      <PrintDialog open={posterOpen} onOpenChange={setPosterOpen} title={t("fin.qr.poster")} testId="qr-poster-dialog">
        <QrPoster settings={{ ...settings, ...(fees || {}) }} />
      </PrintDialog>
    </div>
  );
}
