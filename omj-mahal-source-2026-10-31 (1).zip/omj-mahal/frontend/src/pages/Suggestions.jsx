import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Lightbulb, Bug, MessageSquarePlus, Trash2, Send } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import { PageHeader, EmptyState, TextField, SelectField } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

const STATUS_TONE = { new: "bg-[#c58b2b]/15 text-[#a06f1c]", planned: "bg-primary/10 text-primary", done: "bg-[#0d5c3a] text-white", declined: "bg-muted text-muted-foreground" };

const Row = ({ s, isAdmin, onStatus, onDelete, t }) => {
  const [reply, setReply] = useState(s.reply || "");
  const Icon = s.kind === "issue" ? Bug : Lightbulb;
  return (
    <div className="rounded-xl border border-[#e6dbc9] bg-card p-4 shadow-sm space-y-2" data-testid={`suggestion-${s.id}`}>
      <div className="flex items-start gap-3">
        <span className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-full", s.kind === "issue" ? "bg-red-50 text-red-700" : "bg-[#d4af37]/20 text-[#8a6d1d]")}><Icon className="h-4 w-4" /></span>
        <div className="min-w-0 flex-1">
          <p className="font-bold leading-tight">{s.title}</p>
          <p className="text-xs text-muted-foreground">{s.name}{s.house_no ? ` · ${s.house_no}` : ""} · {fmtDate(s.created_at.slice(0, 10))}</p>
          {s.details && <p className="text-sm mt-1 whitespace-pre-wrap">{s.details}</p>}
          {s.reply && <p className="text-sm mt-2 rounded-lg bg-accent px-3 py-2"><b>{t("ideas.replyLabel")}:</b> {s.reply}</p>}
        </div>
        <span className={cn("shrink-0 rounded-full px-2.5 py-0.5 text-xs font-bold", STATUS_TONE[s.status])} data-testid={`suggestion-status-${s.id}`}>{t(`ideas.status.${s.status}`)}</span>
      </div>
      {isAdmin && (
        <div className="flex flex-col sm:flex-row gap-2 pt-1">
          <input value={reply} onChange={(e) => setReply(e.target.value)} placeholder={t("ideas.replyPh")} className="flex-1 h-10 rounded-md border border-input bg-background px-3 text-sm" data-testid={`suggestion-reply-${s.id}`} />
          <div className="flex gap-1 flex-wrap">
            {["planned", "done", "declined"].map((st) => <Button key={st} size="sm" variant={s.status === st ? "default" : "outline"} className="h-10" onClick={() => onStatus(s, st, reply)} data-testid={`suggestion-set-${st}-${s.id}`}>{t(`ideas.status.${st}`)}</Button>)}
            <Button size="icon" variant="ghost" className="h-10 w-10 text-destructive" onClick={() => onDelete(s)} data-testid={`suggestion-delete-${s.id}`}><Trash2 className="h-4 w-4" /></Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default function Suggestions() {
  const { t } = useLang();
  const { isAdmin } = useAuth();
  const [rows, setRows] = useState(null);
  const [form, setForm] = useState({ title: "", details: "", kind: "feature" });
  const [loading, setLoading] = useState(false);
  const load = useCallback(() => api.get("/suggestions").then((r) => setRows(r.data)).catch(() => setRows([])), []);
  useEffect(() => { load(); }, [load]);
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try { await api.post("/suggestions", form); toast.success(t("ideas.sent")); setForm({ title: "", details: "", kind: "feature" }); load(); }
    catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  const setStatus = async (s, status, reply) => { try { await api.put(`/suggestions/${s.id}/status`, { status, reply }); load(); } catch (err) { toast.error(apiError(err)); } };
  const remove = async (s) => { try { await api.delete(`/suggestions/${s.id}`); load(); } catch (err) { toast.error(apiError(err)); } };
  return (
    <div data-testid="suggestions-page">
      <PageHeader title={t("ideas.title")} subtitle={t("ideas.subtitle")} />
      <form onSubmit={submit} className="rounded-2xl border border-[#e6dbc9] bg-card p-4 sm:p-5 shadow-sm space-y-4 mb-6" data-testid="suggestion-form">
        <div className="grid grid-cols-1 sm:grid-cols-[180px_1fr] gap-4">
          <SelectField label={t("ideas.kind")} value={form.kind} onChange={(v) => setForm((f) => ({ ...f, kind: v }))} testId="suggestion-kind-select" options={["feature", "issue", "other"].map((k) => ({ value: k, label: t(`ideas.kinds.${k}`) }))} />
          <TextField label={t("ideas.titleField")} value={form.title} onChange={(v) => setForm((f) => ({ ...f, title: v }))} required testId="suggestion-title-input" placeholder={t("ideas.titlePh")} />
        </div>
        <Textarea value={form.details} onChange={(e) => setForm((f) => ({ ...f, details: e.target.value }))} placeholder={t("ideas.detailsPh")} rows={3} data-testid="suggestion-details-input" />
        <div className="flex justify-end"><Button type="submit" disabled={loading} className="h-11" data-testid="suggestion-submit-button"><Send className="h-4 w-4 mr-2" />{t("ideas.submit")}</Button></div>
      </form>
      {rows === null ? <p className="text-muted-foreground">{t("common.loading")}</p> : rows.length === 0 ? <EmptyState text={t("ideas.empty")} testId="suggestions-empty" /> : (
        <div className="space-y-3" data-testid="suggestions-list">{rows.map((s) => <Row key={s.id} s={s} isAdmin={isAdmin} onStatus={setStatus} onDelete={remove} t={t} />)}</div>
      )}
      <p className="mt-6 text-xs text-muted-foreground flex items-center gap-1"><MessageSquarePlus className="h-3.5 w-3.5" />{t("ideas.footer")}</p>
    </div>
  );
}
