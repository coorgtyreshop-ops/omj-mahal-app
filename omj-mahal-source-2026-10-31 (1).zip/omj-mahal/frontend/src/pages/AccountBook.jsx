import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { ArrowLeft, Plus, Minus, Pencil, Trash2, Printer, Users } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { fmtDate, inr, monthLabel } from "@/lib/format";
import { PageHeader, EmptyState, ConfirmDelete, StatCard } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PrintDialog } from "@/components/print/Printables";
import { BookStatement } from "@/components/print/BookStatement";
import { BookForm, EntryForm } from "@/components/ledger/LedgerForms";
import { cn } from "@/lib/utils";

const CatChips = ({ map, prefix, t, tone }) => {
  const rows = Object.entries(map).filter(([, v]) => v > 0);
  if (!rows.length) return null;
  return <div className="flex flex-wrap gap-2">{rows.map(([k, v]) => <span key={k} className={cn("rounded-full px-3 py-1 text-xs font-semibold", tone)} data-testid={`cat-${prefix}-${k}`}>{t(`ledger.${prefix === "income" ? "incomeCats" : "expenseCats"}.${k}`)}: {inr(v)}</span>)}</div>;
};

export default function AccountBook() {
  const { id } = useParams();
  const { t, lang, months } = useLang();
  const { settings } = useAuth();
  const navigate = useNavigate();
  const [book, setBook] = useState(null);
  const [entry, setEntry] = useState(null);
  const [editBook, setEditBook] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [printOpen, setPrintOpen] = useState(false);
  const load = useCallback(() => api.get(`/ledger/books/${id}`).then((r) => setBook(r.data)).catch(() => navigate("/accounts")), [id, navigate]);
  useEffect(() => { load(); }, [load]);
  if (!book) return <p className="text-muted-foreground">{t("common.loading")}</p>;
  const s = book.summary;
  const name = lang === "ml" && book.name_ml ? book.name_ml : book.name;
  const when = book.month ? monthLabel(book.month, months) : fmtDate(book.date);
  const remove = async () => {
    try {
      if (deleting.book) { await api.delete(`/ledger/books/${book.id}`); toast.success(t("common.deleted")); navigate(`/accounts?tab=${book.committee}`); return; }
      await api.delete(`/ledger/entries/${deleting.id}`); toast.success(t("common.deleted")); setDeleting(null); load();
    } catch (e) { toast.error(apiError(e)); }
  };
  return (
    <div data-testid="account-book-page">
      <Link to={`/accounts?tab=${book.committee}`} className="inline-flex items-center gap-1 text-sm text-primary hover:underline mb-3" data-testid="book-back-link"><ArrowLeft className="h-4 w-4" />{t("ledger.title")}</Link>
      <PageHeader title={name} subtitle={`${t(`ledger.${book.committee}`)} · ${when}${book.note ? ` · ${book.note}` : ""}`} actions={<>
        <Button variant="outline" onClick={() => setPrintOpen(true)} className="h-11" data-testid="book-print-button"><Printer className="h-4 w-4 mr-2" />{t("ledger.print")}</Button>
        {book.can_edit && <Button variant="outline" onClick={() => setEditBook(true)} className="h-11" data-testid="book-edit-button"><Pencil className="h-4 w-4 mr-2" />{t("common.edit")}</Button>}
        {book.can_edit && <Button variant="ghost" onClick={() => setDeleting({ book: true })} className="h-11 text-destructive" data-testid="book-delete-button"><Trash2 className="h-4 w-4" /></Button>}
      </>} />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5 mb-5">
        <StatCard label={t("ledger.income")} value={inr(s.income)} testId="book-income" />
        <StatCard label={t("ledger.expense")} value={inr(s.expense)} tone="red" testId="book-expense" delay={60} />
        <StatCard label={t("ledger.balance")} value={inr(s.balance)} tone={s.balance < 0 ? "amber" : "gold"} testId="book-balance" delay={120} />
        <StatCard label={t("ledger.donors")} value={s.donors} hint={`${s.entries} ${t("ledger.entries")}`} icon={Users} testId="book-donors" delay={180} />
      </div>
      <div className="space-y-2 mb-5">
        <CatChips map={s.income_by} prefix="income" t={t} tone="bg-primary/10 text-primary" />
        <CatChips map={s.expense_by} prefix="expense" t={t} tone="bg-red-50 text-red-700" />
      </div>
      {book.can_edit ? (
        <div className="flex flex-wrap gap-2 mb-4">
          <Button onClick={() => setEntry({ kind: "income" })} className="h-11" data-testid="add-income-button"><Plus className="h-4 w-4 mr-2" />{t("ledger.addIncome")}</Button>
          <Button onClick={() => setEntry({ kind: "expense" })} variant="outline" className="h-11 border-red-200 text-red-700 hover:bg-red-50" data-testid="add-expense-button"><Minus className="h-4 w-4 mr-2" />{t("ledger.addExpense")}</Button>
        </div>
      ) : <p className="text-xs text-muted-foreground mb-4" data-testid="book-readonly">{t("ledger.readOnly")}</p>}
      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        {book.entries.length === 0 ? <EmptyState text={t("ledger.noEntries")} testId="entries-empty" /> : (
          <Table data-testid="entries-table">
            <TableHeader><TableRow className="bg-accent/60"><TableHead>{t("common.date")}</TableHead><TableHead>{t("ledger.category")}</TableHead><TableHead>{t("ledger.donor")} / {t("ledger.payee")}</TableHead><TableHead className="hidden sm:table-cell">{t("ledger.qty")}</TableHead><TableHead className="text-right">{t("ledger.amount")}</TableHead>{book.can_edit && <TableHead />}</TableRow></TableHeader>
            <TableBody>
              {book.entries.map((e) => (
                <TableRow key={e.id} data-testid={`entry-row-${e.id}`}>
                  <TableCell className="text-sm whitespace-nowrap">{fmtDate(e.date)}</TableCell>
                  <TableCell><span className={cn("rounded-full px-2.5 py-0.5 text-xs font-semibold", e.kind === "income" ? "bg-primary/10 text-primary" : "bg-red-50 text-red-700")}>{t(`ledger.${e.kind === "income" ? "incomeCats" : "expenseCats"}.${e.category}`)}</span></TableCell>
                  <TableCell className="text-sm">{e.party || "—"}{e.note && <span className="block text-xs text-muted-foreground">{e.note}</span>}</TableCell>
                  <TableCell className="hidden sm:table-cell text-sm">{e.qty ? `${e.qty} ${e.unit}` : ""}</TableCell>
                  <TableCell className={cn("text-right font-mono font-semibold", e.kind === "income" ? "text-primary" : "text-red-700")}>{e.amount ? `${e.kind === "income" ? "+" : "−"}${inr(e.amount)}` : "—"}</TableCell>
                  {book.can_edit && <TableCell className="text-right whitespace-nowrap"><Button size="icon" variant="ghost" onClick={() => setEntry(e)} data-testid={`edit-entry-${e.id}`}><Pencil className="h-4 w-4" /></Button><Button size="icon" variant="ghost" className="text-destructive" onClick={() => setDeleting(e)} data-testid={`delete-entry-${e.id}`}><Trash2 className="h-4 w-4" /></Button></TableCell>}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
      {entry && <EntryForm open onOpenChange={(o) => !o && setEntry(null)} book={book} kind={entry.kind} item={entry.id ? entry : null} onSaved={load} />}
      <BookForm open={editBook} onOpenChange={setEditBook} committee={book.committee} item={book} onSaved={load} />
      <ConfirmDelete open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)} onConfirm={remove} />
      <PrintDialog open={printOpen} onOpenChange={setPrintOpen} title={t("ledger.statement")} testId="book-print-dialog"><BookStatement book={book} settings={settings} /></PrintDialog>
    </div>
  );
}
