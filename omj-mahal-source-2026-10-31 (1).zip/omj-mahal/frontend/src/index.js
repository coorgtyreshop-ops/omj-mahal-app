import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import "@/index.css";
import App from "@/App";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      refetchOnWindowFocus: false,
    },
  },
});

const root = ReactDOM.createRoot(document.getElementById("root"));
if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
  // New versions install silently and are used on the next open — no visible reload mid-session (WhatsApp-style).
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}

// New server build → refresh the cached shell + service worker in the background; the next open uses the new version.
const checkBuild = async () => {
  try {
    const res = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/version`, { cache: "no-store" });
    const { build } = await res.json();
    const seen = localStorage.getItem("mahal_build");
    localStorage.setItem("mahal_build", build);
    if (seen && seen !== build) {
      if ("serviceWorker" in navigator) for (const r of await navigator.serviceWorker.getRegistrations()) await r.update();
      if (window.caches) {
        const fresh = await fetch("/", { cache: "no-store" });
        if (fresh.ok) await (await caches.open("omj-mahal-v5")).put("/", fresh);
      }
    }
  } catch { /* offline — keep going */ }
};
checkBuild();

root.render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </React.StrictMode>,
);
window.__bootReady?.();
