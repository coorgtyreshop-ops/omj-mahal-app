import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { MessageCircle, MessageSquare, Check, Trash2, Smartphone } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { openChatLink } from "@/lib/whatsapp";

export const Outbox = ({ onChange }) => {
  const { t } = useLang();
  const [items, setItems] = useState([]);
  const load = useCallback(() => api.get("/notifications/outbox").then((r) => { setItems(r.data); onChange?.(r.data.length); }), [onChange]);
  useEffect(() => { load(); }, [load]);

  const open = (m, link) => { openChatLink(link, t("outbox.tapOpen")); };
  const markSent = async (m) => { try { await api.post(`/notifications/outbox/${m.id}/sent`); load(); } catch (e) { toast.error(apiError(e)); } };
  const clear = async () => { try { await api.post("/notifications/outbox/clear"); toast.success(t("outbox.cleared")); load(); } catch (e) { toast.error(apiError(e)); } };

  return (
    <section className="rounded-xl border border-[#c58b2b]/40 bg-[#c58b2b]/5 shadow-sm mb-6" data-testid="outbox-section">
      <div className="px-4 py-3 flex flex-wrap items-center justify-between gap-2 border-b border-[#c58b2b]/20">
        <div className="flex items-center gap-2 font-semibold"><Smartphone className="h-4 w-4 text-[#a06f1c]" />{t("outbox.title")} <span className="rounded-full bg-[#c58b2b]/20 text-[#a06f1c] px-2 text-xs" data-testid="outbox-count">{items.length}</span></div>
        {items.length > 0 && <Button size="sm" variant="ghost" onClick={clear} className="h-9 text-destructive" data-testid="outbox-clear-button"><Trash2 className="h-4 w-4 mr-1" />{t("outbox.clear")}</Button>}
      </div>
      <p className="px-4 pt-3 text-xs text-muted-foreground">{t("outbox.hint")}</p>
      {items.length === 0 ? <p className="px-4 py-4 text-sm text-muted-foreground" data-testid="outbox-empty">{t("outbox.empty")}</p> : (
        <ul className="divide-y divide-[#c58b2b]/15" data-testid="outbox-list">
          {items.map((m) => (
            <li key={m.id} className="px-4 py-3 flex flex-col sm:flex-row sm:items-center gap-3" data-testid={`outbox-item-${m.id}`}>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">{m.recipient_name || m.to} <span className="text-xs text-muted-foreground font-normal">· {m.to} · {t(`notifBell.kinds.${m.kind}`) || m.kind}</span></p>
                <p className="text-xs text-muted-foreground whitespace-pre-line line-clamp-2">{m.body}</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <Button size="sm" onClick={() => open(m, m.wa_link)} className="h-10 bg-[#25D366] hover:bg-[#1ebe5b] text-white" data-testid={`outbox-wa-${m.id}`}><MessageCircle className="h-4 w-4 mr-1" />WhatsApp</Button>
                <Button size="sm" variant="outline" onClick={() => open(m, m.sms_link)} className="h-10" data-testid={`outbox-sms-${m.id}`}><MessageSquare className="h-4 w-4 mr-1" />SMS</Button>
                <Button size="sm" variant="ghost" onClick={() => markSent(m)} className="h-10" title={t("outbox.markSent")} data-testid={`outbox-done-${m.id}`}><Check className="h-4 w-4" /></Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};
