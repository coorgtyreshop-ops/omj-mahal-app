import { useEffect, useRef, useState } from "react";
import { Keyboard, X, Delete, CornerDownLeft, Space, ChevronDown } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { cn } from "@/lib/utils";
import { toKannada, insertIntoField, deleteFromField, isTextTarget, KN_VOWELS, KN_CONSONANTS, KN_MATRAS, KN_DIGITS, PHONETIC_HINTS } from "@/lib/kannada";
import { kbdIsOn, setKbdOn, useKbdOn } from "@/lib/kbdState";

const KEY = "kn_keyboard";
export const readKbd = () => (kbdIsOn() ? "on" : "off");

export const KeyboardToggle = ({ open, onToggle }) => {
  const { t } = useLang();
  return (
    <button type="button" onClick={onToggle} title={t("kbd.title")} className={cn("grid h-9 w-9 place-items-center rounded-full border transition-colors", open ? "bg-[#d4af37] text-[#1e2923] border-[#d4af37]" : "bg-card border-border hover:bg-accent")} data-testid="kannada-keyboard-toggle" aria-pressed={open}>
      <span className="text-base font-bold leading-none">ಕ</span>
    </button>
  );
};

const Key = ({ children, onPress, wide, className, testId }) => (
  <button type="button" onPointerDown={(e) => e.preventDefault()} onClick={onPress} className={cn("h-10 min-w-[2.25rem] rounded-md border border-[#e6dbc9] bg-white text-lg leading-none hover:bg-[#d4af37]/20 active:bg-[#d4af37]/40 select-none", wide && "px-3 text-sm font-semibold", className)} data-testid={testId}>{children}</button>
);

export const KannadaKeyboard = ({ open, onClose }) => {
  const { t } = useLang();
  const [tab, setTab] = useState(localStorage.getItem(KEY + "_tab") || "phonetic");
  const [latin, setLatin] = useState("");
  const [mini, setMini] = useState(false);
  const [hasTarget, setHasTarget] = useState(false);
  const target = useRef(null);
  const sel = useRef(null);
  const strip = useRef(null);

  useEffect(() => { localStorage.setItem(KEY + "_tab", tab); }, [tab]);
  useEffect(() => {
    if (!open) return;
    const onFocus = (e) => { if (isTextTarget(e.target)) { target.current = e.target; sel.current = null; setHasTarget(true); } };
    const onSel = () => { const el = target.current; if (el && document.activeElement === el) sel.current = { start: el.selectionStart, end: el.selectionEnd }; };
    document.addEventListener("focusin", onFocus);
    document.addEventListener("selectionchange", onSel);
    document.addEventListener("keyup", onSel);
    document.addEventListener("click", onSel);
    return () => { document.removeEventListener("focusin", onFocus); document.removeEventListener("selectionchange", onSel); document.removeEventListener("keyup", onSel); document.removeEventListener("click", onSel); };
  }, [open]);

  const put = (text) => {
    const el = target.current;
    if (!el || !el.isConnected) return;
    sel.current = insertIntoField(el, text, sel.current) || sel.current;
  };
  const backspace = () => { const el = target.current; if (el) sel.current = deleteFromField(el, sel.current) || sel.current; };
  const commit = (withSpace = true) => {
    const kn = toKannada(latin.trim());
    if (kn) put(kn + (withSpace ? " " : ""));
    setLatin("");
    strip.current?.focus();
  };
  const onStripKey = (e) => {
    if (e.key === " " || e.key === "Enter") { e.preventDefault(); commit(e.key === " "); }
    else if (e.key === "Backspace" && !latin) { e.preventDefault(); backspace(); }
  };
  if (!open) return null;
  const preview = toKannada(latin);
  return (
    <div className="fixed inset-x-0 bottom-0 z-[60] md:inset-x-auto md:right-4 md:bottom-4 md:w-[520px]" data-kbd-panel data-testid="kannada-keyboard">
      <div className="rounded-t-2xl md:rounded-2xl border border-[#d4af37]/60 bg-[#faf8f5] shadow-2xl">
        <div className="flex items-center gap-2 px-3 py-2 border-b border-[#e6dbc9]">
          <span className="grid h-7 w-7 place-items-center rounded-full bg-[#d4af37] text-[#1e2923] font-bold">ಕ</span>
          <span className="text-sm font-bold flex-1">{t("kbd.title")}</span>
          <div className="flex rounded-full border border-[#e6dbc9] overflow-hidden text-xs font-semibold">
            <button type="button" onClick={() => setTab("phonetic")} className={cn("px-3 h-8", tab === "phonetic" ? "bg-primary text-white" : "bg-white")} data-testid="kbd-tab-phonetic">{t("kbd.phonetic")}</button>
            <button type="button" onClick={() => setTab("letters")} className={cn("px-3 h-8", tab === "letters" ? "bg-primary text-white" : "bg-white")} data-testid="kbd-tab-letters">{t("kbd.letters")}</button>
          </div>
          <button type="button" onClick={() => setMini((m) => !m)} className="grid h-8 w-8 place-items-center rounded-full hover:bg-accent" data-testid="kbd-minimize"><ChevronDown className={cn("h-4 w-4 transition-transform", mini && "rotate-180")} /></button>
          <button type="button" onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full hover:bg-accent" data-testid="kbd-close"><X className="h-4 w-4" /></button>
        </div>
        {!mini && (
          <div className="p-3 space-y-2 max-h-[45vh] overflow-y-auto">
            {!hasTarget && <p className="text-xs text-[#a06f1c] font-semibold" data-testid="kbd-no-target">{t("kbd.tapField")}</p>}
            {tab === "phonetic" ? (
              <>
                <div className="flex gap-2">
                  <input ref={strip} value={latin} onChange={(e) => setLatin(e.target.value.replace(/[^A-Za-z~]/g, ""))} onKeyDown={onStripKey} placeholder={t("kbd.typePh")} autoCapitalize="off" autoCorrect="off" spellCheck={false} className="flex-1 h-11 rounded-lg border border-input bg-white px-3 font-mono text-base outline-none focus:ring-2 focus:ring-primary/40" data-testid="kbd-latin-input" data-kbd="off" />
                  <button type="button" onClick={() => commit(true)} disabled={!latin} className="h-11 px-4 rounded-lg bg-primary text-white text-sm font-semibold disabled:opacity-50" data-testid="kbd-insert">{t("kbd.insert")}</button>
                  <Key onPress={backspace} wide testId="kbd-backspace"><Delete className="h-4 w-4" /></Key>
                </div>
                <div className="min-h-[2.75rem] rounded-lg bg-white border border-dashed border-[#d4af37] px-3 py-2 text-2xl leading-tight" data-testid="kbd-preview">{preview || <span className="text-sm text-muted-foreground">{t("kbd.previewPh")}</span>}</div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">{t("kbd.hint")} <span className="font-mono">{PHONETIC_HINTS}</span></p>
              </>
            ) : (
              <>
                <div className="flex flex-wrap gap-1" data-testid="kbd-vowels">{KN_VOWELS.map((c) => <Key key={c} onPress={() => put(c)}>{c}</Key>)}</div>
                <div className="flex flex-wrap gap-1" data-testid="kbd-consonants">{KN_CONSONANTS.map((c) => <Key key={c} onPress={() => put(c)} testId={`kbd-key-${c}`}>{c}</Key>)}</div>
                <div className="flex flex-wrap gap-1" data-testid="kbd-matras">{KN_MATRAS.map(([label, ch]) => <Key key={label} onPress={() => put(ch)} className="text-[#0d5c3a]">{label === "್" ? "್" : `◌${label}`}</Key>)}{KN_DIGITS.map((d) => <Key key={d} onPress={() => put(d)} className="text-muted-foreground">{d}</Key>)}</div>
                <div className="flex gap-1">
                  <Key onPress={() => put(" ")} wide className="flex-1" testId="kbd-space"><Space className="h-4 w-4 mx-auto" /></Key>
                  <Key onPress={backspace} wide testId="kbd-backspace-letters"><Delete className="h-4 w-4" /></Key>
                  <Key onPress={() => put("\n")} wide testId="kbd-enter"><CornerDownLeft className="h-4 w-4" /></Key>
                  {[",", ".", "?", "!", "-"].map((p) => <Key key={p} onPress={() => put(p)} wide>{p}</Key>)}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export const useKannadaKeyboard = () => {
  const open = useKbdOn();
  return { open, toggle: () => setKbdOn(!kbdIsOn()), close: () => setKbdOn(false), Icon: Keyboard };
};
