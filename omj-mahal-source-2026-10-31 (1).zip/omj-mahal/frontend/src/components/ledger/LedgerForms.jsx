import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { TextField, SelectField, SubmitRow, Field } from "@/components/shared";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

export const INCOME_CATS = ["donation", "kind", "tin", "auction", "rent", "other"];
export const EXPENSE_CATS = ["food", "guest", "sound", "decoration", "printing", "transport", "rent", "maintenance", "electricity", "other"];

const emptyBook = { name: "", name_ml: "", committee: "main", date: "", month: "", event_id: "", note: "" };

export const BookForm = ({ open, onOpenChange, committee, item, onSaved }) => {
  const { t, lang } = useLang();
  const [form, setForm] = useState(emptyBook);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!open) return;
    setForm(item ? { ...emptyBook, ...item, event_id: item.event_id || "" } : { ...emptyBook, committee, date: committee === "main" ? new Date().toISOString().slice(0, 10) : "", month: committee === "salath" ? new Date().toISOString().slice(0, 7) : "" });
    const y = new Date().getFullYear();
    api.get("/events", { params: { from: `${y - 1}-01-01`, to: `${y + 1}-12-31` } }).then((r) => setEvents(r.data)).catch(() => setEvents([]));
  }, [open, item, committee]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const pickEvent = (id) => {
    const ev = events.find((e) => e.id === id);
    setForm((f) => ({ ...f, event_id: id === "none" ? "" : id, ...(ev ? { name: f.name || ev.title, name_ml: f.name_ml || ev.title_ml || "", date: ev.date } : {}) }));
  };
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const payload = { ...form, event_id: form.event_id || null };
      if (item?.id) await api.put(`/ledger/books/${item.id}`, payload); else await api.post("/ledger/books", payload);
      toast.success(t("common.saved")); onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  const isSalath = form.committee === "salath" || form.committee === "rent";
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="book-form-dialog">
        <DialogHeader><DialogTitle>{item?.id ? t("ledger.editBook") : t("ledger.newBook")} — {t(`ledger.${form.committee}`)}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          {isSalath && <p className="text-xs text-muted-foreground">{t("ledger.salathHint")}</p>}
          {!isSalath && <SelectField label={t("ledger.linkEvent")} value={form.event_id || "none"} onChange={pickEvent} testId="book-event-select" options={[{ value: "none", label: t("ledger.noEvent") }, ...events.map((e) => ({ value: e.id, label: `${e.date} — ${lang === "ml" && e.title_ml ? e.title_ml : e.title}` }))]} />}
          <TextField label={t("ledger.name")} value={form.name} onChange={set("name")} required testId="book-name-input" placeholder={form.committee === "rent" ? "Room rent — September 2026" : isSalath ? "Salath — September 2026" : "Nabidinam 2026"} />
          <TextField label={t("ledger.nameMl")} value={form.name_ml} onChange={set("name_ml")} testId="book-name-ml-input" />
          <div className="grid grid-cols-2 gap-4">
            {isSalath ? <TextField label={t("ledger.month")} type="month" value={form.month} onChange={set("month")} required testId="book-month-input" /> : <TextField label={t("ledger.date")} type="date" value={form.date} onChange={set("date")} required testId="book-date-input" />}
            <TextField label={t("ledger.note")} value={form.note} onChange={set("note")} testId="book-note-input" />
          </div>
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

const emptyEntry = { kind: "income", category: "donation", party: "", amount: "", qty: "", unit: "", date: "", note: "" };

export const EntryForm = ({ open, onOpenChange, book, kind, item, onSaved }) => {
  const { t } = useLang();
  const [form, setForm] = useState(emptyEntry);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!open) return;
    const k = item?.kind || kind || "income";
    setForm(item ? { ...emptyEntry, ...item, amount: item.amount || "", qty: item.qty || "" } : { ...emptyEntry, kind: k, category: k === "income" ? (book?.committee === "rent" ? "rent" : "donation") : (book?.committee === "rent" ? "maintenance" : "food"), date: book?.date || new Date().toISOString().slice(0, 10) });
  }, [open, item, kind, book]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const cats = form.kind === "income" ? INCOME_CATS : EXPENSE_CATS;
  const isKind = form.kind === "income" && form.category === "kind";
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const payload = { ...form, amount: Number(form.amount) || 0, qty: Number(form.qty) || 0, house_id: null };
      if (item?.id) await api.put(`/ledger/entries/${item.id}`, payload); else await api.post(`/ledger/books/${book.id}/entries`, payload);
      toast.success(t("common.saved")); onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="entry-form-dialog">
        <DialogHeader><DialogTitle>{item?.id ? t("ledger.editEntry") : form.kind === "income" ? t("ledger.addIncome") : t("ledger.addExpense")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <SelectField label={t("ledger.category")} value={form.category} onChange={set("category")} testId="entry-category-select" options={cats.map((c) => ({ value: c, label: t(`ledger.${form.kind === "income" ? "incomeCats" : "expenseCats"}.${c}`) }))} />
          <TextField label={form.kind === "income" ? t("ledger.donor") : t("ledger.payee")} value={form.party} onChange={set("party")} testId="entry-party-input" placeholder={t("ledger.partyOptional")} />
          {isKind && (
            <div className="grid grid-cols-2 gap-4">
              <TextField label={t("ledger.qty")} type="number" inputMode="decimal" value={form.qty} onChange={set("qty")} testId="entry-qty-input" />
              <TextField label={t("ledger.unit")} value={form.unit} onChange={set("unit")} testId="entry-unit-input" placeholder="kg" />
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <Field label={t("ledger.amount")} required={!isKind}><Input type="number" inputMode="decimal" min="0" step="any" value={form.amount} onChange={(e) => set("amount")(e.target.value)} required={!isKind} className="h-11" data-testid="entry-amount-input" /></Field>
            <TextField label={t("common.date")} type="date" value={form.date} onChange={set("date")} testId="entry-date-input" />
          </div>
          {isKind && <p className="text-xs text-muted-foreground">{t("ledger.kindHint")}</p>}
          <TextField label={t("ledger.note")} value={form.note} onChange={set("note")} testId="entry-note-input" />
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} />
        </form>
      </DialogContent>
    </Dialog>
  );
};
