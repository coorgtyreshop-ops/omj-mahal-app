import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { todayStr } from "@/lib/format";
import { hijri } from "@/lib/hijri";
import { TextField, SelectField, SubmitRow, Field } from "@/components/shared";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export const CATEGORIES = ["programme", "class", "meeting", "eid", "nabidinam", "ramadan", "other"];
const empty = { title: "", title_ml: "", title_kn: "", guests: "", chair: "", organizer: "", leader: "", women_facility: false, women_note: "", date: todayStr(), time: "", venue: "", description: "", category: "programme", notify_members: true };

export const EventForm = ({ open, onOpenChange, item, onSaved }) => {
  const { t, lang } = useLang();
  const { settings } = useAuth();
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) setForm({ ...empty, ...(item || {}) }); }, [open, item]);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const h = form.date ? hijri(form.date, settings?.hijri_adjustment || 0, lang) : null;

  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const payload = { title: form.title, title_ml: form.title_ml, title_kn: form.title_kn, guests: form.guests, chair: form.chair, organizer: form.organizer, leader: form.leader, women_facility: !!form.women_facility, women_note: form.women_note, date: form.date, time: form.time, venue: form.venue, description: form.description, category: form.category, notify_members: !!form.notify_members };
      const { data } = item?.id ? await api.put(`/events/${item.id}`, payload) : await api.post("/events", payload);
      toast.success(t("cal.saved")); onSaved(data);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid="event-form-dialog">
        <DialogHeader><DialogTitle>{item?.id ? t("cal.editEvent") : t("cal.addEvent")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="grid grid-cols-2 gap-4">
          <TextField label={t("cal.fields.title")} value={form.title} onChange={set("title")} required testId="event-title-input" className="col-span-2" />
          <TextField label={t("cal.fields.titleMl")} value={form.title_ml} onChange={set("title_ml")} testId="event-title-ml-input" />
          <TextField label={t("cal.fields.titleKn")} value={form.title_kn} onChange={set("title_kn")} testId="event-title-kn-input" />
          <div>
            <TextField label={t("cal.fields.date")} type="date" value={form.date} onChange={set("date")} required testId="event-date-input" />
            {h && <p className="text-xs text-[#8a6d1d] font-semibold mt-1" data-testid="event-hijri-preview">{h.label}</p>}
          </div>
          <TextField label={t("cal.fields.time")} value={form.time} onChange={set("time")} placeholder="7:30 PM" testId="event-time-input" />
          <TextField label={t("cal.fields.venue")} value={form.venue} onChange={set("venue")} testId="event-venue-input" />
          <SelectField label={t("cal.fields.category")} value={form.category} onChange={set("category")} testId="event-category-select" options={CATEGORIES.map((c) => ({ value: c, label: t(`cal.categories.${c}`) }))} />
          <Field label={t("cal.fields.guests")} className="col-span-2"><Textarea value={form.guests} onChange={(e) => set("guests")(e.target.value)} rows={2} placeholder={t("cal.fields.guestsPh")} data-testid="event-guests-input" /></Field>
          <TextField label={t("cal.fields.chair")} value={form.chair} onChange={set("chair")} testId="event-chair-input" />
          <TextField label={t("cal.fields.organizer")} value={form.organizer} onChange={set("organizer")} testId="event-organizer-input" />
          <TextField label={t("cal.fields.leader")} value={form.leader} onChange={set("leader")} testId="event-leader-input" className="col-span-2" />
          <div className="col-span-2 flex items-center justify-between rounded-lg border p-3"><Label className="text-sm">{t("cal.fields.women")}</Label><Switch checked={!!form.women_facility} onCheckedChange={set("women_facility")} data-testid="event-women-switch" /></div>
          {form.women_facility && <TextField label={t("cal.fields.womenNote")} value={form.women_note} onChange={set("women_note")} placeholder={t("cal.fields.womenDefault")} testId="event-women-note-input" className="col-span-2" />}
          <Field label={t("cal.fields.description")} className="col-span-2"><Textarea value={form.description} onChange={(e) => set("description")(e.target.value)} rows={3} data-testid="event-description-input" /></Field>
          <div className="col-span-2 flex items-center justify-between rounded-lg border p-3"><Label className="text-sm">{t("cal.fields.notify")}</Label><Switch checked={!!form.notify_members} onCheckedChange={set("notify_members")} data-testid="event-notify-switch" /></div>
          <div className="col-span-2"><SubmitRow loading={loading} onCancel={() => onOpenChange(false)} /></div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
