import { useState } from "react";
import { toast } from "sonner";
import { CalendarDays, Clock, MapPin, Download, Share2, X, Printer } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { fmtDate } from "@/lib/format";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

const BASE = process.env.REACT_APP_BACKEND_URL;

export const eventTitle = (ev, lang) => (lang === "ml" && ev.title_ml ? ev.title_ml : lang === "kn" && ev.title_kn ? ev.title_kn : ev.title);

export const usePosterActions = (ev, title) => {
  const [busy, setBusy] = useState(false);
  const url = ev?.poster_url ? `${BASE}${ev.poster_url}` : "";
  const file = async () => { const b = await (await fetch(url)).blob(); return new File([b], `${(title || "poster").replace(/[^\w\u0D00-\u0D7F\u0C80-\u0CFF]+/g, "_")}.png`, { type: b.type || "image/png" }); };
  const download = async () => {
    if (!url) return;
    setBusy(true);
    try { const f = await file(); const a = document.createElement("a"); a.href = URL.createObjectURL(f); a.download = f.name; a.click(); URL.revokeObjectURL(a.href); }
    catch { window.open(url, "_blank", "noopener"); } finally { setBusy(false); }
  };
  const share = async () => {
    const text = `${title}\n${fmtDate(ev.date)}${ev.time ? " " + ev.time : ""}${ev.venue ? "\n" + ev.venue : ""}`;
    setBusy(true);
    try {
      if (url && navigator.canShare) { const f = await file(); if (navigator.canShare({ files: [f] })) { await navigator.share({ files: [f], title, text }); return; } }
      if (navigator.share) { await navigator.share({ title, text, url: url || window.location.href }); return; }
      await navigator.clipboard.writeText(`${text}\n${url}`); toast.success("Copied");
    } catch (e) { if (e?.name !== "AbortError") toast.error(e.message); } finally { setBusy(false); }
  };
  const print = () => printPoster(ev, title, url);
  return { download, share, print, busy, url };
};

const esc = (s) => String(s || "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

const printPoster = (ev, title, url) => {
  const w = window.open("", "_blank", "width=900,height=1200");
  if (!w) return toast.error("Popup blocked — allow popups to print");
  const lines = [`${fmtDate(ev.date)}${ev.time ? " · " + ev.time : ""}`, ev.venue].filter(Boolean).map(esc).join(" · ");
  w.document.write(`<html><head><title>${esc(title)}</title><style>@page{size:A4;margin:10mm}body{margin:0;font-family:sans-serif;color:#1e2923;text-align:center}img{width:100%;max-height:250mm;object-fit:contain}h1{font-size:20px;margin:5mm 0 2mm}p{margin:0;font-size:13px;color:#555}</style></head><body>${url ? `<img src="${url}" alt="" onload="setTimeout(function(){window.print()},250)">` : ""}<h1>${esc(title)}</h1><p>${lines}</p></body></html>`);
  w.document.close(); w.focus();
  if (!url) setTimeout(() => w.print(), 300);
};

const Row = ({ icon: Icon, children }) => <span className="inline-flex items-center gap-1.5"><Icon className="h-4 w-4 text-[#d4af37]" />{children}</span>;

export const PosterViewer = ({ ev, onClose }) => {
  const { t, lang } = useLang();
  const title = ev ? eventTitle(ev, lang) : "";
  const { download, share, print, busy, url } = usePosterActions(ev, title);
  if (!ev) return null;
  const hijri = ev.hijri?.[lang === "ml" ? "label_ml" : lang === "kn" ? "label_kn" : "label"];
  const guests = ev.guest_photos || [];
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg p-0 overflow-hidden bg-[#0b1f16] text-white border-[#d4af37]/40 max-h-[95vh] overflow-y-auto" data-testid="poster-viewer">
        <DialogTitle className="sr-only">{title}</DialogTitle>
        <button type="button" onClick={onClose} className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-full bg-black/50 hover:bg-black/70" data-testid="poster-viewer-close"><X className="h-5 w-5" /></button>
        {url ? <img src={url} alt={title} className="w-full max-h-[72vh] object-contain bg-black" data-testid="poster-viewer-image" /> : <div className="h-48 grid place-items-center text-2xl font-bold px-6 text-center">{title}</div>}
        <div className="p-4 sm:p-5 space-y-3">
          <h3 className="text-xl font-bold leading-tight" data-testid="poster-viewer-title">{title}</h3>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-white/90">
            <Row icon={CalendarDays}>{fmtDate(ev.date)}{hijri && <span className="text-[#d4af37]"> · {hijri}</span>}</Row>
            {ev.time && <Row icon={Clock}>{ev.time}</Row>}
            {ev.venue && <Row icon={MapPin}>{ev.venue}</Row>}
          </div>
          {(ev.chair || ev.organizer || ev.leader) && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-1 text-xs text-white/85">
              {ev.chair && <p><span className="text-[#d4af37]">{t("cal.fields.chair")}:</span> {ev.chair}</p>}
              {ev.organizer && <p><span className="text-[#d4af37]">{t("cal.fields.organizer")}:</span> {ev.organizer}</p>}
              {ev.leader && <p><span className="text-[#d4af37]">{t("cal.fields.leader")}:</span> {ev.leader}</p>}
            </div>
          )}
          {guests.length > 0 && (
            <div className="flex flex-wrap gap-3">
              {guests.map((g) => (
                <div key={g.id} className="flex items-center gap-2">
                  <img src={`${BASE}${g.url}`} alt={g.name} className="h-10 w-10 rounded-full object-cover ring-2 ring-[#d4af37]" />
                  <div className="leading-tight"><p className="text-xs font-semibold">{g.name}</p>{g.role && <p className="text-[10px] text-white/70">{g.role}</p>}</div>
                </div>
              ))}
            </div>
          )}
          {!guests.length && ev.guests && <p className="text-xs text-white/80 whitespace-pre-line">{ev.guests}</p>}
          {ev.description && <p className="text-sm text-white/80 whitespace-pre-line">{ev.description}</p>}
          {ev.women_facility && <p className="text-xs text-[#d4af37] font-semibold">{ev.women_note || t("cal.fields.womenDefault")}</p>}
          <div className="flex gap-2 pt-1">
            {url && <Button onClick={download} disabled={busy} className="flex-1 h-11 bg-[#d4af37] text-[#1e2923] hover:bg-[#e2c053] font-semibold" data-testid="poster-download-button"><Download className="h-4 w-4 mr-2" />{t("posters.download")}</Button>}
            <Button onClick={print} variant="outline" className="h-11 border-white/30 bg-white/5 text-white hover:bg-white/15" data-testid="poster-print-button"><Printer className="h-4 w-4 mr-2" />{t("posters.print")}</Button>
            <Button onClick={share} disabled={busy} variant="outline" className="flex-1 h-11 border-white/30 bg-white/5 text-white hover:bg-white/15" data-testid="poster-share-button"><Share2 className="h-4 w-4 mr-2" />{t("posters.share")}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
