import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Sparkles, Download, Share2, Trash2, Star, Pencil, Send, Clock, MapPin, Loader2, Upload, X, UserPlus } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import { hijri } from "@/lib/hijri";
import { SelectField, TextField, ConfirmDelete } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

const BASE = process.env.REACT_APP_BACKEND_URL;
const STYLES = ["classic", "modern", "festive", "ramadan", "minimal", "photo", "calligraphy", "kids"];
const SIZES = ["story", "square", "a4", "landscape", "banner"];
const COLOURS = ["green_gold", "blue_gold", "maroon_gold", "black_gold", "white_green", "teal_orange", "purple_gold"];

const fetchBlob = async (url) => (await fetch(url, { credentials: "include" })).blob();

export const PosterActions = ({ ev, poster, onChanged, admin }) => {
  const { t } = useLang();
  const [busy, setBusy] = useState("");
  const name = `${ev.title.replace(/\s+/g, "-")}-poster.png`;
  const download = async () => {
    setBusy("download");
    try { const b = await fetchBlob(`${BASE}${poster.url}`); const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = name; a.click(); } catch { toast.error(t("common.error")); } finally { setBusy(""); }
  };
  const share = async () => {
    setBusy("share");
    try {
      const b = await fetchBlob(`${BASE}${poster.url}`); const file = new File([b], name, { type: "image/png" });
      const text = `${ev.title_ml ? ev.title_ml + " / " : ""}${ev.title} — ${ev.date}${ev.time ? " " + ev.time : ""}${ev.venue ? ", " + ev.venue : ""}`;
      if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file], text });
      else { await navigator.clipboard?.writeText(`${text}\n${BASE}${poster.url}`); toast.success(t("common.copied")); }
    } catch (e) { if (e?.name !== "AbortError") toast.error(t("common.error")); } finally { setBusy(""); }
  };
  const setCover = async () => { await api.put(`/events/${ev.id}/poster/${poster.id}/cover`); onChanged(); };
  const remove = async () => { await api.delete(`/events/${ev.id}/poster/${poster.id}`); onChanged(); };
  return (
    <div className="flex flex-wrap gap-1">
      <Button size="sm" variant="outline" onClick={download} disabled={!!busy} className="h-9" data-testid={`poster-download-${poster.id}`}><Download className="h-4 w-4 mr-1" />{t("cal.poster.download")}</Button>
      <Button size="sm" variant="outline" onClick={share} disabled={!!busy} className="h-9" data-testid={`poster-share-${poster.id}`}><Share2 className="h-4 w-4 mr-1" />{t("cal.poster.share")}</Button>
      {admin && ev.poster_url !== poster.url && <Button size="sm" variant="ghost" onClick={setCover} className="h-9" data-testid={`poster-cover-${poster.id}`}><Star className="h-4 w-4 mr-1" />{t("cal.poster.setCover")}</Button>}
      {admin && <Button size="sm" variant="ghost" onClick={remove} className="h-9 text-destructive" data-testid={`poster-remove-${poster.id}`}><Trash2 className="h-4 w-4" /></Button>}
    </div>
  );
};

const GeneratePanel = ({ ev, onStarted }) => {
  const { t } = useLang();
  const [language, setLanguage] = useState("both");
  const [style, setStyle] = useState("classic");
  const [size, setSize] = useState("story");
  const [colour, setColour] = useState("green_gold");
  const [instruction, setInstruction] = useState("");
  const [photo, setPhoto] = useState(null);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef();
  const go = async () => {
    setLoading(true);
    try {
      const fd = new FormData(); fd.append("language", language); fd.append("style", style); fd.append("instruction", instruction); fd.append("size", size); fd.append("colour", colour); if (photo) fd.append("photo", photo);
      await api.post(`/events/${ev.id}/poster`, fd, { headers: { "Content-Type": "multipart/form-data" } });
      toast.success(t("cal.poster.started")); onStarted();
    } catch (e) { toast.error(apiError(e)); } finally { setLoading(false); }
  };
  return (
    <div className="rounded-xl border border-dashed border-primary/40 bg-primary/[0.03] p-4 space-y-3" data-testid="poster-generate-panel">
      <div className="grid grid-cols-2 gap-3">
        <SelectField label={t("cal.poster.language")} value={language} onChange={setLanguage} testId="poster-language-select" options={["both", "kn_en", "all", "ml", "kn", "en"].map((v) => ({ value: v, label: t(`cal.poster.${v}`) }))} />
        <SelectField label={t("cal.poster.style")} value={style} onChange={setStyle} testId="poster-style-select" options={STYLES.map((v) => ({ value: v, label: t(`cal.poster.styles.${v}`) }))} />
        <SelectField label={t("cal.poster.size")} value={size} onChange={setSize} testId="poster-size-select" options={SIZES.map((v) => ({ value: v, label: t(`cal.poster.sizes.${v}`) }))} />
        <SelectField label={t("cal.poster.colour")} value={colour} onChange={setColour} testId="poster-colour-select" options={COLOURS.map((v) => ({ value: v, label: t(`cal.poster.colours.${v}`) }))} />
      </div>
      <TextField label={t("cal.poster.instruction")} value={instruction} onChange={setInstruction} placeholder={t("cal.poster.instructionPh")} testId="poster-instruction-input" />
      <div>
        <p className="text-sm font-medium mb-1">{t("cal.poster.photo")}</p>
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => setPhoto(e.target.files?.[0] || null)} data-testid="poster-photo-input" />
        <div className="flex items-center gap-3">
          <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current.click()} className="h-9" data-testid="poster-photo-button"><Upload className="h-4 w-4 mr-1" />{photo ? photo.name : t("cal.poster.photo")}</Button>
          {photo && <><img src={URL.createObjectURL(photo)} alt="" className="h-12 w-12 rounded object-cover" /><Button type="button" size="icon" variant="ghost" onClick={() => setPhoto(null)}><X className="h-4 w-4" /></Button></>}
        </div>
        <p className="text-xs text-muted-foreground mt-1">{t("cal.poster.photoHint")}</p>
      </div>
      <Button onClick={go} disabled={loading} className="h-11 w-full" data-testid="poster-generate-button"><Sparkles className="h-4 w-4 mr-2" />{ev.posters?.length ? t("cal.poster.regenerate") : t("cal.poster.generate")}</Button>
    </div>
  );
};

const EditPanel = ({ ev, poster, onStarted }) => {
  const { t } = useLang();
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const go = async () => {
    if (!text.trim()) return;
    setLoading(true);
    try { await api.post(`/events/${ev.id}/poster/edit`, { instruction: text, poster_id: poster.id }); toast.success(t("cal.poster.started")); setText(""); onStarted(); } catch (e) { toast.error(apiError(e)); } finally { setLoading(false); }
  };
  return (
    <div className="flex gap-2 items-end" data-testid="poster-edit-panel">
      <TextField label={t("cal.poster.edit")} value={text} onChange={setText} placeholder={t("cal.poster.editPh")} testId="poster-edit-input" className="flex-1" />
      <Button onClick={go} disabled={loading || !text.trim()} className="h-11" data-testid="poster-edit-button"><Pencil className="h-4 w-4 mr-1" />{t("cal.poster.editBtn")}</Button>
    </div>
  );
};

const GuestPhotos = ({ ev, admin, onChanged }) => {
  const { t } = useLang();
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const ref = useRef();
  const add = async () => {
    if (!file) return;
    setLoading(true);
    try { const fd = new FormData(); fd.append("name", name); fd.append("role", role); fd.append("photo", file); await api.post(`/events/${ev.id}/guests`, fd, { headers: { "Content-Type": "multipart/form-data" } }); toast.success(t("cal.fields.guestAdded")); setName(""); setRole(""); setFile(null); onChanged(); }
    catch (e) { toast.error(apiError(e)); } finally { setLoading(false); }
  };
  const remove = async (g) => { await api.delete(`/events/${ev.id}/guests/${g.id}`); onChanged(); };
  const guests = ev.guest_photos || [];
  if (!admin && !guests.length) return null;
  return (
    <div className="space-y-2" data-testid="guest-photos-section">
      <p className="text-sm font-semibold">{t("cal.fields.guestPhotos")}</p>
      {guests.length > 0 && (
        <div className="flex flex-wrap gap-3">
          {guests.map((g) => (
            <div key={g.id} className="relative flex flex-col items-center w-20 text-center" data-testid={`guest-photo-${g.id}`}>
              <img src={`${BASE}${g.url}`} alt={g.name} className="h-16 w-16 rounded-full object-cover ring-2 ring-[#d4af37]" />
              <p className="text-[11px] font-semibold leading-tight mt-1 truncate w-full">{g.name}</p>
              {g.role && <p className="text-[10px] text-muted-foreground truncate w-full">{g.role}</p>}
              {admin && <button type="button" onClick={() => remove(g)} className="absolute -top-1 -right-1 grid h-5 w-5 place-items-center rounded-full bg-destructive text-white" data-testid={`guest-remove-${g.id}`}><X className="h-3 w-3" /></button>}
            </div>
          ))}
        </div>
      )}
      {admin && (
        <div className="grid grid-cols-2 gap-2 items-end rounded-lg border border-dashed p-3">
          <TextField label={t("cal.fields.guestName")} value={name} onChange={setName} testId="guest-name-input" />
          <TextField label={t("cal.fields.guestRole")} value={role} onChange={setRole} testId="guest-role-input" />
          <input ref={ref} type="file" accept="image/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} data-testid="guest-photo-input" />
          <Button type="button" variant="outline" size="sm" onClick={() => ref.current.click()} className="h-10" data-testid="guest-photo-button"><Upload className="h-4 w-4 mr-1" />{file ? file.name.slice(0, 18) : t("cal.poster.photo")}</Button>
          <Button type="button" size="sm" onClick={add} disabled={!file || loading} className="h-10" data-testid="guest-add-button"><UserPlus className="h-4 w-4 mr-1" />{t("cal.fields.addGuest")}</Button>
        </div>
      )}
    </div>
  );
};

export const EventDetail = ({ eventId, onClose, onEdit }) => {
  const { t, lang } = useLang();
  const { isAdmin, settings } = useAuth();
  const [ev, setEv] = useState(null);
  const [current, setCurrent] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const load = useCallback(() => api.get(`/events/${eventId}`).then((r) => { setEv(r.data); setCurrent((c) => r.data.posters.find((p) => p.id === c?.id) || r.data.posters.find((p) => p.url === r.data.poster_url) || r.data.posters[r.data.posters.length - 1] || null); }), [eventId]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (ev?.poster_status !== "generating") return;
    const id = setInterval(async () => { const { data } = await api.get(`/events/${eventId}`); if (data.poster_status !== "generating") { setEv(data); setCurrent(data.posters[data.posters.length - 1] || null); if (data.poster_status === "ready") toast.success(t("cal.poster.ready")); else toast.error(`${t("cal.poster.failed")}: ${data.poster_error}`); } }, 4000);
    return () => clearInterval(id);
  }, [ev?.poster_status, eventId, t]);

  const notify = async () => { try { const { data } = await api.post(`/events/${ev.id}/notify`); toast.success(t("cal.notified", { n: data.houses })); load(); } catch (e) { toast.error(apiError(e)); } };
  const remove = async () => { try { await api.delete(`/events/${ev.id}`); toast.success(t("cal.deleted")); onClose(); } catch (e) { toast.error(apiError(e)); } };

  if (!ev) return null;
  const h = hijri(ev.date, settings?.hijri_adjustment || 0, lang);
  const title = lang === "ml" && ev.title_ml ? ev.title_ml : lang === "kn" && ev.title_kn ? ev.title_kn : ev.title;
  const generating = ev.poster_status === "generating";
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[94vh] overflow-y-auto" data-testid="event-detail-dialog">
        <DialogHeader><DialogTitle data-testid="event-detail-title">{title}</DialogTitle></DialogHeader>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-5">
          <div className="md:col-span-2 space-y-3">
            {ev.title_ml && lang !== "ml" && <p className="text-lg font-semibold -mt-2">{ev.title_ml}</p>}
            {lang === "ml" && ev.title !== ev.title_ml && <p className="text-sm text-muted-foreground -mt-2">{ev.title}</p>}
            <div className="rounded-xl bg-primary/5 border border-primary/20 p-3">
              <p className="font-bold">{fmtDate(ev.date)}</p>
              <p className="text-sm text-[#8a6d1d] font-semibold" data-testid="event-detail-hijri">{h.label}</p>
              {ev.time && <p className="text-sm inline-flex items-center gap-1 mt-1"><Clock className="h-3.5 w-3.5" />{ev.time}</p>}
              {ev.venue && <p className="text-sm inline-flex items-center gap-1 ml-3"><MapPin className="h-3.5 w-3.5" />{ev.venue}</p>}
            </div>
            <span className="inline-block rounded-full bg-accent px-2.5 py-0.5 text-xs font-semibold">{t(`cal.categories.${ev.category}`)}</span>
            {ev.guests && <p className="text-sm whitespace-pre-wrap"><span className="font-semibold">{t("cal.fields.guests")}:</span> {ev.guests}</p>}
            {(ev.chair || ev.organizer || ev.leader) && (
              <div className="text-sm space-y-0.5" data-testid="event-roles">
                {ev.chair && <p><span className="font-semibold">{t("cal.fields.chair")}:</span> {ev.chair}</p>}
                {ev.organizer && <p><span className="font-semibold">{t("cal.fields.organizer")}:</span> {ev.organizer}</p>}
                {ev.leader && <p><span className="font-semibold">{t("cal.fields.leader")}:</span> {ev.leader}</p>}
              </div>
            )}
            {ev.women_facility && <p className="text-sm text-[#a06f1c] font-semibold" data-testid="event-women-note">{ev.women_note || t("cal.fields.womenDefault")}</p>}
            <GuestPhotos ev={ev} admin={isAdmin} onChanged={load} />
            {ev.description && <p className="text-sm whitespace-pre-wrap">{ev.description}</p>}
            {isAdmin && (
              <div className="flex flex-wrap gap-2 pt-2">
                <Button size="sm" variant="outline" onClick={notify} className="h-9" data-testid="event-notify-button"><Send className="h-4 w-4 mr-1" />{t("cal.notifyNow")}</Button>
                <Button size="sm" variant="outline" onClick={() => onEdit(ev)} className="h-9" data-testid="event-edit-button"><Pencil className="h-4 w-4 mr-1" />{t("common.edit")}</Button>
                <Button size="sm" variant="ghost" onClick={() => setDeleting(true)} className="h-9 text-destructive" data-testid="event-delete-button"><Trash2 className="h-4 w-4" /></Button>
              </div>
            )}
            {ev.notified_at && <p className="text-xs text-muted-foreground">{t("cal.notifiedAt")}: {fmtDate(ev.notified_at.slice(0, 10))}</p>}
          </div>

          <div className="md:col-span-3 space-y-3" data-testid="poster-section">
            <h3 className="font-bold flex items-center gap-2"><Sparkles className="h-4 w-4 text-[#c58b2b]" />{t("cal.poster.title")}</h3>
            {generating && <div className="rounded-xl border bg-accent/60 p-6 text-center" data-testid="poster-generating"><Loader2 className="h-8 w-8 mx-auto animate-spin text-primary" /><p className="text-sm mt-2">{t("cal.poster.generating")}</p></div>}
            {ev.poster_status === "failed" && !generating && <p className="text-sm text-destructive rounded-lg bg-destructive/10 px-3 py-2" data-testid="poster-failed">{t("cal.poster.failed")}: {ev.poster_error}</p>}
            {current ? (
              <div className="space-y-2">
                <img src={`${BASE}${current.url}`} alt="poster" className="w-full max-h-[520px] object-contain rounded-xl border bg-[#faf8f5]" data-testid="poster-image" />
                <PosterActions ev={ev} poster={current} onChanged={load} admin={isAdmin} />
                {ev.posters.length > 1 && (
                  <div className="flex gap-2 overflow-x-auto py-1" data-testid="poster-thumbs">
                    {ev.posters.map((p) => <button type="button" key={p.id} onClick={() => setCurrent(p)} className={cn("relative shrink-0 rounded-md overflow-hidden border-2", p.id === current.id ? "border-primary" : "border-transparent")} data-testid={`poster-thumb-${p.id}`}><img src={`${BASE}${p.url}`} alt="" className="h-20 w-16 object-cover" />{p.url === ev.poster_url && <Star className="absolute top-0.5 right-0.5 h-3 w-3 text-[#d4af37] fill-[#d4af37]" />}</button>)}
                  </div>
                )}
                {isAdmin && !generating && <EditPanel ev={ev} poster={current} onStarted={load} />}
              </div>
            ) : !generating && <p className="text-sm text-muted-foreground" data-testid="poster-none">{t("cal.poster.none")}</p>}
            {isAdmin && !generating && <GeneratePanel ev={ev} onStarted={load} />}
            {isAdmin && <p className="text-xs text-muted-foreground">{t("cal.poster.tip")}</p>}
          </div>
        </div>
        <ConfirmDelete open={deleting} onOpenChange={setDeleting} onConfirm={remove} />
      </DialogContent>
    </Dialog>
  );
};
