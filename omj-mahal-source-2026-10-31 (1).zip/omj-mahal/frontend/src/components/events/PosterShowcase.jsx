import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CalendarDays, Clock, MapPin, ChevronLeft, ChevronRight, Sparkles, Maximize2, Images } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { fmtDate, todayStr } from "@/lib/format";
import { cn } from "@/lib/utils";
import { PosterViewer, eventTitle } from "@/components/events/PosterViewer";

const BASE = process.env.REACT_APP_BACKEND_URL;
const daysLeft = (d) => Math.round((new Date(d + "T00:00:00Z") - new Date(todayStr() + "T00:00:00Z")) / 86400000);

export const useDisplayItems = (given) => {
  const [items, setItems] = useState(given || []);
  useEffect(() => { if (given) setItems(given); }, [given]);
  useEffect(() => {
    if (given) return;
    fetch(`${BASE}/api/public/display`).then((r) => (r.ok ? r.json() : [])).then(setItems).catch(() => {});
  }, [given]);
  return items;
};

export const useBadge = () => {
  const { t } = useLang();
  return (date) => { const left = daysLeft(date); return left === 0 ? t("cal.today") : left === 1 ? t("showcase.tomorrow") : t("showcase.daysLeft", { n: left }); };
};

export const PosterShowcase = ({ items: given, to = "/posters", compact = false, className }) => {
  const { t, lang } = useLang();
  const items = useDisplayItems(given);
  const badgeFor = useBadge();
  const [i, setI] = useState(0);
  const [open, setOpen] = useState(null);
  useEffect(() => {
    if (items.length < 2 || open) return;
    const id = setInterval(() => setI((x) => (x + 1) % items.length), 8000);
    return () => clearInterval(id);
  }, [items.length, open]);
  if (!items.length) return null;
  const ev = items[i % items.length];
  const title = eventTitle(ev, lang);
  const hijri = ev.hijri?.[lang === "ml" ? "label_ml" : lang === "kn" ? "label_kn" : "label"];
  const guests = ev.guest_photos || [];
  return (
    <section className={cn("relative overflow-hidden rounded-2xl shadow-xl text-white", compact ? "" : "mb-6", className)} data-testid="poster-showcase" style={{ background: "linear-gradient(135deg,#0d5c3a 0%,#083d27 60%,#1e2923 100%)" }}>
      <div className="absolute inset-0 opacity-20 islamic-pattern pointer-events-none" />
      <div className={cn("relative grid grid-cols-1", !compact && "md:grid-cols-[minmax(0,340px)_1fr]")}>
        <button type="button" onClick={() => setOpen(ev)} className="relative block w-full bg-black/30 group" data-testid="showcase-open" aria-label={t("posters.tapHint")}>
          {ev.poster_url ? (
            <img src={`${BASE}${ev.poster_url}`} alt={title} className={cn("w-full object-contain mx-auto transition-transform duration-500 group-hover:scale-[1.01]", compact ? "max-h-[55vh] md:max-h-[420px]" : "max-h-[75vh] md:max-h-[540px]")} data-testid="showcase-poster" />
          ) : (
            <div className={cn("w-full grid place-items-center p-6 text-center", compact ? "h-48" : "h-64 md:h-[420px]")}><div><Sparkles className="h-10 w-10 text-[#d4af37] mx-auto mb-2" /><p className="text-xl font-bold">{title}</p></div></div>
          )}
          <span className="absolute left-3 top-3 rounded-full bg-[#d4af37] text-[#1e2923] px-3 py-1 text-xs font-bold uppercase tracking-wide shadow" data-testid="showcase-badge">{badgeFor(ev.date)}</span>
          <span className="absolute right-3 bottom-3 grid h-9 w-9 place-items-center rounded-full bg-black/50 text-white opacity-80 group-hover:opacity-100"><Maximize2 className="h-4 w-4" /></span>
        </button>
        <div className={cn("min-w-0 flex flex-col p-4", !compact && "sm:p-5")}>
          <span className="text-[11px] uppercase tracking-[0.2em] text-[#d4af37]">{t(`cal.categories.${ev.category}`)}</span>
          <h3 className={cn("font-bold leading-tight mt-1", compact ? "text-lg" : "text-2xl sm:text-3xl")} data-testid="showcase-title">{title}</h3>
          {ev.title_ml && lang !== "ml" && <p className="text-white/80 text-sm">{ev.title_ml}</p>}
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-white/90">
            <span className="inline-flex items-center gap-1"><CalendarDays className="h-4 w-4 text-[#d4af37]" />{fmtDate(ev.date)}{hijri && <span className="text-[#d4af37]"> · {hijri}</span>}</span>
            {ev.time && <span className="inline-flex items-center gap-1"><Clock className="h-4 w-4 text-[#d4af37]" />{ev.time}</span>}
            {ev.venue && <span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4 text-[#d4af37]" />{ev.venue}</span>}
          </div>
          {!compact && (ev.chair || ev.organizer || ev.leader) && (
            <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-1 text-xs text-white/85">
              {ev.chair && <p><span className="text-[#d4af37]">{t("cal.fields.chair")}:</span> {ev.chair}</p>}
              {ev.organizer && <p><span className="text-[#d4af37]">{t("cal.fields.organizer")}:</span> {ev.organizer}</p>}
              {ev.leader && <p><span className="text-[#d4af37]">{t("cal.fields.leader")}:</span> {ev.leader}</p>}
            </div>
          )}
          {!compact && guests.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-3" data-testid="showcase-guests">
              {guests.slice(0, 6).map((g) => (
                <div key={g.id} className="flex items-center gap-2">
                  <img src={`${BASE}${g.url}`} alt={g.name} className="h-10 w-10 rounded-full object-cover ring-2 ring-[#d4af37]" />
                  <div className="leading-tight"><p className="text-xs font-semibold">{g.name}</p>{g.role && <p className="text-[10px] text-white/70">{g.role}</p>}</div>
                </div>
              ))}
            </div>
          )}
          {!compact && !guests.length && ev.guests && <p className="mt-2 text-xs text-white/80 whitespace-pre-line line-clamp-3">{ev.guests}</p>}
          {ev.women_facility && <p className="mt-2 text-xs text-[#d4af37] font-semibold">{ev.women_note || t("cal.fields.womenDefault")}</p>}
          <div className="mt-auto pt-3 flex flex-wrap gap-2">
            <button type="button" onClick={() => setOpen(ev)} className="inline-flex items-center gap-1.5 rounded-full bg-[#d4af37] text-[#1e2923] px-4 h-9 text-sm font-semibold hover:bg-[#e2c053]" data-testid="showcase-details">{t("posters.details")}</button>
            {to && <Link to={to} className="inline-flex items-center gap-1.5 rounded-full border border-white/30 bg-white/5 px-4 h-9 text-sm font-semibold hover:bg-white/15" data-testid="showcase-link"><Images className="h-4 w-4" />{t("posters.viewAll")}</Link>}
          </div>
        </div>
      </div>
      {items.length > 1 && (
        <div className="relative flex items-center justify-between px-4 pb-3">
          <button type="button" onClick={() => setI((i - 1 + items.length) % items.length)} className="grid h-8 w-8 place-items-center rounded-full bg-white/10 hover:bg-white/20" data-testid="showcase-prev"><ChevronLeft className="h-4 w-4" /></button>
          <div className="flex gap-1.5">{items.map((_, k) => <span key={k} className={cn("h-1.5 rounded-full transition-all", k === i % items.length ? "w-6 bg-[#d4af37]" : "w-1.5 bg-white/40")} />)}</div>
          <button type="button" onClick={() => setI((i + 1) % items.length)} className="grid h-8 w-8 place-items-center rounded-full bg-white/10 hover:bg-white/20" data-testid="showcase-next"><ChevronRight className="h-4 w-4" /></button>
        </div>
      )}
      <PosterViewer ev={open} onClose={() => setOpen(null)} />
    </section>
  );
};
