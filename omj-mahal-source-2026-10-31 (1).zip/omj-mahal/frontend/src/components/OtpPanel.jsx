import { useState } from "react";
import { toast } from "sonner";
import { IdCard, MessageCircle, MessageSquare, ArrowLeft, KeyRound } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { cn } from "@/lib/utils";

const ChannelPicker = ({ value, onChange }) => {
  const { t } = useLang();
  const opts = [{ v: "whatsapp", icon: MessageCircle, cls: "text-[#128C7E]" }, { v: "sms", icon: MessageSquare, cls: "text-primary" }];
  return (
    <div className="space-y-2">
      <Label>{t("otp.via")}</Label>
      <div className="grid grid-cols-2 gap-2">
        {opts.map(({ v, icon: Icon, cls }) => (
          <button type="button" key={v} onClick={() => onChange(v)} data-testid={`otp-channel-${v}`}
            className={cn("h-11 rounded-lg border font-semibold flex items-center justify-center gap-2 transition-colors", value === v ? "border-primary bg-primary/10 text-primary" : "bg-card hover:bg-accent")}>
            <Icon className={cn("h-4 w-4", value === v ? "" : cls)} />{t(`notif.channels.${v}`)}
          </button>
        ))}
      </div>
    </div>
  );
};

const CodeInput = ({ value, onChange }) => (
  <InputOTP maxLength={6} value={value} onChange={onChange} data-testid="otp-code-input" containerClassName="justify-center">
    <InputOTPGroup>{[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} className="h-12 w-11 text-lg" />)}</InputOTPGroup>
  </InputOTP>
);

export const OtpPanel = ({ purpose = "login", onDone, onBack }) => {
  const { t } = useLang();
  const { setSession } = useAuth();
  const [loginId, setLoginId] = useState("");
  const [channel, setChannel] = useState("whatsapp");
  const [sent, setSent] = useState(null);
  const [code, setCode] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [pw, setPw] = useState({ a: "", b: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const run = async (fn) => {
    setError(""); setLoading(true);
    try { await fn(); } catch (err) { setError(apiError(err, t("common.error"))); } finally { setLoading(false); }
  };

  const send = (e) => { e?.preventDefault(); run(async () => {
    const { data } = await api.post("/auth/otp/request", { login_id: loginId.trim().toUpperCase(), channel, purpose });
    setSent(data); setCode("");
  }); };

  const verify = (e) => { e?.preventDefault(); run(async () => {
    const { data } = await api.post("/auth/otp/verify", { login_id: loginId.trim().toUpperCase(), code, purpose });
    if (purpose === "login") { setSession(data); onDone?.(); return; }
    setResetToken(data.reset_token);
  }); };

  const reset = (e) => { e.preventDefault();
    if (pw.a !== pw.b) return setError(t("otp.mismatch"));
    run(async () => {
      await api.post("/auth/otp/reset-password", { reset_token: resetToken, new_password: pw.a });
      toast.success(t("otp.resetDone")); onDone?.();
    });
  };

  const Err = error && <p className="text-sm text-destructive bg-destructive/5 border border-destructive/20 rounded-md px-3 py-2" data-testid="otp-error">{error}</p>;

  if (resetToken) return (
    <form onSubmit={reset} className="space-y-4" data-testid="otp-reset-form">
      <div className="space-y-2"><Label>{t("otp.newPassword")}</Label><Input type="password" value={pw.a} onChange={(e) => setPw((p) => ({ ...p, a: e.target.value }))} className="h-12" minLength={4} required data-testid="reset-new-password" /></div>
      <div className="space-y-2"><Label>{t("otp.confirm")}</Label><Input type="password" value={pw.b} onChange={(e) => setPw((p) => ({ ...p, b: e.target.value }))} className="h-12" minLength={4} required data-testid="reset-confirm-password" /></div>
      {Err}
      <Button type="submit" disabled={loading} className="w-full h-12 text-base font-semibold" data-testid="reset-submit-button"><KeyRound className="h-4 w-4 mr-2" />{t("otp.setPassword")}</Button>
    </form>
  );

  if (sent) return (
    <form onSubmit={verify} className="space-y-4" data-testid="otp-verify-form">
      <p className="text-sm text-muted-foreground" data-testid="otp-sent-info">{t("otp.sentTo", { to: sent.sent_to })}</p>
      {sent.demo_code && (
        <div className="rounded-lg border border-dashed border-[#d4af37] bg-[#d4af37]/10 px-3 py-2 text-sm text-[#8a6d1d]">
          {t("otp.demo")}: <b className="font-mono text-base tracking-widest" data-testid="otp-demo-code">{sent.demo_code}</b>
        </div>
      )}
      <div className="space-y-2"><Label className="block text-center">{t("otp.enter")}</Label><CodeInput value={code} onChange={setCode} /></div>
      {Err}
      <Button type="submit" disabled={loading || code.length < 6} className="w-full h-12 text-base font-semibold" data-testid="otp-verify-button">{loading ? t("otp.verifying") : t("otp.verify")}</Button>
      <div className="flex justify-between text-sm">
        <button type="button" onClick={() => setSent(null)} className="text-muted-foreground hover:underline" data-testid="otp-change-number">{t("otp.change")}</button>
        <button type="button" onClick={send} className="font-semibold text-primary hover:underline" data-testid="otp-resend-button">{t("otp.resend")}</button>
      </div>
    </form>
  );

  return (
    <form onSubmit={send} className="space-y-4" data-testid="otp-request-form">
      {purpose === "reset" && <p className="text-sm text-muted-foreground">{t("otp.resetHint")}</p>}
      <div className="space-y-2">
        <Label htmlFor="otp-id">{t("loginId")}</Label>
        <div className="relative">
          <IdCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="otp-id" autoCapitalize="characters" value={loginId} onChange={(e) => setLoginId(e.target.value.toUpperCase())} className="h-12 pl-10 text-base font-mono tracking-wider uppercase" placeholder={t("loginIdPlaceholder")} required data-testid="otp-id-input" />
        </div>
        <p className="text-xs text-muted-foreground">{t("loginIdHint")}</p>
      </div>
      <ChannelPicker value={channel} onChange={setChannel} />
      {Err}
      <Button type="submit" disabled={loading} className="w-full h-12 text-base font-semibold" data-testid="otp-send-button">{loading ? t("otp.sending") : t("otp.send")}</Button>
      {onBack && <button type="button" onClick={onBack} className="w-full flex items-center justify-center gap-1 text-sm text-muted-foreground hover:underline" data-testid="otp-back-button"><ArrowLeft className="h-4 w-4" />{t("otp.back")}</button>}
    </form>
  );
};
