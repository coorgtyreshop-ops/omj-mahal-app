import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Download, Upload, ShieldCheck, RotateCcw, Cloud, FileCode2, Link2 } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const fmtSize = (n) => (n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);
const fmtWhen = (iso) => (iso ? new Date(iso).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "");
const saveBlob = (blob, name) => { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click(); URL.revokeObjectURL(a.href); };
const total = (counts) => Object.values(counts || {}).reduce((a, b) => a + b, 0);

export const BackupSection = () => {
  const { t } = useLang();
  const [info, setInfo] = useState({ snapshots: [], keep: 30 });
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const fileRef = useRef();
  const load = () => api.get("/backup/snapshots").then((r) => setInfo(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);

  const run = async (fn) => { setBusy(true); try { await fn(); } catch (e) { toast.error(apiError(e)); } finally { setBusy(false); } };
  const download = () => run(async () => { const r = await api.get("/backup/export", { responseType: "blob" }); saveBlob(r.data, `omj-mahal-backup-${new Date().toISOString().slice(0, 10)}.json`); toast.success(t("backup.downloaded")); load(); });
  const downloadSnap = (s) => run(async () => { const r = await api.get(`/backup/snapshots/${s.id}/download`, { responseType: "blob" }); saveBlob(r.data, `omj-mahal-backup-${s.created_at.slice(0, 10)}.json`); });
  const snapNow = () => run(async () => { await api.post("/backup/snapshots"); toast.success(t("backup.created")); load(); });
  const downloadSource = () => run(async () => { const r = await api.get("/backup/source-code", { responseType: "blob" }); saveBlob(r.data, `omj-mahal-source-${new Date().toISOString().slice(0, 10)}.zip`); toast.success(t("backup.sourceDone")); });
  const copySourceLink = () => run(async () => {
    const r = await api.post("/backup/source-link");
    const url = `${process.env.REACT_APP_BACKEND_URL}/api/backup/source-code?t=${r.data.token}`;
    try { await navigator.clipboard.writeText(url); toast.success(t("backup.sourceLinkCopied")); } catch { window.prompt(t("backup.sourceLink"), url); }
  });
  const restore = () => run(async () => {
    let r;
    if (confirm.kind === "file") { const fd = new FormData(); fd.append("file", confirm.file); r = await api.post("/backup/restore", fd); }
    else r = await api.post(`/backup/snapshots/${confirm.id}/restore`);
    toast.success(t("backup.restored", { n: r.data.restored })); setConfirm(null); setTimeout(() => window.location.reload(), 1500);
  });

  return (
    <section className="rounded-xl border border-[#0d5c3a]/40 bg-[#0d5c3a]/[0.04] p-5 shadow-sm max-w-3xl" data-testid="settings-backup-section">
      <h2 className="font-bold text-base mb-1 text-primary flex items-center gap-2"><ShieldCheck className="h-4 w-4" />{t("backup.title")}</h2>
      <p className="text-xs text-muted-foreground mb-3">{t("backup.safeNote")}</p>
      <div className="flex flex-wrap gap-2 mb-3">
        <Button type="button" onClick={download} disabled={busy} className="h-11" data-testid="backup-download-button"><Download className="h-4 w-4 mr-2" />{t("backup.download")}</Button>
        <Button type="button" variant="outline" onClick={() => fileRef.current?.click()} disabled={busy} className="h-11" data-testid="backup-restore-file-button"><Upload className="h-4 w-4 mr-2" />{t("backup.restore")}</Button>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" data-testid="backup-file-input" onChange={(e) => { const f = e.target.files?.[0]; if (f) setConfirm({ kind: "file", file: f, label: f.name }); e.target.value = ""; }} />
        <Button type="button" variant="outline" onClick={snapNow} disabled={busy} className="h-11" data-testid="backup-snapshot-now-button"><RotateCcw className="h-4 w-4 mr-2" />{t("backup.now")}</Button>
      </div>
      <p className="text-xs text-muted-foreground mb-3" data-testid="backup-status">
        {t("backup.lastDownload")}: <b>{info.last_download ? fmtWhen(info.last_download) : t("backup.never")}</b> · {t("backup.lastAuto")}: <b>{info.last_auto ? fmtWhen(info.last_auto) : t("backup.never")}</b>
      </p>
      <div className="rounded-lg border border-dashed bg-card p-3 mb-4 flex flex-wrap items-center gap-3" data-testid="backup-source-row">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold flex items-center gap-1.5"><FileCode2 className="h-4 w-4 text-primary" />{t("backup.source")}</p>
          <p className="text-xs text-muted-foreground">{t("backup.sourceNote")}</p>
        </div>
        <Button type="button" variant="outline" onClick={downloadSource} disabled={busy} className="h-11" data-testid="backup-source-button"><Download className="h-4 w-4 mr-2" />{t("backup.sourceBtn")}</Button>
        <Button type="button" variant="ghost" onClick={copySourceLink} disabled={busy} className="h-11" data-testid="backup-source-link-button"><Link2 className="h-4 w-4 mr-2" />{t("backup.sourceLink")}</Button>
      </div>
      <h3 className="text-sm font-semibold mb-2">{t("backup.snapshots", { n: info.keep })}</h3>
      {info.snapshots.length === 0 ? <p className="text-xs text-muted-foreground" data-testid="backup-none">{t("backup.none")}</p> : (
        <div className="rounded-lg border bg-card divide-y max-h-72 overflow-y-auto" data-testid="backup-snapshot-list">
          {info.snapshots.map((s) => (
            <div key={s.id} className="flex items-center gap-2 px-3 py-2 text-sm" data-testid={`backup-snapshot-${s.id}`}>
              <div className="min-w-0 flex-1">
                <p className="font-medium flex items-center gap-1.5 flex-wrap">{fmtWhen(s.created_at)}<span className="rounded-full bg-muted px-2 text-[10px]">{t(`backup.kinds.${s.kind}`)}</span>{s.cloud && <Cloud className="h-3 w-3 text-primary" title={t("backup.cloudCopy")} />}</p>
                <p className="text-xs text-muted-foreground">{s.counts?.houses || 0} {t("backup.houses")} · {s.counts?.members || 0} {t("backup.members")} · {s.counts?.payments || 0} {t("backup.payments")} · {total(s.counts)} {t("backup.records")} · {fmtSize(s.size)}</p>
              </div>
              <Button type="button" size="sm" variant="outline" onClick={() => setConfirm({ kind: "snap", id: s.id, label: fmtWhen(s.created_at) })} disabled={busy} className="h-9" data-testid={`backup-restore-${s.id}`}>{t("backup.restoreThis")}</Button>
              <Button type="button" size="icon" variant="ghost" onClick={() => downloadSnap(s)} disabled={busy} data-testid={`backup-download-${s.id}`}><Download className="h-4 w-4" /></Button>
            </div>
          ))}
        </div>
      )}
      <AlertDialog open={!!confirm} onOpenChange={(o) => !o && setConfirm(null)}>
        <AlertDialogContent data-testid="backup-confirm-dialog">
          <AlertDialogHeader>
            <AlertDialogTitle>{t("backup.confirmTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("backup.confirmDesc", { label: confirm?.label || "" })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="backup-confirm-cancel">{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); restore(); }} disabled={busy} data-testid="backup-confirm-restore">{busy ? t("common.loading") : t("backup.confirmBtn")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
};
