import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, monthLabel, todayStr, currentMonth } from "@/lib/format";
import { TextField, SelectField, SubmitRow, Field } from "@/components/shared";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

export const COLLECTION_TYPES = ["varisankhya", "eid_fitr", "eid_adha", "nabidinam", "building", "special", "auction", "pledge", "old_balance", "donation"];
export const HOUSE_TYPES = ["special", "auction", "pledge", "old_balance"];
export const typeLabel = (t, k, settings) => {
  if (k === "special" && settings?.special_name) return settings.special_name;
  if (k?.startsWith("c_")) return settings?.custom_heads?.find((h) => h.id === k)?.name || k;
  return t(`fin.types.${k}`);
};
export const allTypes = (settings) => [...COLLECTION_TYPES.filter((k) => k !== "donation"), ...(settings?.custom_heads || []).map((h) => h.id), "donation"];
const addMonths = (ym, n) => { const [y, m] = ym.split("-").map(Number); const idx = y * 12 + m - 1 + n; return `${Math.floor(idx / 12)}-${String((idx % 12) + 1).padStart(2, "0")}`; };

const Chip = ({ on, pending, onClick, children, testId }) => (
  <button type="button" onClick={onClick} data-testid={testId}
    className={cn("rounded-full border px-3 py-1.5 text-sm font-medium transition-colors min-h-[38px]",
      on ? "bg-primary text-primary-foreground border-primary" : pending ? "bg-[#c58b2b]/10 border-[#c58b2b]/40 text-[#a06f1c]" : "bg-card border-border text-foreground hover:bg-accent")}>
    {children}
  </button>
);

export const CollectionPaymentForm = ({ open, onOpenChange, houses, presetHouse, presetType, fixedType, presetMember, onSaved }) => {
  const { t, months } = useLang();
  const { settings } = useAuth();
  const [houseId, setHouseId] = useState("");
  const [type, setType] = useState(fixedType || "varisankhya");
  const [detail, setDetail] = useState(null);
  const [memberId, setMemberId] = useState("head");
  const subs = (detail?.members || []).filter((m) => m.member_type === "sub");
  const [summary, setSummary] = useState(null);
  const [funds, setFunds] = useState([]);
  const [fundId, setFundId] = useState("");
  const [selected, setSelected] = useState([]);
  const [amount, setAmount] = useState("");
  const [mode, setMode] = useState("cash");
  const [date, setDate] = useState(todayStr());
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    setHouseId(presetHouse || ""); setType(fixedType || presetType || "varisankhya"); setSelected([]); setDetail(null); setSummary(null); setMemberId(presetMember || "head");
    setMode("cash"); setDate(todayStr()); setNote(""); setAmount(""); setFundId("");
  }, [open, presetHouse, presetType, fixedType, presetMember]);

  useEffect(() => {
    if (!houseId) return;
    Promise.all([api.get(`/houses/${houseId}`), api.get(`/finance/house/${houseId}/summary`)]).then(([h, s]) => { setDetail(h.data); setSummary(s.data.collections); });
  }, [houseId]);
  useEffect(() => { if (open && type === "donation") api.get("/funds").then((r) => { setFunds(r.data); if (r.data[0]) setFundId(r.data[0].id); }); }, [open, type]);

  const col = summary?.[type];
  useEffect(() => {
    setAmount("");
    if (!col) return setSelected([]);
    if (type === "varisankhya") setSelected((detail?.dues.pending_months || []).slice(0, 1));
    else if (col.kind === "yearly") setSelected(col.pending_periods.slice(0, 1));
    else setSelected([]);
  }, [type, col, detail]);

  const options = useMemo(() => {
    if (!col) return [];
    if (type === "varisankhya" && detail) {
      const paid = new Set(detail.dues.paid_months);
      const upcoming = Array.from({ length: 6 }, (_, i) => addMonths(currentMonth(), i + 1));
      return [...detail.dues.pending_months, ...upcoming].filter((m) => !paid.has(m));
    }
    if (col.kind === "yearly") {
      const next = String(new Date().getFullYear() + 1);
      return [...col.pending_periods, ...(col.pending_periods.includes(next) || (col.paid_periods || []).includes(next) ? [] : [next])];
    }
    return [];
  }, [col, type, detail]);
  const pendingSet = useMemo(() => new Set(type === "varisankhya" ? detail?.dues.pending_months || [] : col?.pending_periods || []), [type, detail, col]);

  const computed = useMemo(() => {
    if (!col) return 0;
    if (type === "varisankhya" || col.kind === "yearly") return selected.length * (col.rate || 0);
    if (col.kind === "one_time") return col.pending || 0;
    return 0;
  }, [col, type, selected]);
  const total = amount !== "" ? Number(amount) : computed;
  const toggle = (m) => setSelected((s) => (s.includes(m) ? s.filter((x) => x !== m) : [...s, m].sort()));
  const usesPeriods = type === "varisankhya" || col?.kind === "yearly";

  const submit = async (e) => {
    e.preventDefault();
    if (!houseId) return toast.error(t("subs.selectHouse"));
    if (total <= 0) return toast.error(t("fin.amount"));
    if (type === "donation" && !fundId) return toast.error(t("fin.selectFund"));
    setLoading(true);
    try {
      let data, kind = "subscription";
      if (type === "donation") {
        ({ data } = await api.post("/donations", { fund_id: fundId, donor_name: detail.head_name, house_id: houseId, amount: total, mode, date, note }));
        kind = "donation";
      } else {
        const periods = type === "varisankhya" ? { months: selected } : { years: col.kind === "yearly" ? selected : [] };
        ({ data } = await api.post("/payments", { house_id: houseId, type, ...periods, amount: total, mode, date, note, member_id: memberId !== "head" ? memberId : null }));
      }
      toast.success(t("subs.recorded"));
      onSaved({ ...data, house_no: detail.house_no, head_name: detail.head_name }, kind);
      onOpenChange(false);
    } catch (err) { toast.error(apiError(err, t("common.error"))); } finally { setLoading(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid="payment-form-dialog">
        <DialogHeader><DialogTitle>{t("fin.record")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <SelectField label={t("subs.selectHouse")} value={houseId} onChange={setHouseId} required testId="payment-house-select" placeholder={t("subs.selectHouse")}
            options={houses.map((h) => ({ value: h.id, label: `${h.house_no} — ${h.head_name}` }))} />
          {!fixedType && <SelectField label={t("fin.type")} value={type} onChange={setType} testId="payment-type-select" options={allTypes(settings).filter((k) => !HOUSE_TYPES.includes(k) || (summary?.[k]?.rate || 0) > 0).map((k) => ({ value: k, label: typeLabel(t, k, settings) }))} />}
          {detail && col && (
            <>
              {usesPeriods && (
                <Field label={`${type === "varisankhya" ? `${t("subs.selectMonths")} (${t("subs.monthlyAmount")}: ${inr(col.rate)})` : `${t("fin.years")} (${t("fin.perYear")}: ${inr(col.rate)})`} — ${t("fin.partial.optional")}`}>
                  {options.length === 0 ? <p className="text-sm text-muted-foreground">{t("fin.noDue")}</p> : (
                    <div className="flex flex-wrap gap-2" data-testid="payment-month-chips">
                      {options.map((p) => <Chip key={p} on={selected.includes(p)} pending={pendingSet.has(p)} onClick={() => toggle(p)} testId={`month-chip-${p}`}>{type === "varisankhya" ? monthLabel(p, months, true) : p}</Chip>)}
                    </div>
                  )}
                </Field>
              )}
              {type !== "donation" && <p className="text-sm text-muted-foreground" data-testid="payment-head-summary">{col.kind === "one_time" ? t("fin.target") : t("fin.due")}: <b>{inr(col.due ?? col.rate)}</b> · {t("fin.paid")}: <b>{inr(col.paid)}</b> · {t("fin.pending")}: <b className="text-[#a06f1c]">{inr(col.pending)}</b></p>}
              {type !== "donation" && <p className="text-xs text-muted-foreground">{t("fin.partial.hint")}</p>}
              {type === "donation" && <SelectField label={t("fin.fund")} value={fundId} onChange={setFundId} testId="payment-fund-select" placeholder={t("fin.selectFund")} options={funds.map((f) => ({ value: f.id, label: f.name }))} />}
              <div className="grid grid-cols-2 gap-4">
                <TextField label={t("subs.totalAmount")} type="number" min="0" value={amount === "" ? total : amount} onChange={setAmount} testId="payment-amount-input" />
                <SelectField label={t("common.mode")} value={mode} onChange={setMode} testId="payment-mode-select" options={["cash", "upi", "bank"].map((m) => ({ value: m, label: t(`paymentModes.${m}`) }))} />
                {subs.length > 0 && <SelectField label={t("subs.paidBy")} value={memberId} onChange={setMemberId} testId="payment-member-select" options={[{ value: "head", label: `${detail.head_name} (${t("mtype.head")})` }, ...subs.map((m) => ({ value: m.id, label: `${m.name} (${t("mtype.sub")})` }))]} />}
                <TextField label={t("subs.paymentDate")} type="date" value={date} onChange={setDate} testId="payment-date-input" />
                <TextField label={t("common.note")} value={note} onChange={setNote} testId="payment-note-input" />
              </div>
              <div className="rounded-lg bg-accent px-4 py-3 flex justify-between items-center">
                <span className="text-sm font-medium">{typeLabel(t, type, settings)}{usesPeriods && ` · ${selected.length} ${type === "varisankhya" ? t("subs.monthsCount") : t("fin.years")}`}</span>
                <span className="text-xl font-bold text-primary" data-testid="payment-total">{inr(total)}</span>
              </div>
              {type !== "donation" && total > 0 && (
                <p className="text-sm text-right" data-testid="payment-remaining">{t("fin.partial.after")}: <b className={Math.max(0, (col.pending || 0) - total) > 0 ? "text-[#a06f1c]" : "text-primary"}>{inr(Math.max(0, (col.pending || 0) - total))}</b>{total > (col.pending || 0) && col.kind !== "one_time" && <span className="text-xs text-muted-foreground"> · {t("fin.partial.advance")}: {inr(total - (col.pending || 0))}</span>}</p>
              )}
            </>
          )}
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} label={t("subs.payNow")} />
        </form>
      </DialogContent>
    </Dialog>
  );
};
