import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2, Users } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { RELATIONS, STATUSES, todayIso } from "@/components/forms/HouseMemberForms";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const blank = () => ({ name: "", relation: "", dob: "", gender: "", status: "" });
const REL = RELATIONS.filter((r) => r !== "Self");

const Row = ({ row, index, onChange, onRemove, canRemove }) => {
  const { t } = useLang();
  const set = (k) => (v) => onChange({ ...row, [k]: v });
  const pick = (k, opts, testId, ph) => (
    <Select value={row[k] || undefined} onValueChange={set(k)}>
      <SelectTrigger className="h-10" data-testid={`${testId}-${index}`}><SelectValue placeholder={ph} /></SelectTrigger>
      <SelectContent>{opts.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
    </Select>
  );
  return (
    <div className="rounded-xl border border-[#e6dbc9] bg-card p-3 space-y-2" data-testid={`family-row-${index}`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold uppercase tracking-wide text-[#8a6d1d]">{t("family.person", { n: index + 1 })}</span>
        {canRemove && <button type="button" onClick={onRemove} className="text-destructive p-1" data-testid={`family-remove-${index}`}><Trash2 className="h-4 w-4" /></button>}
      </div>
      <Input value={row.name} onChange={(e) => set("name")(e.target.value)} placeholder={t("members.name")} className="h-10" required data-testid={`family-name-${index}`} />
      <div className="grid grid-cols-2 gap-2">
        {pick("relation", REL.map((r) => ({ value: r, label: t(`members.relations.${r}`) })), "family-relation", t("members.relation"))}
        {pick("gender", [{ value: "male", label: t("members.male") }, { value: "female", label: t("members.female") }], "family-gender", t("members.gender"))}
        <Input type="date" value={row.dob} onChange={(e) => set("dob")(e.target.value)} max={todayIso()} className="h-10" required data-testid={`family-dob-${index}`} />
        {pick("status", STATUSES.map((s) => ({ value: s, label: t(`mstatus.${s}`) })), "family-status", t("mstatus.label"))}
      </div>
    </div>
  );
};

export const FamilyQuickAdd = ({ open, onOpenChange, house, onSaved }) => {
  const { t } = useLang();
  const [rows, setRows] = useState([blank()]);
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) setRows([blank()]); }, [open]);

  const submit = async (e) => {
    e.preventDefault();
    const members = rows.filter((r) => r.name.trim());
    if (!members.length) return toast.error(t("family.empty"));
    if (members.some((r) => !r.dob || !r.gender)) return toast.error(t("dob.required"));
    setLoading(true);
    try {
      const { data } = await api.post("/members/bulk", { house_id: house.id, members });
      toast.success(t("family.saved", { n: data.count }));
      onSaved?.(data); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };

  if (!house) return null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid="family-quick-add-dialog">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Users className="h-5 w-5 text-primary" />{t("family.title")}</DialogTitle>
          <p className="text-sm text-muted-foreground">{t("family.subtitle", { head: house.head_name })} · <b className="text-primary">{house.house_no}</b></p>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          {rows.map((r, i) => <Row key={i} row={r} index={i} canRemove={rows.length > 1} onChange={(v) => setRows((rs) => rs.map((x, j) => (j === i ? v : x)))} onRemove={() => setRows((rs) => rs.filter((_, j) => j !== i))} />)}
          <Button type="button" variant="outline" onClick={() => setRows((rs) => [...rs, blank()])} className="w-full h-11 border-dashed" data-testid="family-add-row"><Plus className="h-4 w-4 mr-1" />{t("family.addRow")}</Button>
          <div className="flex gap-2 justify-end pt-1">
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} className="h-11" data-testid="family-skip">{t("family.skip")}</Button>
            <Button type="submit" disabled={loading} className="h-11 min-w-[140px]" data-testid="family-save">{loading ? t("common.saving") : t("family.save", { n: rows.filter((r) => r.name.trim()).length })}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
