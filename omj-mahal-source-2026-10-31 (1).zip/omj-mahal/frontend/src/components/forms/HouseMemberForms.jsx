import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TextField, SelectField, SubmitRow } from "@/components/shared";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { currentMonth, ageFrom } from "@/lib/format";
import { TypeBadge } from "@/components/MemberCard";

export const RELATIONS = ["Self", "Wife", "Husband", "Son", "Daughter", "Father", "Mother", "Grandfather", "Grandmother", "Elder Brother", "Younger Brother", "Elder Sister", "Younger Sister", "Brother", "Sister", "Daughter-in-law", "Son-in-law", "Grandson", "Granddaughter", "Uncle", "Aunt", "Nephew", "Niece", "Other"];
export const STATUSES = ["student", "working", "homemaker", "retired", "none"];
const BLOOD = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"];
export const todayIso = () => new Date().toISOString().slice(0, 10);

const emptyHouse = (def) => ({ house_no: "", head_name: "", father_name: "", head_dob: "", head_blood_group: "", head_occupation: "", head_occupation_detail: "", head_education: "", address: "", ward: "", phone: "", whatsapp: "", subscription_amount: def ?? 100, start_month: currentMonth() });
export const OCCUPATIONS = ["doctor", "engineer", "teacher", "govt", "private", "business", "tyre", "timber", "driver", "labour", "farmer", "tailor", "gulf", "religious", "other"];
export const EDUCATIONS = ["lkg", "class1", "class2", "class3", "class4", "class5", "class6", "class7", "class8", "class9", "class10", "class11", "class12", "diploma", "degree", "engineering", "medical", "pg", "doctorate", "madrasa", "other"];
export const occLabel = (t, key) => (key ? (OCCUPATIONS.includes(key) ? t(`members.occupations.${key}`) : key) : "");
export const eduLabel = (t, key) => (key ? (EDUCATIONS.includes(key) ? t(`members.educations.${key}`) : key) : "");

/* Occupation category + free-text detail, and study level — shared by the house (head) form and the member form. */
export const WorkStudyFields = ({ occupation, detail, education, onOcc, onDetail, onEdu, prefix, showEducation = true }) => {
  const { t } = useLang();
  return (
    <>
      <SelectField label={t("members.occupations.label")} value={occupation || ""} onChange={onOcc} testId={`${prefix}-occupation-select`} options={OCCUPATIONS.map((v) => ({ value: v, label: t(`members.occupations.${v}`) }))} />
      <TextField label={t("members.occupations.detail")} value={detail || ""} onChange={onDetail} testId={`${prefix}-occupation-detail-input`} placeholder={occupation === "other" ? t("members.occupations.other") : ""} />
      {showEducation && <SelectField label={t("members.educations.label")} value={education || ""} onChange={onEdu} testId={`${prefix}-education-select`} options={EDUCATIONS.map((v) => ({ value: v, label: t(`members.educations.${v}`) }))} className="sm:col-span-2" />}
    </>
  );
};

export const HouseForm = ({ open, onOpenChange, house, onSaved, onCreated }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [form, setForm] = useState(emptyHouse(settings?.default_subscription));
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) setForm(house ? { ...emptyHouse(), ...house } : emptyHouse(settings?.default_subscription));
  }, [open, house, settings]);

  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    if (!house?.id && !form.head_dob) return toast.error(t("dob.required"));
    setLoading(true);
    try {
      const payload = { ...form, subscription_amount: Number(form.subscription_amount) };
      const { data } = house?.id ? await api.put(`/houses/${house.id}`, payload) : await api.post("/houses", payload);
      toast.success(t("houses.houseSaved"));
      onSaved?.(data);
      onOpenChange(false);
      if (!house?.id) onCreated?.(data);
    } catch (err) {
      toast.error(apiError(err, t("common.error")));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid="house-form-dialog">
        <DialogHeader><DialogTitle>{house?.id ? t("houses.editHouse") : t("houses.addHouse")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <TextField label={t("houses.houseNo")} value={form.house_no} onChange={set("house_no")} required testId="house-no-input" />
          <TextField label={t("houses.headName")} value={form.head_name} onChange={set("head_name")} required testId="house-head-input" />
          <TextField label={t("houses.fatherName")} value={form.father_name || ""} onChange={set("father_name")} testId="house-father-input" placeholder={t("houses.fatherPh")} />
          <TextField label={t("houses.headDob")} type="date" value={form.head_dob} onChange={set("head_dob")} required={!house?.id} max={todayIso()} testId="house-head-dob-input" />
          <SelectField label={t("members.bloodGroup")} value={form.head_blood_group || ""} onChange={set("head_blood_group")} testId="house-head-blood-select" options={BLOOD.map((b) => ({ value: b, label: b }))} />
          <WorkStudyFields prefix="house-head" occupation={form.head_occupation} detail={form.head_occupation_detail} education={form.head_education} onOcc={set("head_occupation")} onDetail={set("head_occupation_detail")} onEdu={set("head_education")} showEducation={false} />
          <TextField label={t("houses.ward")} value={form.ward} onChange={set("ward")} testId="house-ward-input" />
          <TextField label={t("common.address")} value={form.address} onChange={set("address")} testId="house-address-input" className="sm:col-span-2" />
          <TextField label={t("common.phone")} value={form.phone} onChange={set("phone")} testId="house-phone-input" inputMode="tel" />
          <TextField label={t("houses.whatsapp")} value={form.whatsapp} onChange={set("whatsapp")} testId="house-whatsapp-input" inputMode="tel" placeholder={t("notif.sameAsPhone")} />
          <TextField label={t("houses.subscription")} type="number" min="0" value={form.subscription_amount} onChange={set("subscription_amount")} required testId="house-subscription-input" />
          <TextField label={t("houses.startMonth")} type="month" value={form.start_month} onChange={set("start_month")} testId="house-start-month-input" />
          {!house?.id && <p className="sm:col-span-2 text-xs text-muted-foreground -mt-1">{t("family.headHint")}</p>}
          <div className="sm:col-span-2"><SubmitRow loading={loading} onCancel={() => onOpenChange(false)} /></div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

const emptyMember = (houseId) => ({ house_id: houseId || "", name: "", relation: "", dob: "", gender: "", occupation: "", occupation_detail: "", marital_status: "", education: "", blood_group: "", phone: "", status: "" });

export const MemberForm = ({ open, onOpenChange, member, houseId, houses, onSaved }) => {
  const { t } = useLang();
  const [form, setForm] = useState(emptyMember(houseId));
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) setForm(member ? { ...emptyMember(houseId), ...member } : emptyMember(houseId));
  }, [open, member, houseId]);

  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const age = form.dob && ageFrom(form.dob) !== "" ? ageFrom(form.dob) : null;
  const isHead = form.relation === "Self";
  const previewType = isHead ? "head" : form.gender === "male" && age !== null && age >= 18 && form.status === "working" ? "sub" : "family";
  const adultMale = !isHead && form.gender === "male" && age !== null && age >= 18;

  const submit = async (e) => {
    e.preventDefault();
    if (!form.house_id) return toast.error(t("members.selectHouse"));
    if (!form.dob) return toast.error(t("dob.required"));
    setLoading(true);
    try {
      const payload = Object.fromEntries(Object.entries(form).filter(([k]) => k in emptyMember()));
      const { data } = member?.id ? await api.put(`/members/${member.id}`, payload) : await api.post("/members", payload);
      toast.success(t("common.saved"));
      onSaved?.(data);
      onOpenChange(false);
    } catch (err) {
      toast.error(apiError(err, t("common.error")));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid="member-form-dialog">
        <DialogHeader><DialogTitle>{member?.id ? t("members.editMember") : t("members.addMember")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {houses && (
            <SelectField className="sm:col-span-2" label={t("members.house")} value={form.house_id} onChange={set("house_id")} required testId="member-house-select" placeholder={t("members.selectHouse")}
              options={houses.map((h) => ({ value: h.id, label: `${h.house_no} — ${h.head_name}` }))} />
          )}
          <TextField label={t("members.name")} value={form.name} onChange={set("name")} required testId="member-name-input" className="sm:col-span-2" />
          <SelectField label={t("members.relation")} value={form.relation} onChange={set("relation")} required testId="member-relation-select" options={RELATIONS.map((r) => ({ value: r, label: t(`members.relations.${r}`) }))} />
          <SelectField label={t("members.gender")} value={form.gender} onChange={set("gender")} required testId="member-gender-select" options={[{ value: "male", label: t("members.male") }, { value: "female", label: t("members.female") }]} />
          <TextField label={t("members.dob")} type="date" value={form.dob} onChange={set("dob")} required max={todayIso()} testId="member-dob-input" />
          <SelectField label={t("mstatus.label")} value={form.status} onChange={set("status")} testId="member-status-select" options={STATUSES.map((v) => ({ value: v, label: t(`mstatus.${v}`) }))} />
          {form.dob && (
            <div className={`sm:col-span-2 rounded-lg px-3 py-2 text-sm flex flex-wrap items-center gap-2 ${previewType === "sub" ? "bg-[#0d5c3a]/10" : adultMale ? "bg-[#c58b2b]/15" : "bg-accent"}`} data-testid="member-type-preview">
              <b data-testid="member-age-preview">{t("members.preview.age", { age: age ?? "—" })}</b>
              <span>·</span>
              <TypeBadge type={previewType} />
              <span className="text-xs text-muted-foreground w-full">{previewType === "sub" ? t("members.preview.sub") : adultMale && form.status !== "working" ? t("members.preview.subHint") : previewType === "head" ? t("members.preview.head") : age !== null && age < 18 ? t("members.preview.minor") : t("members.preview.family")}</span>
            </div>
          )}
          {form.status !== "student" && <WorkStudyFields prefix="member" occupation={form.occupation} detail={form.occupation_detail} education={form.education} onOcc={set("occupation")} onDetail={set("occupation_detail")} onEdu={set("education")} showEducation={false} />}
          {form.status === "student" && <SelectField label={t("members.educations.label")} value={form.education || ""} onChange={set("education")} testId="member-education-select" className="sm:col-span-2" options={EDUCATIONS.map((v) => ({ value: v, label: t(`members.educations.${v}`) }))} />}
          <SelectField label={t("members.maritalStatus")} value={form.marital_status} onChange={set("marital_status")} testId="member-marital-select" options={["single", "married", "widowed", "divorced"].map((v) => ({ value: v, label: t(`members.${v}`) }))} />
          <SelectField label={t("members.bloodGroup")} value={form.blood_group} onChange={set("blood_group")} testId="member-blood-select" options={BLOOD.map((b) => ({ value: b, label: b }))} />
          <TextField label={t("common.phone")} value={form.phone} onChange={set("phone")} testId="member-phone-input" inputMode="tel" className={previewType === "sub" ? "sm:col-span-2" : ""} />
          {previewType === "sub" && <p className="sm:col-span-2 -mt-2 text-xs text-[#0d5c3a]" data-testid="member-sub-phone-hint">{t("members.preview.subPhone")}</p>}
          <div className="sm:col-span-2"><SubmitRow loading={loading} onCancel={() => onOpenChange(false)} /></div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
