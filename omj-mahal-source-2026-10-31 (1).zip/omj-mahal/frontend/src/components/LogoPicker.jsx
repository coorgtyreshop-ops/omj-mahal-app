import { useRef, useState } from "react";
import { toast } from "sonner";
import { Upload, Check } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { PRESETS, presetLogo, logoSrc } from "@/lib/branding";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const LogoPicker = ({ value, onChange }) => {
  const { t } = useLang();
  const { refreshSettings } = useAuth();
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const customActive = !!value.logo_url;

  const upload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const fd = new FormData(); fd.append("file", file);
    try {
      const { data } = await api.post("/upload/logo", fd, { headers: { "Content-Type": "multipart/form-data" } });
      onChange({ logo_url: data.url, logo_preset: "" });
      await refreshSettings();
      toast.success(t("logo.uploaded"));
    } catch (err) { toast.error(apiError(err)); } finally { setUploading(false); e.target.value = ""; }
  };

  return (
    <div data-testid="logo-picker">
      <p className="text-sm font-medium mb-2">{t("logo.choose")} <span className="text-xs text-muted-foreground font-normal">— {t("logo.hint")}</span></p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {PRESETS.map((p, i) => {
          const active = !customActive && (value.logo_preset || "logo5") === p;
          return (
            <button type="button" key={p} onClick={() => onChange({ logo_preset: p, logo_url: "" })} data-testid={`logo-preset-${p}`}
              className={cn("relative rounded-xl border-2 bg-white p-3 flex flex-col items-center gap-2 transition-colors", active ? "border-primary shadow-md" : "border-border hover:border-primary/40")}>
              {active && <span className="absolute top-2 right-2 grid h-5 w-5 place-items-center rounded-full bg-primary text-white"><Check className="h-3 w-3" /></span>}
              <img src={presetLogo(p)} alt="" className="h-20 w-20 object-contain" />
              <span className="text-xs font-semibold">{t("logo.preset", { n: i + 1 })}</span>
            </button>
          );
        })}
        <button type="button" onClick={() => fileRef.current?.click()} disabled={uploading} data-testid="logo-upload-button"
          className={cn("relative rounded-xl border-2 border-dashed bg-white p-3 flex flex-col items-center justify-center gap-2 transition-colors", customActive ? "border-primary shadow-md" : "border-border hover:border-primary/40")}>
          {customActive && <span className="absolute top-2 right-2 grid h-5 w-5 place-items-center rounded-full bg-primary text-white"><Check className="h-3 w-3" /></span>}
          {customActive ? <img src={logoSrc(value)} alt="" className="h-20 w-20 object-contain" data-testid="logo-custom-preview" /> : <Upload className="h-8 w-8 text-primary" />}
          <span className="text-xs font-semibold text-center">{uploading ? t("logo.uploading") : customActive ? t("logo.custom") : t("logo.upload")}</span>
        </button>
      </div>
      <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml" className="hidden" onChange={upload} data-testid="logo-file-input" />
      {customActive && <Button type="button" variant="link" size="sm" onClick={() => onChange({ logo_preset: "logo5", logo_url: "" })} className="px-0 mt-1 h-auto" data-testid="logo-use-preset">{t("logo.choose")}</Button>}
    </div>
  );
};
