import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  LayoutDashboard, Home, Users, Wallet, HandCoins, Receipt, BarChart3, Megaphone,
  UsersRound, ScrollText, Settings, KeyRound, UserCircle, LogOut, MoreHorizontal, MessageSquare, HelpCircle, CreditCard, Landmark, QrCode, CalendarDays, BookOpen, Images, MessagesSquare, Lightbulb, ScanLine,
} from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { logoSrc, mahalName, appName } from "@/lib/branding";
import { Ticker } from "@/components/Ticker";
import { InstallBanner, OfflineBar } from "@/components/Pwa";
import { NotificationBell } from "@/components/NotificationBell";
import { KannadaKeyboard, KeyboardToggle, useKannadaKeyboard } from "@/components/keyboard/KannadaKeyboard";

const FINANCE_ITEM = { key: "finance", to: "/collections", icon: Landmark };
const SCAN_ITEM = { key: "scan", to: "/scan", icon: ScanLine };

const ADMIN_NAV = [
  { key: "dashboard", to: "/", icon: LayoutDashboard },
  { key: "houses", to: "/houses", icon: Home },
  { key: "members", to: "/members", icon: Users },
  { key: "calendar", to: "/calendar", icon: CalendarDays },
  { key: "posters", to: "/posters", icon: Images },
  { key: "group", to: "/group", icon: MessagesSquare },
  FINANCE_ITEM,
  SCAN_ITEM,
  { key: "accounts", to: "/accounts", icon: BookOpen },
  { key: "subscriptions", to: "/subscriptions", icon: Wallet },
  { key: "donations", to: "/donations", icon: HandCoins },
  { key: "expenses", to: "/expenses", icon: Receipt },
  { key: "reports", to: "/reports", icon: BarChart3 },
  { key: "announcements", to: "/announcements", icon: Megaphone },
  { key: "committee", to: "/committee", icon: UsersRound },
  { key: "certificates", to: "/certificates", icon: ScrollText },
  { key: "messages", to: "/messages", icon: MessageSquare },
  { key: "users", to: "/users", icon: KeyRound },
  { key: "suggestions", to: "/suggestions", icon: Lightbulb },
  { key: "settings", to: "/settings", icon: Settings },
  { key: "help", to: "/help", icon: HelpCircle },
];

const MEMBER_NAV = [
  { key: "dashboard", to: "/", icon: LayoutDashboard },
  { key: "myHouse", to: "/my-house", icon: Home },
  { key: "cards", to: "/cards", icon: CreditCard },
  { key: "pay", to: "/pay", icon: QrCode },
  { key: "calendar", to: "/calendar", icon: CalendarDays },
  { key: "posters", to: "/posters", icon: Images },
  { key: "group", to: "/group", icon: MessagesSquare },
  { key: "accounts", to: "/accounts", icon: BookOpen },
  { key: "subscriptions", to: "/subscriptions", icon: Wallet },
  { key: "donations", to: "/donations", icon: HandCoins },
  { key: "announcements", to: "/announcements", icon: Megaphone },
  { key: "committee", to: "/committee", icon: UsersRound },
  { key: "suggestions", to: "/suggestions", icon: Lightbulb },
  { key: "help", to: "/help", icon: HelpCircle },
];

const BOTTOM_KEYS = { admin: ["dashboard", "houses", "finance", "subscriptions"], member: ["dashboard", "myHouse", "pay", "announcements"] };

const Crest = ({ settings, lang, compact }) => (
  <div className="flex items-center gap-3">
    <div className="h-10 w-10 rounded-full bg-white grid place-items-center shrink-0 overflow-hidden ring-2 ring-[#d4af37]/70">
      <img src={logoSrc(settings)} alt="" className="h-full w-full object-cover" data-testid="app-logo" />
    </div>
    {!compact && (
      <div className="min-w-0">
        <p data-testid="mahal-name" className="font-bold text-white leading-tight truncate">{appName(settings)}</p>
        <p className="text-[11px] text-[#d4af37]/90 truncate">{mahalName(settings, lang)}</p>
      </div>
    )}
  </div>
);

export default function AppShell() {
  const { t, lang } = useLang();
  const { user, logout, settings, isAdmin, canFinance } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [moreOpen, setMoreOpen] = useState(false);
  const kbd = useKannadaKeyboard();
  const ledgerOk = isAdmin || canFinance || (user?.ledger_scope && user.ledger_scope !== "none");
  const nav = (isAdmin ? ADMIN_NAV : canFinance ? [...MEMBER_NAV.slice(0, 5), FINANCE_ITEM, SCAN_ITEM, ...MEMBER_NAV.slice(5)] : MEMBER_NAV).filter((n) => n.key !== "accounts" || ledgerOk);
  const bottom = nav.filter((n) => BOTTOM_KEYS[isAdmin ? "admin" : "member"].includes(n.key));

  const doLogout = async () => {
    await logout();
    navigate("/login");
  };

  const itemCls = (active) =>
    cn(
      "flex items-center gap-3 rounded-lg px-3 py-2.5 text-[15px] font-medium transition-colors",
      active ? "bg-white/15 text-white shadow-[inset_3px_0_0_#d4af37]" : "text-white/75 hover:bg-white/10 hover:text-white"
    );

  return (
    <div className="min-h-screen flex bg-background">
      <aside className="hidden lg:flex flex-col w-[260px] fixed inset-y-0 left-0 islamic-pattern text-white z-30" data-testid="sidebar">
        <div className="px-5 pt-6 pb-4"><Crest settings={settings} lang={lang} /></div>
        <div className="gold-rule mx-5" />
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {nav.map(({ key, to, icon: Icon }) => (
            <NavLink key={key} to={to} end={to === "/"} data-testid={`nav-${key}`} className={({ isActive }) => itemCls(isActive)}>
              <Icon className="h-5 w-5 shrink-0" />
              <span className="truncate">{t(`nav.${key}`)}</span>
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-white/10 space-y-3">
          <NavLink to="/profile" data-testid="nav-profile" className="flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-white/10 transition-colors">
            <UserCircle className="h-9 w-9 text-[#d4af37]" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold truncate" data-testid="sidebar-user-name">{user?.name}</p>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#d4af37]/20 text-[#d4af37] font-semibold uppercase tracking-wide">{t(`role.${user?.role}`)}</span>
            </div>
          </NavLink>
          <button onClick={doLogout} data-testid="logout-button" className="w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-white/80 hover:bg-white/10 hover:text-white text-sm font-medium transition-colors">
            <LogOut className="h-4 w-4" /> {t("logout")}
          </button>
        </div>
      </aside>

      <div className="flex-1 lg:pl-[260px] flex flex-col min-w-0">
        <header className="sticky top-0 z-20 bg-background/85 backdrop-blur-md border-b border-border">
          <OfflineBar />
          <Ticker />
          <div className="flex items-center justify-between gap-3 px-4 sm:px-6 h-16">
            <div className="lg:hidden flex items-center gap-2 min-w-0">
              <Crest settings={settings} lang={lang} compact />
              <div className="min-w-0"><p className="font-bold truncate text-foreground leading-tight" data-testid="mobile-mahal-name">{appName(settings)}</p><p className="text-[11px] text-muted-foreground truncate">{mahalName(settings, lang)}</p></div>
            </div>
            <div className="hidden lg:block text-sm text-muted-foreground">
              {t("dashboard.welcome")}, <span className="font-semibold text-foreground">{user?.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSwitcher />
              <KeyboardToggle open={kbd.open} onToggle={kbd.toggle} />
              <NotificationBell />
              <button onClick={() => navigate("/profile")} data-testid="topbar-profile-button" className="hidden sm:grid h-10 w-10 place-items-center rounded-full bg-primary/10 text-primary hover:bg-primary/15 transition-colors">
                <UserCircle className="h-6 w-6" />
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 pb-24 lg:pb-8 max-w-[1400px] w-full mx-auto">
          <Outlet />
          <KannadaKeyboard open={kbd.open} onClose={kbd.close} />
        </main>
      </div>

      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t border-border shadow-[0_-4px_20px_rgba(13,92,58,0.08)]" data-testid="bottom-nav">
        <div className="grid grid-cols-5">
          {bottom.map(({ key, to, icon: Icon }) => {
            const active = to === "/" ? location.pathname === "/" : location.pathname.startsWith(to);
            return (
              <NavLink key={key} to={to} data-testid={`bottomnav-${key}`} className={cn("flex flex-col items-center justify-center gap-1 min-h-[60px] text-[11px] font-semibold transition-colors", active ? "text-primary" : "text-muted-foreground")}>
                <Icon className={cn("h-5 w-5", active && "scale-110")} />
                <span className="truncate max-w-[70px]">{t(`nav.${key}`)}</span>
              </NavLink>
            );
          })}
          <button onClick={() => setMoreOpen(true)} data-testid="bottomnav-more" className="flex flex-col items-center justify-center gap-1 min-h-[60px] text-[11px] font-semibold text-muted-foreground">
            <MoreHorizontal className="h-5 w-5" />
            <span>{t("nav.more")}</span>
          </button>
        </div>
      </nav>

      <InstallBanner />

      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent side="bottom" className="rounded-t-2xl max-h-[85vh] overflow-y-auto" data-testid="more-sheet">
          <SheetHeader><SheetTitle>{t("nav.more")}</SheetTitle></SheetHeader>
          <div className="grid grid-cols-3 gap-3 py-4">
            {[...nav, { key: "profile", to: "/profile", icon: UserCircle }].map(({ key, to, icon: Icon }) => (
              <NavLink key={key} to={to} onClick={() => setMoreOpen(false)} data-testid={`more-nav-${key}`} className="flex flex-col items-center gap-2 rounded-xl border border-border bg-card p-4 text-center text-xs font-semibold hover:border-primary/40 hover:bg-accent transition-colors min-h-[84px]">
                <Icon className="h-6 w-6 text-primary" />
                <span className="leading-tight">{t(`nav.${key}`)}</span>
              </NavLink>
            ))}
            <button onClick={doLogout} data-testid="more-logout-button" className="flex flex-col items-center gap-2 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-center text-xs font-semibold text-destructive min-h-[84px]">
              <LogOut className="h-6 w-6" /> {t("logout")}
            </button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
