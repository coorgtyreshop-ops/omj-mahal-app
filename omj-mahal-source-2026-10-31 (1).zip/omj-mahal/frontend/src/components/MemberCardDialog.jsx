import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { toast } from "sonner";
import { toPng } from "html-to-image";
import { Download, Share2, Printer, Camera, Trash2 } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { MemberCard, CardPlaceholder, verifyUrl } from "@/components/MemberCard";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

const resizeImage = (file, max = 600) => new Promise((resolve) => {
  const img = new Image();
  const url = URL.createObjectURL(file);
  img.onload = () => {
    const scale = Math.min(1, max / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    URL.revokeObjectURL(url);
    c.toBlob((b) => resolve(b), "image/jpeg", 0.86);
  };
  img.src = url;
});

export const MemberCardDialog = ({ memberId, open, onOpenChange, canEditPhoto, onChanged }) => {
  const { t } = useLang();
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState("");
  const cardRef = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => {
    if (!open || !memberId) return;
    setData(null);
    api.get(`/members/${memberId}/card`).then((r) => setData(r.data)).catch((e) => { toast.error(apiError(e)); onOpenChange(false); });
  }, [open, memberId, onOpenChange]);

  const render = async () => toPng(cardRef.current, { pixelRatio: 3, cacheBust: true, backgroundColor: "#fbf7ee" });

  const download = async () => {
    setBusy("download");
    try {
      const png = await render();
      const a = document.createElement("a"); a.href = png; a.download = `${data.member.member_no}.png`; a.click();
      toast.success(t("card.downloaded"));
    } catch (e) { toast.error(apiError(e)); } finally { setBusy(""); }
  };

  const share = async () => {
    setBusy("share");
    const link = verifyUrl(data.settings, data.member.member_no);
    const text = `${data.settings.short_name || data.settings.mahal_name} - ${t("card.title")}: ${data.member.name} (${data.member.member_no})\n${link}`;
    try {
      const png = await render();
      const blob = await (await fetch(png)).blob();
      const file = new File([blob], `${data.member.member_no}.png`, { type: "image/png" });
      if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], text }); }
      else window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener");
    } catch (e) { if (e?.name !== "AbortError") toast.error(apiError(e)); } finally { setBusy(""); }
  };

  const upload = async (file) => {
    if (!file) return;
    setBusy("photo");
    try {
      const blob = await resizeImage(file);
      const fd = new FormData(); fd.append("file", blob, "photo.jpg");
      const { data: m } = await api.post(`/members/${memberId}/photo`, fd);
      setData((d) => ({ ...d, member: m })); toast.success(t("card.uploaded")); onChanged?.();
    } catch (e) { toast.error(apiError(e)); } finally { setBusy(""); if (fileRef.current) fileRef.current.value = ""; }
  };

  const removePhoto = async () => {
    setBusy("photo");
    try { const { data: m } = await api.delete(`/members/${memberId}/photo`); setData((d) => ({ ...d, member: m })); onChanged?.(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(""); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid="member-card-dialog">
        <DialogHeader><DialogTitle>{t("card.title")}</DialogTitle></DialogHeader>
        <div className="flex justify-center py-2 overflow-x-auto">{data ? <MemberCard data={data} cardRef={cardRef} /> : <CardPlaceholder />}</div>
        {data && (
          <>
            <p className="text-xs text-muted-foreground text-center">{t("card.hint")}</p>
            <div className="grid grid-cols-3 gap-2">
              <Button onClick={download} disabled={!!busy} className="h-11" data-testid="card-download-button"><Download className="h-4 w-4 mr-1" />{t("card.download")}</Button>
              <Button variant="outline" onClick={share} disabled={!!busy} className="h-11" data-testid="card-share-button"><Share2 className="h-4 w-4 mr-1" />{t("card.share")}</Button>
              <Button variant="outline" onClick={() => window.print()} className="h-11" data-testid="card-print-button"><Printer className="h-4 w-4 mr-1" />{t("card.print")}</Button>
            </div>
            {canEditPhoto && (
              <div className="flex gap-2 justify-center">
                <input ref={fileRef} type="file" accept="image/*" capture="user" className="hidden" onChange={(e) => upload(e.target.files?.[0])} data-testid="card-photo-input" />
                <Button variant="secondary" size="sm" onClick={() => fileRef.current?.click()} disabled={busy === "photo"} className="h-10" data-testid="card-photo-button"><Camera className="h-4 w-4 mr-1" />{busy === "photo" ? t("card.uploading") : data.member.photo_url ? t("card.changePhoto") : t("card.photo")}</Button>
                {data.member.photo_url && <Button variant="ghost" size="sm" onClick={removePhoto} disabled={busy === "photo"} className="h-10 text-destructive" data-testid="card-photo-remove"><Trash2 className="h-4 w-4 mr-1" />{t("card.removePhoto")}</Button>}
              </div>
            )}
          </>
        )}
      </DialogContent>
      {open && data && createPortal(<div className="print-area p-8 flex justify-center"><MemberCard data={data} testId="member-card-print" /></div>, document.body)}
    </Dialog>
  );
};
