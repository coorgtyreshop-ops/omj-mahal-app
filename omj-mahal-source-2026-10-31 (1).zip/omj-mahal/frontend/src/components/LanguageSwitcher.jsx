import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { LANGS } from "@/i18n/translations";
import { cn } from "@/lib/utils";

const LABEL = { en: "EN", ml: "മ", kn: "ಕ" };

export const LanguageSwitcher = ({ dark = false, className }) => {
  const { lang, setLang, t } = useLang();
  const { user } = useAuth();

  const choose = (l) => {
    setLang(l);
    localStorage.setItem("mahal_lang_manual", "1");
    if (user) api.patch("/auth/language", { language: l }).catch(() => {});
  };

  return (
    <div
      data-testid="language-switcher"
      className={cn(
        "inline-flex rounded-full p-1 gap-0.5",
        dark ? "bg-white/10 border border-white/15" : "bg-muted border border-border",
        className
      )}
    >
      {LANGS.map((l) => (
        <button
          key={l}
          type="button"
          data-testid={`language-switcher-${l}`}
          onClick={() => choose(l)}
          title={t(`lang.${l}`)}
          className={cn(
            "min-w-[40px] h-9 px-3 rounded-full text-sm font-semibold transition-colors",
            lang === l
              ? dark ? "bg-[#d4af37] text-[#1e2923]" : "bg-primary text-primary-foreground"
              : dark ? "text-white/80 hover:bg-white/10" : "text-muted-foreground hover:bg-background"
          )}
        >
          {LABEL[l]}
        </button>
      ))}
    </div>
  );
};
