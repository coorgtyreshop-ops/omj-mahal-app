import { useEffect, useState } from "react";
import { Bell, Receipt, Wallet, Megaphone, CalendarDays, KeyRound, MessageSquare } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const ICONS = { receipt: Receipt, pay_request: Wallet, pay_rejected: Wallet, dues_reminder: Wallet, auto_reminder: Wallet, announcement: Megaphone, event: CalendarDays, credentials: KeyRound };
const SEEN_KEY = "omj_notif_seen";

export const NotificationBell = () => {
  const { t } = useLang();
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [seenAt, setSeenAt] = useState(() => localStorage.getItem(SEEN_KEY) || "");

  useEffect(() => {
    if (!user?.house_id) return;
    const load = () => api.get("/notifications/mine").then((r) => setItems(r.data)).catch(() => {});
    load();
    const id = setInterval(load, 60000);
    return () => clearInterval(id);
  }, [user?.house_id]);

  if (!user?.house_id) return null;
  const unread = items.filter((n) => n.created_at > seenAt).length;
  const onOpen = (o) => { setOpen(o); if (o && items[0]) { localStorage.setItem(SEEN_KEY, items[0].created_at); setSeenAt(items[0].created_at); } };
  const when = (iso) => { const d = new Date(iso); return `${d.toLocaleDateString("en-IN", { day: "2-digit", month: "short" })} ${d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}`; };

  return (
    <Popover open={open} onOpenChange={onOpen}>
      <PopoverTrigger asChild>
        <button className="relative grid h-10 w-10 place-items-center rounded-full bg-primary/10 text-primary hover:bg-primary/15 transition-colors" data-testid="notification-bell">
          <Bell className="h-5 w-5" />
          {unread > 0 && <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-[#c58b2b] text-white text-[10px] font-bold grid place-items-center px-1" data-testid="notification-unread-count">{unread}</span>}
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[340px] sm:w-[400px] p-0 max-h-[70vh] overflow-y-auto" data-testid="notification-panel">
        <div className="px-4 py-3 border-b font-semibold flex items-center gap-2"><MessageSquare className="h-4 w-4 text-primary" />{t("notifBell.title")}</div>
        {items.length === 0 ? <p className="p-4 text-sm text-muted-foreground" data-testid="notification-empty">{t("notifBell.empty")}</p> : (
          <ul className="divide-y">
            {items.map((n) => { const Icon = ICONS[n.kind] || MessageSquare; const fresh = n.created_at > seenAt; return (
              <li key={n.id} className={cn("flex gap-3 px-4 py-3", fresh && "bg-[#d4af37]/10")} data-testid={`notification-item-${n.id}`}>
                <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary/10 text-primary"><Icon className="h-4 w-4" /></span>
                <div className="min-w-0"><p className="text-sm whitespace-pre-wrap leading-snug">{n.body}</p><p className="text-[11px] text-muted-foreground mt-1">{when(n.created_at)} · {t(`notifBell.kinds.${n.kind}`) || n.kind}</p></div>
              </li>
            ); })}
          </ul>
        )}
      </PopoverContent>
    </Popover>
  );
};
