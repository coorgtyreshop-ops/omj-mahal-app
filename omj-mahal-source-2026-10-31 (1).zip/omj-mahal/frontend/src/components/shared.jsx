import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLang } from "@/context/LanguageContext";
import { cn } from "@/lib/utils";
import { Inbox } from "lucide-react";

export const PageHeader = ({ title, subtitle, actions, testId }) => (
  <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-6" data-testid={testId}>
    <div>
      <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">{title}</h1>
      {subtitle && <p className="text-muted-foreground mt-1 text-sm sm:text-base">{subtitle}</p>}
    </div>
    {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
  </div>
);

export const StatCard = ({ label, value, icon: Icon, hint, tone = "emerald", testId, delay = 0 }) => {
  const tones = {
    emerald: "bg-primary/10 text-primary",
    gold: "bg-[#d4af37]/20 text-[#8a6d1d]",
    amber: "bg-[#c58b2b]/15 text-[#c58b2b]",
    red: "bg-destructive/10 text-destructive",
  };
  return (
    <div className="stat-in rounded-xl border border-[#e6dbc9] bg-card p-4 sm:p-5 shadow-sm hover:shadow-md transition-shadow" style={{ animationDelay: `${delay}ms` }} data-testid={testId}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs sm:text-sm font-medium text-muted-foreground leading-snug">{label}</p>
        {Icon && <span className={cn("grid h-9 w-9 place-items-center rounded-lg shrink-0", tones[tone])}><Icon className="h-5 w-5" /></span>}
      </div>
      <p className="mt-2 text-2xl sm:text-3xl font-bold tracking-tight text-foreground" data-testid={testId ? `${testId}-value` : undefined}>{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
};

export const EmptyState = ({ text, testId }) => (
  <div className="flex flex-col items-center justify-center gap-3 py-14 text-center text-muted-foreground" data-testid={testId || "empty-state"}>
    <span className="grid h-14 w-14 place-items-center rounded-full bg-accent"><Inbox className="h-7 w-7 text-primary/60" /></span>
    <p className="text-sm">{text}</p>
  </div>
);

export const Field = ({ label, children, className, required }) => (
  <div className={cn("space-y-1.5", className)}>
    <Label className="text-sm font-medium">{label}{required && <span className="text-destructive"> *</span>}</Label>
    {children}
  </div>
);

export const TextField = ({ label, value, onChange, type = "text", required, testId, placeholder, className, ...rest }) => (
  <Field label={label} required={required} className={className}>
    <Input type={type} value={value ?? ""} onChange={(e) => onChange(e.target.value)} required={required} placeholder={placeholder} data-testid={testId} className="h-11" {...rest} />
  </Field>
);

export const SelectField = ({ label, value, onChange, options, placeholder, required, testId, className }) => (
  <Field label={label} required={required} className={className}>
    <Select value={value || undefined} onValueChange={onChange}>
      <SelectTrigger className="h-11" data-testid={testId}><SelectValue placeholder={placeholder || "—"} /></SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value} data-testid={testId ? `${testId}-option-${o.value}` : undefined}>{o.label}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  </Field>
);

export const ConfirmDelete = ({ open, onOpenChange, onConfirm, loading }) => {
  const { t } = useLang();
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent data-testid="confirm-delete-dialog">
        <AlertDialogHeader>
          <AlertDialogTitle>{t("common.confirmDelete")}</AlertDialogTitle>
          <AlertDialogDescription>{t("common.confirmDeleteDesc")}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel data-testid="confirm-delete-cancel">{t("common.cancel")}</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} disabled={loading} className="bg-destructive hover:bg-destructive/90" data-testid="confirm-delete-confirm">{t("common.delete")}</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export const SubmitRow = ({ loading, onCancel, label }) => {
  const { t } = useLang();
  return (
    <div className="flex justify-end gap-2 pt-2">
      {onCancel && <Button type="button" variant="outline" onClick={onCancel} className="h-11" data-testid="form-cancel-button">{t("common.cancel")}</Button>}
      <Button type="submit" disabled={loading} className="h-11 min-w-[120px]" data-testid="form-submit-button">{loading ? t("common.saving") : label || t("common.save")}</Button>
    </div>
  );
};

export const StatusBadge = ({ ok, children }) => (
  <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold", ok ? "bg-primary/10 text-primary" : "bg-[#c58b2b]/15 text-[#a06f1c]")}>{children}</span>
);
