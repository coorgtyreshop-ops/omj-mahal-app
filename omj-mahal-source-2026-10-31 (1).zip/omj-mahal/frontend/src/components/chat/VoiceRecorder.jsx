import { useEffect, useRef, useState } from "react";
import { Mic, Square, X, Send } from "lucide-react";
import { toast } from "sonner";
import { useLang } from "@/context/LanguageContext";
import { cn } from "@/lib/utils";

const pickMime = () => ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus", "audio/ogg"].find((m) => window.MediaRecorder?.isTypeSupported?.(m)) || "";
const extFor = (mime) => (mime.includes("mp4") ? "m4a" : mime.includes("ogg") ? "ogg" : "webm");
export const fmtDur = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

export const VoiceRecorder = ({ onSend, disabled }) => {
  const { t } = useLang();
  const [rec, setRec] = useState(null);
  const [secs, setSecs] = useState(0);
  const [busy, setBusy] = useState(false);
  const chunks = useRef([]);
  const timer = useRef(null);
  const cancelled = useRef(false);
  const secsRef = useRef(0);
  useEffect(() => { secsRef.current = secs; }, [secs]);

  useEffect(() => () => { clearInterval(timer.current); rec?.stream?.getTracks().forEach((tr) => tr.stop()); }, [rec]);

  const start = async () => {
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) { toast.error(t("chat.noMic")); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mime = pickMime();
      const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      chunks.current = []; cancelled.current = false;
      mr.ondataavailable = (e) => { if (e.data.size) chunks.current.push(e.data); };
      mr.onstop = async () => {
        stream.getTracks().forEach((tr) => tr.stop());
        clearInterval(timer.current);
        const dur = secsRef.current;
        setRec(null); setSecs(0);
        if (cancelled.current || dur < 1) return;
        const type = mr.mimeType || mime || "audio/webm";
        const blob = new Blob(chunks.current, { type });
        setBusy(true);
        try { await onSend(new File([blob], `voice.${extFor(type)}`, { type }), dur); } finally { setBusy(false); }
      };
      mr.start(250);
      setRec(mr); setSecs(0);
      timer.current = setInterval(() => setSecs((s) => { const n = s + 1; if (n >= 120) mr.stop(); return n; }), 1000);
    } catch { toast.error(t("chat.micDenied")); }
  };
  const stop = () => rec?.state !== "inactive" && rec?.stop();
  const cancel = () => { cancelled.current = true; stop(); };

  if (rec) {
    return (
      <div className="flex items-center gap-2 flex-1 rounded-full bg-red-50 border border-red-200 px-3 h-12" data-testid="voice-recording">
        <span className="h-3 w-3 rounded-full bg-red-600 animate-pulse" />
        <span className="font-mono text-sm text-red-700 flex-1" data-testid="voice-timer">{fmtDur(secs)} · {t("chat.recording")}</span>
        <button type="button" onClick={cancel} className="grid h-9 w-9 place-items-center rounded-full hover:bg-red-100 text-red-700" data-testid="voice-cancel-button" aria-label={t("common.cancel")}><X className="h-5 w-5" /></button>
        <button type="button" onClick={stop} className="grid h-9 w-9 place-items-center rounded-full bg-primary text-white hover:bg-primary/90" data-testid="voice-send-button" aria-label={t("chat.sendVoice")}><Send className="h-4 w-4" /></button>
      </div>
    );
  }
  return (
    <button type="button" onClick={start} disabled={disabled || busy} className={cn("grid h-12 w-12 shrink-0 place-items-center rounded-full bg-[#d4af37] text-[#1e2923] hover:bg-[#e2c053] disabled:opacity-50", busy && "animate-pulse")} data-testid="voice-record-button" aria-label={t("chat.record")}>
      {busy ? <Square className="h-4 w-4" /> : <Mic className="h-5 w-5" />}
    </button>
  );
};
