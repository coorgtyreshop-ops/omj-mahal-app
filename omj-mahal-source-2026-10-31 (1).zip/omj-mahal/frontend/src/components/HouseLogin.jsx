import { useState } from "react";
import { openChatLink } from "@/lib/whatsapp";
import { toast } from "sonner";
import { KeyRound, Send, Copy, Check, Wand2, ShieldCheck, UserPlus } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import { TextField, SubmitRow, Field } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

export const CredentialsBox = ({ phone, loginId, password, onSend, sending, sent }) => {
  const { t } = useLang();
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(`${loginId ? `${t("loginId")}: ${loginId}\n` : ""}${t("phone")}: ${phone}\n${t("password")}: ${password}`); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch {}
  };
  return (
    <div className="rounded-xl border-2 border-dashed border-[#d4af37] bg-[#d4af37]/10 p-4" data-testid="credentials-box">
      <p className="text-xs font-bold uppercase tracking-wide text-[#8a6d1d] mb-2">{t("hlogin.credentials")}</p>
      <div className="grid grid-cols-2 gap-3">
        {loginId && <div className="col-span-2"><p className="text-xs text-muted-foreground">{t("hlogin.idLabel")}</p><p className="font-mono text-2xl font-bold tracking-wider text-[#8a6d1d]" data-testid="cred-login-id">{loginId}</p><p className="text-xs text-muted-foreground">{t("hlogin.idHint")}</p></div>}
        <div><p className="text-xs text-muted-foreground">{t("phone")}</p><p className="font-mono text-lg font-bold" data-testid="cred-phone">{phone}</p></div>
        <div><p className="text-xs text-muted-foreground">{t("password")}</p><p className="font-mono text-lg font-bold tracking-wider text-primary" data-testid="cred-password">{password}</p></div>
      </div>
      <p className="text-xs text-muted-foreground mt-2">{t("hlogin.shareHint")}</p>
      <div className="flex flex-wrap gap-2 mt-3">
        <Button size="sm" variant="outline" onClick={copy} className="h-9 bg-white" data-testid="cred-copy-button">{copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}{copied ? t("hlogin.copied") : t("hlogin.copy")}</Button>
        {onSend && <Button size="sm" onClick={onSend} disabled={sending || sent} className="h-9 bg-[#128C7E] hover:bg-[#0f7a6d]" data-testid="cred-send-whatsapp-button"><Send className="h-4 w-4 mr-1" />{sent ? t("hlogin.sent") : t("hlogin.sendWhatsapp")}</Button>}
      </div>
    </div>
  );
};

const LoginDialog = ({ open, onOpenChange, house, mode, onDone }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [phone, setPhone] = useState(house.login?.phone || house.phone || "");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const gen = () => setPassword(String(Math.floor(100000 + Math.random() * 900000)));
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const url = mode === "create" ? `/houses/${house.id}/login` : `/houses/${house.id}/login/reset`;
      const { data } = await api.post(url, { phone: mode === "create" ? phone : undefined, password: password || undefined, app_url: settings?.app_url || window.location.origin });
      setResult(data); toast.success(mode === "create" ? t("hlogin.created") : t("hlogin.resetDone")); onDone?.();
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  const send = async () => {
    setSending(true);
    try { await api.post(`/houses/${house.id}/login/send`, { password: result.password, app_url: settings?.app_url || window.location.origin }); setSent(true); toast.success(t("hlogin.sent")); }
    catch (err) { toast.error(apiError(err)); } finally { setSending(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="login-dialog">
        <DialogHeader><DialogTitle>{mode === "create" ? t("hlogin.create") : t("hlogin.reset")} — {house.house_no}</DialogTitle></DialogHeader>
        {result ? (
          <div className="space-y-4">
            <CredentialsBox phone={result.phone} loginId={result.login_id} password={result.password} onSend={send} sending={sending} sent={sent} />
            <div className="flex justify-end"><Button onClick={() => onOpenChange(false)} className="h-11" data-testid="login-dialog-close">{t("common.close")}</Button></div>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            {mode === "create" ? <TextField label={t("hlogin.phoneLabel")} value={phone} onChange={setPhone} required inputMode="tel" testId="login-phone-field" /> : <p className="text-sm">{t("hlogin.phoneLabel")}: <b className="font-mono">{house.login?.phone}</b></p>}
            <Field label={t("hlogin.passwordLabel")}>
              <div className="flex gap-2">
                <Input value={password} onChange={(e) => setPassword(e.target.value)} className="h-11 font-mono" placeholder={t("hlogin.autoHint")} data-testid="login-password-field" />
                <Button type="button" variant="outline" onClick={gen} className="h-11" data-testid="login-auto-password"><Wand2 className="h-4 w-4 mr-1" />{t("hlogin.auto")}</Button>
              </div>
            </Field>
            <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} label={mode === "create" ? t("hlogin.create") : t("hlogin.reset")} />
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};

export const HouseLoginCard = ({ house, onChanged }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [dialog, setDialog] = useState(null);
  const [sendingId, setSendingId] = useState(false);
  const login = house.login;
  const sendId = async () => {
    setSendingId(true);
    try {
      const { data } = await api.post(`/houses/${house.id}/login/send-id`, { app_url: settings?.app_url || window.location.origin });
      toast.success(t("hlogin.idSent"));
      if (data.wa_link && data.status !== "sent") openChatLink(data.wa_link, t("outbox.tapOpen"));
    } catch (err) { toast.error(apiError(err)); } finally { setSendingId(false); }
  };
  return (
    <section className="rounded-xl border border-[#e6dbc9] bg-card p-5 shadow-sm" data-testid="house-login-card">
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-full ${login ? "bg-primary/10 text-primary" : "bg-[#c58b2b]/15 text-[#a06f1c]"}`}>{login ? <ShieldCheck className="h-6 w-6" /> : <KeyRound className="h-6 w-6" />}</span>
        <div className="flex-1 min-w-0">
          <h3 className="font-bold">{t("hlogin.title")}</h3>
          {login ? (
            <p className="text-sm text-muted-foreground" data-testid="house-login-status">{t("hlogin.exists")} · {t("loginId")}: <span className="font-mono font-bold text-[#8a6d1d] tracking-wider" data-testid="house-login-id">{login.login_id}</span> · <span className="font-mono font-semibold text-foreground">{login.phone}</span> · {t("hlogin.lastLogin")} {fmtDate(login.created_at)}</p>
          ) : (
            <p className="text-sm text-muted-foreground" data-testid="house-login-status">{t("hlogin.none")}</p>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          {login ? (
            <>
              <Button onClick={sendId} disabled={sendingId} className="h-11 bg-[#128C7E] hover:bg-[#0f7a6d]" data-testid="send-id-button"><Send className="h-4 w-4 mr-2" />{t("hlogin.sendId")}</Button>
              <Button variant="outline" onClick={() => setDialog("reset")} className="h-11" data-testid="reset-login-button"><KeyRound className="h-4 w-4 mr-2" />{t("hlogin.reset")}</Button>
            </>
          ) : (
            <Button onClick={() => setDialog("create")} className="h-11" disabled={!house.phone} data-testid="create-login-button"><UserPlus className="h-4 w-4 mr-2" />{t("hlogin.create")}</Button>
          )}
        </div>
      </div>
      {dialog && <LoginDialog open onOpenChange={(o) => !o && setDialog(null)} house={house} mode={dialog} onDone={onChanged} />}
    </section>
  );
};
