import { useLang } from "@/context/LanguageContext";
import { fmtDate, inr, monthLabel } from "@/lib/format";
import { MahalHead } from "@/components/print/Printables";

const Table = ({ title, rows, total, partyLabel, t }) => (
  <div className="mb-4">
    <h4 className="font-bold text-[#0d5c3a] border-b border-[#d4af37] mb-1">{title}</h4>
    <table className="w-full text-sm border-collapse">
      <thead><tr className="text-left bg-[#faf8f5]"><th className="p-1.5 border">{t("common.date")}</th><th className="p-1.5 border">{t("ledger.category")}</th><th className="p-1.5 border">{partyLabel}</th><th className="p-1.5 border">{t("ledger.qty")}</th><th className="p-1.5 border text-right">{t("ledger.amount")}</th></tr></thead>
      <tbody>
        {rows.map((e) => (
          <tr key={e.id}><td className="p-1.5 border">{fmtDate(e.date)}</td><td className="p-1.5 border">{t(`ledger.${e.kind === "income" ? "incomeCats" : "expenseCats"}.${e.category}`)}</td><td className="p-1.5 border">{e.party}{e.note ? <span className="text-gray-500"> — {e.note}</span> : ""}</td><td className="p-1.5 border">{e.qty ? `${e.qty} ${e.unit}` : ""}</td><td className="p-1.5 border text-right font-mono">{e.amount ? inr(e.amount) : "—"}</td></tr>
        ))}
        <tr className="font-bold bg-[#faf8f5]"><td colSpan={4} className="p-1.5 border text-right">{t("common.total")}</td><td className="p-1.5 border text-right font-mono">{inr(total)}</td></tr>
      </tbody>
    </table>
  </div>
);

export const BookStatement = ({ book, settings }) => {
  const { t, lang, months } = useLang();
  const s = book.summary;
  const income = book.entries.filter((e) => e.kind === "income");
  const expense = book.entries.filter((e) => e.kind === "expense");
  const when = book.month ? monthLabel(book.month, months) : fmtDate(book.date);
  return (
    <div className="bg-white text-black p-4" data-testid="book-statement">
      <MahalHead settings={settings} lang={lang} />
      <p className="text-center text-xs uppercase tracking-widest text-gray-600">{t(`ledger.${book.committee}`)}</p>
      <h3 className="text-center text-xl font-bold mt-1">{lang === "ml" && book.name_ml ? book.name_ml : book.name}</h3>
      <p className="text-center text-sm text-gray-700 mb-4">{t("ledger.statement")} · {when}</p>
      <div className="grid grid-cols-3 gap-3 mb-4 text-center">
        <div className="border rounded p-2"><p className="text-xs text-gray-600">{t("ledger.income")}</p><p className="font-bold text-[#0d5c3a]">{inr(s.income)}</p></div>
        <div className="border rounded p-2"><p className="text-xs text-gray-600">{t("ledger.expense")}</p><p className="font-bold text-red-700">{inr(s.expense)}</p></div>
        <div className="border rounded p-2"><p className="text-xs text-gray-600">{t("ledger.balance")}</p><p className="font-bold">{inr(s.balance)}</p></div>
      </div>
      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
        <div><p className="font-semibold mb-1">{t("ledger.income")} — {t("ledger.byCategory")}</p>{Object.entries(s.income_by).filter(([, v]) => v).map(([k, v]) => <p key={k} className="flex justify-between"><span>{t(`ledger.incomeCats.${k}`)}</span><span className="font-mono">{inr(v)}</span></p>)}</div>
        <div><p className="font-semibold mb-1">{t("ledger.expense")} — {t("ledger.byCategory")}</p>{Object.entries(s.expense_by).filter(([, v]) => v).map(([k, v]) => <p key={k} className="flex justify-between"><span>{t(`ledger.expenseCats.${k}`)}</span><span className="font-mono">{inr(v)}</span></p>)}</div>
      </div>
      {income.length > 0 && <Table title={t("ledger.income")} rows={income} total={s.income} partyLabel={t("ledger.donor")} t={t} />}
      {expense.length > 0 && <Table title={t("ledger.expense")} rows={expense} total={s.expense} partyLabel={t("ledger.payee")} t={t} />}
      <div className="flex justify-between mt-10 text-sm"><span>{t("fin.treasurer")}: ____________________</span><span>{t("certs.president")}: ____________________</span></div>
    </div>
  );
};
