import { createPortal } from "react-dom";
import { Printer } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useLang } from "@/context/LanguageContext";
import { fmtDate, inr, monthLabel, fill } from "@/lib/format";
import { logoSrc } from "@/lib/branding";

const mahalName = (s, lang) => (lang === "ml" && s?.mahal_name_ml) || (lang === "kn" && s?.mahal_name_kn) || s?.mahal_name || "";

export const MahalHead = ({ settings, lang }) => (
  <div className="text-center border-b-2 border-[#d4af37] pb-3 mb-4">
    <img src={logoSrc(settings)} alt="" className="h-16 w-16 rounded-full mx-auto mb-2 object-cover" />
    <h2 className="text-xl font-bold text-[#0d5c3a]">{mahalName(settings, lang)}</h2>
    {settings?.mahal_name && lang !== "en" && <p className="text-sm text-[#0d5c3a]/80">{settings.mahal_name}</p>}
    {settings?.address && <p className="text-xs text-gray-600">{settings.address}</p>}
    <p className="text-xs text-gray-600">
      {settings?.phone && <span>Ph: {settings.phone} </span>}
      {settings?.registration_no && <span>| Reg. No: {settings.registration_no}</span>}
    </p>
  </div>
);

export const ReceiptBody = ({ payment, kind = "subscription", settings }) => {
  const { t, months, lang } = useLang();
  return (
    <div className="border-2 border-[#0d5c3a] rounded-lg p-5 bg-white text-[#1e2923] max-w-[520px] mx-auto" style={{ fontFamily: "inherit" }}>
      <MahalHead settings={settings} lang={lang} />
      <div className="flex justify-between text-sm mb-4">
        <span><b>{t("common.receiptNo")}:</b> <span data-testid="receipt-no">{payment.receipt_no}</span></span>
        <span><b>{t("common.date")}:</b> {fmtDate(payment.date)}</span>
      </div>
      <p className="text-center uppercase tracking-[0.2em] text-xs text-[#8a6d1d] font-bold mb-3">
        {kind === "subscription" ? t("subs.receipt") : t("donations.donationFor")}
      </p>
      <div className="space-y-2 text-sm">
        <p>{t("subs.receivedFrom")}: <b>{kind === "subscription" ? payment.head_name : payment.donor_name}</b>{payment.house_no && <> ({t("houses.houseNo")} <b>{payment.house_no}</b>)</>}</p>
        {kind === "subscription" ? (
          payment.type && payment.type !== "varisankhya"
            ? <p>{t("fin.type")}: <b>{t(`fin.types.${payment.type}`)}</b>{payment.years?.length > 0 && <> · {t("fin.periods")}: <b>{payment.years.join(", ")}</b></>}</p>
            : <p>{t("subs.forMonths")}: <b>{(payment.months || []).map((m) => monthLabel(m, months, true)).join(", ")}</b></p>
        ) : (
          <p>{t("donations.fund")}: <b>{payment.fund_name}</b></p>
        )}
        <p>{t("common.mode")}: <b>{t(`paymentModes.${payment.mode}`)}</b></p>
        {payment.note && <p>{t("common.note")}: {payment.note}</p>}
      </div>
      <div className="mt-4 flex items-center justify-between rounded-md bg-[#faf8f5] border border-[#e6dbc9] px-4 py-3">
        <span className="font-semibold">{t("common.amount")}</span>
        <span className="text-2xl font-bold text-[#0d5c3a]" data-testid="receipt-amount">{inr(payment.amount)}</span>
      </div>
      {kind === "subscription" && payment.balance_after && (
        <div className="mt-2 rounded-md border border-[#e6dbc9] px-4 py-2 text-sm" data-testid="receipt-balance">
          <div className="flex justify-between"><span>{t(`fin.types.${payment.type || "varisankhya"}`)} — {t("fin.due")}</span><b>{inr(payment.balance_after.head_due)}</b></div>
          <div className="flex justify-between"><span>{t("fin.paid")} ({t("fin.receipt.soFar")})</span><b>{inr(payment.balance_after.head_paid)}</b></div>
          <div className="flex justify-between border-t mt-1 pt-1"><span className="font-semibold">{t("fin.pending")}</span><b className={payment.balance_after.head_pending > 0 ? "text-[#a06f1c]" : "text-[#0d5c3a]"} data-testid="receipt-head-pending">{payment.balance_after.head_pending > 0 ? inr(payment.balance_after.head_pending) : t("fin.receipt.cleared")}</b></div>
          {payment.balance_after.breakdown && Object.keys(payment.balance_after.breakdown).length > 0 && (
            <div className="mt-2 border-t pt-1 text-xs" data-testid="receipt-breakdown">
              <p className="font-semibold text-gray-700">{t("fin.receipt.breakdown")}</p>
              {Object.entries(payment.balance_after.breakdown).map(([k, v]) => <div key={k} className="flex justify-between"><span>• {t(`fin.types.${k}`)}</span><span className="text-[#a06f1c]">{inr(v)}</span></div>)}
            </div>
          )}
          <div className="flex justify-between text-sm font-semibold mt-1 border-t pt-1"><span>{t("fin.receipt.totalPending")}</span><span className="text-[#a06f1c]" data-testid="receipt-total-pending">{inr(payment.balance_after.total_pending)}</span></div>
        </div>
      )}
      <div className="mt-8 flex items-end justify-between text-xs text-gray-600">
        <span>{t("subs.thankYou")}</span>
        <div className="text-center">
          <div className="w-40 border-t border-gray-500 pt-1">{t("subs.signature")}</div>
          {payment.created_by && <span>{t("subs.receivedBy")}: {payment.created_by}</span>}
        </div>
      </div>
      <p className="mt-3 text-[10px] text-gray-400 text-center">{t("subs.computerReceipt")}</p>
    </div>
  );
};

export const CertificateBody = ({ cert, settings }) => {
  const { t, lang } = useLang();
  const text = fill(t(`certs.text.${cert.type}`), cert.data);
  return (
    <div className="relative border-[6px] border-double border-[#d4af37] p-8 bg-white text-[#1e2923] max-w-[760px] mx-auto min-h-[520px]">
      <div className="absolute inset-2 border border-[#0d5c3a]/40 pointer-events-none" />
      <MahalHead settings={settings} lang={lang} />
      <h3 className="text-center text-2xl font-bold text-[#0d5c3a] uppercase tracking-wide mb-1">{t(`certs.types.${cert.type}`)}</h3>
      <div className="flex justify-between text-xs text-gray-600 mb-6">
        <span>{t("certs.certNo")}: <b data-testid="cert-no">{cert.cert_no}</b></span>
        <span>{t("certs.issuedOn")}: <b>{fmtDate(cert.issued_on)}</b></span>
      </div>
      <p className="text-[15px] leading-8 text-justify" data-testid="cert-text">{text}</p>
      <div className="mt-14 grid grid-cols-3 gap-4 text-center text-sm">
        <div><div className="border-t border-gray-500 pt-2"><b>{settings?.president_name || ""}</b><br />{t("certs.president")}</div></div>
        <div className="grid place-items-center"><div className="h-20 w-20 rounded-full border-2 border-dashed border-[#d4af37] grid place-items-center text-[10px] text-gray-400">{t("certs.seal")}</div></div>
        <div><div className="border-t border-gray-500 pt-2"><b>{settings?.secretary_name || ""}</b><br />{t("certs.secretary")}</div></div>
      </div>
    </div>
  );
};

export const PrintDialog = ({ open, onOpenChange, title, children, testId = "print-dialog" }) => {
  const { t } = useLang();
  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto" data-testid={testId}>
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between gap-3 pr-6">
              <span>{title}</span>
              <Button onClick={() => window.print()} className="h-10" data-testid="print-button"><Printer className="h-4 w-4 mr-2" />{t("common.print")}</Button>
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">{children}</div>
        </DialogContent>
      </Dialog>
      {open && createPortal(<div className="print-area p-6">{children}</div>, document.body)}
    </>
  );
};
