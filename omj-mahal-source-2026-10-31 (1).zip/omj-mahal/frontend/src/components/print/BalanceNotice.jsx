import { useLang } from "@/context/LanguageContext";
import { fmtDate, inr, monthLabel, todayStr, fmtPhone } from "@/lib/format";
import { MahalHead } from "@/components/print/Printables";
import { useQr } from "@/components/MemberCard";
import { allTypes, typeLabel } from "@/components/forms/CollectionPaymentForm";

const Qr = ({ link }) => { const src = useQr(link); return src ? <img src={src} alt="UPI" className="h-24 w-24" /> : null; };

export const BalanceNotice = ({ data, settings }) => {
  const { t, months, lang } = useLang();
  const { house, collections: c, upi_link, year, year_payments: pays = [] } = data;
  const clear = c.total_pending <= 0;
  const rows = allTypes(settings).filter((k) => k !== "donation" && ((c[k]?.pending || 0) > 0 || (c[k]?.due || 0) > 0 || (c[k]?.paid || 0) > 0));
  const totalDue = rows.reduce((a, k) => a + (c[k].due || 0), 0);
  const totalPaid = rows.reduce((a, k) => a + (c[k].paid || 0), 0);
  const periodLabel = (k, p) => (k === "varisankhya" ? monthLabel(p, months, true) : p);
  const thisMonth = c.varisankhya?.pending_periods?.includes(todayStr().slice(0, 7)) ? c.varisankhya.rate : 0;
  const cell = "border border-[#e6dbc9] px-2 py-1";
  return (
    <div className="border-2 border-[#0d5c3a] rounded-lg p-5 bg-white text-[#1e2923] max-w-[560px] mx-auto notice-page" style={{ fontFamily: "inherit", pageBreakAfter: "always" }} data-testid={`balance-notice-${house.house_no}`}>
      <MahalHead settings={settings} lang={lang} />
      <p className="text-center uppercase tracking-[0.2em] text-xs text-[#8a6d1d] font-bold mb-1">{t("fin.notice.title")}</p>
      <div className="flex justify-between text-sm mb-3">
        <span><b>{t("houses.houseNo")}:</b> {house.house_no}{house.ward && <> · {t("houses.ward")} {house.ward}</>}</span>
        <span><b>{t("common.date")}:</b> {fmtDate(todayStr())}</span>
      </div>
      <p className="text-sm mb-1" data-testid="notice-greeting">{clear ? t("fin.notice.allClear", { name: house.head_name }) : t("fin.notice.greeting", { name: house.head_name })}</p>
      {c.members?.sub > 0 && <p className="text-xs text-[#8a6d1d] mb-3" data-testid="notice-units">{t("fin.units", { n: c.members.sub, u: c.members.units })}</p>}
      <table className="w-full text-sm border-collapse" data-testid="notice-table">
        <thead><tr className="bg-[#faf8f5] text-left"><th className={cell}>{t("fin.type")}</th><th className={`${cell} text-right`}>{t("fin.due")}</th><th className={`${cell} text-right`}>{t("fin.paid")}</th><th className={`${cell} text-right`}>{t("fin.pending")}</th></tr></thead>
        <tbody>
          {rows.map((k) => (
            <tr key={k} data-testid={`notice-row-${k}`}>
              <td className={`${cell} font-medium`}>{typeLabel(t, k, settings)}<span className="block text-[11px] text-gray-500 font-normal">{(k === "old_balance" || k === "auction") ? (c[k].note || "") : c[k].kind === "monthly" ? `${inr(c[k].rate)} ${t("fin.perMonth")}` : c[k].kind === "yearly" ? `${inr(c[k].rate)} ${t("fin.perYear")}` : `${t("fin.target")} ${inr(c[k].rate)}`}{c[k].pending_periods?.length > 0 && <> · {t("fin.pendingPeriods")}: {c[k].pending_periods.map((p) => periodLabel(k, p)).join(", ")}</>}</span></td>
              <td className={`${cell} text-right`}>{inr(c[k].due)}</td>
              <td className={`${cell} text-right text-[#0d5c3a]`}>{inr(c[k].paid)}</td>
              <td className={`${cell} text-right font-semibold ${c[k].pending > 0 ? "text-[#a06f1c]" : "text-[#0d5c3a]"}`}>{c[k].pending > 0 ? inr(c[k].pending) : "✔"}</td>
            </tr>
          ))}
          <tr className="bg-[#faf8f5] font-bold" data-testid="notice-totals-row"><td className={cell}>{t("common.total")}</td><td className={`${cell} text-right`}>{inr(totalDue)}</td><td className={`${cell} text-right text-[#0d5c3a]`}>{inr(totalPaid)}</td><td className={`${cell} text-right text-[#a06f1c]`}>{inr(c.total_pending)}</td></tr>
        </tbody>
      </table>
      {year && (
        <div className="mt-3 rounded-md border border-[#e6dbc9] px-3 py-2 text-xs" data-testid="notice-received">
          <p className="font-semibold text-[#0d5c3a] mb-1">{t("fin.notice.received", { year })}</p>
          {pays.length === 0 ? <p className="text-gray-600">{t("fin.notice.noneReceived")}</p> : (
            <table className="w-full"><tbody>
              {pays.map((p, i) => <tr key={i} data-testid={`notice-payment-${i}`}><td className="py-0.5">{fmtDate(p.date)}</td><td className="py-0.5">{typeLabel(t, p.type, settings)}</td><td className="py-0.5 text-gray-500">{p.receipt_no}</td><td className="py-0.5 text-right font-semibold">{inr(p.amount)}</td></tr>)}
              <tr className="border-t font-bold"><td colSpan={3} className="pt-1">{t("common.total")}</td><td className="pt-1 text-right text-[#0d5c3a]">{inr(pays.reduce((a, p) => a + (p.amount || 0), 0))}</td></tr>
            </tbody></table>
          )}
        </div>
      )}
      <div className="mt-3 flex items-center justify-between rounded-md bg-[#faf8f5] border border-[#e6dbc9] px-4 py-3">
        <div><p className="font-semibold">{t("fin.totalPending")}</p>{thisMonth > 0 && <p className="text-xs text-gray-600">{t("fin.notice.thisMonth")}: <b>{inr(thisMonth)}</b></p>}</div>
        <span className="text-2xl font-bold text-[#a06f1c]" data-testid="notice-total">{inr(c.total_pending)}</span>
      </div>
      <div className="mt-4 flex items-start justify-between gap-4 text-xs text-gray-700">
        <div className="space-y-1">
          <p>{t("fin.notice.request")}</p>
          {upi_link && <p>{t("fin.scanPay")}{settings?.upi_id && <> · UPI: <b>{settings.upi_id}</b></>}</p>}
          {settings?.upi_phone && <p data-testid="notice-gpay">{t("fin.gpay.number")}: <b>{fmtPhone(settings.upi_phone)}</b></p>}
          {settings?.bank_account_no && <p>{t("fin.bank.title")}: {settings.bank_name && `${settings.bank_name} · `}A/c <b>{settings.bank_account_no}</b>{settings.bank_ifsc && <> · IFSC {settings.bank_ifsc}</>}{settings.bank_account_name && <> · {settings.bank_account_name}</>}</p>}
          {settings?.phone && <p>{t("common.phone")}: {settings.phone}</p>}
        </div>
        {upi_link && <Qr link={upi_link} />}
      </div>
      <div className="mt-6 flex items-end justify-between text-xs text-gray-600">
        <span>{t("fin.notice.footer")}</span>
        <div className="w-40 border-t border-gray-500 pt-1 text-center">{t("subs.signature")}</div>
      </div>
    </div>
  );
};
