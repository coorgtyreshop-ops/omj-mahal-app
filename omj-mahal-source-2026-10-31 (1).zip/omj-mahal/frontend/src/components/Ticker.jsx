import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BellRing } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api } from "@/lib/api";
import { fmtDate } from "@/lib/format";

export const Ticker = ({ to = "/announcements", className = "" }) => {
  const { t, lang } = useLang();
  const [items, setItems] = useState([]);
  useEffect(() => { api.get("/public/ticker").then((r) => setItems(r.data)).catch(() => setItems([])); }, []);
  if (!items.length) return null;
  const text = items.map((a) => `${a.when === "today" ? t("ticker.today") : fmtDate(a.date)}${a.time ? " " + a.time : ""} · ${t(`ann.categories.${a.category}`)}: ${lang === "ml" && a.title_ml ? a.title_ml : lang === "kn" && a.title_kn ? a.title_kn : a.title}`);
  return (
    <Link to={to} className={`flex items-center gap-3 bg-[#1c2420] text-[#f5e6b8] text-sm h-9 overflow-hidden ${className}`} data-testid="event-ticker">
      <span className="flex items-center gap-1 shrink-0 bg-[#d4af37] text-[#1e2923] h-full px-3 text-xs font-bold uppercase tracking-wide"><BellRing className="h-3.5 w-3.5" />{t("ticker.label")}</span>
      <div className="flex-1 overflow-hidden relative h-full">
        <div className="ticker-track absolute whitespace-nowrap flex items-center h-full gap-12" style={{ animationDuration: `${Math.max(18, text.join("").length / 6)}s` }}>
          {[...text, ...text].map((s, i) => <span key={i} className="inline-flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#d4af37]" />{s}</span>)}
        </div>
      </div>
    </Link>
  );
};
