import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { UserRound, ShieldCheck } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { logoSrc, mahalName, appName, fileUrl } from "@/lib/branding";
import { cn } from "@/lib/utils";
import { fmtDate } from "@/lib/format";

export const verifyUrl = (settings, memberNo) => `${(settings?.app_url || window.location.origin).replace(/\/$/, "")}/verify/${memberNo}`;

export const useQr = (text, width = 240) => {
  const [src, setSrc] = useState("");
  useEffect(() => {
    if (!text) return;
    QRCode.toDataURL(text, { margin: 1, width, color: { dark: "#0d3d28", light: "#ffffff" } }).then(setSrc).catch(() => setSrc(""));
  }, [text, width]);
  return src;
};

export const TypeBadge = ({ type, className }) => {
  const { t } = useLang();
  const tone = { head: "bg-[#d4af37] text-[#1e2923]", sub: "bg-primary text-white", family: "bg-primary/10 text-primary" }[type] || "bg-muted";
  return <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide", tone, className)} data-testid={`type-badge-${type}`}>{t(`mtype.${type}`)}</span>;
};

export const Photo = ({ src, name, className }) => (
  <div className={cn("shrink-0 overflow-hidden rounded-xl bg-white/90 ring-2 ring-[#d4af37] grid place-items-center", className)}>
    {src ? <img src={fileUrl(src)} alt="" crossOrigin="anonymous" className="h-full w-full object-cover" /> : <span className="text-2xl font-bold text-primary">{(name || "?").trim().charAt(0).toUpperCase()}</span>}
  </div>
);

export const MemberCard = ({ data, cardRef, testId = "member-card" }) => {
  const { t, lang } = useLang();
  const { member: m, house, settings, member_since } = data;
  const qr = useQr(verifyUrl(settings, m.member_no));
  return (
    <div ref={cardRef} data-testid={testId} className="w-[420px] max-w-full rounded-2xl overflow-hidden shadow-xl text-[#1e2923] bg-[#fbf7ee] border border-[#d4af37]/60 select-none" style={{ fontFamily: "inherit" }}>
      <div className="islamic-pattern text-white px-4 py-3 flex items-center gap-3">
        <img src={logoSrc(settings)} alt="" crossOrigin="anonymous" className="h-12 w-12 rounded-full bg-white object-cover ring-2 ring-[#d4af37]" />
        <div className="min-w-0 flex-1">
          <p className="font-bold leading-tight text-lg">{appName(settings)}</p>
          <p className="text-[12px] text-white/85 leading-tight truncate">{mahalName(settings, lang)}</p>
        </div>
        <span className="text-[10px] uppercase tracking-[0.2em] text-[#d4af37] font-bold text-right leading-tight">{t("card.title")}</span>
      </div>
      <div className="h-1 bg-gradient-to-r from-[#d4af37] via-[#f1d97a] to-[#d4af37]" />
      <div className="p-4 flex gap-4">
        <Photo src={m.photo_url} name={m.name} className="h-24 w-20" />
        <div className="min-w-0 flex-1 space-y-1">
          <p className="font-bold text-lg leading-tight truncate" data-testid="card-member-name">{m.name}</p>
          <TypeBadge type={m.member_type} />
          <div className="grid grid-cols-[auto_1fr] gap-x-2 text-[12px] leading-5 mt-1">
            <span className="text-[#6b6257]">{t("card.memberNo")}</span><b className="font-mono tracking-wide" data-testid="card-member-no">{m.member_no}</b>
            <span className="text-[#6b6257]">{t("card.houseNo")}</span><b className="truncate">{house.house_no}<span className="font-normal text-[#6b6257]"> · {house.head_name}</span></b>
            {m.relation && m.relation !== "Self" && <><span className="text-[#6b6257]">{t("card.relation")}</span><span>{t(`members.relations.${m.relation}`)}</span></>}
            {m.dob && <><span className="text-[#6b6257]">{t("card.dob")}</span><b data-testid="card-dob">{fmtDate(m.dob)}{m.age !== null && m.age !== undefined && <span className="font-normal text-[#6b6257]"> · {t("card.age")} {m.age}</span>}</b></>}
            {m.member_type === "sub" && m.phone && <><span className="text-[#6b6257]">{t("card.phone")}</span><span className="font-mono" data-testid="card-phone">{m.phone}</span></>}
            {member_since && <><span className="text-[#6b6257]">{t("card.since")}</span><span>{member_since}</span></>}
          </div>
        </div>
        <div className="shrink-0 flex flex-col items-center gap-1">
          {qr ? <img src={qr} alt="QR" className="h-[84px] w-[84px] rounded-md border border-[#d4af37]/50 bg-white" data-testid="card-qr" /> : <div className="h-[84px] w-[84px] rounded-md bg-muted" />}
          <span className="text-[9px] text-[#6b6257] text-center leading-tight">{t("card.scan")}</span>
        </div>
      </div>
      <div className="px-4 pb-2 grid grid-cols-2 gap-6" data-testid="card-signatures">
        {[["president", settings.president_name], ["secretary", settings.secretary_name]].map(([role, name]) => (
          <div key={role} className="text-center">
            <div className="h-7 border-b border-dashed border-[#6b6257]/60" />
            <p className="text-[10px] font-semibold leading-tight mt-1" data-testid={`card-sign-${role}`}>{t(`card.${role}`)}{name ? <span className="font-normal text-[#6b6257]"> · {name}</span> : ""}</p>
            <p className="text-[9px] text-[#6b6257] leading-tight">{t("card.signature")}</p>
          </div>
        ))}
      </div>
      <div className="px-4 pb-3 flex items-center justify-between text-[10px] text-[#6b6257]">
        <span className="truncate">{settings.address}{settings.phone ? ` · ${settings.phone}` : ""}</span>
        <span className="inline-flex items-center gap-1 text-primary font-semibold shrink-0"><ShieldCheck className="h-3 w-3" />{house.ward}</span>
      </div>
    </div>
  );
};

export const CardPlaceholder = () => <div className="w-[420px] max-w-full h-[230px] rounded-2xl bg-muted animate-pulse grid place-items-center"><UserRound className="h-8 w-8 text-muted-foreground" /></div>;
