import { useState } from "react";
import { toast } from "sonner";
import { KeyRound, Send, Trash2 } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { openChatLink } from "@/lib/whatsapp";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TextField } from "@/components/shared";

/* Own Login ID / password for a secondary (working son) member — same house account, own phone. */
export const SubMemberLoginDialog = ({ member, open, onOpenChange, onDone }) => {
  const { t } = useLang();
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState(member?.phone || "");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const run = async (send) => {
    setBusy(true);
    try {
      const { data } = await api.post(`/members/${member.id}/login`, { password: password || null, phone: phone || null, send_whatsapp: send, app_url: window.location.origin });
      setResult(data);
      toast.success(t("members.subLogin.created", { id: data.login_id, pw: data.password }));
      if (send && data.sent?.wa_link && data.sent.status !== "sent") openChatLink(data.sent.wa_link, t("outbox.tapOpen"));
      onDone?.();
    } catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };
  const remove = async () => {
    try { await api.delete(`/members/${member.id}/login`); toast.success(t("members.subLogin.removed")); setResult(null); onDone?.(); onOpenChange(false); } catch (e) { toast.error(apiError(e)); }
  };
  if (!member) return null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="sub-login-dialog">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><KeyRound className="h-5 w-5 text-primary" />{t("members.subLogin.title")}</DialogTitle></DialogHeader>
        <p className="text-sm"><b>{member.name}</b> · <span className="font-mono text-primary" data-testid="sub-login-id">{member.member_no}</span></p>
        <p className="text-xs text-muted-foreground">{t("members.subLogin.hint")}</p>
        <TextField label={t("common.phone")} value={phone} onChange={setPhone} inputMode="tel" testId="sub-login-phone-input" />
        <TextField label={t("password")} value={password} onChange={setPassword} placeholder={t("hlogin.autoHint")} testId="sub-login-password-input" />
        {result && <p className="rounded-lg bg-[#0d5c3a]/10 px-3 py-2 text-sm" data-testid="sub-login-result">Member ID: <b className="font-mono">{result.login_id}</b> · {t("password")}: <b className="font-mono">{result.password}</b></p>}
        <div className="flex flex-wrap justify-end gap-2 pt-2">
          {member.login_id && <Button type="button" variant="ghost" className="h-11 text-destructive mr-auto" onClick={remove} data-testid="sub-login-remove"><Trash2 className="h-4 w-4 mr-1" />{t("members.subLogin.remove")}</Button>}
          <Button type="button" variant="outline" className="h-11" disabled={busy} onClick={() => run(false)} data-testid="sub-login-create"><KeyRound className="h-4 w-4 mr-1" />{t("members.subLogin.create")}</Button>
          <Button type="button" className="h-11 bg-[#128C7E] hover:bg-[#0f7a6d]" disabled={busy} onClick={() => run(true)} data-testid="sub-login-send"><Send className="h-4 w-4 mr-1" />{t("members.subLogin.send")}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
