import { useState } from "react";
import { toast } from "sonner";
import { Sparkles, Languages, Wand2, PenLine, Check } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { SelectField } from "@/components/shared";
import { VoiceRecorder } from "@/components/chat/VoiceRecorder";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const LANGS = ["ml", "kn", "en"];

export const AiComposer = ({ open, onOpenChange, initial = "", purpose = "message", onUse }) => {
  const { t, lang } = useLang();
  const [text, setText] = useState(initial);
  const [target, setTarget] = useState(lang === "en" ? "ml" : lang);
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState("");
  const run = async (action, src) => {
    const input = (src ?? text).trim();
    if (!input) return toast.error(t("ai.empty"));
    setBusy(action);
    try { const { data } = await api.post("/assistant/compose", { text: input, language: target, action, purpose }); setResult(data.text); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(""); }
  };
  const transcribe = async (file) => {
    const fd = new FormData(); fd.append("file", file); fd.append("language", target);
    setBusy("voice");
    try { const { data } = await api.post("/assistant/transcribe", fd); setText((v) => (v ? `${v} ${data.text}` : data.text)); toast.success(t("ai.heard")); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(""); }
  };
  const use = () => { onUse(result || text); onOpenChange(false); };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid="ai-composer-dialog">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-[#d4af37]" />{t("ai.title")}</DialogTitle></DialogHeader>
        <p className="text-xs text-muted-foreground -mt-2">{t("ai.hint")}</p>
        <div className="flex items-end gap-3">
          <SelectField label={t("ai.language")} value={target} onChange={setTarget} testId="ai-language-select" options={LANGS.map((l) => ({ value: l, label: t(`lang.${l}`) }))} className="flex-1" />
          <div className="pb-0.5"><VoiceRecorder onSend={transcribe} disabled={!!busy} /></div>
        </div>
        <Textarea rows={4} value={text} onChange={(e) => setText(e.target.value)} placeholder={t("ai.inputPh")} data-testid="ai-input" />
        {busy === "voice" && <p className="text-xs text-primary animate-pulse" data-testid="ai-listening">{t("ai.transcribing")}</p>}
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="outline" onClick={() => run("polish")} disabled={!!busy} className="h-10" data-testid="ai-polish-button"><Wand2 className="h-4 w-4 mr-1.5" />{busy === "polish" ? t("ai.working") : t("ai.polish")}</Button>
          <Button type="button" variant="outline" onClick={() => run("translate")} disabled={!!busy} className="h-10" data-testid="ai-translate-button"><Languages className="h-4 w-4 mr-1.5" />{busy === "translate" ? t("ai.working") : t("ai.translate", { lang: t(`lang.${target}`) })}</Button>
          <Button type="button" variant="outline" onClick={() => run("draft")} disabled={!!busy} className="h-10" data-testid="ai-draft-button"><PenLine className="h-4 w-4 mr-1.5" />{busy === "draft" ? t("ai.working") : t("ai.draft")}</Button>
        </div>
        {result && (
          <div className="space-y-2" data-testid="ai-result-box">
            <p className="text-xs font-semibold text-primary">{t("ai.result")}</p>
            <Textarea rows={6} value={result} onChange={(e) => setResult(e.target.value)} data-testid="ai-result" />
          </div>
        )}
        <div className="flex justify-end gap-2 pt-1">
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="h-11" data-testid="ai-cancel-button">{t("common.cancel")}</Button>
          <Button type="button" onClick={use} disabled={!(result || text).trim()} className="h-11" data-testid="ai-use-button"><Check className="h-4 w-4 mr-2" />{t("ai.use")}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export const AiButton = ({ value, onUse, purpose, className = "" }) => {
  const { t } = useLang();
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button type="button" variant="outline" onClick={() => setOpen(true)} className={`h-10 border-[#d4af37]/60 text-[#8a6d1d] hover:bg-[#d4af37]/10 ${className}`} data-testid="ai-open-button"><Sparkles className="h-4 w-4 mr-1.5" />{t("ai.button")}</Button>
      {open && <AiComposer open onOpenChange={setOpen} initial={value} purpose={purpose} onUse={onUse} />}
    </>
  );
};
