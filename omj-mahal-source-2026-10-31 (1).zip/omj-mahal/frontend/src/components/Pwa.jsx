import { useEffect, useState } from "react";
import { Download, X, Share, WifiOff } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { appName } from "@/lib/branding";
import { Button } from "@/components/ui/button";

const isIos = () => /iphone|ipad|ipod/i.test(window.navigator.userAgent) && !window.MSStream;
const isStandalone = () => window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;

export const InstallBanner = () => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [prompt, setPrompt] = useState(null);
  const [show, setShow] = useState(false);
  const [ios, setIos] = useState(false);

  useEffect(() => {
    if (isStandalone() || localStorage.getItem("mahal_install_dismissed")) return;
    const handler = (e) => { e.preventDefault(); setPrompt(e); setShow(true); };
    window.addEventListener("beforeinstallprompt", handler);
    if (isIos()) { setIos(true); setShow(true); }
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const dismiss = () => { setShow(false); localStorage.setItem("mahal_install_dismissed", "1"); };
  const install = async () => {
    if (!prompt) return;
    prompt.prompt();
    const { outcome } = await prompt.userChoice;
    if (outcome === "accepted") setShow(false);
    setPrompt(null);
  };

  if (!show) return null;
  return (
    <div className="fixed bottom-[68px] lg:bottom-4 inset-x-3 lg:left-auto lg:right-4 lg:w-[380px] z-40 rounded-2xl islamic-pattern text-white p-4 shadow-2xl border border-[#d4af37]/40" data-testid="install-banner">
      <button onClick={dismiss} className="absolute top-2 right-2 p-1 rounded-full hover:bg-white/10" data-testid="install-dismiss"><X className="h-4 w-4" /></button>
      <div className="flex items-start gap-3">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#d4af37] text-[#0d5c3a]">{ios ? <Share className="h-5 w-5" /> : <Download className="h-5 w-5" />}</span>
        <div className="min-w-0 flex-1">
          <p className="font-bold">{ios ? t("pwa.iosTitle") : t("pwa.installTitle", { name: appName(settings) })}</p>
          <p className="text-sm text-white/80 mt-0.5">{ios ? t("pwa.iosDesc") : t("pwa.installDesc")}</p>
          {!ios && (
            <div className="flex gap-2 mt-3">
              <Button size="sm" onClick={install} className="h-9 bg-[#d4af37] text-[#1e2923] hover:bg-[#e2c053]" data-testid="install-button"><Download className="h-4 w-4 mr-1" />{t("pwa.install")}</Button>
              <Button size="sm" variant="ghost" onClick={dismiss} className="h-9 text-white hover:bg-white/10" data-testid="install-later">{t("pwa.later")}</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const OfflineBar = () => {
  const { t } = useLang();
  const [offline, setOffline] = useState(!navigator.onLine);
  useEffect(() => {
    const on = () => setOffline(false), off = () => setOffline(true);
    window.addEventListener("online", on); window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);
  if (!offline) return null;
  return (
    <div className="bg-[#c58b2b] text-white text-sm px-4 py-2 flex items-center gap-2 justify-center" data-testid="offline-bar">
      <WifiOff className="h-4 w-4" /><b>{t("pwa.offline")}</b><span className="hidden sm:inline">— {t("pwa.offlineDesc")}</span>
    </div>
  );
};
