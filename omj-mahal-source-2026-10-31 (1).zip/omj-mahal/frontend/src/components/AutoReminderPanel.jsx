import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Repeat, Zap } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { inr, fmtDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/shared";

export const AutoReminderPanel = ({ onSent }) => {
  const { t } = useLang();
  const [status, setStatus] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => { try { const { data } = await api.get("/notifications/auto-reminder/status"); setStatus(data); } catch {} }, []);
  useEffect(() => { load(); }, [load]);

  const run = async () => {
    setBusy(true);
    try { const { data } = await api.post("/notifications/auto-reminder/run"); toast.success(t("autoRem.ran", { n: data.sent })); load(); onSent?.(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };

  if (!status) return null;
  return (
    <div className="rounded-xl border border-[#e6dbc9] bg-card p-5 shadow-sm space-y-3" data-testid="auto-reminder-panel">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="font-bold flex items-center gap-2"><Repeat className="h-5 w-5 text-primary" />{t("autoRem.title")}</h3>
        <StatusBadge ok={status.enabled}>{status.enabled ? "ON" : "OFF"}</StatusBadge>
      </div>
      <p className="text-sm text-muted-foreground">{t("autoRem.desc")}</p>
      <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm">
        <span>{t("autoRem.threshold")}: <b>{inr(status.threshold)}</b></span>
        <span>{t("autoRem.days")}: <b>{status.days}</b></span>
        <span>{t("autoRem.channel")}: <b>{t(`notif.channels.${status.channel}`)}</b></span>
        <span>{t("autoRem.lastRun")}: <b data-testid="auto-reminder-last-run">{status.last_run ? fmtDate(status.last_run) : t("autoRem.never")}</b></span>
      </div>
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1">{t("autoRem.eligible")} ({status.eligible.length})</p>
        {status.eligible.length === 0 ? <p className="text-sm text-muted-foreground" data-testid="auto-reminder-none">{t("autoRem.none")}</p> : (
          <ul className="text-sm divide-y rounded-lg border" data-testid="auto-reminder-eligible">
            {status.eligible.map((h) => (
              <li key={h.id} className="flex items-center justify-between gap-2 px-3 py-2">
                <span><b className="text-primary">{h.house_no}</b> · {h.head_name}</span>
                <span className="text-right"><b className="text-[#a06f1c]">{inr(h.pending_amount)}</b> <span className="text-xs text-muted-foreground">· {h.pending_count}m{h.last_auto_reminder ? ` · ${t("autoRem.lastSent")} ${fmtDate(h.last_auto_reminder)}` : ""}</span></span>
              </li>
            ))}
          </ul>
        )}
      </div>
      <Button onClick={run} disabled={busy || !status.eligible.length} variant="outline" className="h-11" data-testid="auto-reminder-run-button"><Zap className="h-4 w-4 mr-2" />{t("autoRem.runNow")}</Button>
    </div>
  );
};
