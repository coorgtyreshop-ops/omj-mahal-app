import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CheckCircle2, Circle, X, Cake, KeyRound } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const LINKS = { settings: "/settings", houses: "/houses?new=1", members: "/members", payments: "/subscriptions?new=1", announcements: "/announcements?new=1", committee: "/committee", logins: "/users" };

export const SetupChecklist = ({ setup }) => {
  const { t } = useLang();
  const [hidden, setHidden] = useState(() => localStorage.getItem("mahal_setup_hidden") === "1");
  const keys = Object.keys(LINKS);
  const done = keys.filter((k) => setup[k]).length;
  if (hidden || done === keys.length) return null;
  return (
    <div className="relative rounded-xl border border-[#d4af37]/50 bg-[#d4af37]/10 p-4 sm:p-5 mb-6" data-testid="setup-checklist">
      <button onClick={() => { localStorage.setItem("mahal_setup_hidden", "1"); setHidden(true); }} className="absolute top-3 right-3 p-1 rounded-full hover:bg-black/5" data-testid="setup-hide" title={t("setup.hide")}><X className="h-4 w-4" /></button>
      <div className="flex items-center gap-3 mb-3">
        <h2 className="font-bold text-lg">{t("setup.title")}</h2>
        <span className="text-xs font-semibold rounded-full bg-white px-2 py-0.5 text-[#8a6d1d]">{done}/{keys.length} {t("setup.done")}</span>
      </div>
      <p className="text-sm text-muted-foreground mb-3">{t("setup.subtitle")}</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
        {keys.map((k) => (
          <Link key={k} to={LINKS[k]} data-testid={`setup-step-${k}`} className={cn("flex items-center gap-2 rounded-lg border bg-white px-3 py-2 text-sm transition-colors hover:border-primary/50", setup[k] ? "text-muted-foreground line-through decoration-primary/60" : "font-medium")}>
            {setup[k] ? <CheckCircle2 className="h-5 w-5 text-primary shrink-0" /> : <Circle className="h-5 w-5 text-[#c58b2b] shrink-0" />}
            <span className="leading-tight">{t(`setup.steps.${k}`)}</span>
          </Link>
        ))}
      </div>
    </div>
  );
};

export const BirthdaysCard = ({ items }) => {
  const { t, months } = useLang();
  const m = months[new Date().getMonth()];
  return (
    <div data-testid="birthdays-card">
      <h2 className="text-lg font-bold mb-3 flex items-center gap-2"><Cake className="h-5 w-5 text-[#c58b2b]" />{t("dob.birthdays")} <span className="text-sm font-normal text-muted-foreground">· {m}</span></h2>
      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm divide-y">
        {items.length === 0 ? <p className="p-4 text-sm text-muted-foreground">{t("dob.noBirthdays")}</p> : items.slice(0, 8).map((b) => (
          <div key={b.id} className="flex items-center gap-3 px-4 py-2.5 text-sm" data-testid={`birthday-${b.id}`}>
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#d4af37]/20 text-[#8a6d1d] font-bold">{b.day}</span>
            <div className="min-w-0 flex-1"><p className="font-medium truncate">{b.name}</p><p className="text-xs text-muted-foreground">{b.house_no} · {t("dob.turns")} {b.age}</p></div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const MustChangeBanner = () => {
  const { t } = useLang();
  return (
    <div className="rounded-xl border border-[#c58b2b]/50 bg-[#c58b2b]/10 p-4 mb-6 flex flex-col sm:flex-row sm:items-center gap-3" data-testid="must-change-banner">
      <KeyRound className="h-6 w-6 text-[#a06f1c] shrink-0" />
      <div className="flex-1"><p className="font-bold text-[#a06f1c]">{t("mustChange.title")}</p><p className="text-sm text-muted-foreground">{t("mustChange.desc")}</p></div>
      <Button asChild className="h-10" data-testid="must-change-action"><Link to="/profile">{t("mustChange.action")}</Link></Button>
    </div>
  );
};


export const TodayCard = () => {
  const { t, lang } = useLang();
  const [data, setData] = useState(null);
  useEffect(() => { api.get("/events/today").then((r) => setData(r.data)).catch(() => setData({ hijri: {}, today: [], upcoming: [] })); }, []);
  if (!data) return null;
  const label = lang === "ml" ? data.hijri?.label_ml : lang === "kn" ? data.hijri?.label_kn : data.hijri?.label;
  const items = [...data.today, ...data.upcoming].slice(0, 4);
  const name = (ev) => (lang === "ml" && ev.title_ml ? ev.title_ml : lang === "kn" && ev.title_kn ? ev.title_kn : ev.title);
  return (
    <Link to="/calendar" className="block rounded-2xl bg-primary text-white p-5 shadow-lg mb-6 hover:shadow-xl transition-shadow" data-testid="today-hijri-card">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] opacity-80">{t("cal.hijriToday")}</p>
          <p className="text-2xl font-bold" data-testid="dashboard-hijri-label">{label}</p>
        </div>
        <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold">{t("nav.calendar")} →</span>
      </div>
      {items.length > 0 && (
        <ul className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2" data-testid="dashboard-events">
          {items.map((ev) => (
            <li key={ev.id} className="rounded-lg bg-white/10 px-3 py-2 text-sm flex items-center gap-2">
              <span className={ev.date === data.today?.[0]?.date && data.today.includes(ev) ? "rounded bg-[#d4af37] text-[#1e2923] px-1.5 text-[10px] font-bold" : "rounded bg-white/20 px-1.5 text-[10px] font-bold"}>{data.today.includes(ev) ? t("cal.today") : ev.date.slice(5)}</span>
              <span className="truncate">{name(ev)}{ev.time && <span className="opacity-75"> · {ev.time}</span>}</span>
            </li>
          ))}
        </ul>
      )}
    </Link>
  );
};
