import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Hourglass, ArrowRight } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api } from "@/lib/api";
import { ReleaseAllButton } from "@/components/finance/ReleaseStatement";

/* Admin dashboard reminder: houses whose committee update has not been sent yet. */
export const UnreleasedHouses = () => {
  const { t } = useLang();
  const [houses, setHouses] = useState(null);
  const load = () => api.get("/houses").then((r) => setHouses(r.data.filter((h) => !h.statement_released))).catch(() => setHouses([]));
  useEffect(() => { load(); }, []);
  if (!houses || houses.length === 0) return null;
  return (
    <section className="rounded-xl border border-[#c58b2b]/50 bg-[#c58b2b]/[0.08] p-4 mb-6" data-testid="unreleased-houses-card">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
        <h2 className="text-base font-bold flex items-center gap-2"><Hourglass className="h-4 w-4 text-[#a06f1c]" />{t("fin.release.pendingHouses", { n: houses.length })}</h2>
        <ReleaseAllButton onDone={load} />
      </div>
      <p className="text-xs text-muted-foreground mb-3">{t("fin.release.pendingHousesHint")}</p>
      <ul className="flex flex-wrap gap-2" data-testid="unreleased-houses-list">
        {houses.map((h) => (
          <li key={h.id}>
            <Link to={`/houses/${h.id}`} className="inline-flex items-center gap-1 rounded-full border border-[#c58b2b]/50 bg-white px-3 py-1 text-sm hover:bg-[#c58b2b]/10" data-testid={`unreleased-house-${h.house_no}`}>
              <b className="text-primary">{h.house_no}</b> {h.head_name}<ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
};
