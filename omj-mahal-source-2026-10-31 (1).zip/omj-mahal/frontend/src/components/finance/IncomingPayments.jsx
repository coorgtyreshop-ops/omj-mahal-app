import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Check, X, BellRing, Clock } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, fmtDate } from "@/lib/format";
import { typeLabel } from "@/components/forms/CollectionPaymentForm";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TextField } from "@/components/shared";

const when = (iso) => { const d = new Date(iso); return `${fmtDate(iso.slice(0, 10))} · ${d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata" })}`; };

const Row = ({ r, onApprove, onReject, settings, t }) => (
  <li className="rounded-lg border bg-card px-3 py-2 flex flex-wrap items-center gap-2" data-testid={`incoming-row-${r.id}`}>
    <div className="flex-1 min-w-[180px]">
      <p className="text-sm"><b className="text-primary">{r.house_no}</b> · {r.head_name} <span className="text-muted-foreground">— {typeLabel(t, r.type, settings)}</span></p>
      <p className="text-[11px] text-muted-foreground flex items-center gap-1"><Clock className="h-3 w-3" />{t("fin.incoming.sentAt")} {when(r.created_at)}{r.upi_ref && <> · {t("fin.incoming.ref")}: <span className="font-mono">{r.upi_ref}</span></>}{r.note && <> · {r.note}</>}</p>
      <p className={`text-[11px] font-medium ${r.stage === "started" ? "text-[#a06f1c]" : "text-[#0d5c3a]"}`} data-testid={`incoming-stage-${r.id}`}>{r.stage === "started" ? t("fin.incoming.started") : t("fin.incoming.submitted")}</p>
    </div>
    <p className="text-lg font-bold" data-testid={`incoming-amount-${r.id}`}>{inr(r.amount)}</p>
    <div className="flex gap-1">
      <Button size="sm" className="h-9" onClick={() => onApprove(r)} data-testid={`incoming-approve-${r.id}`}><Check className="h-4 w-4 mr-1" />{t("fin.incoming.confirm")}</Button>
      <Button size="sm" variant="outline" className="h-9 text-destructive" onClick={() => onReject(r)} data-testid={`incoming-reject-${r.id}`}><X className="h-4 w-4 mr-1" />{t("fin.incoming.notReceived")}</Button>
    </div>
  </li>
);

export const IncomingPayments = ({ onChange }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [feed, setFeed] = useState(null);
  const [rejecting, setRejecting] = useState(null);
  const [reason, setReason] = useState("");
  const seen = useRef(null);
  const load = useCallback(async () => {
    try {
      const { data } = await api.get("/finance/pay-requests/feed");
      if (seen.current) data.pending.filter((r) => !seen.current.has(r.id)).forEach((r) => toast(t("fin.incoming.newToast", { name: r.head_name, amount: inr(r.amount) }), { icon: <BellRing className="h-4 w-4 text-[#a06f1c]" /> }));
      seen.current = new Set(data.pending.map((r) => r.id));
      setFeed(data);
    } catch { /* keep last */ }
  }, [t]);
  useEffect(() => { load(); const id = setInterval(load, 10000); return () => clearInterval(id); }, [load]);
  const approve = async (r) => { try { const { data } = await api.post(`/finance/pay-requests/${r.id}/approve`); toast.success(t("fin.approvedMsg", { receipt: data.receipt_no })); load(); onChange?.(); } catch (e) { toast.error(apiError(e)); } };
  const reject = async () => { try { await api.post(`/finance/pay-requests/${rejecting.id}/reject`, { reason }); toast.success(t("fin.rejectedMsg")); setRejecting(null); setReason(""); load(); } catch (e) { toast.error(apiError(e)); } };
  if (!feed) return null;
  const n = feed.pending.length;
  return (
    <section className={`rounded-xl border p-4 mb-6 ${n ? "border-[#a06f1c] bg-[#c58b2b]/10 shadow-md" : "border-[#e6dbc9] bg-card"}`} data-testid="incoming-payments-card">
      <div className="flex items-center justify-between gap-2 mb-1">
        <h2 className="text-base font-bold flex items-center gap-2"><BellRing className={`h-4 w-4 ${n ? "text-[#a06f1c] animate-pulse" : "text-muted-foreground"}`} />{t("fin.incoming.title")}</h2>
        {n > 0 && <span className="rounded-full bg-[#a06f1c] text-white text-xs font-bold px-2 py-0.5" data-testid="incoming-count">{t("fin.incoming.waiting", { n, amount: inr(feed.pending_total) })}</span>}
      </div>
      <p className="text-xs text-muted-foreground mb-3">{t("fin.incoming.hint")}</p>
      {n === 0 ? <p className="text-sm text-muted-foreground" data-testid="incoming-empty">{t("fin.incoming.empty")}</p> : (
        <ul className="space-y-2" data-testid="incoming-list">{feed.pending.map((r) => <Row key={r.id} r={r} settings={settings} t={t} onApprove={approve} onReject={setRejecting} />)}</ul>
      )}
      {feed.recent.length > 0 && (
        <details className="mt-3 text-xs" data-testid="incoming-recent">
          <summary className="cursor-pointer text-muted-foreground font-medium">{t("fin.incoming.recent")} ({feed.recent.length})</summary>
          <ul className="mt-2 space-y-1">
            {feed.recent.map((r) => <li key={r.id} className="flex justify-between gap-2 border-b border-dashed py-1" data-testid={`incoming-recent-${r.id}`}><span><b className="text-primary">{r.house_no}</b> {r.head_name} · {typeLabel(t, r.type, settings)} · {when(r.decided_at)}</span><span className={r.status === "approved" ? "text-[#0d5c3a] font-semibold" : "text-destructive"}>{inr(r.amount)} {r.status === "approved" ? `✔ ${r.receipt_no}` : "✕"}</span></li>)}
          </ul>
        </details>
      )}
      <Dialog open={!!rejecting} onOpenChange={(o) => !o && setRejecting(null)}>
        <DialogContent className="max-w-sm" data-testid="incoming-reject-dialog">
          <DialogHeader><DialogTitle>{t("fin.reject")}</DialogTitle></DialogHeader>
          <TextField label={t("fin.reason")} value={reason} onChange={setReason} testId="incoming-reject-reason" />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setRejecting(null)} className="h-11" data-testid="incoming-reject-cancel">{t("common.cancel")}</Button>
            <Button type="button" variant="destructive" onClick={reject} className="h-11" data-testid="incoming-reject-confirm">{t("fin.reject")}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
};
