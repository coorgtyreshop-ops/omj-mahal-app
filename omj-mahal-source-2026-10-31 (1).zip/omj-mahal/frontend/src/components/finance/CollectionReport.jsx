import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { toast } from "sonner";
import { Printer, CheckCircle2, CircleDot, XCircle } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, fmtDate } from "@/lib/format";
import { SelectField } from "@/components/shared";
import { MahalHead } from "@/components/print/Printables";
import { typeLabel } from "@/components/forms/CollectionPaymentForm";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { HouseReportBody, useHouseReport } from "@/components/finance/HouseReport";

const GROUPS = [
  { key: "full", icon: CheckCircle2, color: "text-[#0d5c3a]", bg: "bg-[#0d5c3a]/10", amountKey: "paid", amountLabel: "gaveFull" },
  { key: "partial", icon: CircleDot, color: "text-[#a06f1c]", bg: "bg-[#c58b2b]/15", amountKey: "pending", amountLabel: "stillOwes" },
  { key: "none", icon: XCircle, color: "text-destructive", bg: "bg-destructive/10", amountKey: "pending", amountLabel: "toGive" },
];

const Box = ({ label, value, tone = "", testId }) => (
  <div className={`rounded-lg border px-3 py-2 ${tone}`} data-testid={testId}><p className="text-[11px] text-muted-foreground leading-tight">{label}</p><p className="text-lg font-bold">{value}</p></div>
);

const Head = ({ title, date }) => {
  const { t, lang } = useLang();
  const { settings } = useAuth();
  return (
    <>
      <div className="hidden print:block"><MahalHead settings={settings} lang={lang} /></div>
      <h2 className="font-bold text-center text-lg" data-testid="report-heading">{t("fin.report.title")} — {title}</h2>
      <p className="text-center text-xs text-muted-foreground mb-3">{t("fin.report.asOn")}: {fmtDate(date)}</p>
    </>
  );
};

const GroupTable = ({ g, rows, type }) => {
  const { t } = useLang();
  const Icon = g.icon;
  const sum = rows.reduce((a, r) => a + (r[g.amountKey] || 0), 0);
  const title = type === "donation" ? t("fin.report.donors") : t(`fin.report.${g.key}`);
  return (
    <section className="mt-4 rounded-lg border overflow-hidden break-inside-avoid" data-testid={`report-group-${g.key}`}>
      <div className={`flex items-center justify-between gap-2 px-3 py-2 text-sm font-semibold ${g.bg}`}>
        <span className={`inline-flex items-center gap-2 ${g.color}`}><Icon className="h-4 w-4" />{title}<span className="rounded-full bg-white/80 px-2 text-xs text-foreground" data-testid={`report-count-${g.key}`}>{rows.length}</span></span>
        <span className="text-xs sm:text-sm">{t(`fin.report.${g.amountLabel}`)}: <b data-testid={`report-sum-${g.key}`}>{inr(sum)}</b></span>
      </div>
      {rows.length === 0 ? <p className="px-3 py-3 text-xs text-muted-foreground">{t("common.none")}</p> : (
        <Table>
          <TableHeader><TableRow>
            <TableHead className="w-8">#</TableHead><TableHead>{t("houses.houseNo")}</TableHead><TableHead>{t("houses.headName")}</TableHead>
            {type !== "donation" && <TableHead className="text-right">{t("fin.due")}</TableHead>}
            <TableHead className="text-right">{t("fin.paid")}</TableHead>
            {type !== "donation" && <TableHead className="text-right">{t("fin.pending")}</TableHead>}
          </TableRow></TableHeader>
          <TableBody>
            {rows.map((r, i) => (
              <TableRow key={r.id} data-testid={`report-row-${g.key}-${r.house_no}`}>
                <TableCell className="text-xs text-muted-foreground">{i + 1}</TableCell>
                <TableCell className="font-bold text-primary">{r.house_no}</TableCell>
                <TableCell>{r.head_name}{r.phone && <span className="block text-[10px] text-muted-foreground">{r.phone}</span>}</TableCell>
                {type !== "donation" && <TableCell className="text-right text-sm">{inr(r.due)}</TableCell>}
                <TableCell className="text-right text-sm">{inr(r.paid)}</TableCell>
                {type !== "donation" && <TableCell className={`text-right font-semibold ${r.pending > 0 ? "text-[#a06f1c]" : "text-[#0d5c3a]"}`}>{r.pending > 0 ? inr(r.pending) : "✔"}</TableCell>}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </section>
  );
};

const Summary = ({ data }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const types = data.types.filter((k) => data.report[k].totals.houses > 0);
  return (
    <div data-testid="report-summary">
      <Head title={t("fin.report.summary")} date={data.date} />
      <div className="grid grid-cols-3 gap-2 mb-3">
        <Box label={t("fin.report.due")} value={inr(data.grand.due)} testId="report-grand-due" />
        <Box label={t("fin.report.received")} value={inr(data.grand.paid + data.grand.donation)} tone="border-[#0d5c3a]/40 bg-[#0d5c3a]/5" testId="report-grand-paid" />
        <Box label={t("fin.report.pending")} value={inr(data.grand.pending)} tone="border-[#c58b2b]/40 bg-[#c58b2b]/5" testId="report-grand-pending" />
      </div>
      <Table data-testid="report-summary-table">
        <TableHeader><TableRow className="bg-accent/60">
          <TableHead>{t("fin.type")}</TableHead><TableHead className="text-right">{t("fin.report.houses")}</TableHead><TableHead className="text-right">{t("fin.report.due")}</TableHead>
          <TableHead className="text-right">{t("fin.report.received")}</TableHead><TableHead className="text-right">{t("fin.report.pending")}</TableHead><TableHead className="text-right">{t("fin.report.counts")}</TableHead>
        </TableRow></TableHeader>
        <TableBody>
          {types.map((k) => { const r = data.report[k]; return (
            <TableRow key={k} data-testid={`report-summary-row-${k}`}>
              <TableCell className="font-semibold">{typeLabel(t, k, settings)}</TableCell>
              <TableCell className="text-right">{r.totals.houses}</TableCell>
              <TableCell className="text-right">{k === "donation" ? "—" : inr(r.totals.due)}</TableCell>
              <TableCell className="text-right text-[#0d5c3a] font-semibold">{inr(r.totals.paid)}</TableCell>
              <TableCell className="text-right text-[#a06f1c] font-semibold">{k === "donation" ? "—" : inr(r.totals.pending)}</TableCell>
              <TableCell className="text-right text-xs whitespace-nowrap"><span className="text-[#0d5c3a]">{r.full.length}</span> / <span className="text-[#a06f1c]">{r.partial.length}</span> / <span className="text-destructive">{r.none.length}</span></TableCell>
            </TableRow>
          ); })}
          {types.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground">{t("fin.report.noHouses")}</TableCell></TableRow>}
        </TableBody>
      </Table>
    </div>
  );
};

export const ReportBody = ({ data, type }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  if (type === "summary") return <Summary data={data} />;
  const r = data.report[type];
  const groups = type === "donation" ? GROUPS.slice(0, 1) : GROUPS;
  return (
    <div data-testid={`report-${type}`}>
      <Head title={typeLabel(t, type, settings)} date={data.date} />
      <div className={`grid gap-2 mb-1 ${type === "donation" ? "grid-cols-2" : "grid-cols-2 sm:grid-cols-4"}`}>
        {type !== "donation" && <Box label={t("fin.report.due")} value={inr(r.totals.due)} testId="report-total-due" />}
        <Box label={t("fin.report.received")} value={inr(r.totals.paid)} tone="border-[#0d5c3a]/40 bg-[#0d5c3a]/5" testId="report-total-paid" />
        {type !== "donation" && <Box label={t("fin.report.pending")} value={inr(r.totals.pending)} tone="border-[#c58b2b]/40 bg-[#c58b2b]/5" testId="report-total-pending" />}
        <Box label={t("fin.report.houses")} value={r.totals.houses} testId="report-total-houses" />
      </div>
      {r.totals.houses === 0 && <p className="text-sm text-muted-foreground text-center py-4">{t("fin.report.noHouses")}</p>}
      {groups.map((g) => <GroupTable key={g.key} g={g} rows={r[g.key]} type={type} />)}
    </div>
  );
};

export const ReportDialog = ({ open, onOpenChange }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [data, setData] = useState(null);
  const [type, setType] = useState("summary");
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const houseData = useHouseReport(open, type === "houses", Number(year));
  useEffect(() => { if (open) api.get("/finance/report").then((r) => setData(r.data)).catch((e) => toast.error(apiError(e))); }, [open]);
  const options = useMemo(() => (data ? [{ value: "summary", label: t("fin.report.summary") }, { value: "houses", label: t("fin.report.byHouse") }, ...data.types.filter((k) => k === "varisankhya" || data.report[k].totals.houses > 0).map((k) => ({ value: k, label: typeLabel(t, k, settings) }))] : []), [data, t, settings]);
  const years = useMemo(() => { const y = new Date().getFullYear(); return [y, y - 1, y - 2].map((v) => ({ value: String(v), label: String(v) })); }, []);
  const body = type === "houses" ? (houseData ? <HouseReportBody data={houseData} /> : <p className="py-6 text-center text-sm text-muted-foreground">{t("common.loading")}</p>) : data ? <ReportBody data={data} type={type} /> : <p className="py-6 text-center text-sm text-muted-foreground">{t("common.loading")}</p>;
  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-5xl max-h-[92vh] overflow-y-auto" data-testid="report-dialog">
          <DialogHeader><DialogTitle>{t("fin.report.title")}</DialogTitle></DialogHeader>
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div className="flex flex-wrap items-end gap-3">
              <SelectField label={t("fin.report.type")} value={type} onChange={setType} options={options} testId="report-type-select" className="min-w-[240px]" />
              {type === "houses" && <SelectField label={t("fin.report.year")} value={year} onChange={setYear} options={years} testId="report-year-select" className="w-28" />}
            </div>
            <Button variant="outline" onClick={() => window.print()} className="h-11" data-testid="report-print-button"><Printer className="h-4 w-4 mr-2" />{t("fin.report.print")}</Button>
          </div>
          <p className="text-xs text-muted-foreground">{type === "houses" ? t("fin.report.housesHint") : t("fin.report.hint")}</p>
          {body}
        </DialogContent>
      </Dialog>
      {open && createPortal(<div className="print-area p-6">{body}</div>, document.body)}
    </>
  );
};
