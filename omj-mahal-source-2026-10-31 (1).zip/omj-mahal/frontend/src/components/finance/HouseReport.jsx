import { useEffect, useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, CircleDot, XCircle } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, fmtDate } from "@/lib/format";
import { MahalHead } from "@/components/print/Printables";
import { typeLabel } from "@/components/forms/CollectionPaymentForm";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const GROUPS = [
  { key: "full", icon: CheckCircle2, color: "text-[#0d5c3a]", bg: "bg-[#0d5c3a]/10" },
  { key: "partial", icon: CircleDot, color: "text-[#a06f1c]", bg: "bg-[#c58b2b]/15" },
  { key: "none", icon: XCircle, color: "text-destructive", bg: "bg-destructive/10" },
];

const Box = ({ label, value, tone = "", testId }) => (
  <div className={`rounded-lg border px-3 py-2 ${tone}`} data-testid={testId}><p className="text-[11px] text-muted-foreground leading-tight">{label}</p><p className="text-lg font-bold">{value}</p></div>
);

const Received = ({ payments, settings }) => {
  const { t } = useLang();
  if (!payments.length) return <span className="text-xs text-destructive">{t("fin.report.noPayments")}</span>;
  return <span className="text-xs leading-5 block min-w-[200px]">{payments.map((p, i) => <span key={i} className="block">{fmtDate(p.date)} · <b>{inr(p.amount)}</b> <span className="text-muted-foreground">({typeLabel(t, p.type, settings)})</span></span>)}</span>;
};

const Group = ({ g, rows, settings }) => {
  const { t } = useLang();
  const Icon = g.icon;
  return (
    <section className="mt-4 rounded-lg border overflow-hidden break-inside-avoid" data-testid={`house-report-group-${g.key}`}>
      <div className={`flex items-center justify-between gap-2 px-3 py-2 text-sm font-semibold ${g.bg}`}>
        <span className={`inline-flex items-center gap-2 ${g.color}`}><Icon className="h-4 w-4" />{t(`fin.report.${g.key}`)}<span className="rounded-full bg-white/80 px-2 text-xs text-foreground" data-testid={`house-report-count-${g.key}`}>{rows.length}</span></span>
        <span className="text-xs sm:text-sm">{t("fin.report.received")}: <b>{inr(rows.reduce((a, r) => a + r.paid, 0))}</b> · {t("fin.report.pending")}: <b>{inr(rows.reduce((a, r) => a + r.pending, 0))}</b></span>
      </div>
      {rows.length === 0 ? <p className="px-3 py-3 text-xs text-muted-foreground">{t("common.none")}</p> : (
        <Table>
          <TableHeader><TableRow>
            <TableHead className="w-8">#</TableHead><TableHead>{t("houses.houseNo")}</TableHead><TableHead>{t("houses.headName")}</TableHead>
            <TableHead>{t("fin.report.allHeads")}</TableHead><TableHead>{t("fin.report.receivedOn")}</TableHead>
            <TableHead className="text-right">{t("fin.due")}</TableHead><TableHead className="text-right">{t("fin.paid")}</TableHead><TableHead className="text-right">{t("fin.pending")}</TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {rows.map((r, i) => (
              <TableRow key={r.id} data-testid={`house-report-row-${r.house_no}`}>
                <TableCell className="text-xs text-muted-foreground align-top">{i + 1}</TableCell>
                <TableCell className="font-bold text-primary align-top">{r.house_no}</TableCell>
                <TableCell className="align-top">{r.head_name}{r.phone && <span className="block text-[10px] text-muted-foreground">{r.phone}</span>}</TableCell>
                <TableCell className="align-top text-xs leading-5">{r.heads.map((h) => <span key={h.type} className="block whitespace-nowrap">{typeLabel(t, h.type, settings)}: {inr(h.paid)} / {inr(h.due)}{h.pending > 0 && <span className="text-[#a06f1c]"> (−{inr(h.pending)})</span>}</span>)}</TableCell>
                <TableCell className="align-top max-w-[260px]"><Received payments={r.payments} settings={settings} /></TableCell>
                <TableCell className="text-right text-sm align-top">{inr(r.due)}</TableCell>
                <TableCell className="text-right text-sm align-top text-[#0d5c3a]">{inr(r.paid)}</TableCell>
                <TableCell className={`text-right font-semibold align-top ${r.pending > 0 ? "text-[#a06f1c]" : "text-[#0d5c3a]"}`}>{r.pending > 0 ? inr(r.pending) : "✔"}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </section>
  );
};

export const HouseReportBody = ({ data }) => {
  const { t, lang } = useLang();
  const { settings } = useAuth();
  return (
    <div data-testid="house-report">
      <div className="hidden print:block"><MahalHead settings={settings} lang={lang} /></div>
      <h2 className="font-bold text-center text-lg" data-testid="house-report-heading">{t("fin.report.byHouse")} — {data.year}</h2>
      <p className="text-center text-xs text-muted-foreground mb-3">{t("fin.report.asOn")}: {fmtDate(data.date)}</p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-1">
        <Box label={t("fin.report.due")} value={inr(data.totals.due)} testId="house-report-due" />
        <Box label={t("fin.report.received")} value={inr(data.totals.paid)} tone="border-[#0d5c3a]/40 bg-[#0d5c3a]/5" testId="house-report-paid" />
        <Box label={t("fin.report.pending")} value={inr(data.totals.pending)} tone="border-[#c58b2b]/40 bg-[#c58b2b]/5" testId="house-report-pending" />
        <Box label={`${t("fin.report.houses")} · ${t("fin.report.counts")}`} value={`${data.totals.houses} · ${data.counts.full}/${data.counts.partial}/${data.counts.none}`} testId="house-report-houses" />
      </div>
      {GROUPS.map((g) => <Group key={g.key} g={g} rows={data.groups[g.key]} settings={settings} />)}
    </div>
  );
};

export const useHouseReport = (open, enabled, year) => {
  const [data, setData] = useState(null);
  useEffect(() => { if (open && enabled) api.get("/finance/report/houses", { params: year ? { year } : {} }).then((r) => setData(r.data)).catch((e) => toast.error(apiError(e))); }, [open, enabled, year]);
  return data;
};
