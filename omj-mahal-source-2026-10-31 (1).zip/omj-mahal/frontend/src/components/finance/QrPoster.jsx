import { useLang } from "@/context/LanguageContext";
import { useQr } from "@/components/MemberCard";
import { fileUrl } from "@/lib/branding";
import { fmtPhone } from "@/lib/format";
import { MahalHead } from "@/components/print/Printables";

const upiAscii = (s) => (s || "").normalize("NFKD").replace(/[^A-Za-z0-9 .-]/g, "").trim().slice(0, 40);
export const genericUpiLink = (upiId, name) => (upiId && upiId.includes("@") ? `upi://pay?pa=${encodeURIComponent(upiId.trim())}&pn=${encodeURIComponent(upiAscii(name) || "Mahal")}&cu=INR` : "");

/* Big QR block reused by the member Pay page (card) and the printable A4 poster. */
export const QrBlock = ({ upiId, upiName, qrUrl, gpayPhone, bank, size = 220, poster = false }) => {
  const { t } = useLang();
  const qr = useQr(genericUpiLink(upiId, upiName), size);
  const img = upiId ? qr : fileUrl(qrUrl);
  if (!img) return null;
  return (
    <div className={poster ? "text-center" : "flex flex-col sm:flex-row items-center gap-5"} data-testid="qr-block">
      <img src={img} alt="UPI QR" style={{ width: size, height: size }} className="rounded-lg bg-white border border-[#e6dbc9] object-contain mx-auto" data-testid="qr-block-image" />
      <div className={`${poster ? "mt-4 text-base" : "text-sm"} space-y-1 ${poster ? "" : "text-center sm:text-left"}`}>
        {upiId ? <p className="font-mono font-bold text-primary text-lg" data-testid="qr-block-upi">{upiId}</p> : <p className="text-xs text-muted-foreground">{t("fin.qr.imageOnly")}</p>}
        {upiName && <p className="font-semibold">{upiName}</p>}
        {gpayPhone && <p>{t("fin.gpay.number")}: <b className="font-mono">{fmtPhone(gpayPhone)}</b></p>}
        {bank?.bank_account_no && <p className="text-xs text-muted-foreground">{t("fin.qr.bankAlso")}: {bank.bank_name && `${bank.bank_name} · `}A/c <b className="font-mono">{bank.bank_account_no}</b>{bank.bank_ifsc && <> · IFSC <b className="font-mono">{bank.bank_ifsc}</b></>}{bank.bank_account_name && <> · {bank.bank_account_name}</>}</p>}
      </div>
    </div>
  );
};

export const QrPoster = ({ settings }) => {
  const { t, lang } = useLang();
  return (
    <div className="border-[6px] border-double border-[#d4af37] p-8 bg-white text-[#1e2923] max-w-[720px] mx-auto min-h-[900px] flex flex-col" data-testid="qr-poster">
      <MahalHead settings={settings} lang={lang} />
      <h1 className="text-center text-4xl font-bold text-[#0d5c3a] mt-6">{t("fin.qr.posterTitle")}</h1>
      <p className="text-center text-sm text-[#8a6d1d] font-semibold uppercase tracking-[0.2em] mt-1">UPI · Google Pay · PhonePe · Paytm</p>
      <div className="flex-1 grid place-items-center py-8">
        <QrBlock upiId={settings?.upi_id} upiName={settings?.upi_name || settings?.short_name || settings?.mahal_name} qrUrl={settings?.upi_qr_url} gpayPhone={settings?.upi_phone} bank={settings} size={400} poster />
      </div>
      <p className="text-center text-sm text-gray-700 leading-6">{t("fin.qr.posterHint")}</p>
      <p className="text-center text-xs text-gray-500 mt-4">{t("fin.notice.footer")}</p>
    </div>
  );
};
