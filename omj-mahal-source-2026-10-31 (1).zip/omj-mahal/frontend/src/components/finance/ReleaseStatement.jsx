import { useState } from "react";
import { toast } from "sonner";
import { Send, ShieldCheck, Hourglass, CheckCircle2 } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { typeLabel } from "@/components/forms/CollectionPaymentForm";
import { api, apiError } from "@/lib/api";
import { fmtDate, inr } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

/* Member-side placeholder shown until the committee releases the verified statement. */
export const ReviewPendingCard = ({ compact = false }) => {
  const { t } = useLang();
  return (
    <div className={`rounded-xl border border-dashed border-[#c58b2b] bg-[#c58b2b]/10 ${compact ? "p-4" : "p-6"} flex gap-4 items-start`} data-testid="review-pending-card">
      <Hourglass className="h-8 w-8 text-[#a06f1c] shrink-0 animate-pulse" />
      <div>
        <p className="font-bold text-[#7a5210]">{t("fin.release.pending")}</p>
        <p className="text-sm text-muted-foreground mt-1">{t("fin.release.pendingBody")}</p>
      </div>
    </div>
  );
};

const fmtWhen = (iso) => (iso ? `${fmtDate(iso.slice(0, 10))} ${new Date(iso).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata" })}` : "");

/* Admin-side status badge + "send update" action for one house. */
export const ReleaseButton = ({ house, onDone }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(null);
  const [cols, setCols] = useState(null);
  const released = !!house.statement_released;
  const heads = Object.entries(cols || {}).filter(([, v]) => v && typeof v === "object" && v.kind !== "free" && (v.due > 0 || v.paid > 0));
  const openDialog = () => { setOpen(true); api.get(`/finance/house/${house.id}/summary`).then((r) => setCols(r.data.collections)).catch(() => setCols({})); };
  const send = async () => {
    setBusy(true);
    try { const { data } = await api.post(`/houses/${house.id}/release`); toast.success(t("fin.release.sentToast", { name: house.head_name })); setSent(data.message); setOpen(false); onDone?.(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };
  return (
    <>
      <div className="flex flex-wrap items-center gap-2" data-testid="release-status">
        <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold ${released ? "bg-[#0d5c3a]/10 text-[#0d5c3a]" : "bg-[#c58b2b]/15 text-[#a06f1c]"}`} data-testid="release-badge">
          {released ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Hourglass className="h-3.5 w-3.5" />}
          {released ? t("fin.release.sentAt", { date: fmtWhen(house.statement_released_at) }) : t("fin.release.notSent")}
        </span>
        <Button size="sm" variant={released ? "outline" : "default"} className="h-10" onClick={openDialog} data-testid="release-button"><Send className="h-4 w-4 mr-1" />{released ? t("fin.release.resend") : t("fin.release.send")}</Button>
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md" data-testid="release-confirm-dialog">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-primary" />{t("fin.release.confirmTitle", { name: house.head_name })}</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">{t("fin.release.confirmBody")}</p>
          {heads.length > 0 && (
            <table className="w-full text-sm" data-testid="release-preview-table"><tbody>
              {heads.map(([k, v]) => <tr key={k} className="border-b border-dashed"><td className="py-1">{typeLabel(t, k, settings)}</td><td className="py-1 text-right">{inr(v.paid)} / {inr(v.due)}</td><td className={`py-1 text-right font-semibold ${v.pending > 0 ? "text-[#a06f1c]" : "text-[#0d5c3a]"}`}>{v.pending > 0 ? `−${inr(v.pending)}` : "✔"}</td></tr>)}
            </tbody></table>
          )}
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="h-11" data-testid="release-cancel">{t("common.cancel")}</Button>
            <Button type="button" onClick={send} disabled={busy} className="h-11" data-testid="release-confirm"><Send className="h-4 w-4 mr-2" />{released ? t("fin.release.resend") : t("fin.release.send")}</Button>
          </div>
        </DialogContent>
      </Dialog>
      <Dialog open={!!sent} onOpenChange={(o) => !o && setSent(null)}>
        <DialogContent className="max-w-md" data-testid="release-sent-dialog">
          <DialogHeader><DialogTitle>{t("fin.release.sentMessage")}</DialogTitle></DialogHeader>
          <pre className="whitespace-pre-wrap text-sm font-sans rounded-lg bg-accent p-3 max-h-[50vh] overflow-y-auto" data-testid="release-sent-message">{sent}</pre>
        </DialogContent>
      </Dialog>
    </>
  );
};

/* Bulk release for the Collections page. */
export const ReleaseAllButton = ({ onDone }) => {
  const { t } = useLang();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const send = async () => {
    setBusy(true);
    try { const { data } = await api.post("/houses/release-all"); toast.success(t("fin.release.sentAllToast", { n: data.released })); setOpen(false); onDone?.(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };
  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)} className="h-11" data-testid="release-all-button"><Send className="h-4 w-4 mr-2" />{t("fin.release.sendAll")}</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md" data-testid="release-all-dialog">
          <DialogHeader><DialogTitle>{t("fin.release.sendAll")}</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">{t("fin.release.confirmAllBody")}</p>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="h-11" data-testid="release-all-cancel">{t("common.cancel")}</Button>
            <Button type="button" onClick={send} disabled={busy} className="h-11" data-testid="release-all-confirm">{t("fin.release.sendAll")}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
