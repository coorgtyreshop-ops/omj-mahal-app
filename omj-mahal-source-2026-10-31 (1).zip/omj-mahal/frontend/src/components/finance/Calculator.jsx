import { useState } from "react";
import { Calculator as CalcIcon, Delete } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const OPS = { "+": (a, b) => a + b, "−": (a, b) => a - b, "×": (a, b) => a * b, "÷": (a, b) => (b === 0 ? NaN : a / b) };
const KEYS = [["C", "⌫", "%", "÷"], ["7", "8", "9", "×"], ["4", "5", "6", "−"], ["1", "2", "3", "+"], ["00", "0", ".", "="]];
const NAMES = { "+": "add", "−": "sub", "×": "mul", "÷": "div", "=": "eq", ".": "dot", "%": "pct", C: "clear", "⌫": "back" };
const fmt = (n) => (Number.isFinite(n) ? Number(n.toFixed(2)).toLocaleString("en-IN") : "—");

export const evaluate = (expr) => {
  const tokens = expr.match(/\d*\.?\d+%?|[+−×÷]/g) || [];
  const vals = [], ops = [];
  tokens.forEach((tk) => { if (tk in OPS) { if (vals.length > ops.length) ops.push(tk); } else vals.push(tk.endsWith("%") ? parseFloat(tk) / 100 : parseFloat(tk)); });
  while (ops.length && ops.length >= vals.length) ops.pop();
  for (let i = 0; i < ops.length;) { if (ops[i] === "×" || ops[i] === "÷") { vals.splice(i, 2, OPS[ops[i]](vals[i], vals[i + 1])); ops.splice(i, 1); } else i++; }
  return ops.reduce((acc, op, i) => OPS[op](acc, vals[i + 1]), vals[0] ?? 0);
};

export const Calculator = ({ open, onOpenChange }) => {
  const { t } = useLang();
  const [expr, setExpr] = useState("");
  const [history, setHistory] = useState([]);
  const result = evaluate(expr);
  const lastNum = expr.split(/[+−×÷]/).pop();
  const press = (k) => {
    if (k === "C") return setExpr("");
    if (k === "⌫") return setExpr((e) => e.slice(0, -1));
    if (k === "=") { if (!expr || !Number.isFinite(result)) return; setHistory((h) => [{ expr, result }, ...h].slice(0, 5)); return setExpr(String(Number(result.toFixed(2)))); }
    if (k in OPS) return setExpr((e) => (!e ? (k === "−" ? k : e) : /[+−×÷]$/.test(e) ? e.slice(0, -1) + k : e + k));
    if (k === "." && (lastNum.includes(".") || lastNum.includes("%"))) return;
    if (k === "%" && (!lastNum || lastNum.includes("%"))) return;
    setExpr((e) => e + k);
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xs p-4" data-testid="calculator-dialog">
        <DialogHeader><DialogTitle className="flex items-center gap-2 text-base"><CalcIcon className="h-4 w-4" />{t("calc.title")}</DialogTitle></DialogHeader>
        <div className="rounded-lg bg-[#0b1f16] text-white px-4 py-3 text-right">
          <p className="min-h-[24px] break-all text-sm text-white/70 font-mono" data-testid="calc-expression">{expr || "0"}</p>
          <p className="text-3xl font-bold tabular-nums" data-testid="calc-result">{expr ? fmt(result) : "0"}</p>
        </div>
        <div className="grid grid-cols-4 gap-2" data-testid="calc-keys">
          {KEYS.flat().map((k) => (
            <button key={k} type="button" onClick={() => press(k)} data-testid={`calc-key-${NAMES[k] || k}`}
              className={`h-12 rounded-lg text-lg font-semibold transition-colors active:scale-95 ${k === "=" ? "bg-primary text-primary-foreground hover:bg-primary/90" : k in OPS || k === "%" ? "bg-[#d4af37]/20 text-[#8a6d1d] hover:bg-[#d4af37]/30" : k === "C" || k === "⌫" ? "bg-destructive/10 text-destructive hover:bg-destructive/20" : "bg-accent hover:bg-accent/70"}`}>
              {k === "⌫" ? <Delete className="h-5 w-5 mx-auto" /> : k}
            </button>
          ))}
        </div>
        {history.length > 0 && (
          <div className="text-xs" data-testid="calc-history">
            <p className="text-muted-foreground mb-1">{t("calc.history")}</p>
            {history.map((h, i) => <button key={i} type="button" onClick={() => setExpr(String(Number(h.result.toFixed(2))))} className="block w-full text-right font-mono hover:bg-accent rounded px-1" data-testid={`calc-history-${i}`}>{h.expr} = <b>{fmt(h.result)}</b></button>)}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export const CalculatorButton = () => {
  const { t } = useLang();
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)} className="h-11" data-testid="calculator-button"><CalcIcon className="h-4 w-4 mr-2" />{t("calc.open")}</Button>
      <Calculator open={open} onOpenChange={setOpen} />
    </>
  );
};
