import { useRef, useState } from "react";
import jsQR from "jsqr";
import { toast } from "sonner";
import { ImageUp, X } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { api, apiError } from "@/lib/api";
import { fileUrl } from "@/lib/branding";
import { Button } from "@/components/ui/button";

export const readQr = (file) => new Promise((resolve) => {
  const img = new Image();
  img.onload = () => {
    const scale = Math.min(1, 1200 / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
    const ctx = c.getContext("2d");
    ctx.drawImage(img, 0, 0, c.width, c.height);
    const d = ctx.getImageData(0, 0, c.width, c.height);
    URL.revokeObjectURL(img.src);
    resolve(jsQR(d.data, d.width, d.height, { inversionAttempts: "attemptBoth" })?.data || "");
  };
  img.onerror = () => resolve("");
  img.src = URL.createObjectURL(file);
});

export const parseUpi = (text) => {
  if (!/^upi:\/\//i.test(text || "")) return null;
  const q = new URLSearchParams(text.split("?")[1] || "");
  return { pa: (q.get("pa") || "").trim(), pn: (q.get("pn") || "").trim() };
};

export const UpiQrUpload = ({ form, setForm, highlight = false }) => {
  const { t } = useLang();
  const ref = useRef(null);
  const [busy, setBusy] = useState(false);
  const onFile = async (e) => {
    const file = e.target.files?.[0]; e.target.value = "";
    if (!file) return;
    setBusy(true);
    try {
      const upi = parseUpi(await readQr(file));
      if (upi?.pa) {
        setForm((f) => ({ ...f, upi_id: upi.pa, upi_name: f.upi_name || upi.pn, upi_app: "custom" }));
        toast.success(t("fin.qr.read", { upi: upi.pa }));
      } else {
        const fd = new FormData(); fd.append("file", file);
        const { data } = await api.post("/upload/upi-qr", fd, { headers: { "Content-Type": "multipart/form-data" } });
        setForm((f) => ({ ...f, upi_qr_url: data.url }));
        toast.info(t("fin.qr.imageSaved"));
      }
    } catch (err) { toast.error(apiError(err)); } finally { setBusy(false); }
  };
  return (
    <div id="upi-qr-upload" className={`rounded-lg border p-3 space-y-2 ${highlight ? "border-[#0d5c3a] bg-[#0d5c3a]/10 ring-2 ring-[#d4af37]" : "border-dashed border-[#0d5c3a]/40 bg-[#0d5c3a]/[0.04]"}`} data-testid="upi-qr-upload">
      <input ref={ref} type="file" accept="image/*" className="hidden" onChange={onFile} data-testid="upi-qr-file-input" />
      <div className="flex flex-wrap items-center gap-3">
        <Button type="button" variant={highlight ? "default" : "outline"} className="h-10" disabled={busy} onClick={() => ref.current?.click()} data-testid="upi-qr-upload-button"><ImageUp className="h-4 w-4 mr-2" />{busy ? t("fin.qr.uploading") : t("fin.qr.upload")}</Button>
        {form.upi_qr_url && (
          <div className="flex items-center gap-2" data-testid="upi-qr-image-preview">
            <img src={fileUrl(form.upi_qr_url)} alt="QR" className="h-14 w-14 rounded border bg-white object-contain" />
            <Button type="button" size="sm" variant="ghost" className="text-destructive h-9" onClick={() => setForm((f) => ({ ...f, upi_qr_url: "" }))} data-testid="upi-qr-remove-button"><X className="h-4 w-4 mr-1" />{t("fin.qr.remove")}</Button>
          </div>
        )}
      </div>
      <p className="text-xs text-muted-foreground">{t("fin.qr.hint")}</p>
    </div>
  );
};
