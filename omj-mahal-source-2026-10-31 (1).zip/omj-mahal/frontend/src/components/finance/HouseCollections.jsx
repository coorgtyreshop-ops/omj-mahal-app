import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Gavel, HandHeart } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, monthLabel } from "@/lib/format";
import { TextField, SelectField, SubmitRow } from "@/components/shared";
import { CollectionPaymentForm, allTypes, typeLabel } from "@/components/forms/CollectionPaymentForm";
import { OldBalanceDialog } from "@/components/finance/FinanceDialogs";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const MODES = ["cash", "upi", "bank"];

export const HouseCollections = ({ house, onChanged }) => {
  const { t, lang } = useLang();
  const { settings } = useAuth();
  const months = t("months");
  const [c, setC] = useState(null);
  const [payFor, setPayFor] = useState(null);
  const [itemHead, setItemHead] = useState(null);
  const load = () => api.get(`/finance/house/${house.id}/summary`).then((r) => setC(r.data.collections)).catch(() => {});
  useEffect(() => { load(); }, [house.id, house.payments?.length]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!c) return null;
  const rows = allTypes(settings).filter((k) => c[k] && ((c[k].due || 0) > 0 || (c[k].paid || 0) > 0 || ["varisankhya", "eid_fitr", "eid_adha", "nabidinam", "building"].includes(k)));
  const sum = (key) => rows.reduce((a, k) => a + (c[k][key] || 0), 0);
  const rateText = (k) => {
    const v = c[k];
    if (k === "donation") return t("fin.kinds.free");
    if (v.kind === "monthly") return `${inr(v.rate)} ${t("fin.perMonth")} · ${inr(v.yearly_total)} ${t("fin.perYear")}`;
    if (v.kind === "yearly") return `${inr(v.rate)} ${t("fin.perYear")}`;
    return `${t("fin.target")} ${inr(v.rate)}`;
  };
  return (
    <section className="mb-8" data-testid="house-collections">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div>
          <h2 className="text-lg font-bold">{t("houses.collections")}</h2>
          {c.members?.sub > 0 && <p className="text-xs text-[#a06f1c]" data-testid="house-units">{t("fin.units", { n: c.members.sub, u: c.members.units })}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={() => setItemHead("auction")} className="h-10" data-testid="house-auction-button"><Gavel className="h-4 w-4 mr-1" />{t("fin.types.auction")}</Button>
          <Button size="sm" variant="outline" onClick={() => setItemHead("pledge")} className="h-10" data-testid="house-pledge-button"><HandHeart className="h-4 w-4 mr-1" />{t("fin.pledge.button")}</Button>
          <Button size="sm" onClick={() => setPayFor("varisankhya")} className="h-10" data-testid="house-add-payment-button"><Plus className="h-4 w-4 mr-1" />{t("fin.addPayment")}</Button>
        </div>
      </div>
      <div className="rounded-xl border border-[#e6dbc9] bg-card shadow-sm overflow-hidden">
        <Table data-testid="house-collections-table">
          <TableHeader><TableRow className="bg-accent/60">
            <TableHead>{t("fin.type")}</TableHead><TableHead className="text-right">{t("fin.due")}</TableHead><TableHead className="text-right">{t("fin.paid")}</TableHead><TableHead className="text-right">{t("fin.pending")}</TableHead><TableHead className="w-10" />
          </TableRow></TableHeader>
          <TableBody>
            {rows.map((k) => { const v = c[k]; return (
              <TableRow key={k} data-testid={`house-col-${k}`}>
                <TableCell><p className="font-semibold">{typeLabel(t, k, settings)}</p><p className="text-[11px] text-muted-foreground">{rateText(k)}{v.pending_periods?.length > 0 && <> · {t("fin.pendingPeriods")}: {v.pending_periods.map((p) => (k === "varisankhya" ? monthLabel(p, months, true) : p)).join(", ")}</>}</p></TableCell>
                <TableCell className="text-right">{k === "donation" ? "—" : inr(v.due)}</TableCell>
                <TableCell className="text-right text-[#0d5c3a] font-semibold" data-testid={`house-col-paid-${k}`}>{inr(v.paid)}</TableCell>
                <TableCell className={`text-right font-bold ${v.pending > 0 ? "text-[#a06f1c]" : "text-[#0d5c3a]"}`} data-testid={`house-col-pending-${k}`}>{k === "donation" ? "—" : v.pending > 0 ? inr(v.pending) : "✔"}</TableCell>
                <TableCell><Button size="icon" variant="ghost" onClick={() => setPayFor(k)} title={t("fin.addPayment")} data-testid={`house-pay-${k}`}><Plus className="h-4 w-4" /></Button></TableCell>
              </TableRow>
            ); })}
            <TableRow className="bg-accent/40 font-bold" data-testid="house-col-total">
              <TableCell>{t("common.total")}</TableCell><TableCell className="text-right">{inr(sum("due"))}</TableCell><TableCell className="text-right text-[#0d5c3a]">{inr(sum("paid"))}</TableCell><TableCell className="text-right text-[#a06f1c]" data-testid="house-col-total-pending">{inr(c.total_pending)}</TableCell><TableCell />
            </TableRow>
          </TableBody>
        </Table>
      </div>
      <OldBalanceDialog row={itemHead ? { ...house, head: itemHead } : null} onOpenChange={(o) => !o && setItemHead(null)} onSaved={() => { load(); onChanged?.(); }} />
      <CollectionPaymentForm open={!!payFor} onOpenChange={(o) => !o && setPayFor(null)} houses={[house]} presetHouse={house.id} presetType={payFor || "varisankhya"} onSaved={() => { load(); onChanged?.(); }} />
    </section>
  );
};

export const EditPaymentDialog = ({ payment, onOpenChange, onSaved }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (payment) setForm({ amount: payment.amount, date: payment.date, mode: payment.mode || "cash", type: payment.type || "varisankhya", note: payment.note || "" }); }, [payment]);
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try { await api.put(`/payments/${payment.id}`, { ...form, amount: Number(form.amount) }); toast.success(t("fin.paymentUpdated")); onOpenChange(false); onSaved(); }
    catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={!!payment} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="edit-payment-dialog">
        <DialogHeader><DialogTitle>{t("fin.editPayment")} · {payment?.receipt_no}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <SelectField label={t("fin.type")} value={form.type || "varisankhya"} onChange={(v) => setForm((f) => ({ ...f, type: v }))} testId="edit-payment-type" options={allTypes(settings).map((k) => ({ value: k, label: typeLabel(t, k, settings) }))} />
          <div className="grid grid-cols-2 gap-4">
            <TextField label={t("common.amount")} type="number" min="1" value={form.amount ?? ""} onChange={(v) => setForm((f) => ({ ...f, amount: v }))} required testId="edit-payment-amount" />
            <TextField label={t("common.date")} type="date" value={form.date || ""} onChange={(v) => setForm((f) => ({ ...f, date: v }))} testId="edit-payment-date" />
          </div>
          <SelectField label={t("common.mode")} value={form.mode || "cash"} onChange={(v) => setForm((f) => ({ ...f, mode: v }))} testId="edit-payment-mode" options={MODES.map((m) => ({ value: m, label: t(`paymentModes.${m}`) }))} />
          <TextField label={t("common.note")} value={form.note || ""} onChange={(v) => setForm((f) => ({ ...f, note: v }))} testId="edit-payment-note" />
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} label={t("common.save")} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export const PaymentRowActions = ({ p, onEdit, onDelete }) => (
  <>
    <Button size="icon" variant="ghost" onClick={() => onEdit(p)} data-testid={`edit-payment-${p.receipt_no}`}><Pencil className="h-4 w-4" /></Button>
    <Button size="icon" variant="ghost" className="text-destructive" onClick={() => onDelete(p)} data-testid={`delete-payment-${p.receipt_no}`}><Trash2 className="h-4 w-4" /></Button>
  </>
);
