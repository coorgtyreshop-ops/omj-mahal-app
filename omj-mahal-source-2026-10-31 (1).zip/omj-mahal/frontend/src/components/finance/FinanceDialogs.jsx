import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Printer, Trash2 } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { api, apiError } from "@/lib/api";
import { inr, todayStr, fmtDate } from "@/lib/format";
import { TextField, SelectField, SubmitRow } from "@/components/shared";
import { MahalHead } from "@/components/print/Printables";
import { typeLabel } from "@/components/forms/CollectionPaymentForm";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const OB_TYPES = ["varisankhya", "eid_fitr", "eid_adha", "nabidinam", "building", "special", "donation", "other"];

export const OldBalanceDialog = ({ row, onOpenChange, onSaved }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const head = ["auction", "pledge"].includes(row?.head) ? row.head : "old_balance";
  const ep = head === "old_balance" ? "old-balance" : head;
  const isItem = head !== "old_balance";
  const empty = { amount: "", note: "", date: todayStr(), type: "varisankhya" };
  const [form, setForm] = useState(empty);
  const [items, setItems] = useState([]);
  const [paid, setPaid] = useState(0);
  const [loading, setLoading] = useState(false);
  const load = () => row && api.get(`/finance/house/${row.id}/summary`).then((r) => { const ob = r.data.collections[head] || {}; setItems(ob.items || []); setPaid(ob.paid || 0); });
  useEffect(() => { setForm(empty); setItems([]); load(); }, [row]); // eslint-disable-line react-hooks/exhaustive-deps
  const label = (k) => (k === "other" ? t("fin.oldBalance.other") : typeLabel(t, k, settings));
  const tx = (k) => t(`fin.${head === "old_balance" ? "oldBalance" : head}.${k}`);
  const submit = async (e) => {
    e.preventDefault(); setLoading(true);
    try { await api.post(`/finance/house/${row.id}/${ep}`, { amount: Number(form.amount || 0), note: form.note, date: form.date, type: isItem ? head : form.type }); toast.success(tx("saved")); setForm(empty); load(); onSaved(); }
    catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  const remove = async (id) => {
    try { await api.delete(`/finance/house/${row.id}/${ep}/${id}`); load(); onSaved(); } catch (err) { toast.error(apiError(err)); }
  };
  const total = items.reduce((a, i) => a + i.amount, 0);
  return (
    <Dialog open={!!row} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto" data-testid={isItem ? `${head}-dialog` : "old-balance-dialog"}>
        <DialogHeader><DialogTitle>{tx("title")}</DialogTitle></DialogHeader>
        {row && <p className="text-sm -mt-2"><span className="font-bold text-primary">{row.house_no}</span> · {row.head_name}</p>}
        {items.length > 0 && (
          <div className="rounded-lg border divide-y" data-testid="old-balance-items">
            {items.map((i) => (
              <div key={i.id} className="flex items-center gap-2 px-3 py-2 text-sm" data-testid={`old-balance-item-${i.id}`}>
                <div className="min-w-0 flex-1"><p className="font-medium">{isItem ? (i.note || t(`fin.types.${head}`)) : label(i.type)} · <span className="font-mono">{inr(i.amount)}</span></p><p className="text-xs text-muted-foreground truncate">{isItem ? "" : i.note}{i.date ? `${isItem ? "" : " · "}${fmtDate(i.date)}` : ""}</p></div>
                <Button size="icon" variant="ghost" className="text-destructive" onClick={() => remove(i.id)} data-testid={`old-balance-delete-${i.id}`}><Trash2 className="h-4 w-4" /></Button>
              </div>
            ))}
            <div className="flex justify-between px-3 py-2 text-sm bg-accent/50"><span>{t("common.total")}: <b>{inr(total)}</b> · {t("fin.paid")}: <b>{inr(paid)}</b></span><span>{t("fin.pending")}: <b className="text-[#a06f1c]" data-testid="old-balance-pending">{inr(Math.max(0, total - paid))}</b></span></div>
          </div>
        )}
        <form onSubmit={submit} className="space-y-4">
          <p className="text-xs text-muted-foreground">{tx("hint")}</p>
          <div className="grid grid-cols-2 gap-4">
            {head === "old_balance" && <SelectField label={t("fin.oldBalance.type")} value={form.type} onChange={(v) => setForm((f) => ({ ...f, type: v }))} testId="old-balance-type-select" options={OB_TYPES.map((k) => ({ value: k, label: label(k) }))} />}
            <TextField label={tx("amount")} type="number" min="1" value={form.amount} onChange={(v) => setForm((f) => ({ ...f, amount: v }))} required testId="old-balance-amount-input" className={isItem ? "col-span-2" : ""} />
          </div>
          <TextField label={tx("note")} value={form.note} onChange={(v) => setForm((f) => ({ ...f, note: v }))} placeholder={tx("notePh")} testId="old-balance-note-input" />
          <TextField label={tx("date")} type="date" value={form.date} onChange={(v) => setForm((f) => ({ ...f, date: v }))} testId="old-balance-date-input" />
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} label={tx("add")} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export const BulkOldBalanceDialog = ({ open, onOpenChange, rows, onSaved }) => {
  const { t } = useLang();
  const { settings } = useAuth();
  const [amounts, setAmounts] = useState({});
  const [type, setType] = useState("varisankhya");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(todayStr());
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (open) { setAmounts({}); setQ(""); } }, [open]);
  const label = (k) => (k === "other" ? t("fin.oldBalance.other") : typeLabel(t, k, settings));
  const list = (rows || []).filter((r) => !q || `${r.house_no} ${r.head_name}`.toLowerCase().includes(q.toLowerCase()));
  const filled = Object.entries(amounts).filter(([, v]) => Number(v) > 0);
  const total = filled.reduce((a, [, v]) => a + Number(v), 0);
  const submit = async (e) => {
    e.preventDefault();
    if (!filled.length) return toast.error(t("fin.oldBalance.amount"));
    setLoading(true);
    try {
      const { data } = await api.post("/finance/old-balance/bulk", { rows: filled.map(([house_id, v]) => ({ house_id, amount: Number(v), type, note, date })) });
      toast.success(t("fin.oldBalance.bulkSaved", { n: data.added })); onSaved(); onOpenChange(false);
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto" data-testid="bulk-old-balance-dialog">
        <DialogHeader><DialogTitle>{t("fin.oldBalance.bulkTitle")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <p className="text-xs text-muted-foreground">{t("fin.oldBalance.bulkHint")}</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <SelectField label={t("fin.oldBalance.type")} value={type} onChange={setType} testId="bulk-ob-type-select" options={OB_TYPES.map((k) => ({ value: k, label: label(k) }))} />
            <TextField label={t("fin.oldBalance.note")} value={note} onChange={setNote} placeholder={t("fin.oldBalance.notePh")} testId="bulk-ob-note-input" />
            <TextField label={t("fin.oldBalance.date")} type="date" value={date} onChange={setDate} testId="bulk-ob-date-input" />
          </div>
          <TextField label={t("common.search")} value={q} onChange={setQ} placeholder={t("houses.searchPh")} testId="bulk-ob-search" />
          <div className="rounded-lg border divide-y max-h-[45vh] overflow-y-auto" data-testid="bulk-ob-rows">
            {list.map((r) => (
              <div key={r.id} className="flex items-center gap-3 px-3 py-2" data-testid={`bulk-ob-row-${r.house_no}`}>
                <div className="min-w-0 flex-1"><p className="text-sm font-semibold truncate"><span className="text-primary">{r.house_no}</span> · {r.head_name}</p>{r.old_balance > 0 && <p className="text-xs text-muted-foreground">{t("fin.oldBalance.current")}: {inr(r.old_balance)}</p>}</div>
                <input type="number" min="0" inputMode="decimal" value={amounts[r.id] ?? ""} onChange={(e) => setAmounts((a) => ({ ...a, [r.id]: e.target.value }))} placeholder="₹" className="h-10 w-28 rounded-md border border-input bg-background px-2 text-right font-mono text-sm" data-testid={`bulk-ob-amount-${r.house_no}`} data-kbd="off" />
              </div>
            ))}
            {list.length === 0 && <p className="p-4 text-sm text-muted-foreground text-center">{t("common.noData")}</p>}
          </div>
          <div className="flex items-center justify-between text-sm"><span>{filled.length} {t("houses.title")}</span><span>{t("common.total")}: <b data-testid="bulk-ob-total">{inr(total)}</b></span></div>
          <SubmitRow loading={loading} onCancel={() => onOpenChange(false)} label={t("fin.oldBalance.bulkSave")} />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export const StatementDialog = ({ open, onOpenChange }) => {
  const { t, lang } = useLang();
  const { settings } = useAuth();
  const thisYear = new Date().getFullYear();
  const [year, setYear] = useState(String(thisYear));
  const [data, setData] = useState(null);
  useEffect(() => { if (open) api.get("/finance/statement", { params: { year } }).then((r) => setData(r.data)); }, [open, year]);
  const print = () => {
    const node = document.getElementById("statement-print");
    const w = window.open("", "_blank", "width=900,height=700");
    w.document.write(`<html><head><title>${t("fin.statement.title")} ${year}</title><style>body{font-family:sans-serif;padding:16px;color:#1e2923}table{width:100%;border-collapse:collapse;font-size:12px}th,td{border:1px solid #ccc;padding:4px 6px;text-align:right}th:first-child,td:first-child{text-align:left}th{background:#f3efe6}</style></head><body>${node.innerHTML}</body></html>`);
    w.document.close(); w.focus(); setTimeout(() => w.print(), 300);
  };
  const types = data?.types || [];
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[92vh] overflow-y-auto" data-testid="statement-dialog">
        <DialogHeader><DialogTitle>{t("fin.statement.title")}</DialogTitle></DialogHeader>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <SelectField label={t("fin.statement.year")} value={year} onChange={setYear} testId="statement-year-select" options={Array.from({ length: 6 }, (_, i) => String(thisYear - i)).map((y) => ({ value: y, label: y }))} />
          <Button variant="outline" onClick={print} className="h-11" data-testid="statement-print-button"><Printer className="h-4 w-4 mr-2" />{t("fin.statement.print")}</Button>
        </div>
        <p className="text-xs text-muted-foreground">{t("fin.statement.hint")}</p>
        <div id="statement-print">
          <div className="hidden print:block"><MahalHead settings={settings} lang={lang} /></div>
          <h2 className="font-bold text-center my-2">{t("fin.statement.title")} — {year} · {settings?.short_name || settings?.mahal_name} · {fmtDate(todayStr())}</h2>
          <div className="overflow-x-auto">
            <Table data-testid="statement-table">
              <TableHeader><TableRow className="bg-accent/60">
                <TableHead>{t("houses.houseNo")}</TableHead>
                {types.map((k) => <TableHead key={k} className="text-right">{typeLabel(t, k, settings)}</TableHead>)}
                <TableHead className="text-right">{t("fin.types.donation")}</TableHead>
                <TableHead className="text-right font-bold">{t("fin.statement.totalPaid")}</TableHead>
                <TableHead className="text-right font-bold text-[#a06f1c]">{t("fin.statement.pendingNow")}</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {(data?.rows || []).map((r) => (
                  <TableRow key={r.id} data-testid={`statement-row-${r.house_no}`}>
                    <TableCell><span className="font-bold text-primary">{r.house_no}</span> <span className="text-xs text-muted-foreground">{r.head_name}</span></TableCell>
                    {types.map((k) => <TableCell key={k} className="text-right text-sm">{r.paid[k] ? inr(r.paid[k]) : "—"}{r.pending[k] > 0 && <span className="block text-[10px] text-[#a06f1c]">{t("fin.pending")} {inr(r.pending[k])}</span>}</TableCell>)}
                    <TableCell className="text-right text-sm">{r.paid.donation ? inr(r.paid.donation) : "—"}</TableCell>
                    <TableCell className="text-right font-bold">{inr(r.total_paid)}</TableCell>
                    <TableCell className="text-right font-bold text-[#a06f1c]">{inr(r.total_pending)}</TableCell>
                  </TableRow>
                ))}
                {data && (
                  <TableRow className="bg-accent/40 font-bold" data-testid="statement-totals-row">
                    <TableCell>{t("common.total")}</TableCell>
                    {types.map((k) => <TableCell key={k} className="text-right">{inr(data.totals[k]?.paid || 0)}</TableCell>)}
                    <TableCell className="text-right">{inr(data.totals.donation?.paid || 0)}</TableCell>
                    <TableCell className="text-right">{inr(data.rows.reduce((a, r) => a + r.total_paid, 0))}</TableCell>
                    <TableCell className="text-right text-[#a06f1c]">{inr(data.rows.reduce((a, r) => a + r.total_pending, 0))}</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
