import { useEffect, useRef, useState } from "react";
import jsQR from "jsqr";
import { Camera, CameraOff } from "lucide-react";
import { useLang } from "@/context/LanguageContext";

// Card QR carries ".../verify/OMJ-0001"; also accept a bare Member ID / house number typed or scanned.
export const memberNoFrom = (text) => {
  const m = /\/verify\/([A-Za-z0-9-]+)/i.exec(text || "");
  if (m) return decodeURIComponent(m[1]).toUpperCase();
  const raw = (text || "").trim().toUpperCase();
  return /^[A-Z0-9]{0,8}-?\d{1,6}$/.test(raw) ? raw : "";
};

export const QrScanner = ({ active, onResult }) => {
  const { t } = useLang();
  const videoRef = useRef(null);
  const [error, setError] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!active) return undefined;
    let stream, raf, stopped = false, last = 0;
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    let detector = null;
    try { detector = "BarcodeDetector" in window ? new window.BarcodeDetector({ formats: ["qr_code"] }) : null; } catch { detector = null; }
    const tick = async (ts) => {
      if (stopped) return;
      const v = videoRef.current;
      if (v && v.readyState >= 2 && v.videoWidth > 0 && ts - last > 180) {
        last = ts;
        let text = "";
        try {
          if (detector) {
            const codes = await detector.detect(v);
            text = codes[0]?.rawValue || "";
          } else {
            const scale = Math.min(1, 640 / v.videoWidth);
            canvas.width = Math.round(v.videoWidth * scale); canvas.height = Math.round(v.videoHeight * scale);
            ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
            const d = ctx.getImageData(0, 0, canvas.width, canvas.height);
            text = jsQR(d.data, d.width, d.height, { inversionAttempts: "dontInvert" })?.data || "";
          }
        } catch { detector = null; }
        if (text && !stopped) { stopped = true; onResult(text); return; }
      }
      raf = requestAnimationFrame(tick);
    };
    setError(""); setReady(false);
    if (!navigator.mediaDevices?.getUserMedia) { setError("unsupported"); return undefined; }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false })
      .then((s) => {
        if (stopped) { s.getTracks().forEach((tr) => tr.stop()); return; }
        stream = s;
        const v = videoRef.current;
        if (v) { v.srcObject = s; v.play().catch(() => {}); }
        setReady(true);
        raf = requestAnimationFrame(tick);
      })
      .catch((e) => setError(e?.name || "camera"));
    return () => { stopped = true; if (raf) cancelAnimationFrame(raf); stream?.getTracks().forEach((tr) => tr.stop()); };
  }, [active, onResult]);

  if (!active) return null;
  return (
    <div className="relative rounded-2xl overflow-hidden bg-black aspect-[4/3] sm:aspect-video" data-testid="qr-scanner">
      <video ref={videoRef} playsInline muted autoPlay className="absolute inset-0 h-full w-full object-cover" data-testid="qr-scanner-video" />
      {!error && (
        <div className="absolute inset-0 grid place-items-center pointer-events-none">
          <div className="relative h-52 w-52 sm:h-60 sm:w-60">
            <span className="absolute left-0 top-0 h-8 w-8 border-l-4 border-t-4 border-[#d4af37] rounded-tl-lg" />
            <span className="absolute right-0 top-0 h-8 w-8 border-r-4 border-t-4 border-[#d4af37] rounded-tr-lg" />
            <span className="absolute left-0 bottom-0 h-8 w-8 border-l-4 border-b-4 border-[#d4af37] rounded-bl-lg" />
            <span className="absolute right-0 bottom-0 h-8 w-8 border-r-4 border-b-4 border-[#d4af37] rounded-br-lg" />
            <span className="scan-line absolute left-2 right-2 h-0.5 bg-[#d4af37]/90 shadow-[0_0_12px_#d4af37]" />
          </div>
          <p className="absolute bottom-3 inset-x-0 text-center text-white text-sm font-medium drop-shadow" data-testid="qr-scanner-hint">{ready ? t("scan.cameraHint") : t("scan.starting")}</p>
        </div>
      )}
      {error && (
        <div className="absolute inset-0 grid place-items-center bg-[#1e2923] text-white p-6 text-center" data-testid="qr-scanner-error">
          <div className="space-y-2">
            <CameraOff className="h-10 w-10 mx-auto text-[#d4af37]" />
            <p className="text-sm">{t("scan.cameraError")}</p>
          </div>
        </div>
      )}
      {!error && !ready && <Camera className="absolute top-3 right-3 h-5 w-5 text-white/70 animate-pulse" />}
    </div>
  );
};
