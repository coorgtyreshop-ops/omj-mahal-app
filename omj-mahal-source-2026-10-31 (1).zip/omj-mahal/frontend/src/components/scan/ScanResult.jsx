import { Link } from "react-router-dom";
import { CheckCircle2, AlertCircle, Phone, Plus, ScanLine, RefreshCw, Home, Users, ShieldCheck, Lock } from "lucide-react";
import { useLang } from "@/context/LanguageContext";
import { useAuth } from "@/context/AuthContext";
import { inr, monthLabel, fmtDate, fmtPhone } from "@/lib/format";
import { Photo, TypeBadge } from "@/components/MemberCard";
import { allTypes, typeLabel } from "@/components/forms/CollectionPaymentForm";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const Identity = ({ member, house, since, children }) => {
  const { t } = useLang();
  return (
    <div className="flex items-start gap-4" data-testid="scan-identity">
      <Photo src={member.photo_url} name={member.name} className="h-24 w-20 shrink-0" />
      <div className="min-w-0 flex-1">
        <p className="text-xl font-bold leading-tight" data-testid="scan-name">{member.name}</p>
        <p className="font-mono text-sm tracking-wide text-muted-foreground" data-testid="scan-member-no">{member.member_no}</p>
        <div className="mt-1 flex flex-wrap items-center gap-2 text-sm">
          <TypeBadge type={member.member_type} />
          <span className="text-muted-foreground">{t("card.houseNo")}: <b className="text-foreground" data-testid="scan-house-no">{house.house_no}</b> · {house.head_name}{house.ward ? ` · ${house.ward}` : ""}</span>
        </div>
        <div className="mt-1 flex flex-wrap gap-x-3 text-xs text-muted-foreground">
          {since && <span>{t("card.since")} {since}</span>}
          {(member.phone || house.phone) && <a href={`tel:${member.phone || house.phone}`} className="inline-flex items-center gap-1 text-primary font-semibold" data-testid="scan-phone"><Phone className="h-3 w-3" />{fmtPhone(member.phone || house.phone)}</a>}
        </div>
        {children}
      </div>
    </div>
  );
};

const HeadRow = ({ k, v, label, periodLabel }) => {
  const { t } = useLang();
  const pending = v.pending > 0;
  const n = v.pending_periods?.length || 0;
  return (
    <div className={cn("rounded-xl border p-3", pending ? "border-[#c58b2b]/50 bg-[#c58b2b]/[0.06]" : "border-[#0d5c3a]/25 bg-[#0d5c3a]/[0.05]")} data-testid={`scan-head-${k}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-bold">{label}</p>
          {k !== "donation" && <p className="text-xs text-muted-foreground">{t("fin.due")}: {inr(v.due)} · {t("fin.paid")}: <span className="text-[#0d5c3a] font-semibold">{inr(v.paid)}</span></p>}
          {k === "donation" && <p className="text-xs text-muted-foreground">{t("fin.paid")}: <span className="text-[#0d5c3a] font-semibold">{inr(v.paid)}</span></p>}
          {v.note && <p className="text-xs text-muted-foreground">{v.note}</p>}
        </div>
        <div className="text-right shrink-0">
          {k === "donation" ? null : pending ? (
            <><p className="text-[11px] text-[#a06f1c]">{t("fin.pending")}</p><p className="text-lg font-bold text-[#a06f1c]" data-testid={`scan-pending-${k}`}>{inr(v.pending)}</p></>
          ) : (
            <p className="inline-flex items-center gap-1 text-sm font-bold text-[#0d5c3a]" data-testid={`scan-cleared-${k}`}><CheckCircle2 className="h-4 w-4" />{t("scan.cleared")}</p>
          )}
        </div>
      </div>
      {pending && n > 0 && (
        <p className="mt-2 text-sm font-semibold text-[#a06f1c] flex flex-wrap items-center gap-x-2" data-testid={`scan-from-${k}`}>
          <AlertCircle className="h-4 w-4" />{t("scan.from", { p: periodLabel(k, v.pending_periods[0]) })}
          <span className="text-xs font-medium text-muted-foreground">· {t(v.kind === "monthly" ? "scan.months" : "scan.years", { n })}{n > 1 && ` (${periodLabel(k, v.pending_periods[0])} → ${periodLabel(k, v.pending_periods[n - 1])})`}</span>
        </p>
      )}
      {!pending && v.advance > 0 && <p className="mt-1 text-xs text-[#0d5c3a]">{t("scan.advance")}: {inr(v.advance)}</p>}
    </div>
  );
};

export const ScanResult = ({ data, loading, onRecord, onRescan, onScope, onRefresh }) => {
  const { t, months } = useLang();
  const { settings, isAdmin } = useAuth();
  const { member: m, house: h, collections: c } = data;
  const heads = allTypes(settings).filter((k) => c[k] && (k === "donation" ? c[k].paid > 0 : (c[k].due > 0 || c[k].paid > 0)));
  const pendingHeads = heads.filter((k) => c[k].pending > 0);
  const clear = c.total_pending <= 0;
  const periodLabel = (k, p) => (k === "varisankhya" ? monthLabel(p, months, true) : p);
  const isSub = m.member_type === "sub";
  return (
    <div className="space-y-5" data-testid="scan-result">
      <div className="rounded-2xl border border-[#e6dbc9] bg-card p-4 sm:p-5 shadow-sm">
        <Identity member={m} house={h} since={data.member_since}>
          {isSub && (
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
              <span className="rounded-full bg-primary/10 text-primary px-2 py-0.5 font-semibold" data-testid="scan-scope">{data.scope === "member" ? t("scan.ownShare") : t("scan.houseTotal")}</span>
              <button type="button" className="text-primary font-semibold hover:underline" onClick={() => onScope(data.scope === "member" ? "house" : "auto")} data-testid="scan-scope-toggle">{data.scope === "member" ? t("scan.showHouse") : t("scan.showOwn")}</button>
            </div>
          )}
          {!isSub && c.members?.sub > 0 && <p className="mt-2 text-xs text-[#a06f1c] flex items-center gap-1" data-testid="scan-units"><Users className="h-3 w-3" />{t("fin.units", { n: c.members.sub, u: c.members.units })}</p>}
        </Identity>
      </div>

      <div className={cn("rounded-2xl p-5 text-white shadow-lg", clear ? "bg-[#0d5c3a]" : "bg-[#a06f1c]")} data-testid="scan-status-banner">
        {clear ? (
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-10 w-10 shrink-0" />
            <div><p className="text-xl font-bold" data-testid="scan-all-clear">{t("scan.allClear")}</p>{data.last_paid && <p className="text-sm opacity-90">{t("scan.lastPaid")}: {fmtDate(data.last_paid.date)} · {inr(data.last_paid.amount)} · {data.last_paid.receipt_no}</p>}</div>
          </div>
        ) : (
          <div>
            <p className="text-sm opacity-90 flex items-center gap-2"><AlertCircle className="h-4 w-4" />{t("scan.balance")} · {t("scan.headsPending", { n: pendingHeads.length })}</p>
            <p className="text-4xl font-bold mt-1" data-testid="scan-total-pending">{inr(c.total_pending)}</p>
            {data.last_paid ? <p className="text-xs mt-2 opacity-90">{t("scan.lastPaid")}: {fmtDate(data.last_paid.date)} · {inr(data.last_paid.amount)}</p> : <p className="text-xs mt-2 opacity-90">{t("scan.noPayments")}</p>}
          </div>
        )}
        <div className="mt-3 flex flex-wrap gap-2">
          {data.can_record && <Button onClick={() => onRecord(pendingHeads[0] || "varisankhya")} className="h-11 bg-white text-[#1e2923] hover:bg-white/90" data-testid="scan-record-button"><Plus className="h-4 w-4 mr-1" />{t("scan.record")}</Button>}
          <Button variant="outline" onClick={onRescan} className="h-11 border-white/60 bg-transparent text-white hover:bg-white/10 hover:text-white" data-testid="scan-again-button"><ScanLine className="h-4 w-4 mr-1" />{t("scan.again")}</Button>
          <Button variant="ghost" onClick={onRefresh} disabled={loading} className="h-11 text-white hover:bg-white/10 hover:text-white" data-testid="scan-refresh-button"><RefreshCw className={cn("h-4 w-4 mr-1", loading && "animate-spin")} />{t("scan.refresh")}</Button>
          {isAdmin && <Button asChild variant="ghost" className="h-11 text-white hover:bg-white/10 hover:text-white" data-testid="scan-open-house"><Link to={`/houses/${h.id}`}><Home className="h-4 w-4 mr-1" />{t("scan.openHouse")}</Link></Button>}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-2"><h2 className="font-bold">{t("houses.collections")}</h2><span className="text-[11px] text-muted-foreground" data-testid="scan-live">{t("scan.live")}</span></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3" data-testid="scan-heads">
          {heads.map((k) => <HeadRow key={k} k={k} v={c[k]} label={typeLabel(t, k, settings)} periodLabel={periodLabel} />)}
        </div>
      </div>

      <div>
        <h2 className="font-bold mb-2">{t("scan.payments")}</h2>
        {data.payments.length === 0 ? <p className="text-sm text-muted-foreground rounded-xl border border-dashed p-4 text-center" data-testid="scan-payments-empty">{t("scan.noPayments")}</p> : (
          <ul className="rounded-xl border border-[#e6dbc9] bg-card divide-y" data-testid="scan-payments">
            {data.payments.slice(0, 12).map((p) => (
              <li key={p.id} className="px-4 py-2.5 flex items-center justify-between gap-3 text-sm" data-testid={`scan-payment-${p.receipt_no}`}>
                <div className="min-w-0">
                  <p className="font-medium">{typeLabel(t, p.type, settings)}{p.months?.length > 0 && <span className="text-xs text-muted-foreground"> · {p.months.map((x) => monthLabel(x, months, true)).join(", ")}</span>}{p.years?.length > 0 && <span className="text-xs text-muted-foreground"> · {p.years.join(", ")}</span>}</p>
                  <p className="text-xs text-muted-foreground">{fmtDate(p.date)} · {p.receipt_no}{p.mode && ` · ${t(`paymentModes.${p.mode}`)}`}{p.member_name && ` · ${t("scan.paidBy")} ${p.member_name}`}</p>
                </div>
                <span className="font-bold text-[#0d5c3a] shrink-0">{inr(p.amount)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export const IdentityOnly = ({ identity, memberNo, message, onRescan }) => {
  const { t } = useLang();
  return (
    <div className="space-y-4" data-testid="scan-identity-only">
      {identity ? (
        <div className="rounded-2xl border border-[#e6dbc9] bg-card p-4 sm:p-5 shadow-sm">
          <Identity member={identity.member} house={{ house_no: identity.house_no, head_name: identity.head_name, ward: identity.ward }} since={identity.member_since}>
            <p className="mt-2 inline-flex items-center gap-1 rounded-full bg-primary/10 text-primary px-3 py-1 text-xs font-bold"><ShieldCheck className="h-4 w-4" />{t("card.verified", { name: identity.settings?.short_name || identity.settings?.mahal_name || "" })}</p>
          </Identity>
        </div>
      ) : (
        <div className="rounded-2xl border border-destructive/40 bg-destructive/5 p-5 text-center" data-testid="scan-not-found">
          <p className="font-bold">{t("scan.notFound")}</p>
          <p className="font-mono text-sm text-muted-foreground">{memberNo}</p>
        </div>
      )}
      {message && <p className="rounded-xl bg-accent px-4 py-3 text-sm flex items-center gap-2" data-testid="scan-message"><Lock className="h-4 w-4 text-muted-foreground shrink-0" />{message}</p>}
      <Button variant="outline" onClick={onRescan} className="h-11" data-testid="scan-again-button"><ScanLine className="h-4 w-4 mr-1" />{t("scan.again")}</Button>
    </div>
  );
};
