import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useLang } from "@/context/LanguageContext";
import { applyBranding } from "@/lib/branding";
import { readCache, writeCache, clearCache } from "@/lib/cache";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  // Open instantly with the last-known session/settings; verify with the server in the background.
  const [user, setUser] = useState(() => (localStorage.getItem("mahal_token") ? readCache("me") : null));
  const [settings, setSettings] = useState(() => readCache("settings"));
  const { setLang } = useLang();

  const loadSettings = useCallback(async () => {
    try {
      const { data } = await api.get("/settings");
      setSettings(data);
      writeCache("settings", data);
      applyBranding(data);
    } catch {
      setSettings((s) => s || {});
    }
  }, []);

  useEffect(() => {
    const cached = readCache("settings");
    if (cached) applyBranding(cached);
    loadSettings();
    if (!localStorage.getItem("mahal_token")) {
      setUser(false);
      return;
    }
    api
      .get("/auth/me")
      .then(({ data }) => {
        setUser(data);
        writeCache("me", data);
        if (data.language && !localStorage.getItem("mahal_lang_manual")) setLang(data.language);
      })
      .catch((err) => {
        if (err?.response) {
          // token rejected → really logged out
          localStorage.removeItem("mahal_token");
          clearCache();
          setUser(false);
        } else {
          // offline / server waking up → keep the cached session if we have one
          setUser((u) => u || false);
        }
      });
  }, [loadSettings, setLang]);

  const setSession = useCallback(
    (data) => {
      localStorage.setItem("mahal_token", data.token);
      localStorage.removeItem("mahal_lang_manual");
      setUser(data.user);
      writeCache("me", data.user);
      if (data.user.language) setLang(data.user.language);
      return data.user;
    },
    [setLang]
  );

  const login = useCallback(
    async (loginId, password) => {
      const { data } = await api.post("/auth/login", { login_id: loginId, password });
      return setSession(data);
    },
    [setSession]
  );

  const logout = useCallback(async () => {
    try {
      await api.post("/auth/logout");
    } catch {}
    localStorage.removeItem("mahal_token");
    clearCache();
    setUser(false);
  }, []);

  const value = useMemo(
    () => ({ user, setUser, login, setSession, logout, settings, refreshSettings: loadSettings, isAdmin: user?.role === "admin", canFinance: user?.role === "admin" || (!!settings?.finance_manager_id && settings.finance_manager_id === user?.id) }),
    [user, login, setSession, logout, settings, loadSettings]
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
