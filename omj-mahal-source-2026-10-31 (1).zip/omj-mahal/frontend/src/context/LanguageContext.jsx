import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { translations, LANGS } from "@/i18n/translations";

const LanguageContext = createContext(null);

const getPath = (obj, path) => path.split(".").reduce((o, k) => (o == null ? undefined : o[k]), obj);

export function LanguageProvider({ children }) {
  const [lang, setLangState] = useState(() => {
    const saved = localStorage.getItem("mahal_lang");
    return LANGS.includes(saved) ? saved : "en";
  });

  useEffect(() => {
    document.documentElement.lang = lang;
    localStorage.setItem("mahal_lang", lang);
  }, [lang]);

  const setLang = useCallback((l) => {
    if (LANGS.includes(l)) setLangState(l);
  }, []);

  const t = useCallback(
    (key, vars) => {
      let val = getPath(translations[lang], key) ?? getPath(translations.en, key) ?? key;
      if (typeof val === "string" && vars) {
        val = val.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? "");
      }
      return val;
    },
    [lang]
  );

  const value = useMemo(() => ({ lang, setLang, t, months: translations[lang].months }), [lang, setLang, t]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export const useLang = () => useContext(LanguageContext);
