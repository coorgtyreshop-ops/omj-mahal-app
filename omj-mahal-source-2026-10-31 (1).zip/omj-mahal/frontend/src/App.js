import { BrowserRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { LanguageProvider } from "@/context/LanguageContext";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import AppShell from "@/components/layout/AppShell";
import Accounts from "@/pages/Accounts";
import AccountBook from "@/pages/AccountBook";
import Posters from "@/pages/Posters";
import Chat from "@/pages/Chat";
import Suggestions from "@/pages/Suggestions";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Houses from "@/pages/Houses";
import HouseDetail from "@/pages/HouseDetail";
import Members from "@/pages/Members";
import Subscriptions from "@/pages/Subscriptions";
import Donations from "@/pages/Donations";
import Expenses from "@/pages/Expenses";
import Reports from "@/pages/Reports";
import Announcements from "@/pages/Announcements";
import Committee from "@/pages/Committee";
import Certificates from "@/pages/Certificates";
import Settings from "@/pages/Settings";
import Users from "@/pages/Users";
import Profile from "@/pages/Profile";
import Messages from "@/pages/Messages";
import Help from "@/pages/Help";
import Guest from "@/pages/Guest";
import Verify from "@/pages/Verify";
import MyCards from "@/pages/MyCards";
import Collections from "@/pages/Collections";
import Pay from "@/pages/Pay";
import CalendarPage from "@/pages/Calendar";
import Scan from "@/pages/Scan";

const Splash = () => (
  <div className="min-h-screen grid place-items-center islamic-pattern">
    <div className="h-12 w-12 rounded-xl bg-[#d4af37] animate-pulse" />
  </div>
);

const Protected = ({ children, admin, finance }) => {
  const { user, isAdmin, canFinance } = useAuth();
  const location = useLocation();
  if (user === null) return <Splash />;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (admin && !isAdmin) return <Navigate to="/" replace />;
  if (finance && !canFinance) return <Navigate to="/" replace />;
  return children;
};

const PublicOnly = ({ children }) => {
  const { user } = useAuth();
  if (user === null) return <Splash />;
  if (user) return <Navigate to="/" replace />;
  return children;
};

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<PublicOnly><Login /></PublicOnly>} />
            <Route path="/guide" element={<Help standalone />} />
            <Route path="/guest" element={<PublicOnly><Guest /></PublicOnly>} />
            <Route path="/verify/:memberNo" element={<Verify />} />
            <Route element={<Protected><AppShell /></Protected>}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/houses" element={<Protected admin><Houses /></Protected>} />
              <Route path="/houses/:id" element={<Protected admin><HouseDetail /></Protected>} />
              <Route path="/my-house" element={<HouseDetail />} />
              <Route path="/cards" element={<MyCards />} />
              <Route path="/members" element={<Protected admin><Members /></Protected>} />
              <Route path="/subscriptions" element={<Subscriptions />} />
              <Route path="/collections" element={<Protected finance><Collections /></Protected>} />
              <Route path="/pay" element={<Pay />} />
              <Route path="/scan" element={<Scan />} />
              <Route path="/calendar" element={<CalendarPage />} />
              <Route path="/donations" element={<Donations />} />
              <Route path="/expenses" element={<Protected admin><Expenses /></Protected>} />
              <Route path="/reports" element={<Protected admin><Reports /></Protected>} />
              <Route path="/announcements" element={<Announcements />} />
              <Route path="/committee" element={<Committee />} />
              <Route path="/certificates" element={<Protected admin><Certificates /></Protected>} />
              <Route path="/settings" element={<Protected admin><Settings /></Protected>} />
              <Route path="/messages" element={<Protected admin><Messages /></Protected>} />
              <Route path="/users" element={<Protected admin><Users /></Protected>} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/accounts" element={<Accounts />} />
              <Route path="/accounts/:id" element={<AccountBook />} />
              <Route path="/posters" element={<Posters />} />
              <Route path="/group" element={<Chat />} />
              <Route path="/suggestions" element={<Suggestions />} />
              <Route path="/help" element={<Help />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
        <Toaster position="top-center" richColors />
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;
