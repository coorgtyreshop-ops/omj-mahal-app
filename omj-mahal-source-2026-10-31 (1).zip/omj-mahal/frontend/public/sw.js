const CACHE = "omj-mahal-v5";
const API_CACHE = "omj-api-v5";
const SHELL = ["/", "/offline.html", "/logos/logo1.png", "/logos/logo2.png", "/logos/logo3.png", "/logos/logo4.png", "/logos/logo5.png", "/logos/logo6.png", "/icons/icon5-192.png", "/icons/icon1-192.png", "/icons/icon2-192.png", "/icons/icon3-192.png"];
const CACHEABLE_API = ["/api/dashboard", "/api/announcements", "/api/committee", "/api/settings", "/api/houses", "/api/payments", "/api/funds", "/api/public", "/api/manifest.json"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => ![CACHE, API_CACHE].includes(k)).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

// Drop hashed bundles that the new index.html no longer references (keeps the cache from growing across releases).
const pruneBundles = async (cache, html) => {
  for (const req of await cache.keys()) {
    const p = new URL(req.url).pathname;
    if (p.startsWith("/static/") && !html.includes(p)) await cache.delete(req);
  }
};

// Shell (index.html): serve what we have instantly, fetch the latest behind the scenes for the next open — like a native app.
const refreshShell = (req) => fetch(req).then(async (res) => {
  if (res.ok) {
    const cache = await caches.open(CACHE);
    const copy = res.clone();
    const html = await res.clone().text();
    const old = await cache.match("/");
    await cache.put("/", copy);
    if (old && (await old.text()) !== html) await pruneBundles(cache, html);
  }
  return res;
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  if (url.pathname.startsWith("/api/")) {
    if (!CACHEABLE_API.some((p) => url.pathname.startsWith(p))) return;
    event.respondWith(
      fetch(req)
        .then((res) => {
          if (res.ok) caches.open(API_CACHE).then((c) => c.put(req, res.clone()));
          return res;
        })
        .catch(() => caches.match(req).then((hit) => hit || new Response(JSON.stringify({ detail: "offline" }), { status: 503, headers: { "Content-Type": "application/json" } })))
    );
    return;
  }

  if (req.mode === "navigate") {
    event.respondWith(
      caches.match("/").then((hit) => {
        const network = refreshShell(req).catch(() => hit || caches.match("/offline.html"));
        if (hit) { event.waitUntil(network.catch(() => {})); return hit; }
        return network;
      })
    );
    return;
  }

  const isBundle = url.origin === self.location.origin && url.pathname.startsWith("/static/");
  if (isBundle) {
    // Build output is content-hashed: once cached it never changes → instant from cache.
    event.respondWith(
      caches.match(req).then((hit) => hit || fetch(req).then((res) => {
        if (res.ok) caches.open(CACHE).then((c) => c.put(req, res.clone()));
        return res;
      }))
    );
    return;
  }

  const isCode = req.destination === "script" || req.destination === "style" || /\.(js|css|json|map)$/.test(url.pathname);
  if (url.origin === self.location.origin || url.hostname.includes("fonts.g") || isCode) {
    // everything else: instant from cache, refreshed in the background
    event.respondWith(
      caches.match(req).then((hit) => {
        const network = fetch(req).then((res) => {
          if (res.ok) caches.open(CACHE).then((c) => c.put(req, res.clone()));
          return res;
        }).catch(() => hit);
        if (hit) { event.waitUntil(network.catch(() => {})); return hit; }
        return network;
      })
    );
  }
});
